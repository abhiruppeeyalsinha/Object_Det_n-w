// ============================================================================
// Name        : Struct.h
// Author      : Bhavesh
// ============================================================================


#ifndef STRUCT_H_
#define STRUCT_H_

// ---------- Header Inclusion ----------
#include "Includes.h"


// Device & Cmd IDs
#define  C4I_ID				0x07
#define  AI_ID				0x55
#define  SaveVideoCmd		0x86
#define  AISwitchCmd		0x87
#define  TgtDataCmd			0x88
#define  VideoDataCmd		0x89


// ---------- Macros ----------
#define  FindMin(A, B)	((A) < (B) ? (A) : (B))
#define  FindMax(A, B)	((A) >= (B) ? (A) : (B))


#pragma pack(1)


// ---------- Video Data Structure ----------
struct _VideoData_
{
	Mat VideoFrame;
	UInt8_t VideoType;
	float FrameFlag;
	steady_clock :: time_point FrameTime;

	~_VideoData_(void)
	{
		VideoFrame.release();
	}
};


// ---------- AI Target Data Structure ----------
struct _AIData_
{
    UInt8_t ClassID;
    Point CenterPoint;
    Rect BoundingBox;
    float Confidance;
    UInt16_t TrackID;
};


// Tracking Data Structure
struct _DSTrack_
{
    UInt32_t TrackID;
    Point2f Center;
    Rect BBox;
    vector<float> Feature;
    KalmanFilter kf;
    Int32_t Missed;
    Int32_t Hits;
    _DSTrack_() : TrackID(0), Center(0, 0), BBox(), Feature(), kf(4, 2), Missed(0), Hits(0)
    {

    }
};



// ---------- C4I Target Data Structure ----------
union _AIResp_
{
	UInt8_t Buffer[10];

	struct _AIRespStruct_
	{
		UInt8_t Header[3];
		UInt8_t DataLen;
		UInt8_t AckByte;
		UInt8_t CheckSum;
	} AIRespStruct;
};


struct _TargetData_
{
	UInt8_t ClassID;
	UInt16_t TrackID;
	Int16_t Ny;
	Int16_t Nz;
	UInt16_t Width;
	UInt16_t Height;
	UInt8_t Confidance;
};


union _TgtData_
{
	UInt8_t Buffer[60500];

	struct _TgtDataStruct_
	{
		UInt8_t Header[3];
		UInt16_t DataLen;
		UInt8_t AIType;
		UInt16_t TargetLimit;
		UInt8_t SaveStatus;
		UInt16_t TargetCnt;
		struct _TargetData_ TgtData[5000];
		UInt8_t CheckSum;
	} TgtDataStruct;
};


// ---------- C4I AI Command Structure ----------
union _AICmd_
{
	UInt8_t Buffer[10];

	struct _AICmdStruct_
	{
		UInt8_t Header[3];
		UInt8_t DataLen;
		UInt8_t AIType;
		UInt16_t TargetLimit;
		UInt8_t CheckSum;
	} AICmdStruct;

	struct _SaveCmdStruct_
	{
		UInt8_t Header[3];
		UInt8_t DataLen;
		UInt8_t Stat;
		UInt8_t CheckSum;
	} SaveCmdStruct;
};


struct Config_S
{
    int gaussianKernel = 13;
    double saliencyThreshold = 5.0;

    int mogHistory = 500;
    double mogVarThreshold = 12.0;
    bool mogDetectShadows = false;

    int morphKernel = 3;
    int openIterations = 1;
    int closeIterations = 5;

    int targetscale=35;
    int noisefloorkernal=3;
    double saliencystdmultiplier=4.0;
    double saliencyminthreshold=5.0;
    double minArea = 5.0;
    double maxArea = 5000.0;

    double minWidth = 1.0;
    double maxWidth = 500.0;

    double minHeight = 1.0;
    double maxHeight = 500.0;

    double minAspect = 0.25;
    double maxAspect = 10.0;

    double mincir=0.35;
    double minSolidity = 0.50;

    double maxAssociationDistance = 50.0;

    int maxMissedFrames = 13;
    int confirmationFrames = 5;

    double velocitySmoothing = 0.6;

    double minConfidenceToDisplay = 0.50;
    bool useMotionUnion = false;
    bool detectHotTarget = true;
    bool showWindows = true;
};


struct Detection
{
    Rect bbox;
    Point2f centroid;
    double area;
    double aspectRatio;
    double thermalScore;
    double motionScore;
};


struct Centertrack
{
	int index;
	double distance;
	UInt8_t Type; // Added for Template Matching distinction (0: AI, 1: TM)
	UInt8_t ClassID;
	Point CenterPoint;
	Rect BoundingBox;
	float Confidance;
	UInt16_t TrackID;
};
extern Config_S cfg;


#pragma pack()

#endif /* STRUCT_H_ */




