// ============================================================================
// Name        : ClassicalDetector2.h
// Author      : Bhavesh
// ============================================================================

#ifndef CLASSICALDETECTOR2_H_
#define CLASSICALDETECTOR2_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"


// ---------- Other Flag Variables ----------
extern bool SaveVideo;
extern bool AutoSaveVideo;

// ---------- AI Flag Variables ----------
extern bool BirdPlaneDataFlag;

// ---------- Config Parameters ----------
extern UInt8_t AI_Type;
extern UInt16_t TargetLimit;

// ---------- Camera Variables ----------
extern Size IR_Size;
extern Size EO_Size;

// ---------- Data Structures & Buffers ----------
extern union _TgtData_ TgtData;
extern struct _TargetData_ TargetData;


// ---------- Class Declaration ----------
class Track
{
public:
	Int32_t id;
	KalmanFilter kf;

	Point2f predicted;
	Point2f position;
	Point2f previousPosition;
	Point2f velocity;

	Rect bbox;

	Int32_t age;
	Int32_t hits;
	Int32_t missed;

	bool confirmed;
	double confidence;

	Track(Int32_t trackID, Point2f initialPoint, Rect initialBox);
	Point2f predict();
	void update( const Point2f &measurement, const Rect &newBox, double dt, double smoothing);
	void markMissed();
};


// ---------- Class Declaration ----------
class ClassicalDetector2
{
private:
	// ---------- Private Variables ----------
	struct _ClassicalDetConfig_
	{
		float DOG_THRESHOLD = -1.0f;
		float DOG_STDDEV_FACTOR = 1.25f;
		float MIN_DOG_THRESHOLD = 8.0f;
		float MAX_DOG_THRESHOLD = 48.0f;
		double MIN_AREA_FRAC = 0.00002;
		double MAX_AREA_FRAC = 0.35;
		double MIN_EXTENT = 0.05;
		double MIN_ASPECT = 0.10;
		double MAX_ASPECT = 10.0;
		double MAX_VERTICAL_POSITION = 0.92;
		Int32_t MIN_CONTOUR_AREA = 6;
	};


	struct _ClassicalTrack_
	{
		UInt32_t TrackID = 0;
		UInt8_t ClassID = 0;
		Rect BoundingBox;
		Point2f Center;
		Mat TemplateImage;
		Int32_t Missed = 0;
		Int32_t Hits = 0;
		float TemplateScore = 0.0f;
		bool TemplateMatched = false;
	};

	struct _StationaryTrack_
	{
		Rect LastBox;
		vector<Rect> History;
		Int32_t MissedFrames = 0;
		bool Stationary = false;
	};

	struct _RepeatedCoordinateTrack_
	{
		Int32_t X = 0;
		Int32_t Y = 0;
		Int32_t ConsecutiveFrames = 0;
		long long LastSeenFrame = 0;
		bool SeenThisFrame = false;
	};

	_ClassicalDetConfig_ Config;
	vector<struct _AIData_> TargetDataArr;
	vector<struct _ClassicalTrack_> TrackArr;
	vector<struct _StationaryTrack_> StationaryTrackArr;
	vector<struct _RepeatedCoordinateTrack_> RepeatedCoordinateTrackArr;
	vector<struct _AIData_> LastCentreTargetArr;

	Int32_t StaticCoordFrames;
	UInt32_t NextTrackID;

	Int32_t MaxMissedFrames;
	Int32_t StationaryStableFrames;
	Int32_t StationarySizeTolerance;
	Int32_t StationaryMaxMissedFrames;
	Int32_t CentreHoldMaxFrames;
	Int32_t CentreMissedFrames;
	long long RepeatedFrameNumber;
	double StationaryPositionTolerance;
	double StationaryMatchDistance;

	string VideoLabel;
	float LabelScale;

	Config_S cfg;
	double previousTime;
	vector<Track> tracks;
	Ptr<BackgroundSubtractorMOG2> mog;


	// ---------- Private Functions ----------
	// Adaptive DoG Response Threshold
	float adaptiveResponseThreshold(const Mat &Response);

	// Create Positive/Negative DoG Blob Mask
	Mat blobMask(const Mat &Response, float Threshold);

	// Clean DoG Mask
	void cleanupMask(Mat &Mask);

	// Centre Prior For Candidate Ranking
	double priorWeight(const Rect &Box, Size ImageSize);

	// Rect IOU
	float rectIOU(const Rect &A, const Rect &B);

	// Centre Distance
	float centerDistance(const Rect &A, const Rect &B);

	// Rect Centre
	Point2d centerOf(const Rect &Box);

	// Stationary Track
	bool isStationaryTrack(const vector<Rect> &History);

	// NMS
	vector<struct _AIData_> applyNMS(vector<struct _AIData_> &Detections, float IOUThreshold);

	// Hungarian Solve
	void hungarianSolve(const vector<vector<float>> &Cost, vector<Int32_t> &Assignment);

	// Filter Stationary Targets
	vector<struct _AIData_> filterStationaryTargets(const vector<struct _AIData_> &Detections);

	// Filter Exact Repeated Coordinates
	vector<struct _AIData_> filterRepeatedCoordinates(const vector<struct _AIData_> &Detections);

	// Select N Targets Nearest To Frame Centre
	void selectNearestCentreTargets(Size FrameSize);

	// Hold Previous Centre Targets For Short Detector Misses
	bool appendCentreHoldTargets(Size FrameSize);

	// Draw Corner Style Bounding Box
	void drawCornerBox(Mat &VideoFrame, const Rect &Box, const Scalar &Color, Int32_t Thickness, Int32_t CornerLength);

	// Draw Boxes And Fill Target Data
	void drawBoxes(Mat &VideoFrame);


public:
	// ---------- Public Functions ----------
	// Constructor
	ClassicalDetector2(string Label);

	// Destructor
	~ClassicalDetector2(void);

	// Classical Detector Function
	void Detector(Mat &VideoFrame);
};


#endif /* CLASSICALDETECTOR2_H_ */




