// ============================================================================
// Name        : SysConfig.h
// Author      : Bhavesh
// ============================================================================


#ifndef SYSCONFIG_H_
#define SYSCONFIG_H_


// ---------- Header Inclusion ----------
#include "Includes.h"


// ---------- Macros ----------
#define ConfigFile "Config.json"


// ---------- Other Flag Variables ----------
extern bool SaveVideo;
extern bool SingleVideo;
extern bool DisplayFrame;
extern bool AutoSaveVideo;

// ---------- AI Flag Variables ----------
extern bool BirdPlaneDataFlag;

// ---------- Thread Flag Variables ----------
extern bool C4ICmdRecvFlag;
extern bool C4IDataSendFlag;
extern bool IRVideoReadFlag;
extern bool EOVideoReadFlag;
extern bool ProcessVideoFlag;

// ---------- Config Parameters ----------
extern UInt8_t AI_Type;
extern UInt16_t TargetLimit;

extern string C4I_IPAddr;
extern Int32_t C4I_Port;
extern Int32_t AI_Port;

// ---------- Camera Variables ----------
extern string IR_VideoSrc;
extern string EO_VideoSrc;

// ---------- AI Parameters ----------
extern string IR_Track_Model;
extern string EO_Track_Model;
extern string IR_Detect_Model;
extern string EO_Detect_Model;

// ---------- Data Path ----------
extern string InpPath;
extern string LoadPath;
extern string SavePath;
extern string ParentPath;


// ---------- Function Declaration ----------
// CRC16 function
UInt16_t crc16(UInt8_t *Data, UInt64_t Len);

// Calculate software checksum
UInt16_t getSwCheckSum(string Path);

// Get TimeStamp
string getTimeStamp(void);

// Check Serial Port is available or not
bool releaseUDPPort(Int32_t Port);

// Create Path
string createPath(string Path);

// Get Path
string getPath(UInt8_t typ);

// CheckSum Calculation
UInt8_t calCheckSum(UInt8_t *inpBuff, UInt32_t Length);

// Validate IP Address
bool validateIP(const Int8_t *Addr);

// Read File
string readFile(string path);

// Load Config Data
void loadConfigData(void);

// Check Flags function
void checkFlags(Int32_t argc, Int8_t *argv[]);


#endif /* SYSCONFIG_H_ */




