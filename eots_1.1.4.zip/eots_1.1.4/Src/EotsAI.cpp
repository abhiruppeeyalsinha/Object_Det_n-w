// ============================================================================
// Name        : EotsAI.cpp
// Author      : Bhavesh
// Version     : V1.1.4
// Released On : 08 Sep 2026
// ============================================================================

// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"

#include "Seeker.h"
#include "IRVideoAI.h"
#include "EOVideoAI.h"
#include "C4IInterface.h"
#include "ClassicalDetector.h"
#include "ClassicalDetector2.h"

// ---------- Other Flag Variables ----------
bool SaveVideo = false;
bool SingleVideo = false;
bool DisplayFrame = false;
bool AutoSaveVideo = false;

// ---------- AI Flag Variables ----------
bool BirdPlaneDataFlag = false;

// ---------- Thread Flag Variables ----------
bool C4ICmdRecvFlag = true;
bool C4IDataSendFlag = true;
bool IRVideoReadFlag = true;
bool EOVideoReadFlag = true;
bool ProcessVideoFlag = true;

// ---------- Software Details ----------
UInt16_t SW_CheckSum = 0U;
string SW_Health = "08/09/26 V01.01.04"; // DD/MM/YY V01.00.00

// ---------- Config Parameters ----------
UInt8_t AI_Type = 1U;
UInt16_t TargetLimit = 1U;

string C4I_IPAddr = "0.0.0.0";
Int32_t C4I_Port;
Int32_t AI_Port;

// ---------- Camera Variables ----------
Size IR_Size(640, 512);
Size EO_Size(1920, 1080);

UInt16_t VideoFPS = 25U;
UInt16_t FrameDelay = 1000 / VideoFPS;

string IR_VideoSrc;
string EO_VideoSrc;

// ---------- AI Parameters ----------
string IR_Track_Model;
string EO_Track_Model;
string IR_Detect_Model;
string EO_Detect_Model;

string EO_ClassName[3] = {"Bird", "Drone", "Plane"};
string IR_ClassName[4] = {"Bird", "Fixed", "Hexa", "Plane"};

// ---------- Data Path ----------
string InpPath = "";
string LoadPath = "";
string SavePath = "";
string ParentPath = "";

// ---------- Data Structures & Buffers ----------
union _AICmd_ AICmd;
union _AIResp_ AIResp;
union _TgtData_ TgtData;
struct _TargetData_ TargetData;
struct _VideoData_ C4IVideoData, CameraData;

// ---------- Thread Variables ----------
pthread_t RecvC4ICmdThread;
pthread_t SendC4IDataThread;
pthread_t IRVideoReadThread;
pthread_t EOVideoReadThread;

// ---------- Shared Data Mutex ----------
pthread_mutex_t CameraDataMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t C4IVideoDataMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t TgtDataMutex = PTHREAD_MUTEX_INITIALIZER;

// ---------- Class Objects ----------
Seeker *SeekerObj;
IRVideoAI *IRVideoAIObj;
EOVideoAI *EOVideoAIObj;
C4IInterface *C4IInterfaceObj;
ClassicalDetector *IRDetectorObj;
ClassicalDetector *EODetectorObj;
ClassicalDetector2 *IRDetector2Obj;
ClassicalDetector2 *EODetector2Obj;

// ---------- signal Handler ----------
void signalHandler(Int32_t Signal);

// ---------- Close Process ----------
void closeProcess(void);

// ---------- Main Function ----------
int main(Int32_t argc, Int8_t *argv[])
{
	struct timespec ts;
	struct _VideoData_ VideoData;

	high_resolution_clock::time_point timCntStart, timCntEnd;
	duration<double, milli> timDuration;

	ts.tv_sec = 0;		   // seconds
	ts.tv_nsec = 1000 * 5; // 5 microseconds

	// Register force stop for CNTL+C
	signal(SIGINT, signalHandler);

	SW_CheckSum = getSwCheckSum(getPath(0));

	cout << "Software Details  : " << SW_Health << endl;
	cout << "Software Checksum : 0x" << hex << uppercase << SW_CheckSum << dec << endl;

	// Set load path for the files
	LoadPath = getPath(1);

	// Load Config file
	loadConfigData();

	// Check user flags
	checkFlags(argc, argv);

	// Set Saving path for results
	SavePath = getPath(2);

	// Create Class Objects
	SeekerObj = new Seeker();
	IRVideoAIObj = new IRVideoAI();
	EOVideoAIObj = new EOVideoAI();
	C4IInterfaceObj = new C4IInterface();
	IRDetectorObj = new ClassicalDetector("IR C_Dog1");
	EODetectorObj = new ClassicalDetector("EO C_Dog1");
	IRDetector2Obj = new ClassicalDetector2("IR C_Dog2");
	EODetector2Obj = new ClassicalDetector2("EO C_Dog2");

	if (SingleVideo == false || AI_Type == 1 || AI_Type == 3 || AI_Type == 5)
	{
		// Create & Start IR Video Reading thread
		if (pthread_create(&IRVideoReadThread, NULL, SeekerObj->readIRFramesThread, SeekerObj))
		{
			perror("pthread_create");

			delete SeekerObj;
			delete IRVideoAIObj;
			delete EOVideoAIObj;
			delete C4IInterfaceObj;
			delete IRDetectorObj;
			delete EODetectorObj;
			delete IRDetector2Obj;
			delete EODetector2Obj;

			exit(1);
		}
	}

	if (SingleVideo == false || AI_Type == 2 || AI_Type == 4 || AI_Type == 6)
	{
		// Create & Start EO Video Reading thread
		if (pthread_create(&EOVideoReadThread, NULL, SeekerObj->readEOFramesThread, SeekerObj))
		{
			perror("pthread_create");

			delete SeekerObj;
			delete IRVideoAIObj;
			delete EOVideoAIObj;
			delete C4IInterfaceObj;
			delete IRDetectorObj;
			delete EODetectorObj;
			delete IRDetector2Obj;
			delete EODetector2Obj;

			exit(1);
		}
	}

	if (SingleVideo == false)
	{
		// Create & Start C4I Command Receive thread
		if (pthread_create(&RecvC4ICmdThread, NULL, C4IInterfaceObj->recvCmdC4IThread, C4IInterfaceObj))
		{
			perror("pthread_create");

			delete SeekerObj;
			delete IRVideoAIObj;
			delete EOVideoAIObj;
			delete C4IInterfaceObj;
			delete IRDetectorObj;
			delete EODetectorObj;
			delete IRDetector2Obj;
			delete EODetector2Obj;

			exit(1);
		}
	}

	// Create & Start C4I Data Send thread
	if (pthread_create(&SendC4IDataThread, NULL, C4IInterfaceObj->sendDataC4IThread, C4IInterfaceObj))
	{
		perror("pthread_create");

		delete SeekerObj;
		delete IRVideoAIObj;
		delete EOVideoAIObj;
		delete C4IInterfaceObj;
		delete IRDetectorObj;
		delete EODetectorObj;
		delete IRDetector2Obj;
		delete EODetector2Obj;

		exit(1);
	}

	cout << "Video Processing Started..." << endl
		 << endl;

	while (ProcessVideoFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		// ============================================================
		// STEP 1: Safely obtain camera frame
		// ============================================================

		pthread_mutex_lock(&CameraDataMutex);

		if (CameraData.FrameFlag == false)
		{
			pthread_mutex_unlock(&CameraDataMutex);
			continue;
		}

		// Copy non-image metadata
		// VideoData = CameraData;

		.
		if (!CameraData.VideoFrame.empty())
		{
			VideoData.VideoFrame = CameraData.VideoFrame.clone();
		}
		else
		{
			// VideoData.VideoFrame.release();
			;
		}

		CameraData.FrameFlag = false;

		pthread_mutex_unlock(&CameraDataMutex);

		// ============================================================
		// STEP 2: Validate frame
		// ============================================================

		if (VideoData.VideoFrame.empty() ||
			VideoData.VideoFrame.data == nullptr ||
			VideoData.VideoFrame.cols <= 0 ||
			VideoData.VideoFrame.rows <= 0)
		{
			cerr << "[MAIN] Invalid/Empty camera frame."
				 << " Size="
				 << VideoData.VideoFrame.cols
				 << "x"
				 << VideoData.VideoFrame.rows
				 << endl
				 << flush;

			continue;
		}

		// ============================================================
		// STEP 3: Start processing timer
		// ============================================================

		timCntStart = high_resolution_clock::now();

		// ============================================================
		// STEP 4: Object Detection
		// ============================================================

		try
		{
			if (AI_Type == 1U)
			{
				IRVideoAIObj->Run_enqueueV2(
					VideoData.VideoFrame);
			}
			else if (AI_Type == 2U)
			{
				EOVideoAIObj->Run_enqueueV2(
					VideoData.VideoFrame);
			}
			else if (AI_Type == 3U)
			{
				IRDetectorObj->Detector(
					VideoData.VideoFrame);
			}
			else if (AI_Type == 4U)
			{
				EODetectorObj->Detector(
					VideoData.VideoFrame);
			}
			else if (AI_Type == 5U)
			{
				IRDetector2Obj->Detector(
					VideoData.VideoFrame);
			}
			else if (AI_Type == 6U)
			{
				EODetector2Obj->Detector(
					VideoData.VideoFrame);
			}
			else
			{
				cerr << "[MAIN] Invalid AI_Type: "
					 << static_cast<int>(AI_Type)
					 << endl;

				continue;
			}
		}
		catch (const cv::Exception &e)
		{
			cerr << endl;
			cerr << "============================================"
				 << endl;
			cerr << "[MAIN] OpenCV Exception During AI Processing"
				 << endl;

			cerr << "AI Type     : "
				 << static_cast<int>(AI_Type)
				 << endl;

			cerr << "Frame Size  : "
				 << VideoData.VideoFrame.cols
				 << " x "
				 << VideoData.VideoFrame.rows
				 << endl;

			cerr << "Channels    : "
				 << VideoData.VideoFrame.channels()
				 << endl;

			cerr << "Frame Empty : "
				 << VideoData.VideoFrame.empty()
				 << endl;

			cerr << "Error       : "
				 << e.what()
				 << endl;

			cerr << "============================================"
				 << endl
				 << flush;

			continue;
		}

		// ============================================================
		// STEP 5: Check processed frame
		// ============================================================

		if (VideoData.VideoFrame.empty())
		{
			cerr << "[MAIN] Frame became empty after processing."
				 << endl
				 << flush;

			continue;
		}

		// ============================================================
		// STEP 6: Safely provide processed frame to C4I thread
		// ============================================================

		pthread_mutex_lock(&C4IVideoDataMutex);

		// Copy metadata
		C4IVideoData = VideoData;

		// IMPORTANT:
		// Give C4I its own independent image memory.
		C4IVideoData.VideoFrame =
			VideoData.VideoFrame.clone();

		if (C4IVideoData.VideoFrame.empty())
		{
			C4IVideoData.FrameFlag = false;

			cerr << "[MAIN] Failed to clone frame for C4I."
				 << endl
				 << flush;
		}
		else
		{
			C4IVideoData.FrameFlag = true;
		}

		pthread_mutex_unlock(&C4IVideoDataMutex);

		// ============================================================
		// STEP 7: Processing Time
		// ============================================================

		timCntEnd = high_resolution_clock::now();

		timDuration =
			timCntEnd - timCntStart;

		cout << "Total Process Time - "
			 << timDuration.count()
			 << " ms"
			 << endl
			 << flush;
	}

	// Close Whole Process & Clear Threads
	closeProcess();

	cout << "Terminated Successfully..." << endl
		 << flush;
	return 0;
}

// ---------- signal Handler ----------
void signalHandler(Int32_t Signal)
{
	if (Signal == SIGINT)
	{
		cout << "Process Terminated by Cntl+C..." << endl
			 << flush;
		ProcessVideoFlag = false;
	}

	return;
}

// ---------- Close Process ----------
void closeProcess(void)
{
	// Clear all the flags
	C4ICmdRecvFlag = false;
	C4IDataSendFlag = false;
	IRVideoReadFlag = false;
	EOVideoReadFlag = false;
	ProcessVideoFlag = false;

	// Try to Cancel Threads
	try
	{
		pthread_cancel(RecvC4ICmdThread);
		pthread_cancel(SendC4IDataThread);
		pthread_cancel(IRVideoReadThread);
		pthread_cancel(IRVideoReadThread);
	}
	catch (Exception &e)
	{
		cout << "Error : " << e.what() << endl;
	}

	// Close All Windows
	destroyAllWindows();

	// delete all the objects
	try
	{
		if (SeekerObj != nullptr)
		{
			delete SeekerObj;
		}

		if (IRVideoAIObj != nullptr)
		{
			delete IRVideoAIObj;
		}

		if (EOVideoAIObj != nullptr)
		{
			delete EOVideoAIObj;
		}

		if (C4IInterfaceObj != nullptr)
		{
			delete C4IInterfaceObj;
		}

		if (IRDetectorObj != nullptr)
		{
			delete IRDetectorObj;
		}

		if (EODetectorObj != nullptr)
		{
			delete EODetectorObj;
		}

		if (IRDetector2Obj != nullptr)
		{
			delete IRDetector2Obj;
		}

		if (EODetector2Obj != nullptr)
		{
			delete EODetector2Obj;
		}
	}
	catch (Exception &e)
	{
		cout << "Error : " << e.what() << endl;
	}

	cout << "Process Closed Successfully..." << endl
		 << flush;

	return;
}
