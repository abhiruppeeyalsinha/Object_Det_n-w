// ============================================================================
// Name        : ClassicalDetector2.cpp
// Author      : Bhavesh
// ============================================================================


// ---------- Header Inclusion ----------
#include "ClassicalDetector2.h"


Track :: Track(int trackID, Point2f initialPoint, Rect initialBox)
{
    id = trackID;
    kf.init(4, 2, 0, CV_32F);

    kf.transitionMatrix = (Mat_<float>(4, 4) << 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1);
    kf.measurementMatrix = (Mat_<float>(2, 4) << 1, 0, 0, 0, 0, 1, 0, 0);

    setIdentity(kf.processNoiseCov, Scalar::all(1e-2));
    setIdentity(kf.measurementNoiseCov, Scalar::all(1e-1));
    setIdentity(kf.errorCovPost, Scalar::all(1));

    kf.statePost = (Mat_<float>(4, 1) << initialPoint.x, initialPoint.y, 0, 0);

    position = initialPoint;
    previousPosition = initialPoint;
    predicted = initialPoint;
    bbox = initialBox;

    age = 1;
    hits = 1;
    missed = 0;

    confirmed = false;
    confidence = 0.0;
    velocity = Point2f(0, 0);

    return;
}


Point2f Track :: predict()
{
	Mat prediction = kf.predict();
	predicted = Point2f(prediction.at<float>(0), prediction.at<float>(1));

	return predicted;
}


void Track :: update(const Point2f &measurement, const Rect &newBox, double dt, double smoothing)
{
	Point2f rawVelocity;
	Mat measurementMat, corrected;

	previousPosition = position;
	measurementMat = (Mat_<float>(2, 1) << measurement.x, measurement.y);
	corrected = kf.correct(measurementMat);

	position = Point2f(corrected.at<float>(0), corrected.at<float>(1));
	bbox = newBox;

	hits++;
	missed = 0;
	age++;

	// Raw velocity
	if(dt > 0)
	{
		rawVelocity = (position - previousPosition) * static_cast<float>(1.0 / dt);
		velocity = smoothing * rawVelocity + (1.0 - smoothing) * velocity;
	}

	return;
}


void Track :: markMissed()
{
	missed++;
	age++;
	position = predicted;

	return;
}


Mat createKernel(Int32_t size)
{
    return getStructuringElement(MORPH_ELLIPSE, Size(size, size));
}


Mat thermalSaliency(const Mat &gray, const Config_S &cfg)
{
	double adaptivethres, finalthres;
	Scalar meanval,stdval;
    Mat denoised, saliency, mask;
    Mat noisekernal, structuruingelement;

    if(cfg.noisefloorkernal > 1)
    {
        noisekernal = createKernel(cfg.noisefloorkernal);
        morphologyEx(gray, denoised, MORPH_OPEN, noisekernal);
        morphologyEx(denoised, denoised, MORPH_CLOSE, noisekernal);
    }
    else
    {
        denoised = gray;
    }
    structuruingelement = getStructuringElement(MORPH_ELLIPSE, Size(cfg.targetscale, cfg.targetscale));

    if(cfg.detectHotTarget)
    {
        morphologyEx(denoised, saliency, MORPH_TOPHAT, structuruingelement);
    }
    else
    {
        morphologyEx(denoised, saliency, MORPH_BLACKHAT, structuruingelement);
    }

    meanStdDev(saliency,meanval,stdval);
    adaptivethres = meanval[0] + cfg.saliencystdmultiplier * stdval[0];
    finalthres = FindMax(adaptivethres, cfg.saliencyminthreshold);

    threshold(saliency, mask,finalthres, 255, THRESH_BINARY);

    return mask;
}


// ------------------------------------------------------------
// MOG2 motion detection
// ------------------------------------------------------------
Mat motionMask(Ptr<BackgroundSubtractorMOG2> &mog, const Mat &gray)
{
    Mat mask;

    mog->apply(gray, mask, 0.1);
    threshold(mask, mask, 200, 255, THRESH_BINARY);

    return mask;
}


// ------------------------------------------------------------
// Morphological cleanup
// ------------------------------------------------------------
void cleanMask(Mat &mask, const Config_S &cfg)
{
    Mat kernel;

    kernel = createKernel(cfg.morphKernel);
    medianBlur(mask, mask, 3);
    morphologyEx(mask, mask, MORPH_OPEN, kernel, Point(-1, -1), cfg.openIterations);
    morphologyEx(mask, mask, MORPH_CLOSE, kernel, Point(-1, -1), cfg.closeIterations);

    return;
}


// ------------------------------------------------------------
// Blob extraction
// ------------------------------------------------------------
vector<Detection> extractDetections(const Mat &mask, const Mat &thermalMask, const Mat &motionMaskImg, const Config_S &cfg)
{
	Rect box;
	Moments m;
	Detection d;
	vector<Point> hull;
	Mat roiThermal, roiMotion;
	vector<Detection> detections;
	vector<vector<Point>> contours;

	double area, aspect, perimeter, circularity;
	double hullA, solidity, motionScore;
	double thermalPixels, roiArea, thermalScore;

	findContours(mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

	for(auto &contour : contours)
	{
		area = contourArea(contour);
		if(area < cfg.minArea || area > cfg.maxArea)
		{
			continue;
		}

		box = boundingRect(contour);
		if(box.width < cfg.minWidth || box.width > cfg.maxWidth)
		{
			continue;
		}

		if(box.height < cfg.minHeight || box.height > cfg.maxHeight)
		{
			continue;
		}

		aspect = static_cast<double>(box.width) / static_cast<double>(box.height);
		if(aspect < cfg.minAspect ||aspect > cfg.maxAspect)
		{
			continue;
		}

		perimeter = arcLength(contour, true);
		if(perimeter <= 0)
		{
			continue;
		}

		circularity = (4.0 * CV_PI * area) / (perimeter * perimeter);
		if(circularity < cfg.mincir)
		{
			continue;
		}

        convexHull(contour, hull);

        hullA = contourArea(hull);
        if(hullA <= 0)
        {
        	continue;
        }

        solidity = area / hullA;
        if(solidity < cfg.minSolidity)
        {
        	continue;
        }

        m = moments(contour);
        if(fabs(m.m00) < 1e-6)
        {
        	continue;
        }

        Point2f centroid(static_cast<float>(m.m10 / m.m00), static_cast<float>(m.m01 / m.m00));

        // ----------------------------------------
        // Thermal score
        // ----------------------------------------
        roiThermal = thermalMask(box);
        thermalPixels = countNonZero(roiThermal);
        roiArea = static_cast<double>(box.area());
        thermalScore = thermalPixels / roiArea;

        // ----------------------------------------
        // Motion score
        // ----------------------------------------
        motionScore = 0.0;
        if(!motionMaskImg.empty())
        {
            roiMotion = motionMaskImg(box);
            motionScore = static_cast<double>(countNonZero(roiMotion)) / roiArea;
        }

        d.bbox = box;
        d.centroid = centroid;

        d.area = area;
        d.aspectRatio = aspect;

        d.thermalScore = thermalScore;
        d.motionScore = motionScore;

        detections.push_back(d);
    }

    return detections;
}


// ============================================================
// DISTANCE
// ============================================================
double distanceBetween(const Point2f &a, const Point2f &b)
{
    double dx, dy;

    dx = a.x - b.x;
    dy = a.y - b.y;

    return sqrt((dx * dx) + (dy * dy));
}


// ---------- Adaptive DoG Response Threshold ----------
float ClassicalDetector2 :: adaptiveResponseThreshold(const Mat &Response)
{
	Mat AbsResponse;
	double RawThreshold;
	Scalar MeanVal, StdDevVal;

	if(Config.DOG_THRESHOLD > 0.0f)
	{
		return Config.DOG_THRESHOLD;
	}

	absdiff(Response, Scalar(0), AbsResponse);
	meanStdDev(AbsResponse, MeanVal, StdDevVal);

	RawThreshold = MeanVal[0] + Config.DOG_STDDEV_FACTOR * StdDevVal[0];
	return static_cast<float>(clamp(RawThreshold, static_cast<double>(Config.MIN_DOG_THRESHOLD), static_cast<double>(Config.MAX_DOG_THRESHOLD)));
}


// ---------- Create Positive/Negative DoG Blob Mask ----------
Mat ClassicalDetector2 :: blobMask(const Mat &Response, float Threshold)
{
	Mat OutMask;
	Mat NegResponse;
	Mat PosClip, NegClip;
	Mat PosMask, NegMask;

	max(Response, 0, PosClip);
	PosClip.convertTo(PosClip, CV_8U);
	threshold(PosClip, PosMask, Threshold, 255, THRESH_BINARY);

	NegResponse = -Response;
	max(NegResponse, 0, NegClip);
	NegClip.convertTo(NegClip, CV_8U);
	threshold(NegClip, NegMask, Threshold, 255, THRESH_BINARY);

	bitwise_or(PosMask, NegMask, OutMask);
	return OutMask;
}


// ---------- Clean DoG Mask ----------
void ClassicalDetector2 :: cleanupMask(Mat &Mask)
{
	Mat Kernel;
	Int32_t MinDim, KernelSize;

	if(Mask.empty())
	{
		return;
	}

	MinDim = FindMax(1, FindMin(Mask.cols, Mask.rows));
	KernelSize = (MinDim >= 720) ? 5 : 3;
	Kernel = getStructuringElement(MORPH_ELLIPSE, Size(KernelSize, KernelSize));

	morphologyEx(Mask, Mask, MORPH_OPEN, Kernel);
	morphologyEx(Mask, Mask, MORPH_CLOSE, Kernel);

	return;
}


// ---------- Centre Prior For Candidate Ranking ----------
double ClassicalDetector2 :: priorWeight(const Rect &Box, Size ImageSize)
{
	double DX, DY, MaxDist;

	DX = (Box.x + Box.width * 0.5) - ImageSize.width * 0.5;
	DY = (Box.y + Box.height * 0.5) - ImageSize.height * 0.5;
	MaxDist = FindMax(1.0, hypot(ImageSize.width * 0.5, ImageSize.height * 0.5));

	return 0.75 + (1.0 - FindMin(hypot(DX, DY) / MaxDist, 1.0)) * 0.35;
}


// ---------- Rect IOU ----------
float ClassicalDetector2 :: rectIOU(const Rect &A, const Rect &B)
{
	Int32_t X1, Y1, X2, Y2, W, H;
	float Inter, AreaA, AreaB, Uni;

	X1 = FindMax(A.x, B.x);
	Y1 = FindMax(A.y, B.y);
	X2 = FindMin(A.x + A.width, B.x + B.width);
	Y2 = FindMin(A.y + A.height, B.y + B.height);
	W = FindMax(0, X2 - X1);
	H = FindMax(0, Y2 - Y1);
	Inter = static_cast<float>(W * H);
	AreaA = static_cast<float>(A.width * A.height);
	AreaB = static_cast<float>(B.width * B.height);
	Uni = AreaA + AreaB - Inter + 1e-6f;

	return (Inter / Uni);
}


// ---------- Centre Distance ----------
float ClassicalDetector2 :: centerDistance(const Rect &A, const Rect &B)
{
	Point2f CA(A.x + A.width * 0.5f, A.y + A.height * 0.5f);
	Point2f CB(B.x + B.width * 0.5f, B.y + B.height * 0.5f);

	return static_cast<float>(norm(CA - CB));
}


// ---------- Rect Centre ----------
Point2d ClassicalDetector2 :: centerOf(const Rect &Box)
{
	return Point2d(Box.x + Box.width * 0.5, Box.y + Box.height * 0.5);
}


// ---------- Stationary Track ----------
bool ClassicalDetector2 :: isStationaryTrack(const vector<Rect> &History)
{
	Point2d Centre;

	double MinCx, MaxCx, MinCy, MaxCy;
	Int32_t MinW, MaxW, MinH, MaxH;

	double FirstToLast;
	Point2d FirstCentre, LastCentre;

	bool SizeStable;
	bool PositionStable;

	if(History.size() < static_cast<size_t>(StationaryStableFrames))
	{
		return false;
	}

	MinCx = 1e30;
	MaxCx = -1e30;
	MinCy = 1e30;
	MaxCy = -1e30;
	MinW = 1000000000;
	MaxW = 0;
	MinH = 1000000000;
	MaxH = 0;

	for(const Rect &Box : History)
	{
		Centre = centerOf(Box);
		MinCx = FindMin(MinCx, Centre.x);
		MaxCx = FindMax(MaxCx, Centre.x);
		MinCy = FindMin(MinCy, Centre.y);
		MaxCy = FindMax(MaxCy, Centre.y);
		MinW = FindMin(MinW, Box.width);
		MaxW = FindMax(MaxW, Box.width);
		MinH = FindMin(MinH, Box.height);
		MaxH = FindMax(MaxH, Box.height);
	}

	FirstCentre = centerOf(History.front());
	LastCentre = centerOf(History.back());
	FirstToLast = hypot(LastCentre.x - FirstCentre.x, LastCentre.y - FirstCentre.y);

	PositionStable = FirstToLast <= StationaryPositionTolerance && (MaxCx - MinCx) <= StationaryPositionTolerance * 2.0 && (MaxCy - MinCy) <= StationaryPositionTolerance * 2.0;
	SizeStable = (MaxW - MinW) <= StationarySizeTolerance * 2 && (MaxH - MinH) <= StationarySizeTolerance * 2;

	return PositionStable && SizeStable;
}


// ---------- NMS ----------
vector<struct _AIData_> ClassicalDetector2 :: applyNMS(vector<struct _AIData_> &Detections, float IOUThreshold)
{
	vector<struct _AIData_> Result;

	if(Detections.empty())
	{
		return {};
	}

	sort(Detections.begin(), Detections.end(), [](const struct _AIData_ &A, const struct _AIData_ &B) { return A.Confidance > B.Confidance; });
	vector<bool> Suppressed(Detections.size(), false);

	for(size_t i = 0; i < Detections.size(); i++)
	{
		if (Suppressed[i])
		{
			continue;
		}

		Result.push_back(Detections[i]);
		for(size_t j = i + 1; j < Detections.size(); j++)
		{
			if (Suppressed[j])
			{
				continue;
			}

			if(rectIOU(Detections[i].BoundingBox, Detections[j].BoundingBox) > IOUThreshold)
			{
				Suppressed[j] = true;
			}
		}
	}

	return Result;
}


// ---------- Hungarian Solve ----------
void ClassicalDetector2 :: hungarianSolve(const vector<vector<float>> &Cost, vector<Int32_t> &Assignment)
{
	Int32_t i, j;
	Int32_t J0, I0, J1;
	Int32_t N, Rows, Cols;

	float Delta, Cur;
	const float INF = 1e9f;

	Rows = static_cast<Int32_t>(Cost.size());
	if(Rows == 0)
	{
		Assignment.clear();
		return;
	}

	Cols = static_cast<Int32_t>(Cost[0].size());
	N = FindMax(Rows, Cols);
	vector<vector<float>> A(N, vector<float>(N, INF));

	for(i = 0; i < Rows; i++)
	{
		for(j = 0; j < Cols; j++)
		{
			A[i][j] = Cost[i][j];
		}
	}

	vector<float> U(N + 1, 0), V(N + 1, 0), MinV;
	vector<Int32_t> P(N + 1, 0), Way(N + 1, 0);

	for(i = 1; i <= N; i++)
	{
		J0 = 0;
		P[0] = i;
		MinV.assign(N + 1, INF);
		vector<Int8_t> Used(N + 1, false);

		do
		{
			Used[J0] = true;
			I0 = P[J0];
			J1 = 0;
			Delta = INF;

			for(j = 1; j <= N; j++)
			{
				if(Used[j])
				{
					continue;
				}

				Cur = A[I0 - 1][j - 1] - U[I0] - V[j];
				if(Cur < MinV[j])
				{
					MinV[j] = Cur;
					Way[j] = J0;
				}
				if(MinV[j] < Delta)
				{
					Delta = MinV[j];
					J1 = j;
				}
			}

			for(j = 0; j <= N; j++)
			{
				if(Used[j])
				{
					U[P[j]] += Delta;
					V[j] -= Delta;
				}
				else
				{
					MinV[j] -= Delta;
				}
			}
			J0 = J1;
		} while(P[J0] != 0);

		do
		{
			J1 = Way[J0];
			P[J0] = P[J1];
			J0 = J1;
		} while (J0);
	}

	vector<Int32_t> Ans(N + 1, 0);
	for(j = 1; j <= N; j++)
	{
		Ans[P[j]] = j;
	}

	Assignment.assign(Rows, -1);
	for(i = 1; i <= Rows; i++)
	{
		if(Ans[i] >= 1 && Ans[i] <= Cols)
		{
			Assignment[i - 1] = Ans[i] - 1;
		}
	}

	return;
}


// ---------- Filter Stationary Targets ----------
vector<struct _AIData_> ClassicalDetector2 :: filterStationaryTargets(const vector<struct _AIData_> &Detections)
{
	Rect CurrentBox;
	bool SizeReasonable, Stationary;
	Int32_t BestTrack, MaxSizeChange;
	double BestDistance, Distance, DynamicMatchDistance;

	struct _StationaryTrack_ NewTrack;
	vector<struct _AIData_> MovingDetections;

	MovingDetections.reserve(Detections.size());
	vector<bool> TrackUsed(StationaryTrackArr.size(), false);

	for(const auto &Detection : Detections)
	{
		CurrentBox = Detection.BoundingBox;
		BestTrack = -1;
		BestDistance = 1e30;

		for(size_t t = 0; t < StationaryTrackArr.size(); t++)
		{
			if(TrackUsed[t])
			{
				continue;
			}

			const Rect &PreviousBox = StationaryTrackArr[t].LastBox;
			Distance = centerDistance(PreviousBox, CurrentBox);
			DynamicMatchDistance = FindMax(StationaryMatchDistance, 0.35 * static_cast<double>(FindMax(PreviousBox.width, PreviousBox.height)));
			MaxSizeChange = FindMax(10, static_cast<Int32_t>(0.50 * FindMax(PreviousBox.width, PreviousBox.height)));
			SizeReasonable = abs(CurrentBox.width - PreviousBox.width) <= MaxSizeChange && abs(CurrentBox.height - PreviousBox.height) <= MaxSizeChange;

			if(SizeReasonable && Distance <= DynamicMatchDistance && Distance < BestDistance)
			{
				BestDistance = Distance;
				BestTrack = static_cast<Int32_t>(t);
			}
		}

		Stationary = false;
		if(BestTrack >= 0)
		{
			struct _StationaryTrack_ &Track = StationaryTrackArr[BestTrack];
			TrackUsed[BestTrack] = true;
			Track.MissedFrames = 0;
			Track.LastBox = CurrentBox;
			Track.History.push_back(CurrentBox);

			if(Track.History.size() > static_cast<size_t>(StationaryStableFrames))
			{
				Track.History.erase(Track.History.begin());
			}

			Stationary = isStationaryTrack(Track.History);
			if(Stationary == true && Track.Stationary == false)
			{
				cout << "Suppress : Ny:" << Detection.CenterPoint.x << " Nz:" << Detection.CenterPoint.y << " stationary targets" << endl << flush;
			}
			Track.Stationary = Stationary;
		}
		else
		{
			NewTrack.LastBox = CurrentBox;
			NewTrack.History.push_back(CurrentBox);
			StationaryTrackArr.push_back(NewTrack);
			TrackUsed.push_back(true);
		}

		if(Stationary == false)
		{
			MovingDetections.push_back(Detection);
		}
	}

	for(size_t t = 0; t < StationaryTrackArr.size(); t++)
	{
		if(TrackUsed[t] == false)
		{
			StationaryTrackArr[t].MissedFrames++;
		}
	}

	for(size_t t = StationaryTrackArr.size(); t-- > 0;)
	{
		if(StationaryTrackArr[t].MissedFrames > StationaryMaxMissedFrames)
		{
			StationaryTrackArr.erase(StationaryTrackArr.begin() + static_cast<long>(t));
		}
	}

	return MovingDetections;
}


// ---------- Filter Exact Repeated Coordinates ----------
vector<struct _AIData_> ClassicalDetector2 :: filterRepeatedCoordinates(const vector<struct _AIData_> &Detections)
{
	vector<struct _AIData_> KeptDetections;
	Int32_t X, Y, MatchedTrack, Consecutive;


	RepeatedFrameNumber++;
	for(auto &Track : RepeatedCoordinateTrackArr)
	{
		Track.SeenThisFrame = false;
	}

	KeptDetections.reserve(Detections.size());

	for(const auto &Detection : Detections)
	{
		X = Detection.CenterPoint.x;
		Y = Detection.CenterPoint.y;
		MatchedTrack = -1;

		for(size_t t = 0; t < RepeatedCoordinateTrackArr.size(); t++)
		{
			if(RepeatedCoordinateTrackArr[t].SeenThisFrame == false && RepeatedCoordinateTrackArr[t].X == X && RepeatedCoordinateTrackArr[t].Y == Y)
			{
				MatchedTrack = static_cast<Int32_t>(t);
				break;
			}
		}

		Consecutive = 1;
		if(MatchedTrack >= 0)
		{
			struct _RepeatedCoordinateTrack_ &Track = RepeatedCoordinateTrackArr[MatchedTrack];
			if(Track.LastSeenFrame == RepeatedFrameNumber - 1)
			{
				Track.ConsecutiveFrames++;
			}
			else
			{
				Track.ConsecutiveFrames = 1;
			}

			Track.LastSeenFrame = RepeatedFrameNumber;
			Track.SeenThisFrame = true;
			Consecutive = Track.ConsecutiveFrames;
		}
		else
		{
			struct _RepeatedCoordinateTrack_ NewTrack;
			NewTrack.X = X;
			NewTrack.Y = Y;
			NewTrack.ConsecutiveFrames = 1;
			NewTrack.LastSeenFrame = RepeatedFrameNumber;
			NewTrack.SeenThisFrame = true;
			RepeatedCoordinateTrackArr.push_back(NewTrack);
		}

		if(Consecutive < StaticCoordFrames)
		{
			KeptDetections.push_back(Detection);
		}
		else if(Consecutive == StaticCoordFrames)
		{
			cout << "Suppress : Ny:" << X << " Nz:" << Y << " Consecutive " << Consecutive << " frames" << endl << flush;
		}
	}

	for(size_t t = RepeatedCoordinateTrackArr.size(); t-- > 0; )
	{
		if(RepeatedCoordinateTrackArr[t].SeenThisFrame == false)
		{
			RepeatedCoordinateTrackArr.erase(RepeatedCoordinateTrackArr.begin() + static_cast<long>(t));
		}
	}

	return KeptDetections;
}


// ---------- Select N Targets Nearest To Frame Centre ----------
void ClassicalDetector2 :: selectNearestCentreTargets(Size FrameSize)
{
	struct _RankedTarget_
	{
		double Distance;
		size_t Index;
	};

	Int32_t KeepCount;
	double DX, DY;
	vector<struct _RankedTarget_> RankedTargets;

	if(TargetDataArr.empty())
	{
		return;
	}

	KeepCount = FindMin(FindMax(1U, TargetLimit), TargetDataArr.size());
	Point2d FrameCentre(FrameSize.width * 0.5, FrameSize.height * 0.5);

	RankedTargets.reserve(TargetDataArr.size());

	for(size_t i = 0; i < TargetDataArr.size(); i++)
	{
		DX = static_cast<double>(TargetDataArr[i].CenterPoint.x) - FrameCentre.x;
		DY = static_cast<double>(TargetDataArr[i].CenterPoint.y) - FrameCentre.y;
		RankedTargets.push_back({hypot(DX, DY), i});
	}

	sort(RankedTargets.begin(), RankedTargets.end(), [](const struct _RankedTarget_ &A, const struct _RankedTarget_ &B)
	{
	 if(A.Distance != B.Distance)
	 {
		 return A.Distance < B.Distance;
	 }
	 return A.Index < B.Index; });

	vector<struct _AIData_> SelectedTargets;
	SelectedTargets.reserve(KeepCount);
	for(Int32_t i = 0; i < KeepCount; i++)
	{
		SelectedTargets.push_back(TargetDataArr[RankedTargets[i].Index]);
	}

	TargetDataArr = SelectedTargets;
	LastCentreTargetArr = SelectedTargets;
	CentreMissedFrames = 0;
}


// ---------- Hold Previous Centre Targets For Short Detector Misses ----------
bool ClassicalDetector2 :: appendCentreHoldTargets(Size FrameSize)
{
	if(LastCentreTargetArr.empty() || CentreMissedFrames >= CentreHoldMaxFrames)
	{
		if(!LastCentreTargetArr.empty())
		{
			CentreMissedFrames++;
		}
		return false;
	}

	CentreMissedFrames++;
	TargetDataArr.insert(TargetDataArr.end(), LastCentreTargetArr.begin(), LastCentreTargetArr.end());
	return !TargetDataArr.empty();
}


// ---------- Draw Corner Style Bounding Box ----------
void ClassicalDetector2 :: drawCornerBox(Mat &VideoFrame, const Rect &Box, const Scalar &Color, Int32_t Thickness, Int32_t CornerLength)
{
	Int32_t X1, Y1, X2, Y2, LenX, LenY;

	if(VideoFrame.empty() || Box.width <= 0 || Box.height <= 0)
	{
		return;
	}

	X1 = Box.x;
	Y1 = Box.y;
	X2 = Box.x + Box.width - 1;
	Y2 = Box.y + Box.height - 1;
	LenX = FindMax(1, FindMin(CornerLength, Box.width / 3));
	LenY = FindMax(1, FindMin(CornerLength, Box.height / 3));

	line(VideoFrame, Point(X1, Y1), Point(X1 + LenX, Y1), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y1), Point(X1, Y1 + LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y1), Point(X2 - LenX, Y1), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y1), Point(X2, Y1 + LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y2), Point(X1 + LenX, Y2), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y2), Point(X1, Y2 - LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y2), Point(X2 - LenX, Y2), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y2), Point(X2, Y2 - LenY), Color, Thickness, LINE_AA);

	return;
}


// ---------- Draw Boxes And Fill Target Data ----------
void ClassicalDetector2 :: drawBoxes(Mat &VideoFrame)
{
	Rect SafeBox;
	UInt16_t TgtCnt = 0;
	Point FrameCentre(VideoFrame.cols / 2, VideoFrame.rows / 2);

	Size TextSize;
	string Label;
	Int32_t LabelX, LabelY, Baseline;

	if(VideoFrame.empty())
	{
		TgtData.TgtDataStruct.Header[0] = AI_ID;
		TgtData.TgtDataStruct.Header[1] = C4I_ID;
		TgtData.TgtDataStruct.Header[2] = TgtDataCmd;
		TgtData.TgtDataStruct.AIType = AI_Type;
		TgtData.TgtDataStruct.CheckSum = 0x00;
		TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
		TgtData.TgtDataStruct.TargetLimit = TargetLimit;
		TgtData.TgtDataStruct.TargetCnt = 0;
		TgtData.TgtDataStruct.DataLen = 0x05;
		TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;
		return;
	}

	for(auto &Target : TargetDataArr)
	{
		SafeBox = Target.BoundingBox & Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
		if(SafeBox.width <= 0 || SafeBox.height <= 0)
		{
			continue;
		}

		Target.BoundingBox = SafeBox;
		Target.CenterPoint = Point(SafeBox.x + SafeBox.width / 2, SafeBox.y + SafeBox.height / 2);

		drawCornerBox(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 1, 25);

		Baseline = 0;
		Label = "Tgt " + to_string(TgtCnt + 1) + " (" + to_string(Target.CenterPoint.x - VideoFrame.cols / 2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows / 2) + ")";
		TextSize = getTextSize(Label, FONT_HERSHEY_SIMPLEX, LabelScale, 1, &Baseline);
		LabelX = clamp(Target.BoundingBox.x, 0, FindMax(0, VideoFrame.cols - TextSize.width - 2));
		LabelY = (Target.BoundingBox.y - 5 > TextSize.height) ? Target.BoundingBox.y - 5 : FindMin(VideoFrame.rows - 2, Target.BoundingBox.y + Target.BoundingBox.height + TextSize.height + 4);

		putText(VideoFrame, Label, Point(LabelX, LabelY), FONT_HERSHEY_SIMPLEX, LabelScale, Scalar(255, 255, 255), 1);
		line(VideoFrame, FrameCentre, Target.CenterPoint, Scalar(255, 255, 255), 1, LINE_AA);

		cout << VideoLabel << " : Ny:" << (Target.CenterPoint.x - VideoFrame.cols / 2) << " Nz:" << (Target.CenterPoint.y - VideoFrame.rows / 2) << " W:" << Target.BoundingBox.width << " H:" << Target.BoundingBox.height << " Conf:" << (UInt32_t)(Target.Confidance * 100) << "%" << endl << flush;

		TargetData.ClassID = Target.ClassID;
		TargetData.TrackID = Target.TrackID;
		TargetData.Ny = Target.CenterPoint.x - VideoFrame.cols / 2;
		TargetData.Nz = Target.CenterPoint.y - VideoFrame.rows / 2;
		TargetData.Width = Target.BoundingBox.width;
		TargetData.Height = Target.BoundingBox.height;
		TargetData.Confidance = Target.Confidance * 100;

		if(TgtCnt < 5000)
		{
			TgtData.TgtDataStruct.TgtData[TgtCnt] = TargetData;
			TgtCnt++;
		}
	}

	TgtData.TgtDataStruct.Header[0] = AI_ID;
	TgtData.TgtDataStruct.Header[1] = C4I_ID;
	TgtData.TgtDataStruct.Header[2] = TgtDataCmd;
	TgtData.TgtDataStruct.AIType = AI_Type;
	TgtData.TgtDataStruct.CheckSum = 0x00;
	TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
	TgtData.TgtDataStruct.TargetLimit = TargetLimit;
	TgtData.TgtDataStruct.TargetCnt = TgtCnt;
	TgtData.TgtDataStruct.DataLen = 0x05 + (TgtCnt * sizeof(struct _TargetData_));
	TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;

	return;
}


// ---------- Constructor ----------
ClassicalDetector2 :: ClassicalDetector2(string Label)
{
	StaticCoordFrames = 10;
	NextTrackID = 0;

	MaxMissedFrames = 15;
	StationaryStableFrames = 6;
	StationarySizeTolerance = 4;
	StationaryMaxMissedFrames = 2;
	CentreHoldMaxFrames = 3;
	CentreMissedFrames = 0;
	RepeatedFrameNumber = 0;
	StationaryPositionTolerance = 3.0;
	StationaryMatchDistance = 12.0;
	VideoLabel = Label;
	LabelScale = 0.45F;

	mog = createBackgroundSubtractorMOG2(cfg.mogHistory, cfg.mogVarThreshold, cfg.mogDetectShadows);
	previousTime = static_cast<double>(getTickCount()) / getTickFrequency();

	return;
}


// ---------- Destructor ----------
ClassicalDetector2 :: ~ClassicalDetector2(void)
{
	TargetDataArr.clear();
	TrackArr.clear();

	return;
}


// ---------- Object Detection ----------
void ClassicalDetector2 :: Detector(Mat &VideoFrame)
{
	UInt32_t i, j;
	UInt32_t trackstoshow;
	Int32_t bestDetection;

	struct _AIData_ DetectData;
	vector<Centertrack> Centertracks;

	double thermal, confidence, dt;
	double startTime, bestDistance, dist;
	float framecenterX, framecenterY, offsetX, offsetY;
	Mat GrayFrame, motion, thermalMask, fusedMask, display;


	startTime = static_cast<double>(getTickCount()) / getTickFrequency();
	TargetDataArr.clear();

	if(VideoFrame.empty())
	{
		drawBoxes(VideoFrame);
		return;
	}

	if(VideoFrame.channels() == 3)
	{
		cvtColor(VideoFrame, GrayFrame, COLOR_BGR2GRAY);
	}
	else
	{
		GrayFrame = VideoFrame.clone();
	}

	thermalMask = thermalSaliency(GrayFrame, cfg);
	if(cfg.useMotionUnion)
	{
		motion = motionMask(mog, GrayFrame);
	}

	cleanMask(thermalMask, cfg);
	if(cfg.useMotionUnion)
	{
		cleanMask(motion, cfg);
	}

	if(cfg.useMotionUnion)
	{
		bitwise_and(thermalMask, motion, fusedMask);
	}
	else
	{
		fusedMask = thermalMask.clone();
	}

	cleanMask(fusedMask, cfg);
	vector<Detection> detections = extractDetections(fusedMask, thermalMask, motion, cfg);

	for(auto &track : tracks)
	{
		track.predict();
	}

	vector<bool> detectionUsed(detections.size(), false);
	vector<bool> trackUpdated(tracks.size(), false);

	for(i = 0; i < tracks.size(); ++i)
	{
		bestDistance = cfg.maxAssociationDistance;
		bestDetection = -1;

		for(j = 0; j < detections.size(); ++j)
		{
			if(detectionUsed[j])
			{
				continue;
			}

			dist = distanceBetween(tracks[i].predicted, detections[j].centroid);

			if(dist < bestDistance)
			{
				bestDistance = dist;
				bestDetection = static_cast<Int32_t>(j);
			}
		}

		if(bestDetection >= 0)
		{
			dt = startTime - previousTime;
			if(dt <= 0)
			{
				dt = 1.0 / 30.0;
			}

			tracks[i].update(detections[bestDetection].centroid, detections[bestDetection].bbox, dt, cfg.velocitySmoothing);
			thermal = detections[bestDetection].thermalScore;
			confidence = 0.80 * thermal + 0.20 * FindMin(tracks[i].hits / static_cast<double>(cfg.confirmationFrames), 1.0);
			tracks[i].confidence = FindMin(confidence, 1.0);

			if(tracks[i].hits >= cfg.confirmationFrames)
			{
				tracks[i].confirmed = true;
			}

			detectionUsed[bestDetection] = true;
			trackUpdated[i] = true;
		}
	}

	for(i = 0; i < tracks.size(); ++i)
	{
		if(!trackUpdated[i])
		{
			tracks[i].markMissed();
		}
	}

	for(i = 0; i < detections.size(); ++i)
	{
		if(detectionUsed[i])
		{
			continue;
		}

		Track newTrack(NextTrackID++, detections[i].centroid, detections[i].bbox);
		newTrack.confidence = 0.25 * detections[i].thermalScore;
		tracks.push_back(newTrack);
	}

	tracks.erase(remove_if(tracks.begin(), tracks.end(), [&](const Track &t) { return t.missed > cfg.maxMissedFrames; }), tracks.end());

	if(VideoFrame.channels() == 1)
	{
		cvtColor( VideoFrame, display, COLOR_GRAY2BGR);
	}
	else
	{
		display = VideoFrame.clone();
	}

	framecenterX=display.cols*0.5f;
	framecenterY=display.rows*0.5f;

	for(i = 0; i < tracks.size(); i++)
	{
		if(!tracks[i].confirmed)
		{
			continue;
		}

		if(tracks[i].confidence < cfg.minConfidenceToDisplay)
		{
			continue;
		}

		offsetX = tracks[i].position.x - framecenterX;
		offsetY = tracks[i].position.y - framecenterY;
		dist = sqrt((offsetX * offsetX) + (offsetY * offsetY));
		Centertracks.push_back({(Int32_t)i,dist});
	}

	sort(Centertracks.begin(), Centertracks.end(), [](const Centertrack& a, const Centertrack& b){return a.distance < b.distance;});
	trackstoshow = FindMin((Int32_t)Centertracks.size(), (TargetLimit == 0 ? 5000 : TargetLimit));

	for(i = 0; i < trackstoshow; i++)
	{
		const Track& track = tracks[Centertracks[i].index];

		DetectData.ClassID = 1;
		DetectData.TrackID = track.id;
		DetectData.Confidance = track.confidence;
		DetectData.BoundingBox = track.bbox;
		DetectData.CenterPoint = Point(track.bbox.x + track.bbox.width / 2, track.bbox.y + track.bbox.height / 2);
		TargetDataArr.push_back(DetectData);

		VideoFrame = display;
	}

	drawBoxes(VideoFrame);

	return;
}
