// ============================================================================
// Name        : C4IInterface.cpp
// Author      : Bhavesh
// ============================================================================


// ---------- Header Inclusion ----------
#include "C4IInterface.h"


// Constructor
C4IInterface :: C4IInterface(void)
{
	Len = sizeof(CAddr);

	RecvSock = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
	SendSock = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);

	memset(&SAddr, 0, sizeof(SAddr));
	memset(&CAddr, 0, sizeof(CAddr));
	memset(&RAddr, 0, sizeof(RAddr));

	SAddr.sin_family = AF_INET;
	SAddr.sin_addr.s_addr = INADDR_ANY;
	SAddr.sin_port = htons(AI_Port);

	CAddr.sin_family = AF_INET;
	CAddr.sin_addr.s_addr = inet_addr(C4I_IPAddr.c_str());
	CAddr.sin_port = htons(C4I_Port);

	// Release UDP Port if already bound
	releaseUDPPort(AI_Port);

	if(bind(RecvSock, (struct sockaddr *)&SAddr, sizeof(SAddr)) < 0)
	{
		perror((string("Bind : ") + to_string(AI_Port) + string(" : ")).c_str());
		raise(SIGINT);
	}

	return;
}


// Destructor
C4IInterface :: ~C4IInterface(void)
{
	close(SendSock);
	close(RecvSock);

	return;
}


// Receive Cmd Function
void C4IInterface :: recvCmdC4I(void)
{
	Int32_t RetVal = 0, ByteCnt = 0;

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 10;		// 10 microseconds

	while(C4ICmdRecvFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
		memset(AICmd.Buffer, 0, sizeof(AICmd.Buffer));

		try
		{
			RetVal = recvfrom(RecvSock, AICmd.Buffer, sizeof(AICmd.AICmdStruct), MSG_DONTWAIT, (struct sockaddr *)&RAddr, &Len);
			if(RetVal <= 0)
			{
				continue;
			}
		}
		catch(exception &e)
		{
			cerr << "Error : Receive failed C4I command : " << e.what() << endl;
			continue;
		}


		AIResp.AIRespStruct.Header[0] = AI_ID;
		AIResp.AIRespStruct.Header[1] = C4I_ID;
		AIResp.AIRespStruct.Header[2] = AICmd.Buffer[2];
		AIResp.AIRespStruct.DataLen = 0x01U;
		AIResp.AIRespStruct.CheckSum = 0x00U;


		// Check Headers
		if(AICmd.Buffer[0] != C4I_ID || AICmd.Buffer[1] != AI_ID)
		{
			AIResp.AIRespStruct.AckByte = 0xB2U;
			goto SEND;
		}

		// Check CheckSum


		cout << "Recv Data from C4I : L - " << RetVal << " : ";
		for(ByteCnt = 0; ByteCnt < RetVal; ByteCnt++)
		{
			printf("%02X ", TgtData.Buffer[ByteCnt]);
		}
		cout << endl;


		// Change AI Type According C4I
		if(AICmd.Buffer[2] == AISwitchCmd)
		{
			if(AICmd.AICmdStruct.AIType == 1U)
			{
				AI_Type = 1;
				cout << "IR AI cmd recv from C4I..." << endl;
			}
			else if(AICmd.AICmdStruct.AIType == 2U)
			{
				AI_Type = 2;
				cout << "EO AI cmd recv from C4I..." << endl;
			}
			else if(AICmd.AICmdStruct.AIType == 3U)
			{
				AI_Type = 3;
				cout << "IR Classical 1 cmd recv from C4I..." << endl;
			}
			else if(AICmd.AICmdStruct.AIType == 4U)
			{
				AI_Type = 4;
				cout << "EO Classical 1 cmd recv from C4I..." << endl;
			}
			else if(AICmd.AICmdStruct.AIType == 5U)
			{
				AI_Type = 5;
				cout << "IR Classical 2 cmd recv from C4I..." << endl;
			}
			else if(AICmd.AICmdStruct.AIType == 6U)
			{
				AI_Type = 6;
				cout << "EO Classical 2 cmd recv from C4I..." << endl;
			}
			else
			{
				AI_Type = 0;
				cout << "AI off cmd recv from C4I..." << endl;
			}

			TargetLimit = AICmd.AICmdStruct.TargetLimit;
			if(TargetLimit > 5000U)
			{
				TargetLimit = 5000U;
			}

			AIResp.AIRespStruct.AckByte = 0xE5U;
		}

		else if(AICmd.Buffer[2] == SaveVideoCmd)
		{
			SaveVideo = !!AICmd.SaveCmdStruct.Stat;
			AIResp.AIRespStruct.AckByte = 0xE5U;
		}

		else
		{
			AIResp.AIRespStruct.AckByte = 0xB2U;
		}

	SEND:
		try
		{
			RetVal = AIResp.AIRespStruct.DataLen + 0x05U;
			RetVal = sendto(RecvSock, AIResp.Buffer, RetVal, 0, (struct sockaddr *)&CAddr, sizeof(CAddr));
			cout << "Sent Response to C4I : L:" << RetVal << " : ";
			for(ByteCnt = 0; ByteCnt < RetVal; ByteCnt++)
			{
				printf("%02X ", AIResp.Buffer[ByteCnt]);
			}
			cout << endl;
		}
		catch(exception &e)
		{
			cerr << "Error : " << e.what() << endl;
		}
	}

	return;
}


// Send Data Function
void C4IInterface :: sendDataC4I(void)
{
	UInt32_t FrameLength;
	UInt8_t Packet[64*1024];
	vector<UInt8_t> FrameBuff;

	Int32_t RetVal = 0;
	UInt64_t FrameCnt = 0;
	UInt8_t PacketCnt = 0, PacketNo = 0;
	UInt16_t BuffSize = 63*1024, PacketSize = 0;

	string Time;
	Size VideoDim;
	stringstream ss;
	UInt16_t SaveFrameCnt = 0;
	VideoWriter IR_OutVid, EO_OutVid;

	steady_clock :: time_point SaveTime;
	auto now = system_clock::now();
	auto in_time_t = system_clock::to_time_t(now);

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 10;		// 10 microseconds


	while(C4IDataSendFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(C4IVideoData.FrameFlag == false)
		{
			if(duration_cast<seconds>(steady_clock::now() - SaveTime).count() > 5*60)
			{
				if(IR_OutVid.isOpened())
				{
					IR_OutVid.release();
				}

				if(EO_OutVid.isOpened())
				{
					EO_OutVid.release();
				}

				SaveTime = steady_clock::now();
			}

			usleep(1000 * 2);
			continue;
		}

		C4IVideoData.FrameFlag = false;

		// Send Target Data to C4I
		try
		{
			RetVal = TgtData.TgtDataStruct.DataLen + 0x06U;
			RetVal = sendto(SendSock, TgtData.Buffer, RetVal, 0, (struct sockaddr *)&CAddr, Len);
			cout << "Sent Target Data to C4I : L:" << RetVal << endl;
		}
		catch(exception &e)
		{
			cerr << "Error : " << e.what() << endl;
		}

		// Save Video
		if(SaveVideo == true || AutoSaveVideo == true)
		{
			SaveTime = steady_clock::now();

			if(C4IVideoData.VideoType == 1U || C4IVideoData.VideoType == 3U || C4IVideoData.VideoType == 5U)
			{
				if(SaveFrameCnt >= 7500U && IR_OutVid.isOpened())
				{
					IR_OutVid.release();
					SaveFrameCnt = 0U;
				}

				if(!IR_OutVid.isOpened())
				{
					VideoDim.width = C4IVideoData.VideoFrame.cols;
					VideoDim.height = C4IVideoData.VideoFrame.rows;

					now = system_clock::now();
					in_time_t = system_clock::to_time_t(now);

					ss.str("");
					ss.clear();
					ss << put_time(localtime(&in_time_t), "%d-%m-%y_%H:%M:%S");
					Time = ss.str();

					IR_OutVid.open(SavePath + "IR_" + Time + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, true);

					if(EO_OutVid.isOpened())
					{
						EO_OutVid.release();
						SaveFrameCnt = 0U;
					}
				}

				IR_OutVid.write(C4IVideoData.VideoFrame);
				SaveFrameCnt++;
			}
			else if(C4IVideoData.VideoType == 2U || C4IVideoData.VideoType == 4U || C4IVideoData.VideoType == 6U)
			{
				if(SaveFrameCnt >= 7500U && EO_OutVid.isOpened())
				{
					EO_OutVid.release();
					SaveFrameCnt = 0U;
				}

				if(!EO_OutVid.isOpened())
				{
					VideoDim.width = C4IVideoData.VideoFrame.cols;
					VideoDim.height = C4IVideoData.VideoFrame.rows;

					now = system_clock::now();
					in_time_t = system_clock::to_time_t(now);

					ss.str("");
					ss.clear();
					ss << put_time(localtime(&in_time_t), "%d-%m-%y_%H:%M:%S");
					Time = ss.str();

					EO_OutVid.open(SavePath + "EO_" + Time + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, true);

					if(IR_OutVid.isOpened())
					{
						IR_OutVid.release();
						SaveFrameCnt = 0U;
					}
				}

				EO_OutVid.write(C4IVideoData.VideoFrame);
				SaveFrameCnt++;
			}
			else
			{

			}
		}

		// Display & Video Stream Configuration
		resize(C4IVideoData.VideoFrame, C4IVideoData.VideoFrame, Size(640, 512));
		if(C4IVideoData.VideoType == 1U || C4IVideoData.VideoType == 3U || C4IVideoData.VideoType == 5U)
		{
			cvtColor(C4IVideoData.VideoFrame, C4IVideoData.VideoFrame, COLOR_BGR2GRAY);
		}

		// Display Video Frames
		if(DisplayFrame == true)
		{
			imshow("EOTS AI Video", C4IVideoData.VideoFrame);

			if(waitKey(1) == 'q')
			{
				ProcessVideoFlag = false;
				break;
			}
		}

		// Video Stream
		FrameBuff.clear();
		imencode(".jpeg", C4IVideoData.VideoFrame, FrameBuff, {IMWRITE_JPEG_QUALITY, 60});
		FrameLength = FrameBuff.size();

		PacketCnt = 1U + (UInt8_t)(BuffSize < FrameLength);
		if(FrameLength > (UInt32_t)(BuffSize * 2U))
		{
			cout << "Video Packet Size is to big..." << endl;
			continue;
		}

		for(PacketNo = 0; PacketNo < PacketCnt; PacketNo++)
		{
			PacketSize = FindMin(BuffSize, (FrameLength - (PacketNo * BuffSize))) + 7U;

			Packet[0] = (UInt8_t)AI_ID;
			Packet[1] = (UInt8_t)C4I_ID;
			Packet[2] = (UInt8_t)VideoDataCmd;

			Packet[3] = (UInt8_t)((PacketSize >> 0U) & 0xFFU);
			Packet[4] = (UInt8_t)((PacketSize >> 8U) & 0xFFU);

			Packet[5] = (UInt8_t)C4IVideoData.VideoType;
			memcpy((void *)(Packet + 6U), (void *)&FrameCnt, 4U);
			Packet[10] = (UInt8_t)PacketCnt;
			Packet[11] = (UInt8_t)PacketNo;

			memcpy((Packet + 12U), FrameBuff.data()+(PacketNo * BuffSize), (PacketSize - 7U));
			Packet[PacketSize + 5U] = (UInt8_t)0x00U;

			try
			{
				usleep(1000*4);
				RetVal = sendto(SendSock, Packet, (PacketSize+13), 0, (struct sockaddr *)&CAddr, Len);
				cout << "Sent Video Data to C4I : L:" << RetVal << " F:" << FrameCnt << " PC:" << (UInt32_t)PacketCnt << " PN:" << (UInt32_t)(PacketNo + 1U) << endl;
			}
			catch(exception &e)
			{
				cerr << "Error : " << e.what() << endl;
				continue;
			}
		}

		cout << endl;
		FrameCnt++;
	}


	if(IR_OutVid.isOpened())
	{
		IR_OutVid.release();
	}

	if(EO_OutVid.isOpened())
	{
		EO_OutVid.release();
	}

	return;
}


// Receive Cmd Function
void * C4IInterface :: recvCmdC4IThread(void *args)
{
	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	C4IInterface *Instance = static_cast<C4IInterface *>(args);

	Instance->recvCmdC4I();

	pthread_exit(NULL);
	return nullptr;
}


// Send Data Function
void * C4IInterface :: sendDataC4IThread(void *args)
{
	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	C4IInterface *Instance = static_cast<C4IInterface *>(args);

	Instance->sendDataC4I();

	pthread_exit(NULL);
	return nullptr;
}




