// ============================================================================
// Name        : ClassicalDetector.cpp
// Author      : Bhavesh
// ============================================================================

// ---------- Header Inclusion ----------
#include "ClassicalDetector.h"

// ---------- Adaptive DoG Response Threshold ----------
float ClassicalDetector::adaptiveResponseThreshold(const Mat &Response)
{
	Mat AbsResponse;
	double RawThreshold;
	Scalar MeanVal, StdDevVal;

	if (Config.DOG_THRESHOLD > 0.0f)
	{
		return Config.DOG_THRESHOLD;
	}

	absdiff(Response, Scalar(0), AbsResponse);
	meanStdDev(AbsResponse, MeanVal, StdDevVal);

	RawThreshold = MeanVal[0] + Config.DOG_STDDEV_FACTOR * StdDevVal[0];
	return static_cast<float>(clamp(RawThreshold, static_cast<double>(Config.MIN_DOG_THRESHOLD), static_cast<double>(Config.MAX_DOG_THRESHOLD)));
}

// ---------- Create Positive/Negative DoG Blob Mask ----------
Mat ClassicalDetector::blobMask(const Mat &Response, float Threshold)
{
	Mat OutMask;
	Mat NegResponse;
	Mat PosClip, NegClip;
	Mat PosMask, NegMask;

	max(Response, 0, PosClip);
	PosClip.convertTo(PosClip, CV_8U);
	threshold(PosClip, PosMask, Threshold, 255, THRESH_BINARY);

	NegResponse = -Response;
	max(NegResponse, 0, NegClip);
	NegClip.convertTo(NegClip, CV_8U);
	threshold(NegClip, NegMask, Threshold, 255, THRESH_BINARY);

	bitwise_or(PosMask, NegMask, OutMask);
	return OutMask;
}

// ---------- Clean DoG Mask ----------
void ClassicalDetector::cleanupMask(Mat &Mask)
{
	Mat Kernel;
	Int32_t MinDim, KernelSize;

	if (Mask.empty())
	{
		return;
	}

	MinDim = FindMax(1, FindMin(Mask.cols, Mask.rows));
	KernelSize = (MinDim >= 720) ? 5 : 3;
	Kernel = getStructuringElement(MORPH_ELLIPSE, Size(KernelSize, KernelSize));

	morphologyEx(Mask, Mask, MORPH_OPEN, Kernel);
	morphologyEx(Mask, Mask, MORPH_CLOSE, Kernel);

	return;
}

// ---------- Centre Prior For Candidate Ranking ----------
double ClassicalDetector::priorWeight(const Rect &Box, Size ImageSize)
{
	double DX, DY, MaxDist;

	DX = (Box.x + Box.width * 0.5) - ImageSize.width * 0.5;
	DY = (Box.y + Box.height * 0.5) - ImageSize.height * 0.5;
	MaxDist = FindMax(1.0, hypot(ImageSize.width * 0.5, ImageSize.height * 0.5));

	return 0.75 + (1.0 - FindMin(hypot(DX, DY) / MaxDist, 1.0)) * 0.35;
}

// ---------- Rect IOU ----------
float ClassicalDetector::rectIOU(const Rect &A, const Rect &B)
{
	Int32_t X1, Y1, X2, Y2, W, H;
	float Inter, AreaA, AreaB, Uni;

	X1 = FindMax(A.x, B.x);
	Y1 = FindMax(A.y, B.y);
	X2 = FindMin(A.x + A.width, B.x + B.width);
	Y2 = FindMin(A.y + A.height, B.y + B.height);
	W = FindMax(0, X2 - X1);
	H = FindMax(0, Y2 - Y1);
	Inter = static_cast<float>(W * H);
	AreaA = static_cast<float>(A.width * A.height);
	AreaB = static_cast<float>(B.width * B.height);
	Uni = AreaA + AreaB - Inter + 1e-6f;

	return (Inter / Uni);
}

// ---------- Centre Distance ----------
float ClassicalDetector::centerDistance(const Rect &A, const Rect &B)
{
	Point2f CA(A.x + A.width * 0.5f, A.y + A.height * 0.5f);
	Point2f CB(B.x + B.width * 0.5f, B.y + B.height * 0.5f);

	return static_cast<float>(norm(CA - CB));
}

// ---------- Rect Centre ----------
Point2d ClassicalDetector::centerOf(const Rect &Box)
{
	return Point2d(Box.x + Box.width * 0.5, Box.y + Box.height * 0.5);
}

// ---------- Stationary Track ----------
bool ClassicalDetector::isStationaryTrack(const vector<Rect> &History)
{
	Point2d Centre;

	double MinCx, MaxCx, MinCy, MaxCy;
	Int32_t MinW, MaxW, MinH, MaxH;

	double FirstToLast;
	Point2d FirstCentre, LastCentre;

	bool SizeStable;
	bool PositionStable;

	if (History.size() < static_cast<size_t>(StationaryStableFrames))
	{
		return false;
	}

	MinCx = 1e30;
	MaxCx = -1e30;
	MinCy = 1e30;
	MaxCy = -1e30;
	MinW = 1000000000;
	MaxW = 0;
	MinH = 1000000000;
	MaxH = 0;

	for (const Rect &Box : History)
	{
		Centre = centerOf(Box);
		MinCx = FindMin(MinCx, Centre.x);
		MaxCx = FindMax(MaxCx, Centre.x);
		MinCy = FindMin(MinCy, Centre.y);
		MaxCy = FindMax(MaxCy, Centre.y);
		MinW = FindMin(MinW, Box.width);
		MaxW = FindMax(MaxW, Box.width);
		MinH = FindMin(MinH, Box.height);
		MaxH = FindMax(MaxH, Box.height);
	}

	FirstCentre = centerOf(History.front());
	LastCentre = centerOf(History.back());
	FirstToLast = hypot(LastCentre.x - FirstCentre.x, LastCentre.y - FirstCentre.y);

	PositionStable = FirstToLast <= StationaryPositionTolerance && (MaxCx - MinCx) <= StationaryPositionTolerance * 2.0 && (MaxCy - MinCy) <= StationaryPositionTolerance * 2.0;
	SizeStable = (MaxW - MinW) <= StationarySizeTolerance * 2 && (MaxH - MinH) <= StationarySizeTolerance * 2;

	return PositionStable && SizeStable;
}

// ---------- NMS ----------
vector<struct _AIData_> ClassicalDetector::applyNMS(vector<struct _AIData_> &Detections, float IOUThreshold)
{
	vector<struct _AIData_> Result;

	if (Detections.empty())
	{
		return {};
	}

	sort(Detections.begin(), Detections.end(), [](const struct _AIData_ &A, const struct _AIData_ &B)
		 { return A.Confidance > B.Confidance; });
	vector<bool> Suppressed(Detections.size(), false);

	for (size_t i = 0; i < Detections.size(); i++)
	{
		if (Suppressed[i])
		{
			continue;
		}

		Result.push_back(Detections[i]);
		for (size_t j = i + 1; j < Detections.size(); j++)
		{
			if (Suppressed[j])
			{
				continue;
			}

			if (rectIOU(Detections[i].BoundingBox, Detections[j].BoundingBox) > IOUThreshold)
			{
				Suppressed[j] = true;
			}
		}
	}

	return Result;
}

// ---------- Hungarian Solve ----------
void ClassicalDetector::hungarianSolve(const vector<vector<float>> &Cost, vector<Int32_t> &Assignment)
{
	Int32_t i, j;
	Int32_t J0, I0, J1;
	Int32_t N, Rows, Cols;

	float Delta, Cur;
	const float INF = 1e9f;

	Rows = static_cast<Int32_t>(Cost.size());
	if (Rows == 0)
	{
		Assignment.clear();
		return;
	}

	Cols = static_cast<Int32_t>(Cost[0].size());
	N = FindMax(Rows, Cols);
	vector<vector<float>> A(N, vector<float>(N, INF));

	for (i = 0; i < Rows; i++)
	{
		for (j = 0; j < Cols; j++)
		{
			A[i][j] = Cost[i][j];
		}
	}

	vector<float> U(N + 1, 0), V(N + 1, 0), MinV;
	vector<Int32_t> P(N + 1, 0), Way(N + 1, 0);

	for (i = 1; i <= N; i++)
	{
		J0 = 0;
		P[0] = i;
		MinV.assign(N + 1, INF);
		vector<Int8_t> Used(N + 1, false);

		do
		{
			Used[J0] = true;
			I0 = P[J0];
			J1 = 0;
			Delta = INF;

			for (j = 1; j <= N; j++)
			{
				if (Used[j])
				{
					continue;
				}

				Cur = A[I0 - 1][j - 1] - U[I0] - V[j];
				if (Cur < MinV[j])
				{
					MinV[j] = Cur;
					Way[j] = J0;
				}
				if (MinV[j] < Delta)
				{
					Delta = MinV[j];
					J1 = j;
				}
			}

			for (j = 0; j <= N; j++)
			{
				if (Used[j])
				{
					U[P[j]] += Delta;
					V[j] -= Delta;
				}
				else
				{
					MinV[j] -= Delta;
				}
			}
			J0 = J1;
		} while (P[J0] != 0);

		do
		{
			J1 = Way[J0];
			P[J0] = P[J1];
			J0 = J1;
		} while (J0);
	}

	vector<Int32_t> Ans(N + 1, 0);
	for (j = 1; j <= N; j++)
	{
		Ans[P[j]] = j;
	}

	Assignment.assign(Rows, -1);
	for (i = 1; i <= Rows; i++)
	{
		if (Ans[i] >= 1 && Ans[i] <= Cols)
		{
			Assignment[i - 1] = Ans[i] - 1;
		}
	}

	return;
}

// ---------- Filter Stationary Targets ----------
vector<struct _AIData_> ClassicalDetector::filterStationaryTargets(const vector<struct _AIData_> &Detections)
{
	Rect CurrentBox;
	bool SizeReasonable, Stationary;
	Int32_t BestTrack, MaxSizeChange;
	double BestDistance, Distance, DynamicMatchDistance;

	struct _StationaryTrack_ NewTrack;
	vector<struct _AIData_> MovingDetections;

	MovingDetections.reserve(Detections.size());
	vector<bool> TrackUsed(StationaryTrackArr.size(), false);

	for (const auto &Detection : Detections)
	{
		CurrentBox = Detection.BoundingBox;
		BestTrack = -1;
		BestDistance = 1e30;

		for (size_t t = 0; t < StationaryTrackArr.size(); t++)
		{
			if (TrackUsed[t])
			{
				continue;
			}

			const Rect &PreviousBox = StationaryTrackArr[t].LastBox;
			Distance = centerDistance(PreviousBox, CurrentBox);
			DynamicMatchDistance = FindMax(StationaryMatchDistance, 0.35 * static_cast<double>(FindMax(PreviousBox.width, PreviousBox.height)));
			MaxSizeChange = FindMax(10, static_cast<Int32_t>(0.50 * FindMax(PreviousBox.width, PreviousBox.height)));
			SizeReasonable = abs(CurrentBox.width - PreviousBox.width) <= MaxSizeChange && abs(CurrentBox.height - PreviousBox.height) <= MaxSizeChange;

			if (SizeReasonable && Distance <= DynamicMatchDistance && Distance < BestDistance)
			{
				BestDistance = Distance;
				BestTrack = static_cast<Int32_t>(t);
			}
		}

		Stationary = false;
		if (BestTrack >= 0)
		{
			struct _StationaryTrack_ &Track = StationaryTrackArr[BestTrack];
			TrackUsed[BestTrack] = true;
			Track.MissedFrames = 0;
			Track.LastBox = CurrentBox;
			Track.History.push_back(CurrentBox);

			if (Track.History.size() > static_cast<size_t>(StationaryStableFrames))
			{
				Track.History.erase(Track.History.begin());
			}

			Stationary = isStationaryTrack(Track.History);
			if (Stationary == true && Track.Stationary == false)
			{
				cout << "Suppress : Ny:" << Detection.CenterPoint.x << " Nz:" << Detection.CenterPoint.y << " stationary targets" << endl
					 << flush;
			}
			Track.Stationary = Stationary;
		}
		else
		{
			NewTrack.LastBox = CurrentBox;
			NewTrack.History.push_back(CurrentBox);
			StationaryTrackArr.push_back(NewTrack);
			TrackUsed.push_back(true);
		}

		if (Stationary == false)
		{
			MovingDetections.push_back(Detection);
		}
	}

	for (size_t t = 0; t < StationaryTrackArr.size(); t++)
	{
		if (TrackUsed[t] == false)
		{
			StationaryTrackArr[t].MissedFrames++;
		}
	}

	for (size_t t = StationaryTrackArr.size(); t-- > 0;)
	{
		if (StationaryTrackArr[t].MissedFrames > StationaryMaxMissedFrames)
		{
			StationaryTrackArr.erase(StationaryTrackArr.begin() + static_cast<long>(t));
		}
	}

	return MovingDetections;
}

// ---------- Filter Exact Repeated Coordinates ----------
vector<struct _AIData_> ClassicalDetector::filterRepeatedCoordinates(const vector<struct _AIData_> &Detections)
{
	vector<struct _AIData_> KeptDetections;
	Int32_t X, Y, MatchedTrack, Consecutive;

	RepeatedFrameNumber++;
	for (auto &Track : RepeatedCoordinateTrackArr)
	{
		Track.SeenThisFrame = false;
	}

	KeptDetections.reserve(Detections.size());

	for (const auto &Detection : Detections)
	{
		X = Detection.CenterPoint.x;
		Y = Detection.CenterPoint.y;
		MatchedTrack = -1;

		for (size_t t = 0; t < RepeatedCoordinateTrackArr.size(); t++)
		{
			if (RepeatedCoordinateTrackArr[t].SeenThisFrame == false && RepeatedCoordinateTrackArr[t].X == X && RepeatedCoordinateTrackArr[t].Y == Y)
			{
				MatchedTrack = static_cast<Int32_t>(t);
				break;
			}
		}

		Consecutive = 1;
		if (MatchedTrack >= 0)
		{
			struct _RepeatedCoordinateTrack_ &Track = RepeatedCoordinateTrackArr[MatchedTrack];
			if (Track.LastSeenFrame == RepeatedFrameNumber - 1)
			{
				Track.ConsecutiveFrames++;
			}
			else
			{
				Track.ConsecutiveFrames = 1;
			}

			Track.LastSeenFrame = RepeatedFrameNumber;
			Track.SeenThisFrame = true;
			Consecutive = Track.ConsecutiveFrames;
		}
		else
		{
			struct _RepeatedCoordinateTrack_ NewTrack;
			NewTrack.X = X;
			NewTrack.Y = Y;
			NewTrack.ConsecutiveFrames = 1;
			NewTrack.LastSeenFrame = RepeatedFrameNumber;
			NewTrack.SeenThisFrame = true;
			RepeatedCoordinateTrackArr.push_back(NewTrack);
		}

		if (Consecutive < StaticCoordFrames)
		{
			KeptDetections.push_back(Detection);
		}
		else if (Consecutive == StaticCoordFrames)
		{
			cout << "Suppress : Ny:" << X << " Nz:" << Y << " Consecutive " << Consecutive << " frames" << endl
				 << flush;
		}
	}

	for (size_t t = RepeatedCoordinateTrackArr.size(); t-- > 0;)
	{
		if (RepeatedCoordinateTrackArr[t].SeenThisFrame == false)
		{
			RepeatedCoordinateTrackArr.erase(RepeatedCoordinateTrackArr.begin() + static_cast<long>(t));
		}
	}

	return KeptDetections;
}

// ---------- Select N Targets Nearest To Frame Centre ----------
void ClassicalDetector::selectNearestCentreTargets(Size FrameSize)
{
	struct _RankedTarget_
	{
		double Distance;
		size_t Index;
	};

	Int32_t KeepCount;
	double DX, DY;
	vector<struct _RankedTarget_> RankedTargets;

	if (TargetDataArr.empty())
	{
		return;
	}

	KeepCount = FindMin(FindMax(1U, TargetLimit), TargetDataArr.size());
	Point2d FrameCentre(FrameSize.width * 0.5, FrameSize.height * 0.5);

	RankedTargets.reserve(TargetDataArr.size());

	for (size_t i = 0; i < TargetDataArr.size(); i++)
	{
		DX = static_cast<double>(TargetDataArr[i].CenterPoint.x) - FrameCentre.x;
		DY = static_cast<double>(TargetDataArr[i].CenterPoint.y) - FrameCentre.y;
		RankedTargets.push_back({hypot(DX, DY), i});
	}

	sort(RankedTargets.begin(), RankedTargets.end(), [](const struct _RankedTarget_ &A, const struct _RankedTarget_ &B)
		 {
	 if(A.Distance != B.Distance)
	 {
		 return A.Distance < B.Distance;
	 }
	 return A.Index < B.Index; });

	vector<struct _AIData_> SelectedTargets;
	SelectedTargets.reserve(KeepCount);
	for (Int32_t i = 0; i < KeepCount; i++)
	{
		SelectedTargets.push_back(TargetDataArr[RankedTargets[i].Index]);
	}

	TargetDataArr = SelectedTargets;
	LastCentreTargetArr = SelectedTargets;
	CentreMissedFrames = 0;
}

// ---------- Hold Previous Centre Targets For Short Detector Misses ----------
bool ClassicalDetector::appendCentreHoldTargets(Size FrameSize)
{
	if (LastCentreTargetArr.empty() || CentreMissedFrames >= CentreHoldMaxFrames)
	{
		if (!LastCentreTargetArr.empty())
		{
			CentreMissedFrames++;
		}
		return false;
	}

	CentreMissedFrames++;
	TargetDataArr.insert(TargetDataArr.end(), LastCentreTargetArr.begin(), LastCentreTargetArr.end());
	return !TargetDataArr.empty();
}

// ---------- Draw Corner Style Bounding Box ----------
void ClassicalDetector::drawCornerBox(Mat &VideoFrame, const Rect &Box, const Scalar &Color, Int32_t Thickness, Int32_t CornerLength)
{
	Int32_t X1, Y1, X2, Y2, LenX, LenY;

	if (VideoFrame.empty() || Box.width <= 0 || Box.height <= 0)
	{
		return;
	}

	X1 = Box.x;
	Y1 = Box.y;
	X2 = Box.x + Box.width - 1;
	Y2 = Box.y + Box.height - 1;
	LenX = FindMax(1, FindMin(CornerLength, Box.width / 3));
	LenY = FindMax(1, FindMin(CornerLength, Box.height / 3));

	line(VideoFrame, Point(X1, Y1), Point(X1 + LenX, Y1), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y1), Point(X1, Y1 + LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y1), Point(X2 - LenX, Y1), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y1), Point(X2, Y1 + LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y2), Point(X1 + LenX, Y2), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y2), Point(X1, Y2 - LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y2), Point(X2 - LenX, Y2), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y2), Point(X2, Y2 - LenY), Color, Thickness, LINE_AA);

	return;
}

// ---------- Draw Boxes And Fill Target Data ----------
void ClassicalDetector::drawBoxes(Mat &VideoFrame)
{
	Rect SafeBox;
	UInt16_t TgtCnt = 0;
	Point FrameCentre(VideoFrame.cols / 2, VideoFrame.rows / 2);

	Size TextSize;
	string Label;
	Int32_t LabelX, LabelY, Baseline;

	if (VideoFrame.empty())
	{
		TgtData.TgtDataStruct.Header[0] = AI_ID;
		TgtData.TgtDataStruct.Header[1] = C4I_ID;
		TgtData.TgtDataStruct.Header[2] = TgtDataCmd;
		TgtData.TgtDataStruct.AIType = AI_Type;
		TgtData.TgtDataStruct.CheckSum = 0x00;
		TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
		TgtData.TgtDataStruct.TargetLimit = TargetLimit;
		TgtData.TgtDataStruct.TargetCnt = 0;
		TgtData.TgtDataStruct.DataLen = 0x05;
		TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;
		return;
	}

	for (auto &Target : TargetDataArr)
	{
		SafeBox = Target.BoundingBox & Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
		if (SafeBox.width <= 0 || SafeBox.height <= 0)
		{
			continue;
		}

		Target.BoundingBox = SafeBox;
		Target.CenterPoint = Point(SafeBox.x + SafeBox.width / 2, SafeBox.y + SafeBox.height / 2);

		drawCornerBox(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 1, 25);

		Baseline = 0;
		Label = "Tgt " + to_string(TgtCnt + 1) + " (" + to_string(Target.CenterPoint.x - VideoFrame.cols / 2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows / 2) + ")";
		TextSize = getTextSize(Label, FONT_HERSHEY_SIMPLEX, LabelScale, 1, &Baseline);
		LabelX = clamp(Target.BoundingBox.x, 0, FindMax(0, VideoFrame.cols - TextSize.width - 2));
		LabelY = (Target.BoundingBox.y - 5 > TextSize.height) ? Target.BoundingBox.y - 5 : FindMin(VideoFrame.rows - 2, Target.BoundingBox.y + Target.BoundingBox.height + TextSize.height + 4);

		putText(VideoFrame, Label, Point(LabelX, LabelY), FONT_HERSHEY_SIMPLEX, LabelScale, Scalar(255, 255, 255), 1);
		line(VideoFrame, FrameCentre, Target.CenterPoint, Scalar(255, 255, 255), 1, LINE_AA);

		cout << VideoLabel << " : Ny:" << (Target.CenterPoint.x - VideoFrame.cols / 2) << " Nz:" << (Target.CenterPoint.y - VideoFrame.rows / 2) << " W:" << Target.BoundingBox.width << " H:" << Target.BoundingBox.height << " Conf:" << (UInt32_t)(Target.Confidance * 100) << "%" << endl
			 << flush;

		TargetData.ClassID = Target.ClassID;
		TargetData.TrackID = Target.TrackID;
		TargetData.Ny = Target.CenterPoint.x - VideoFrame.cols / 2;
		TargetData.Nz = Target.CenterPoint.y - VideoFrame.rows / 2;
		TargetData.Width = Target.BoundingBox.width;
		TargetData.Height = Target.BoundingBox.height;
		TargetData.Confidance = Target.Confidance * 100;

		if (TgtCnt < 5000)
		{
			TgtData.TgtDataStruct.TgtData[TgtCnt] = TargetData;
			TgtCnt++;
		}
	}

	TgtData.TgtDataStruct.Header[0] = AI_ID;
	TgtData.TgtDataStruct.Header[1] = C4I_ID;
	TgtData.TgtDataStruct.Header[2] = TgtDataCmd;
	TgtData.TgtDataStruct.AIType = AI_Type;
	TgtData.TgtDataStruct.CheckSum = 0x00;
	TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
	TgtData.TgtDataStruct.TargetLimit = TargetLimit;
	TgtData.TgtDataStruct.TargetCnt = TgtCnt;
	TgtData.TgtDataStruct.DataLen = 0x05 + (TgtCnt * sizeof(struct _TargetData_));
	TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;

	return;
}

// ---------- Constructor ----------
ClassicalDetector::ClassicalDetector(string Label)
{
	StaticCoordFrames = 10;

	MaxMissedFrames = 15;
	StationaryStableFrames = 6;
	StationarySizeTolerance = 4;
	StationaryMaxMissedFrames = 2;
	CentreHoldMaxFrames = 3;
	CentreMissedFrames = 0;
	RepeatedFrameNumber = 0;
	StationaryPositionTolerance = 3.0;
	StationaryMatchDistance = 12.0;
	VideoLabel = Label;
	LabelScale = 0.45F;

	return;
}

// ---------- Destructor ----------
ClassicalDetector::~ClassicalDetector(void)
{
	TargetDataArr.clear();
	TrackArr.clear();

	return;
}

// ---------- Object Detection ----------
void ClassicalDetector::Detector(Mat &VideoFrame)
{
	struct _AIData_ DetectData;
	vector<vector<Point>> Contours;
	vector<struct _AIData_> Candidates;

	float DogThreshold;
	bool DetectorReturnedAny;
	double DogMean, DogNorm, Score;
	double Aspect, Extent, RelativeArea;
	double FrameArea, MinArea, MaxAreaPercent, Area;

	Rect Box;
	Mat GrayFrame;
	Mat G1A, G2A, DogA;
	Mat G1B, G2B, DogB;
	Mat DogA32, DogB32;
	Mat AbsA, AbsB, DogConf;
	Mat MaskA, MaskB, CombinedMask;

	TargetDataArr.clear();

	// ============================================================
	// IMPORTANT: Validate incoming frame
	// ============================================================
	if (VideoFrame.empty() || VideoFrame.cols <= 0 || VideoFrame.rows <= 0 || VideoFrame.data == nullptr)
	{
		cerr << "[ClassicalDetector][" << VideoLabel << "] Invalid/Empty input frame." << " Size=" << VideoFrame.cols << "x" << VideoFrame.rows << endl
			 << flush;

		// Do not retain stale targets from previous frame
		LastCentreTargetArr.clear();
		CentreMissedFrames = 0;

		drawBoxes(VideoFrame);
		return;
	}

	int channels = VideoFrame.channels();

	if (channels == 1)
	{
		VideoFrame.copyTo(GrayFrame);
	}
	else if (channels == 3)
	{
		cvtColor(VideoFrame, GrayFrame, COLOR_BGR2GRAY);
	}
	else if (channels == 4)
	{
		cvtColor(VideoFrame, GrayFrame, COLOR_BGRA2GRAY);
	}
	else
	{
		cerr << "[ClassicalDetector][" << VideoLabel
			 << "] Unexpected channel count: "
			 << channels << endl
			 << flush;

		return;
	}

	// Extra protection before image processing
	if (GrayFrame.empty())
	{
		cerr << "[ClassicalDetector][" << VideoLabel
			 << "] GrayFrame is empty."
			 << endl
			 << flush;

		return;
	}

	// ============================================================
	// EXISTING CODE CONTINUES FROM HERE
	// ============================================================

	GaussianBlur(GrayFrame, G1A, Size(3, 3), 0.8);
	GaussianBlur(GrayFrame, G2A, Size(7, 7), 2.0);
	subtract(G1A, G2A, DogA, noArray(), CV_16S);

	GaussianBlur(GrayFrame, G1B, Size(5, 5), 1.5);
	GaussianBlur(GrayFrame, G2B, Size(11, 11), 3.5);
	subtract(G1B, G2B, DogB, noArray(), CV_16S);

	DogA.convertTo(DogA32, CV_32F);
	DogB.convertTo(DogB32, CV_32F);

	absdiff(DogA32, Scalar(0), AbsA);
	absdiff(DogB32, Scalar(0), AbsB);
	max(AbsA, AbsB, DogConf);

	DogThreshold = adaptiveResponseThreshold(DogConf);
	MaskA = blobMask(DogA32, DogThreshold);
	MaskB = blobMask(DogB32, DogThreshold);
	bitwise_or(MaskA, MaskB, CombinedMask);
	cleanupMask(CombinedMask);

	findContours(CombinedMask, Contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

	FrameArea = FindMax(1.0,
						static_cast<double>(GrayFrame.cols) * GrayFrame.rows);

	MinArea = FindMax(
		static_cast<double>(Config.MIN_CONTOUR_AREA),
		FrameArea * Config.MIN_AREA_FRAC);

	MaxAreaPercent = Config.MAX_AREA_FRAC * 100.0;

	for (auto &Contour : Contours)
	{
		Area = contourArea(Contour);

		if (Area <= MinArea)
		{
			continue;
		}

		Box = boundingRect(Contour);

		if (Box.width <= 0 || Box.height <= 0)
		{
			continue;
		}

		if (Box.x < 0 ||
			Box.y < 0 ||
			Box.x + Box.width > GrayFrame.cols ||
			Box.y + Box.height > GrayFrame.rows)
		{
			continue;
		}

		if (Box.y > GrayFrame.rows * Config.MAX_VERTICAL_POSITION)
		{
			continue;
		}

		Aspect = static_cast<double>(Box.width) / Box.height;
		Extent = Area / (Box.width * Box.height);
		RelativeArea = (Area / FrameArea) * 100.0;

		if (!(Config.MIN_ASPECT < Aspect &&
			  Aspect < Config.MAX_ASPECT &&
			  Extent > Config.MIN_EXTENT &&
			  RelativeArea < MaxAreaPercent))
		{
			continue;
		}

		DogMean = mean(DogConf(Box))[0];
		DogNorm = FindMin(DogMean / 50.0, 1.0);
		Score = DogNorm * priorWeight(Box, GrayFrame.size());

		DetectData.ClassID = 0;
		DetectData.TrackID = 0;

		DetectData.Confidance =static_cast<float>(clamp(0.40 + (Score * 0.55), 0.0, 0.99));

		DetectData.BoundingBox = Box;

		DetectData.CenterPoint =
			Point(Box.x + Box.width / 2,
				  Box.y + Box.height / 2);

		Candidates.push_back(DetectData);
	}

	TargetDataArr = applyNMS(Candidates, 0.18f);

	DetectorReturnedAny = !TargetDataArr.empty();

	if (TargetLimit != 0U)
	{
		TargetDataArr =
			filterRepeatedCoordinates(TargetDataArr);

		if (!TargetDataArr.empty())
		{
			selectNearestCentreTargets(VideoFrame.size());
		}
		else if (DetectorReturnedAny == false)
		{
			appendCentreHoldTargets(VideoFrame.size());
		}
		else
		{
			LastCentreTargetArr.clear();
			CentreMissedFrames = 0;
		}
	}
	else
	{
		TargetDataArr =
			filterStationaryTargets(TargetDataArr);
	}

	drawBoxes(VideoFrame);

	return;
}