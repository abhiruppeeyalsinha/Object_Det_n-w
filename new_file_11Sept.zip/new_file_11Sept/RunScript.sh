#============================================================================
# Name        : RunScript.sh
# Author      : Solar Industries
# Date        : 21 Jan 2026
#============================================================================

#!/bin/bash

# Run only on IPCard
if [ "$(uname -m)" = "aarch64" ]; then
    # Enable Ethernet Connection
    nmcli --wait 0 connection up eth0_static &
    nmcli --wait 0 connection up eth1_static &

    /usr/sbin/nvpmodel -m 8 &   # 20W 6 Core Mode
    /usr/bin/jetson_clocks &    # Enable Clock
fi

# Kill only if exists
pidof Exe-IPCard >/dev/null && pkill Exe-IPCard || true

# -S or -SD flag for data saving
FLAG_S=false
FLAG_SD=false
code_pid=""

for arg in "$@"; do
    case "$arg" in
        -S)  FLAG_S=true ;;
        -SD) FLAG_SD=true ;;
    esac
done

# Get absolute path to the script and its executable
EXE_DIR="$(cd "$(dirname "$0")" && pwd)"

# ------ Enable Signal Handler -----
signalHandler() {
    echo "Stopping Exe-IPCard..."
    pkill -SIGINT "$code_pid" 2>/dev/null || true
}
trap 'signalHandler' INT TERM


# ------ Fast Mode -----
if ! $FLAG_S && ! $FLAG_SD; then
    sudo env LD_LIBRARY_PATH="$EXE_DIR"/Lib "$EXE_DIR"/Exe-IPCard -BP "$@" & code_pid=$!

    wait $code_pid
    echo "Output Not Saved"
    exit 0
fi

# ------ Data logging Mode -----
# Get current date like 06Dec24
DATE=$(date +"%d%b%y")

# Result directory
if $FLAG_SD; then RES_DIR="/mnt/sdcard/IPData/Res/$DATE"
else RES_DIR="$EXE_DIR/Res/$DATE"
fi

# Create the result directory if it dosent exists
mkdir -p -m 775 "$RES_DIR"

# Loop through matching directories (handle no matches)
TEST_NUM=-1
for d in "$RES_DIR"/Test*; do
    # Skip if pattern didn’t match and literal exists
    [ ! -d "$d" ] && continue

    # Extract numeric part
    n=${d##*Test}

    # Check if numeric
    case "$n" in
        ''|*[!0-9]*) continue ;;
    esac

    # Compare and store max
    if [ "$n" -gt "$TEST_NUM" ]; then
        TEST_NUM=$n
    fi
done

# Next test number
TEST_NUM=$((TEST_NUM + 1))

# Create the new test directory
TEST_DIR="$RES_DIR/Test$TEST_NUM"
mkdir -p -m 775 "$TEST_DIR"

# Define the output log file
LOG_FILE="$TEST_DIR/RunLog.txt"

# Add Run Time in File
CURR_TIME=$(date +"%d-%m-%Y %H:%M:%S")
echo Test Running Time - "$CURR_TIME\n" | tee -a "$LOG_FILE"

# Run the executable
sudo env LD_LIBRARY_PATH="$EXE_DIR"/Lib stdbuf -oL "$EXE_DIR"/Exe-IPCard -PT "$TEST_DIR/" -BP "$@" 2>&1 | tee -a "$LOG_FILE" & code_pid=$!

wait $code_pid
echo "Output has been saved to : $TEST_DIR"
exit 0




