// ============================================================================
// Name		: CamRS422.h
// Date		: 21 Jan 2026
// ============================================================================


#ifndef CAMRS422_H_
#define CAMRS422_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"


// ---------- IPCard Status Variables ----------
extern bool NUCStatus;
extern bool SeekerStatus;


// ---------- Other Flag Variables ----------
extern bool CamPortStatus;
extern bool CpuAffinityFlag;


// ---------- Thread Flag Variables ----------
extern bool CamHandShakeThreadFlag;


// ---------- Class Declaration ----------
class CamRS422
{
private:
	Int8_t rxBuff[50];
	struct termios Camtty;
	Int32_t CamRecvFD, CamTransmitFD;

	 Int32_t ePollFD;
	 epoll_event event;

public:
	// Constructor
	CamRS422(void);

	// Destructor
	~CamRS422(void);

	// HandShake
	bool HandShake(void);

	// Nuc 1PT
	bool Nuc_1PT(UInt8_t Type);

	// HandShake Thread
	static void *HandShakeThread(void *args);
};


#endif /* CAMRS422_H_ */




