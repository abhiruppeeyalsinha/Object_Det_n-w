// ============================================================================
// Name		: ObjDetection.h
// Date		: 21 Jan 2026
// ============================================================================

// #ifndef OBJDETECTION_H_
// #define OBJDETECTION_H_

// // ---------- Header Inclusion ----------
// #include "Includes.h"
// #include "Struct.h"

// // ---------- IPCard Status Variables ----------
// extern bool AIStatusFlag;

// // ---------- AI Flag Variables ----------
// extern bool TargetDataFlag;
// extern bool DetectObjectFlag;
// extern bool BirdPlaneDataFlag;
// extern bool TemplateMatchingFlag;

// // ---------- Camera Variables ----------
// extern Size VideoDim;

// // ---------- AI Parameters ----------
// extern string ModelPath;
// extern Int16_t ROI_Loc[2];
// extern UInt16_t ROI_Dim[2];
// extern string ClassName[4];
// extern struct _TargetData_ TargetData;

// // ---------- Class Declaration ----------
// class ObjDetection
// {
// private:
// 	UInt32_t Detections;
// 	UInt32_t DetectionSize;
// 	UInt32_t ClassCnt;

// 	Size Yolov5_Dim;
// 	float ConfThreshold;
// 	float IOUThreshold;

// 	vector<struct _AIData_> TargetDataArr;

// 	float TempConfThreshold;
// 	UInt16_t TemplateFrameCnt;
// 	UInt8_t ActiveArr, StoreArr, MaxTemplateCnt;
// 	vector<struct _Template_> TemplateArr[2];

// 	unique_ptr<IRuntime> runtime;
// 	unique_ptr<ICudaEngine> engine;
// 	unique_ptr<IExecutionContext> context;

// 	vector<void *> Bindings;
// 	vector<size_t> BindingSizes;

// 	cudaStream_t rawStream;
// 	cuda::Stream cvStream;	// Dummy Check

// public:
// 	// Constructor
// 	ObjDetection(void);

// 	// Destructor
// 	~ObjDetection(void);

// 	// Get Memory Size
// 	size_t getMemorySize(Dims dims, size_t ElementSize);

// 	// Load Engine File
// 	bool LoadEngineFile(void);

// 	// PreProcess
// 	void preProcess(Mat VideoFrame, __half *InputBuff);

// 	// PostProcess
// 	void postProcess(UInt16_t VideoWidth, UInt16_t VideoHeight);

// 	// Template Matching
// 	void templateMatch(Mat &VideoFrame);

// 	// Draw Boxes & Sort Using ROI
// 	void drawBoxes(Mat &VideoFrame);

// 	// Detect Object Function
// 	void RunEnqueueV2(Mat &VideoFrame);
// };

// #endif /* OBJDETECTION_H_ */

// ========================= @2 ==================================================

// ObjDetection.h

// #ifndef OBJDETECTION_H_
// #define OBJDETECTION_H_

// // ---------- Header Inclusion ----------
// #include "Includes.h"
// #include "Struct.h"

// // ---------- IPCard Status Variables ----------
// extern bool AIStatusFlag;

// // ---------- AI Flag Variables ----------
// extern bool TargetDataFlag;
// extern bool DetectObjectFlag;
// extern bool BirdPlaneDataFlag;
// extern bool TemplateMatchingFlag;

// // ---------- Camera Variables ----------
// extern Size VideoDim;

// // ---------- AI Parameters ----------
// extern string ModelPath;
// extern Int16_t ROI_Loc[2];
// extern UInt16_t ROI_Dim[2];
// extern string ClassName[4];
// extern struct _TargetData_ TargetData;

// // ---------- Class Declaration ----------
// class ObjDetection
// {
// private:
// 	UInt32_t Detections;
// 	UInt32_t DetectionSize;
// 	UInt32_t ClassCnt;
// 	Size Yolov5_Dim;

// 	float ConfThreshold;
// 	float IOUThreshold;

// 	vector<struct _AIData_> TargetDataArr;

// 	float TempConfThreshold;
// 	UInt16_t TemplateFrameCnt;
// 	UInt8_t ActiveArr, StoreArr, MaxTemplateCnt;
// 	vector<struct _Template_> TemplateArr[2];

// 	unique_ptr<IRuntime> runtime;
// 	unique_ptr<ICudaEngine> engine;
// 	unique_ptr<IExecutionContext> context;
// 	vector<void *> Bindings;
// 	vector<size_t> BindingSizes;

// 	cudaStream_t rawStream;
// 	cuda::Stream cvStream;

// public:
// 	// Constructor
// 	ObjDetection(void);

// 	// Destructor
// 	~ObjDetection(void);

// 	// Get Memory Size
// 	size_t getMemorySize(Dims dims, size_t ElementSize);

// 	// Load Engine File
// 	bool LoadEngineFile(void);

// 	// PreProcess
// 	void preProcess(Mat VideoFrame, __half *InputBuff);

// 	// PostProcess
// 	void postProcess(UInt16_t VideoWidth, UInt16_t VideoHeight);

// 	// Template Matching
// 	void templateMatch(Mat &VideoFrame);

// 	// Draw Boxes & Sort Using ROI
// 	void drawBoxes(Mat &VideoFrame);

// 	// Detect Object Function
// 	void RunEnqueueV2(Mat &VideoFrame);
// };

// #endif /* OBJDETECTION_H_ */

// ========================= @3 ===============================

// ============================================================================
// Name     : ObjDetection.h
// Date     : 16 AUg 2026 For Robust 600m Drone Tracking
// ============================================================================

#ifndef OBJDETECTION_H_
#define OBJDETECTION_H_

// ---------- Header Inclusion ----------
#include "Includes.h"
#include "Struct.h"
#include "SysConfig.h"
#include <opencv2/video/tracking.hpp>

// ---------- IPCard Status Variables ----------
extern bool AIStatusFlag;

// ---------- AI Flag Variables ----------
extern bool TargetDataFlag;
extern bool DetectObjectFlag;
extern bool BirdPlaneDataFlag;
extern bool TemplateMatchingFlag;
extern mutex TargetDataMutex;

// ---------- Camera Variables ----------
extern Size VideoDim;

// ---------- AI Parameters ----------
extern string ModelPath;
extern Int16_t ROI_Loc[2];
extern UInt16_t ROI_Dim[2];
extern string ClassName[4];
extern struct _TargetData_ TargetData;

// ---------- Robust Track Structure ----------
// Replaces the legacy ping-pong TemplateArr[2] with stateful, Kalman-filtered tracks.
struct Track
{
	uint32_t id;	  // Unique track ID
	uint8_t classId;  // Object class
	Rect bbox;		  // Current bounding box (integer pixels)
	Size2f aiBoxSize; // Last AI-confirmed object size; never compounded by TM
	Point2f center;	  // Sub-pixel center
	Point2f predictedCenter; // Exactly one Kalman prediction per frame
	float confidence; // Last confidence (AI conf or TM correlation score)

	Mat templateImg;	  // Grayscale template for TM fallback
	uint32_t templateAge; // Frames since last template update

	uint32_t age;		   // Total frames since creation
	uint32_t missedFrames; // Consecutive frames without measurement
	uint32_t aiMissedFrames; // Consecutive frames without AI confirmation
	bool isActive;		   // Track is alive
	bool isTemplateBased;  // Last update came from TM (not AI)
	bool isPredictedOnly;  // No measurement; position is Kalman-only
	bool updatedThisFrame; // Got a measurement this frame

	cv::KalmanFilter kf; // Constant-velocity Kalman filter (4-state)
	float bestScale;	 // Best TM scale factor from last multi-scale match

	Track()
		: id(0), classId(0), confidence(0.0f),
		  templateAge(0), age(0), missedFrames(0), aiMissedFrames(0),
		  isActive(false), isTemplateBased(false), isPredictedOnly(false),
		  updatedThisFrame(false), bestScale(1.0f) {}
};

// ---------- Class Declaration ----------
class ObjDetection
{
private:
	// Ai inference parameters
	UInt32_t Detections;
	UInt32_t DetectionSize;
	UInt32_t ClassCnt;
	Size Yolov5_Dim;
	float ConfThreshold;
	float IOUThreshold;

	// Per-frame AI detection buffer (populated by postProcess)
	vector<struct _AIData_> TargetDataArr;

	// Robust tracking database
	vector<Track> tracks;
	uint32_t nextTrackId;

	// Tracking tuning constants (tuned for 4–5 px IR targets at 600 m)
	static constexpr uint32_t MAX_TRACKS = 5;
	static constexpr uint32_t MAX_MISSED_FRAMES = 5; // Short Kalman-only bridge
	static constexpr uint32_t MAX_AI_MISSED_FRAMES = 30; // Bound template-only drift
	static constexpr float MIN_TEMPLATE_SIZE = 3.0f;  // Absolute minimum target size
	static constexpr float KALMAN_PROCESS_NOISE = 1e-3f;
	static constexpr float KALMAN_MEASUREMENT_NOISE = 1e-1f;
	static constexpr float TM_SCORE_THRESHOLD = 0.72f; // For TM_CCOEFF_NORMED
	static constexpr float TM_PEAK_MARGIN = 0.03f; // Reject ambiguous repeated hot spots

	// TensorRT handles
	unique_ptr<IRuntime> runtime;
	unique_ptr<ICudaEngine> engine;
	unique_ptr<IExecutionContext> inference;
	string InputTensorName;
	string OutputTensorName;
	nvinfer1::DataType InputDataType;
	nvinfer1::DataType OutputDataType;
	unordered_map<string, void *> DeviceBuffers;
	unordered_map<string, size_t> BufferSizes;

	// Persistent page-locked/device staging buffers.
	unsigned char *hostInputPinned;
	unsigned char *deviceInputFrame;
	size_t deviceInputPitch;
	void *hostOutputPinned;
	size_t outputElementCount;
	cudaStream_t rawStream;
	cudaEvent_t pipelineStartEvent;
	cudaEvent_t preprocessDoneEvent;
	cudaEvent_t inferenceDoneEvent;
	cudaEvent_t outputReadyEvent;
	double lastCpuDecodeMs;
	uint64_t processedFrameCount;

	// Legacy parameters (kept for API compatibility)
	float TempConfThreshold;
	UInt16_t TemplateFrameCnt;
	UInt8_t MaxTemplateCnt;

	// ---------- Internal Tracking Helpers ----------
	void initKalman(Track &track);
	Point2f predictKalman(Track &track);
	Point2f updateKalman(Track &track, Point2f measurement);

	bool isValidTemplate(const Mat &templ);
	void updateTemplate(Mat &frame, Track &track, const Rect &newBbox);
	Rect computeSearchRoi(const Track &track, int frameW, int frameH);
	Point2f subPixelRefine(const Mat &response, Point peak);
	float multiScaleTemplateMatch(Mat &frame, Track &track, Point2f &outCenter, Rect &outBbox);

	void createTrack(Mat &frame, const struct _AIData_ &detection);
	void updateTracksWithAI(Mat &frame, vector<struct _AIData_> &detections);
	void updateTracksWithTemplate(Mat &frame);
	void maintainTracks();

public:
	// Constructor
	ObjDetection(void);
	
	// Destructor
	~ObjDetection(void);

	// Get Memory Size
	size_t getMemorySize(Dims dims, size_t ElementSize);
	
	// Load Engine File
	bool LoadEngineFile(void);
	
	// PreProcess
	void preProcess(const Mat &VideoFrame, void *InputBuff);
	
	// PostProcess
	void postProcess(UInt16_t VideoWidth, UInt16_t VideoHeight);
	
	// Template Matching — now full track-management / AI-fusion fallback
	void templateMatch(Mat &VideoFrame);
	
	// Draw Boxes & Sort Using ROI
	void drawBoxes(Mat &VideoFrame);
	
	// Detect Object Function
	void RunEnqueueV3(Mat &VideoFrame, UInt32_t FrameTime, UInt32_t AIStartTime);
};

#endif /* OBJDETECTION_H_ */
