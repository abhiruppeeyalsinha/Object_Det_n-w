// ============================================================================
// Name		: SysConfig.h
// Date		: 21 Jan 2026
// ============================================================================


#ifndef SYSCONFIG_H_
#define SYSCONFIG_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"


// ---------- IPCard Status Variables ----------
extern bool NUCStatus;
extern bool IPAddrStatus;
extern bool SeekerStatus;

// ---------- Other Flag Variables ----------
extern bool ObcCmdFlag;
extern bool SaveDataFlag;
extern bool SDCardSaveFlag;
extern bool TgtDataModeFlag;
extern bool DisplayFrameFlag;

// ---------- AI Flag Variables ----------
extern bool DetectObjectFlag;
extern bool BirdPlaneDataFlag;
extern bool TemplateMatchingFlag;

// ---------- Thread Flag Variables ----------
extern bool ObcDataThreadFlag;
extern bool ProcessThreadFlag;
extern bool DataRecvThreadFlag;
extern bool VideoStreamThreadFlag;
extern bool CamHandShakeThreadFlag;

// ---------- Config Parameters ----------
extern UInt8_t MissileID;
extern UInt8_t HilsComm;
extern UInt8_t IPCardMode;

extern string EthInterface;
extern string EthConName;

// Data Link Configurations
extern Int8_t DL_IPAddr[16];
extern Int32_t DL_UDPPort;

// IP Card Configurations
extern Int8_t IP_IPAddr[16];
extern Int8_t NetMask_Addr[16];
extern Int8_t GateWay_Addr[16];

// UDP Ports Configuration
extern Int32_t HilsUdpPort;


// ---------- Camera Variables ----------
extern string VideoSource;

// ---------- AI Parameters ----------
extern string ModelPath;

// ---------- Data Path ----------
extern string LoadPath;
extern string SavePath;
extern string ParentPath;


// ---------- System Timer ----------
// ---------- Get Current Time in MicroSeconds ----------
UInt64_t GetCurrMicros(void);

// ---------- Get Current Time in MilliSeconds ----------
UInt32_t GetCurrMillis(void);

// ---------- Get Current TimeStamp ----------
string GetTimeStamp(void);

// ---------- Update Time ----------
void UpdateTime(UInt8_t day, UInt8_t month, UInt16_t year, UInt32_t millis);


// ---------- Software CheckSum ----------
// ---------- CRC16 function ----------
UInt16_t crc16(UInt8_t *Data, UInt64_t Len);

// ---------- Calculate software checksum ----------
UInt16_t getSwCheckSum(string Path);


// ---------- Path & Config ----------
// ---------- Create Path ----------
string createPath(string Path);

// ---------- Get Path ----------
string getPath(UInt8_t typ);

// ---------- readFile ----------
string readFile(string path);

// ---------- load Config file Data ----------
void loadConfigData(void);


// ---------- Other ----------
// ----------system Power Off ----------
void systemPowerOff(void);

// ---------- Check Serial Port is available or not ----------
bool releaseUDPPort(Int32_t Port);

// ---------- Compare String ----------
bool cmpStr(const Int8_t *Str1, const Int8_t *Str2, UInt32_t Len);


// ---------- Ethernet ----------
// ---------- Get IP Address ----------
string getIPAddr(string &EthInterface);

// ---------- Modify IP Address Last Byte ----------
void modifyIPAddr(Int8_t *IPAddr, Int32_t Delta);

// ---------- Set IP Address ----------
bool setIPAddr(Int8_t *IPAddr, Int8_t *NetMask, Int8_t *GateWay);


// ---------- User Flags ----------
// ---------- Validate Integer ----------
bool validateInt(Int8_t *str);

// ---------- Validate IP Address ----------
bool validateIP(const Int8_t *Addr);

// ---------- Validate Port Number ----------
Int32_t validatePORT(Int8_t *Port);

// ---------- Check User Flags ----------
void checkFlags(Int32_t argc, Int8_t *argv[]);


#endif /* SYSCONFIG_H_ */




