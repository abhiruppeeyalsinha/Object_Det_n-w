// ============================================================================
// Name		: ObcRS422.h
// Date		: 21 Jan 2026
// ============================================================================


#ifndef OBCRS422_H_
#define OBCRS422_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"

#include "CamRS422.h"
#include "SysConfig.h"


// ---------- IPCard Status Variables ----------
extern bool NUCStatus;
extern bool IPAddrStatus;
extern bool SeekerStatus;
extern bool AIStatusFlag;
extern bool ObcPortStatus;
extern bool CamPortStatus;
extern bool HilsPortStatus;


// ---------- Other Flag Variables ----------
extern bool ObcCmdFlag;
extern bool SaveDataFlag;
extern bool TgtDataModeFlag;
extern bool IPCardReadyFlag;
extern bool CpuAffinityFlag;
extern bool SendTargetDataFlag;


// ---------- AI Flag Variables ----------
extern bool TargetDataFlag;
extern bool DetectObjectFlag;
extern mutex TargetDataMutex;


// ---------- Thread Flag Variables ----------
extern bool ObcDataThreadFlag;
extern bool DataRecvThreadFlag;


// ---------- Software Details ----------
extern UInt16_t SW_CheckSum;
extern string SW_Health;


// ---------- Config Parameters ----------
extern UInt8_t MissileID;
extern UInt8_t IPCardMode;
extern UInt8_t HilsComm;

// Data Link Configurations
extern Int32_t DL_UDPPort;

// IP Card Configurations
extern Int8_t IP_IPAddr[16];

// UDP Ports Configuration
extern Int32_t HilsUdpPort;


// ---------- Camera Variables ----------
extern Size VideoDim;


// ---------- AI Parameters ----------
extern Int16_t ROI_Loc[2];
extern UInt16_t ROI_Dim[2];

extern struct _TargetData_ TargetData;;


// ---------- Data Path ----------
extern string SavePath;


// ---------- Class Objects ----------
extern CamRS422 *CamRS422Obj;


// ---------- Other Declaration ----------
class ObcRS422
{
private:
	Int32_t ObcRecvFD, ObcTransmitFD, HilsRecvFD;
    Int32_t ObcRawFile, ObcDataFile, HilsDataFile;
    struct termios Obctty, Hilstty;

    Int32_t ePollFD;
    epoll_event events[2];

    UInt32_t len;
	Int32_t HilsUdpSock;
	struct sockaddr_in saddr, caddr;

	union _ObcCmd_ ObcCmd;
	union _ObcResp_ ObcResp;
	union _ObcResp_ ObcStat;

	UInt32_t DataTime1, DataTime2;
	union _HilsData_ RecvHils, Hils1Data, Hils2Data;

	UInt32_t TargetDataTime;

public:
	// Open Obc Port
	void openObcPort(void);

	// Open Hils Port
	void openHilsPort(void);

    // Constructor
    ObcRS422(void);

    // Destructor
    ~ObcRS422(void);

    // Checksum Calculation
    UInt8_t calcCheckSum(UInt8_t *, UInt16_t);

    // Print Data
    void printData(union Message *);

    // Send Message
    void sendMsg(union _ObcResp_ ObcResp);

    // Send Ack Nack
	void sendAckNack(UInt8_t CmdID, UInt8_t Type);

	// Send Health
	void sendHealth(void);

    // Target Data Send
    void sendTargetData(void);

    // Process Obc Data
    void processObcData(void);

    // Process Hils Data
    void processHilsData(void);

    // Obc Data
    void ObcData(void);

    // Data Receive
    void DataRecv(void);

    // Timer Thread
    static void *ObcDataThread(void *args);

    // ObcRS422 Receive Thread
    static void *DataRecvThread(void *args);
};


#endif /* OBCRS422_H_ */



