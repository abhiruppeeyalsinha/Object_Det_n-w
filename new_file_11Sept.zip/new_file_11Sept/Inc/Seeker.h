// ============================================================================
// Name		: Seeker.h
// Date		: 21 Jan 2026
// ============================================================================


#ifndef SEEKER_H_
#define SEEKER_H_


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "ObcRS422.h"


// ---------- IPCard Status Variables ----------
extern bool SeekerStatus;


// ---------- Other Flag Variables ----------
extern bool SaveDataFlag;
extern bool TgtDataModeFlag;
extern bool IPCardReadyFlag;
extern bool CpuAffinityFlag;
extern bool DisplayFrameFlag;
extern bool SendTargetDataFlag;


// ---------- Thread Flag Variables ----------
extern bool ProcessThreadFlag;
extern bool VideoStreamThreadFlag;


// ---------- Config Parameters ----------
extern UInt8_t MissileID;

// Data Link Configurations
extern Int8_t DL_IPAddr[16];
extern Int32_t DL_UDPPort;


// ---------- Camera Variables ----------
extern string VideoSource;
extern UInt32_t VideoFPS;
extern Size VideoDim;
extern UInt32_t FrameDelay;


// ---------- Data Path ----------
extern string SavePath;


// ---------- Video & Processed Data Variables ----------
extern struct _VideoData_ CameraData;
extern struct _VideoData_ ProcessedData;
extern mutex CameraDataMutex;
extern mutex ProcessedDataMutex;


// ---------- Class Declaration ----------
class Seeker
{
private:

#if _VIDEO_FFMPEG_

	// IR Video Stream Variables
	AVFormatContext *pFormatCtx;
	AVCodecContext *pCodecCtx;

	AVFrame *pFrame, *pFrameEO;
	AVPacket *packet;

	uint8_t *out_buffer;
	struct SwsContext *img_convert_ctx;

	AVDictionary *avdic;
	const AVCodec *pCodec;

	int numBytes, videoStream;
	UInt32_t LastIOTime;

	AVInputFormat *inpFormat;

#else

	VideoCapture CAM;

#endif


	VideoWriter OutVid;
	UInt8_t VideoInd;

	UInt32_t len;
	Int32_t UDPSock;
	struct sockaddr_in caddr;

public:
	// Constructor
	Seeker(void);

	// Destructor
	~Seeker(void);

	// Read Frames
	void ReadFrames(void);

	// Video Stream
	void VideoStream(void);

	// Read Frames Thread
	static void *ReadFramesThread(void *args);

	// Video Stream Thread
	static void *VideoStreamThread(void *args);
};


#endif /* SEEKER_H_ */



