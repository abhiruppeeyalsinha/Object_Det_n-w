// ============================================================================
// Name		: Struct.h
// Date		: 21 Jan 2026
// ============================================================================


#ifndef STRUCT_H_
#define STRUCT_H_


// ---------- Header Inclusion ----------
#include "Includes.h"


// ---------- Macros ----------
#define  FindMin(A, B)		(((A) < (B)) ? (A) : (B))
#define  FindMax(A, B)		(((A) > (B)) ? (A) : (B))


// ---------- OBC RS422 Port details ----------
// #define  ObcPort 			"/dev/tty10"		// For Testing
#define  ObcPort 			"/dev/ttyTHS1"			// Connector J5
#define  ObcBAUD 			B921600


// ---------- Camera RS422 Port details ----------
// #define  CamPort 			"/dev/tty11"		// For Testing
#define  CamPort 			"/dev/camera_uart"		// IPEX Connector
#define  CamBAUD 			B57600


// ---------- Hils RS422 Port details ----------
// #define  HilsPort 			"/dev/tty12"		// For Testing
#define  HilsPort 			"/dev/uart_device"		// Connector J8
#define  HilsBAUD 			B115200


// ---------- Device IDs ----------
#define  HilsPC_ID			0x22
#define  Seeker_ID			0x20
#define  IPCard_ID			0x37
#define  OBCCard_ID			0x09
#define  DataLink_ID		0x70


// ---------- OBC Commands ----------
#define  ConfigCmdID		0x65
#define  NucCmdID			0x8C
#define  HealthCmdID		0x8B
#define  TgtDataCmdID		0x8D
#define  ShutDownCmdID		0x8E


// ---------- Camera Commands ----------
extern Int8_t Cam_HandShake[1];
extern Int8_t Cam_ManNUC[7];
extern Int8_t Cam_ExtNUC[7];

// ---------- Camera Response ----------
extern Int8_t Cam_HandShake_Resp_ANA[3];
extern Int8_t Cam_HandShake_Resp_IN[3];
extern Int8_t Cam_NUC_Resp[7];


#pragma pack(1)

// Target Data Structure
struct _TargetData_
{
	UInt8_t ClassID;
	Point CenterPoint;
	Rect BoundingBox;
	float Confidance;
	UInt8_t ValidData;
	UInt32_t FrameTime;
	UInt32_t AIStartTime;
	UInt32_t AIEndTime;
};


// AI Data Structure
struct _AIData_
{
	UInt8_t ClassID;
	Point CenterPoint;
	Rect BoundingBox;
	float Confidance;
	UInt8_t Type;
};


// Template Data Structure
struct _Template_
{
	Mat Template;
	UInt8_t ClassID;
	Point CenterPoint;
	Rect BoundingBox;

	UInt8_t StaticCnt;        // NEW: counter for consecutive static frames
	Point LastCenter;         // NEW: previous frame's center point for movement detection

	Rect ROIBox;
	Rect OverLapBox;

	UInt16_t FrameCnt;

	~_Template_(void)
	{
		Template.release();
	}
};


// Video Data Structure
struct _VideoData_
{
	Mat VideoFrame;
	UInt32_t FrameTime;
	UInt32_t AIStartTime;
	UInt32_t AIEndTime;
	bool FrameFlag;

	~_VideoData_(void)
	{
		VideoFrame.release();
	}
};


struct _IPStat_
{
	UInt32_t CameraStatus 	: 1;
	UInt32_t NUCStatus 		: 1;
	UInt32_t IPAddrStatus 	: 1;
	UInt32_t AIStatusFlag 	: 1;
	UInt32_t Reserved1 		: 1;
	UInt32_t Reserved2 		: 1;
	UInt32_t Reserved3 		: 1;
	UInt32_t Reserved4 		: 1;
};


// RS422 OBC Command Union-Structure
union _ObcCmd_
{
	// Obc command buffer
	UInt8_t ObcCmdBuff[100];

	// Time Sync command
	struct _ConfigCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t MissileID;
		UInt32_t Time;
		UInt8_t Day;
		UInt8_t Month;
		UInt16_t Year;
		UInt8_t CheckSum;
	} ConfigCmd;


	// Health command
	struct _HealthCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Dummy;
		UInt8_t CheckSum;
	} HealthCmd;


	// Nuc command
	struct _NucCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Dummy;
		UInt8_t CheckSum;
	} NucCmd;


	// Shut Down command
	struct _ShutDownCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Dummy;
		UInt8_t CheckSum;
	} ShutDownCmd;


	// Target data command
	struct _TargetDataCmd_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		Int16_t Ny;
		Int16_t Nz;
		UInt16_t Height;
		UInt16_t Width;
		UInt8_t IPCardMode;
		UInt8_t CheckSum;
	} TargetDataCmd;
};


// RS422 OBC Response Union-Structure
union _ObcResp_
{
	// Obc response buffer
	UInt8_t ObcRespBuff[100];

	// Health response structure
	struct _HealthResp_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t SwVersion[18];
		UInt16_t SWCheckSum;
		struct _IPStat_ IpStatus;
		UInt8_t CheckSum;
	} HealthResp;


	// Target data response structure
	struct _TargetDataResp_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		Int16_t Ny;
		Int16_t Nz;
		UInt16_t Height;
		UInt16_t Width;
		UInt8_t Confidance;
		UInt8_t DetectStatus;
		UInt32_t FrameTime;
		UInt32_t AIStartTime;
		UInt32_t AIEndTime;
		UInt32_t IPTime;
		struct _IPStat_ IpStatus;
		UInt8_t CheckSum;
	} TargetDataResp;

	// Target data response structure
	struct _AckNackResp_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		UInt8_t Ack;
		UInt8_t CheckSum;
	} AckNackResp;
};


// Target data response structure
union _HilsData_
{
	UInt8_t Buff[100];

	struct _HilsDataStruct_
	{
		UInt8_t Header[3];
		UInt8_t Length;
		Int16_t Ny;
		Int16_t Nz;
		UInt16_t Height;
		UInt16_t Width;
		UInt8_t Confidance;
		UInt8_t DetectStatus;
		UInt32_t FrameTime;
		UInt32_t AIStartTime;
		UInt32_t AIEndTime;
		UInt32_t IPTime;
		UInt8_t CheckSum;
	} HilsDataStruct;
};



#pragma pack()


#endif /* STRUCT_H_ */




