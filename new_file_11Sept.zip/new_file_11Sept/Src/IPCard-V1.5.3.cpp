//============================================================================
// Name			: IPCard-V1.5.3.cpp
// Author		: Solar Industries
// Version		: V01.05.03
// Released On  : 21 Jan 2026
//============================================================================


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"

#include "Seeker.h"
#include "CamRS422.h"
#include "ObcRS422.h"
#include "ObjDetection.h"


// ---------- IPCard Status Variables ----------
bool NUCStatus = false;
bool IPAddrStatus = false;
bool SeekerStatus = false;
bool AIStatusFlag = false;
bool ObcPortStatus = true;
bool CamPortStatus = true;
bool HilsPortStatus = true;


// ---------- Other Flag Variables ----------
bool ObcCmdFlag = false;
bool SaveDataFlag = false;
bool SDCardSaveFlag = false;
bool TgtDataModeFlag = false;
bool IPCardReadyFlag = false;
bool CpuAffinityFlag = false;
bool DisplayFrameFlag = false;
bool SendTargetDataFlag = false;


// ---------- AI Flag Variables ----------
bool TargetDataFlag = false;
bool DetectObjectFlag = false;
bool BirdPlaneDataFlag = false;
bool TemplateMatchingFlag = false;


// ---------- Thread Flag Variables ----------
bool ObcDataThreadFlag = true;
bool ProcessThreadFlag = true;
bool DataRecvThreadFlag = true;
bool VideoStreamThreadFlag = true;
bool CamHandShakeThreadFlag = true;


// ---------- Software Details ----------
UInt16_t SW_CheckSum = 0U;
string SW_Health = "21/01/26 V01.05.03";	// DD/MM/YY V01.00.00


// ---------- Config Parameters ----------
UInt8_t MissileID = 1U;
UInt8_t IPCardMode = 0U;
UInt8_t HilsComm = 1U;

string EthInterface = "";
string EthConName = "";

// Data Link Configurations
Int8_t DL_IPAddr[16];
Int32_t DL_UDPPort;

// IP Card Configurations
Int8_t IP_IPAddr[16] = "127.0.0.1";
Int8_t NetMask_Addr[16] = "255.255.255.0";
Int8_t GateWay_Addr[16] = "127.0.0.1";

// UDP Ports Configuration
Int32_t HilsUdpPort = 0;


// ---------- Camera Variables ----------
string VideoSource;
UInt32_t VideoFPS = 25U;
Size VideoDim(640, 480);
UInt32_t FrameDelay = 1000U / VideoFPS;	// in MilliSeconds


// ---------- AI Parameters ----------
string ModelPath = "";
Int16_t ROI_Loc[2] = {320, 240};			// Ny, Nz
UInt16_t ROI_Dim[2] = {640, 480};			// Width, Height
string ClassName[4] = {"Bird", "Fixed", "Hexa", "Plane"};

struct _TargetData_ TargetData;
mutex TargetDataMutex;


// ---------- Data Path ----------
string LoadPath = "";
string SavePath = "";
string ParentPath = "";


// ---------- Video & Processed Data Variables ----------
struct _VideoData_ CameraData;
struct _VideoData_ ProcessedData;
mutex CameraDataMutex;
mutex ProcessedDataMutex;


// ---------- Class Objects ----------
Seeker       *SeekerObj;
CamRS422     *CamRS422Obj;
ObcRS422     *ObcRS422Obj;
ObjDetection *ObjDetectionObj;


// ---------- Thread Variables ----------
pthread_t ObcDataThread;
pthread_t DataRecvThread;
pthread_t ReadFramesThread;
pthread_t VideoStreamThread;
pthread_t CamHandShakeThread;


// ---------- Function Decelerations ----------
// ---------- signal Handler ----------
void signalHandler(Int32_t Signal);

// ---------- Close Process ----------
void closeProcess(void);


// ---------- Main Function ----------
int main(Int32_t argc, Int8_t *argv[])
{
	UInt8_t DetectionCnt = 0;
	struct _VideoData_ VideoData;

	UInt32_t AIStartTime;
	UInt64_t totalTime;
	steady_clock::time_point processStart;

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 10;		// 10 microseconds

	// Register signal_handler for CNTL+C
	signal(SIGINT, signalHandler);

	// Calculate Software CheckSum
	SW_CheckSum = getSwCheckSum(getPath(0));

	cout << "Software Details  : " << SW_Health << endl;
	cout << "Software Checksum : 0x" << hex << uppercase << SW_CheckSum << dec << endl;

	// Set load path for the files
	LoadPath = getPath(1);

	// Load config file
	loadConfigData();

	// Check user flags
	checkFlags(argc, argv);

	// Set Saving path for results
	if(SaveDataFlag == true)
	{
		SavePath = getPath(2);
	}

	#ifdef __aarch64__
		CpuAffinityFlag = true;
	#endif

	cout << endl;

	// Create RS422 Class Objects
	ObcRS422Obj = new ObcRS422();
	CamRS422Obj = new CamRS422();

	if(ObcPortStatus == true)
	{
		// Start RS422 Receiving Thread
		if(pthread_create(&DataRecvThread, NULL, ObcRS422Obj->DataRecvThread, ObcRS422Obj))
		{
			perror("pthread_create");
			delete ObcRS422Obj;
			delete CamRS422Obj;
			exit(1);
		}

		// Start Sending Target Data to Obc @40ms
		if(pthread_create(&ObcDataThread, NULL, ObcRS422Obj->ObcDataThread, ObcRS422Obj))
		{
			perror("pthread_create");
			delete ObcRS422Obj;
			delete CamRS422Obj;
			exit(1);
		}
	}

	if(CamPortStatus == true)
	{
		// Start Camera Handshaking Thread
		if(pthread_create(&CamHandShakeThread, NULL, CamRS422Obj->HandShakeThread, CamRS422Obj))
		{
			perror("pthread_create");
			delete ObcRS422Obj;
			delete CamRS422Obj;
			exit(1);
		}
	}

	// Create AI Class Object & Load AI Model
	ObjDetectionObj = new ObjDetection();

	// Check for IP Address && Camera Handshake
	while(IPAddrStatus == false || SeekerStatus == false)
	{
		if(ProcessThreadFlag == false)
		{
			goto EXIT;
		}

		usleep(10 * 1000);
	}

	// Create Camera Class Object
	SeekerObj = new Seeker();

	// Start Video Streaming & Saving thread
	if(pthread_create(&VideoStreamThread, NULL, SeekerObj->VideoStreamThread, SeekerObj))
	{
		perror("pthread_create");
		delete SeekerObj;
		delete ObcRS422Obj;
		delete CamRS422Obj;
		delete ObjDetectionObj;
		exit(1);
	}

	// Start Video Reading thread
	if(pthread_create(&ReadFramesThread, NULL, SeekerObj->ReadFramesThread, SeekerObj))
	{
		perror("pthread_create");
		delete SeekerObj;
		delete ObcRS422Obj;
		delete CamRS422Obj;
		delete ObjDetectionObj;
		exit(1);
	}

	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(2, &cpuset); // Bind to CPU 2
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 98;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// IP Card Ready for Processing
	cout << endl << endl;
	IPCardReadyFlag = true;

	// Main while loop
	while(ProcessThreadFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		{
			lock_guard<mutex> lock(CameraDataMutex);
			if(CameraData.FrameFlag == false)
			{
				continue;
			}

			VideoData.VideoFrame = CameraData.VideoFrame;
			VideoData.FrameTime = CameraData.FrameTime;
			VideoData.FrameFlag = true;
			CameraData.VideoFrame.release();
			CameraData.FrameFlag = false;
		}

		// Start measuring after a complete frame has been acquired safely.
		AIStartTime = GetCurrMillis();
		processStart = steady_clock::now();

		if(AIStatusFlag == true)
		{
			// Detect objects
			if(DetectionCnt < 10U || DetectObjectFlag == true)
			{
				ObjDetectionObj->RunEnqueueV3(VideoData.VideoFrame,
					VideoData.FrameTime, AIStartTime);
			}
			if(DetectionCnt <= 15U)
			{
				DetectionCnt++;
			}
		}

		// Send Target Data sync with AI
		if(TgtDataModeFlag == true && IPCardMode != 2U && IPCardMode != 3U)
		{
			SendTargetDataFlag = true;
		}

		// Update Data for VideoStream, Saving & Display
		Mat completedFrame = VideoData.VideoFrame.clone();
		{
			lock_guard<mutex> lock(ProcessedDataMutex);
			ProcessedData.VideoFrame = completedFrame;
			ProcessedData.FrameFlag = true;
		}

		// Monotonic timing cannot jump when system time is synchronized.
		totalTime = duration_cast<microseconds>(steady_clock::now() - processStart).count();

		static UInt32_t processLogCounter = 0U;
		if (++processLogCounter == 1U || processLogCounter % 30U == 0U)
			cout << "Total Process Time - " << ((float)totalTime / 1000.0f) << " ms" << endl;
	}

EXIT:
	// Close Whole Process & Clear Threads
	closeProcess();

	cout << "Terminated Successfully..." << endl << flush;
	return 0;
}


// ---------- signal Handler ----------
void signalHandler(Int32_t Signal)
{
	if(Signal == SIGINT)
	{
		cout << "Process Terminated by Cntl+C..." << endl << flush;
		ProcessThreadFlag = false;
	}

	return;
}


// ---------- Close Process ----------
void closeProcess(void)
{
	// Clear all the flags
	ObcDataThreadFlag = false;
	ProcessThreadFlag = false;
	DataRecvThreadFlag = false;
	VideoStreamThreadFlag = false;
	CamHandShakeThreadFlag = false;

	// Try to Cancel Threads
	try
	{
		pthread_cancel(ObcDataThread);
		pthread_cancel(DataRecvThread);
		pthread_cancel(ReadFramesThread);
		pthread_cancel(VideoStreamThread);
		pthread_cancel(CamHandShakeThread);
	}
	catch(Exception &e)
	{
		cout << "Error : " << e.what() << endl;
	}

	// Close All Windows
	destroyAllWindows();

	// delete all the objects
	try
	{
		if(SeekerObj != nullptr)
		{
			delete SeekerObj;
			SeekerObj = nullptr;
		}

		if(CamRS422Obj != nullptr)
		{
			delete CamRS422Obj;
			CamRS422Obj = nullptr;
		}

		if(ObcRS422Obj != nullptr)
		{
			delete ObcRS422Obj;
			ObcRS422Obj = nullptr;
		}

		if(ObjDetectionObj != nullptr)
		{
			delete ObjDetectionObj;
			ObjDetectionObj = nullptr;
		}
	}
	catch(Exception &e)
	{
		cout << "Error : " << e.what() << endl;
	}

	cout << "Process Closed Successfully..." << endl << flush;

	return;
}

