// ============================================================================
// Name		: Seeker.cpp
// Date		: 21 Jan 2026
// ============================================================================


// ---------- Header Inclusion ----------
#include "Seeker.h"


// ---------- Constructor ----------
Seeker :: Seeker(void)
{
	VideoInd = 0;

	// Create UDP/UDP Socket
	UDPSock = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
	if(UDPSock < 0)
	{
		cerr << "Error: socket: failed to open VIDEO_UDP socket" << endl;
		SeekerStatus = false;
		return;
	}

	len = sizeof(caddr);
	memset((void *)&caddr, 0, len);

	caddr.sin_family = AF_INET;
	caddr.sin_addr.s_addr = inet_addr(DL_IPAddr);
	caddr.sin_port = htons(DL_UDPPort);


#if _VIDEO_FFMPEG_

	avdic = NULL;
	LastIOTime = 0;
	videoStream = -1;
	inpFormat = nullptr;

	pFormatCtx = avformat_alloc_context();

	if(VideoSource.find("rtsp://") == 0 || VideoSource.find("http://") == 0 || VideoSource.find("https://") == 0
	   || VideoSource.find("udp://") == 0 || VideoSource.find("tcp://") == 0 || VideoSource.find("rtmp://") == 0)
	{
		avformat_network_init();					// Initialize FFmpeg network module

		av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
		av_dict_set(&avdic, "max_delay", "0", 0);
//		av_dict_set(&avdic, "stimeout", "3000000", 0);   // 3s connect
//		av_dict_set(&avdic, "rw_timeout", "5000000", 0); // 5s read

		if(avformat_open_input(&pFormatCtx, VideoSource.c_str(), NULL,  &avdic) != 0)
		{
			cerr << "Can't open the VideoSource" << endl;
			SeekerStatus = false;
			return;
		}
	}
	else if(VideoSource.find("/dev/video") == 0)
	{
		avdevice_register_all();
		inpFormat = av_find_input_format("v4l2");

		av_dict_set(&avdic, "video_size", "640x480", 0);
		av_dict_set(&avdic, "framerate", "25", 0);

		av_dict_set(&avdic, "pixel_format", "yuyv422", 0);
		av_dict_set(&avdic, "input_format", "yuyv422", 0);

		if(avformat_open_input(&pFormatCtx, VideoSource.c_str(), inpFormat,  &avdic) != 0)
		{
			cerr << "Can't open the VideoSource" << endl;
			SeekerStatus = false;
			return;
		}

	}
	else
	{

		if(avformat_open_input(&pFormatCtx, VideoSource.c_str(), NULL,  &avdic) != 0)
		{
			cerr << "Can't open the VideoSource" << endl;
			SeekerStatus = false;
			return;
		}

	}

	// Get stream information
	if(avformat_find_stream_info(pFormatCtx, NULL) < 0)
	{
		cerr << "Couldn't find stream information" << endl;
		SeekerStatus = false;
		return;
	}

	// Find the video stream
	for(UInt32_t i = 0; i < pFormatCtx->nb_streams; i++)
	{
		if(pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			videoStream = i;
			break;
		}
	}

	if(videoStream == -1)
	{
		cerr << "Didn't find a video stream" << endl;
		SeekerStatus = false;
		return;
	}

	// Get codec context
	pCodecCtx = avcodec_alloc_context3(NULL);
	avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[videoStream]->codecpar);
	pCodec = avcodec_find_decoder(pCodecCtx->codec_id);

	if(pCodec == NULL)
	{
		cerr << "Codec not found" << endl;
		SeekerStatus = false;
		return;
	}

	pCodecCtx->bit_rate = 0;
	pCodecCtx->time_base.num = 1;
	pCodecCtx->time_base.den = 10;
	pCodecCtx->frame_number = 1;

	// Open codec
	if(avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
	{
		cerr << "Could not open codec" << endl;
		SeekerStatus = false;
		return;
	}

	// Allocate memory for frames
	pFrame = av_frame_alloc();
	pFrameEO = av_frame_alloc();

	// The sensor is monochrome IR. Preserve one luminance channel through the
	// CPU pipeline; the CUDA preprocessor replicates it to the YOLO RGB planes.
	img_convert_ctx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt,
		pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_GRAY8, SWS_FAST_BILINEAR,
		NULL, NULL, NULL);

	numBytes = av_image_get_buffer_size(AV_PIX_FMT_GRAY8, pCodecCtx->width, pCodecCtx->height, 1);

	//out_buffer = (uint8_t *) av_malloc(numBytes * sizeof(uint8_t));
	out_buffer = (UInt8_t *)av_malloc(numBytes);

	av_image_fill_arrays(pFrameEO->data, pFrameEO->linesize, out_buffer, AV_PIX_FMT_GRAY8,
		pCodecCtx->width, pCodecCtx->height, 1);

	packet = av_packet_alloc();

#else

	CAM.open(VideoSource);
	// CAM.set(CAP_PROP_BUFFERSIZE, 1); // drop old frames

	if(!CAM.isOpened())
	{
		cerr << "ERROR! Unable to open video source " << VideoSource << endl;
		SeekerStatus = false;
	}

#endif


	if(SaveDataFlag == true)
	{
		// Open VideoWriter
		OutVid.open(SavePath + "IPVideo" + to_string(VideoInd) + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, false);
		if(!OutVid.isOpened())
		{
			cerr << "Error in opening new video file" << endl;
			raise(SIGINT);
		}
	}

	return;
}


// ---------- Destructor ----------
Seeker :: ~Seeker(void)
{
	close(UDPSock);
	OutVid.release();

#if _VIDEO_FFMPEG_
	av_packet_free(&packet);
	av_frame_free(&pFrame);
	av_frame_free(&pFrameEO);
	av_free(out_buffer);
	out_buffer = nullptr;

	sws_freeContext(img_convert_ctx);

	avcodec_free_context(&pCodecCtx);
	avformat_close_input(&pFormatCtx);
	avformat_network_deinit();

#else

	CAM.release();

#endif


	return;
}


// ---------- Read Frames ----------
void Seeker :: ReadFrames(void)
{
#if _VIDEO_FFMPEG_

	Int32_t ret;
	Mat VideoFrame;
	Int32_t sleepTime;
	struct timespec ts, ts1;
	UInt32_t timCntStart, timCntEnd, totalTime;

	ts.tv_sec = 0;
	ts.tv_nsec = 1000 * 10;

	ts1.tv_sec = 0;
	ts1.tv_nsec = 0;


	// Wait Until IP Card Gets ready
	while(IPCardReadyFlag == false)
	{
		if(ProcessThreadFlag == false)
		{
			break;
		}

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
	}

	VideoFrame.create(pCodecCtx->height, pCodecCtx->width, CV_8UC1);
	LastIOTime = GetCurrMillis();

	while(ProcessThreadFlag == true && SeekerStatus == true)
	{
		// Start measuring execution time
		timCntStart = GetCurrMillis();

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		ret = av_read_frame(pFormatCtx, packet);

		if(ret == AVERROR_EXIT || ret < 0)
		{
			if(GetCurrMillis() - LastIOTime > 3000)
			{
				cout << "Failed to read Video" << endl;
				SeekerStatus = false;
				destroyAllWindows();
				break;
			}

			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
			continue;
		}

		if(packet->stream_index == videoStream)
		{
			if(avcodec_send_packet(pCodecCtx, packet) == 0 && avcodec_receive_frame(pCodecCtx, pFrame) == 0)
			{
				sws_scale(img_convert_ctx, pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameEO->data, pFrameEO->linesize);
				memcpy(VideoFrame.data, pFrameEO->data[0], pCodecCtx->height * pFrameEO->linesize[0]);

					Mat publishFrame;
					if (VideoFrame.size() != VideoDim)
						resize(VideoFrame, publishFrame, VideoDim, 0.0, 0.0, INTER_AREA);
					else
						publishFrame = VideoFrame;

					UInt32_t frameTime = GetCurrMillis();
					{
						lock_guard<mutex> lock(CameraDataMutex);
						CameraData.VideoFrame = publishFrame.clone();
						CameraData.FrameTime = frameTime;
						CameraData.FrameFlag = true; // Latest-frame-wins queue.
					}
					LastIOTime = frameTime;

				// Send Target Data sync with Camera
				if(TgtDataModeFlag == false && IPCardMode != 2U && IPCardMode != 3U)
				{
					SendTargetDataFlag = true;
				}
			}
		}

		av_packet_unref(packet);

		// Stop Measuring execution time
		timCntEnd =  GetCurrMillis();

		// Calculate the reading & sleep time in milliseconds
		totalTime = (timCntEnd < timCntStart) ? ((86400000U + timCntEnd) - timCntStart) : (timCntEnd - timCntStart);
		sleepTime = FrameDelay - totalTime;

		// cout << "Frame Reading Time - " << totalTime << " ms" << endl << flush;

		// Give Delay in Video Reading only for video files
		if(!(VideoSource.find("/dev/video") == 0 || VideoSource.find("rtsp://") == 0 || VideoSource.find("http://") == 0 ||
			VideoSource.find("https://") == 0 || VideoSource.find("udp://") == 0 || VideoSource.find("tcp://") == 0 ||
			VideoSource.find("rtmp://") == 0) && sleepTime > 0)
		{
			ts1.tv_nsec = (sleepTime * 1000 * 1000) - 30;
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts1, nullptr);
		}
	}

	return;

#else

	bool ret;
	Mat VideoFrame;
	Int32_t sleepTime;
	struct timespec ts, ts1;
	UInt32_t timCntStart, timCntEnd, totalTime;

	ts.tv_sec = 0;
	ts.tv_nsec = 1000 * 5;

	ts1.tv_sec = 0;
	ts1.tv_nsec = 0;

	// Wait Until IP Card Gets ready
	while(IPCardReadyFlag == false)
	{
		if(ProcessThreadFlag == false)
		{
			break;
		}

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
	}

	while(ProcessThreadFlag == true && SeekerStatus == true)
	{
		// Start measuring execution time
		timCntStart = GetCurrMillis();

		// Reading VideoFrame using OpenCV
		VideoFrame.release();
		ret = CAM.read(VideoFrame);

		if(ret == false)
		{
			cerr << "Error! Failed to read video" << endl;

			if(VideoSource == "/dev/video0")
			{
				CAM.release();
				CAM.open(VideoSource);

				if(!CAM.isOpened())
				{
					cerr << "ERROR! Unable to open video source " << VideoSource << endl;
					SeekerStatus = false;
					destroyAllWindows();
					break;
				}
				else
				{
					continue;
				}
			}
			else
			{
				SeekerStatus = false;
				destroyAllWindows();
				break;
			}
		}
		if (VideoFrame.channels() == 3)
			cvtColor(VideoFrame, VideoFrame, COLOR_BGR2GRAY);

		if (VideoFrame.size() != VideoDim)
			resize(VideoFrame, VideoFrame, VideoDim, 0.0, 0.0, INTER_AREA);

		{
			lock_guard<mutex> lock(CameraDataMutex);
			CameraData.VideoFrame = VideoFrame.clone();
			CameraData.FrameTime = GetCurrMillis();
			CameraData.FrameFlag = true; // Latest-frame-wins queue.
		}


		// Send Target Data sync with Camera
		if(TgtDataModeFlag == false && IPCardMode != 2U && IPCardMode != 3U)
		{
			SendTargetDataFlag = true;
		}

		// Stop Measuring execution time
		timCntEnd =  GetCurrMillis();

		// Calculate the reading & sleep time in milliseconds
		totalTime = (timCntEnd < timCntStart) ? ((86400000U + timCntEnd) - timCntStart) : (timCntEnd - timCntStart);
		sleepTime = FrameDelay - totalTime;

		// cout << endl << "Frame Reading Time - " << totalTime << " ms" << endl << flush;

		// Give Delay in Video Reading only for video files
		if(VideoSource.find("/dev/video") != 0 && sleepTime > 0)
		{
			ts1.tv_nsec = (sleepTime * 1000 * 1000) - 30;
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts1, nullptr);
		}
	}

	CAM.release();

	return;

#endif
}


// ---------- Video Stream ----------
void Seeker :: VideoStream(void)
{
	Mat VideoFrame;
	struct timespec ts, ts1;
	UInt16_t SaveFrameCnt = 0U;

	UInt32_t FrameCnt = 0U;
	UInt8_t PacketNo = 0U, PacketCnt = 0U;
	UInt32_t PacketStart = 0U, PacketEnd = 0U;
	UInt32_t FrameLength = 0U;
	const UInt32_t UDPSegSize = 60U * 1024U;

	vector<UInt8_t> DataPacket;
	vector<UInt8_t> FrameBuff;
	vector<Int32_t> FrameCompress = {IMWRITE_JPEG_QUALITY, 60};

	ts.tv_sec = 0;         				// seconds
	ts.tv_nsec = 1000 * 500;			// 500 microseconds

	ts1.tv_sec = 0;         			// seconds
	ts1.tv_nsec = 1000 * 1000 * 3;		// 3 milliseconds

	while(VideoStreamThreadFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		{
			lock_guard<mutex> lock(ProcessedDataMutex);
			if(ProcessedData.FrameFlag == false)
			{
				continue;
			}

			VideoFrame = ProcessedData.VideoFrame;
			ProcessedData.VideoFrame.release();
			ProcessedData.FrameFlag = false;
		}

		if (VideoFrame.channels() == 3)
			cvtColor(VideoFrame, VideoFrame, COLOR_BGR2GRAY);
		// Overlay metadata only after detection so it cannot look like a hot target.
		putText(VideoFrame, GetTimeStamp(), Point(10, 20), FONT_HERSHEY_SIMPLEX,
			0.4, Scalar(255), 1);

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		// Video Stream
		PacketNo = 0U;
		PacketCnt = 0U;
		PacketEnd = 0U;
		PacketStart = 0U;
		FrameLength = 0U;


		FrameBuff.clear();
		imencode(".jpeg", VideoFrame, FrameBuff, FrameCompress);					// Encode to JPEG
		FrameLength = FrameBuff.size();												// Calculate FrameBuff length
		PacketCnt = (FrameLength + (UDPSegSize - 1)) / UDPSegSize;					// Calculate Packet Count

		for(PacketNo = 0; PacketNo < PacketCnt; PacketNo++)
		{
			// Split The VideoFrame data
			PacketStart = PacketNo * UDPSegSize;
			PacketEnd = min(PacketStart + UDPSegSize, FrameLength);

			const UInt32_t payloadLength = PacketEnd - PacketStart;
			DataPacket.resize(payloadLength + 9U);
			DataPacket[0] = IPCard_ID;
			DataPacket[1] = DataLink_ID;
			DataPacket[2] = static_cast<UInt8_t>(MissileID);
			DataPacket[3] = static_cast<UInt8_t>((FrameCnt >> 0U) & 0xFFU);
			DataPacket[4] = static_cast<UInt8_t>((FrameCnt >> 8U) & 0xFFU);
			DataPacket[5] = static_cast<UInt8_t>((FrameCnt >> 16U) & 0xFFU);
			DataPacket[6] = static_cast<UInt8_t>((FrameCnt >> 24U) & 0xFFU);
			DataPacket[7] = PacketCnt;
			DataPacket[8] = PacketNo;
			memcpy(DataPacket.data() + 9U, FrameBuff.data() + PacketStart, payloadLength);

			if ((FrameCnt == 0U || FrameCnt % 30U == 0U) && PacketNo == 0U)
				cout << "Frame Sent ID-" << (UInt32_t)MissileID << " F-" << FrameCnt
					 << " PC-" << (UInt32_t)PacketCnt << " FL-" << FrameLength << endl;

			try
			{
				sendto(UDPSock, DataPacket.data(), DataPacket.size(), 0, (sockaddr *)&caddr, len);
			}
			catch(Exception &e)
			{
				cout << "Error in sending DataPacket..." << endl << flush;
			}

			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts1, nullptr);

		}
		FrameCnt++;


		if(DisplayFrameFlag == true)
		{
			imshow("IP Card - " + to_string((UInt32_t)MissileID), VideoFrame);
			if(waitKey(1) == 'q')
			{
				ProcessThreadFlag = false;
				VideoStreamThreadFlag = false;
				break;
			}
		}

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(SaveDataFlag == true)
		{
			OutVid.write(VideoFrame);
			SaveFrameCnt++;

			if(SaveFrameCnt >= 7500U)
			{
				OutVid.release();
				SaveFrameCnt = 0U;
				VideoInd++;

				OutVid.open(SavePath + "IPVideo" + to_string(VideoInd) + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, false);
				if(!OutVid.isOpened())
				{
					cerr << "Error in opening new video file" << endl;
					SaveDataFlag = false;
				}
			}
		}
	}

	close(UDPSock);
	OutVid.release();

	return;
}


// ---------- Read Frames Thread ----------
void * Seeker :: ReadFramesThread(void *args)
{
	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(3, &cpuset); // Bind to CPU 3
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 98;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->ReadFrames();

	pthread_exit(NULL);
	return nullptr;
}


// ---------- Video Stream Thread ----------
void * Seeker :: VideoStreamThread(void *args)
{
	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(4, &cpuset); // Bind to CPU 4
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 95;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->VideoStream();

	pthread_exit(NULL);
	return nullptr;
}
