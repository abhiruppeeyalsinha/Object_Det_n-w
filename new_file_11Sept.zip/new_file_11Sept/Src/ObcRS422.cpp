// ============================================================================
// Name		: ObcRS422.cpp
// Date		: 21 Jan 2026
// ============================================================================


// ---------- Header Inclusion ----------
#include "ObcRS422.h"


// ---------- Open Obc Port ----------
void ObcRS422 :: openObcPort(void)
{
	ObcRecvFD = open(ObcPort, O_RDONLY | O_NOCTTY | O_NONBLOCK | O_SYNC);
	ObcTransmitFD = open(ObcPort, O_WRONLY | O_NOCTTY | O_NONBLOCK | O_SYNC);

	if(ObcRecvFD < 0 || ObcTransmitFD < 0)
	{
		cout << "Error: open: OBC Serial Port is not available" << endl;
		ObcPortStatus = false;
		return;
	}


	if(tcgetattr(ObcRecvFD, &Obctty) != 0)
	{
		cout << "Error: tcgetattr: OBC Serial Port is not available" << endl;
		ObcPortStatus = false;
		return;
	}

	// 8N1, no flow control
	Obctty.c_cflag &= ~PARENB;		// No Parity
	Obctty.c_cflag &= ~CSTOPB;		// 1 Stop Bit
	Obctty.c_cflag &= ~CRTSCTS;		// No HW Flow Control

	Obctty.c_cflag &= ~CSIZE;
	Obctty.c_cflag |= CS8;			// 8 Bit Data

	Obctty.c_cflag |= (CLOCAL | CREAD);				// Enable Receiver & ignore control lines
	Obctty.c_iflag &= ~(IXON | IXOFF | IXANY);		// Software flow control off

	// Set timeout
	Obctty.c_cc[VMIN]  = 0;			// No wait
	Obctty.c_cc[VTIME] = 0;			// No timeout

	// Set Speed
	cfmakeraw(&Obctty);					// raw mode
	cfsetspeed(&Obctty, ObcBAUD);			// BaudRate

	// Flush Port, then applies attributes
	tcflush(ObcRecvFD, TCIFLUSH);
	if(tcsetattr(ObcRecvFD, TCSANOW, &Obctty) != 0)
	{
		cout << "Error: tcsetattr: OBC Serial Port is not available" << endl;
		ObcPortStatus = false;
		return;
	}

	cout << "OBC_RS422 Port opened successfully..." << endl << flush;

	memset((void *)ObcCmd.ObcCmdBuff, 0, sizeof(ObcCmd.ObcCmdBuff));
	memset((void *)ObcResp.ObcRespBuff, 0, sizeof(ObcResp.ObcRespBuff));
	memset((void *)ObcStat.ObcRespBuff, 0, sizeof(ObcStat.ObcRespBuff));

	if(SaveDataFlag == true)
	{
		ObcRawFile = open((SavePath + "ObcRaw.txt").c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0664);
		// ObcRawFile = open((SavePath + "ObcRaw.txt").c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0664);
		if(ObcRawFile < 0)
		{
			cerr << "Error: open: Failed to open ObcRS422 Log file..." << endl;
		}

		ObcDataFile = open((SavePath + "ObcData.txt").c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0664);
		// ObcDataFile = open((SavePath + "ObcData.txt").c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0664);
		if(ObcDataFile < 0)
		{
			cerr << "Error: open: Failed to open ObcRS422 Data file..." << endl;
		}
		else
		{
			write(ObcDataFile, "%%IPHealth\tNy\tNz\tWidth\tHeight\tConfidance\tStatus\tFrameTime\tAIStartTime\tAIEndTime\tCurrTime\n", 90U);
		}
	}

	// Empty the buffer
	while(read(ObcRecvFD, ObcCmd.ObcCmdBuff, 1) >= 1)
	{
		continue;
	}

	epoll_event ev{};
	ev.events = EPOLLIN;
	ev.data.fd = ObcRecvFD;
	epoll_ctl(ePollFD, EPOLL_CTL_ADD, ObcRecvFD, &ev);

	return;
}


// ---------- Open Hils Port ----------
void ObcRS422 :: openHilsPort(void)
{
	epoll_event ev{};
	ev.events = EPOLLIN;

	if(HilsComm == 1U)
	{
		// Create UDP/UDP Socket
		HilsUdpSock = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
		if(HilsUdpSock < 0)
		{
			cerr << "Error: socket: Failed to open HILS_UDP socket" << endl;
			HilsPortStatus = false;
			return;
		}

		len = sizeof(saddr);
		memset((void *)&saddr, 0, len);
		memset((void *)&caddr, 0, len);

		saddr.sin_family = AF_INET;
		saddr.sin_addr.s_addr = inet_addr("0.0.0.0");
		saddr.sin_port = htons(HilsUdpPort);

		releaseUDPPort(HilsUdpPort);
		bind(HilsUdpSock, (struct sockaddr*)&saddr, len);

		cout << "HILS_UDP Port opened successfully..." << endl << flush;

		// Empty the buffer
		while(recvfrom(HilsUdpSock, RecvHils.Buff, 50, MSG_DONTWAIT, (struct sockaddr *)&caddr, &len) >= 1)
		{
			continue;
		}

		ev.data.fd = HilsUdpSock;
		epoll_ctl(ePollFD, EPOLL_CTL_ADD, HilsUdpSock, &ev);
	}
	else if(HilsComm == 2U)
	{
		HilsRecvFD = open(HilsPort, O_RDONLY | O_NOCTTY | O_NONBLOCK | O_SYNC);

		if(HilsRecvFD < 0)
		{
			cout << "Error: open: HILS Serial Port is not available" << endl;
			HilsPortStatus = false;
			return;
		}


		if(tcgetattr(HilsRecvFD, &Hilstty) != 0)
		{
			cout << "Error: tcgetattr: HILS Serial Port is not available" << endl;
			HilsPortStatus = false;
			return;
		}

		// 8N1, no flow control
		Hilstty.c_cflag &= ~PARENB;		// No Parity
		Hilstty.c_cflag &= ~CSTOPB;		// 1 Stop Bit
		Hilstty.c_cflag &= ~CRTSCTS;	// No HW Flow Control

		Hilstty.c_cflag &= ~CSIZE;
		Hilstty.c_cflag |= CS8;			// 8 Bit Data

		Hilstty.c_cflag |= (CLOCAL | CREAD);			// Enable Receiver & ignore control lines
		Hilstty.c_iflag &= ~(IXON | IXOFF | IXANY);		// Software flow control off

		// Set timeout
		Hilstty.c_cc[VMIN]  = 0;		// No wait
		Hilstty.c_cc[VTIME] = 0;		// No timeout

		// Set Speed
		cfmakeraw(&Hilstty);					// raw mode
		cfsetspeed(&Hilstty, HilsBAUD);			// BaudRate

		// Flush Port, then applies attributes
		tcflush(HilsRecvFD, TCIFLUSH);
		if(tcsetattr(HilsRecvFD, TCSANOW, &Hilstty) != 0)
		{
			cout << "Error: tcsetattr: HILS Serial Port is not available" << endl;
			HilsPortStatus = false;
			return;
		}

		cout << "HILS_RS422 Port opened successfully..." << endl << flush;

		// Empty the buffer
		while(read(HilsRecvFD, RecvHils.Buff, 1) >= 1)
		{
			continue;
		}

		ev.data.fd = HilsRecvFD;
		epoll_ctl(ePollFD, EPOLL_CTL_ADD, HilsRecvFD, &ev);
	}
	else
	{
		HilsPortStatus = false;
		return;
	}

	memset((void *)RecvHils.Buff, 0, sizeof(RecvHils.Buff));
	memset((void *)Hils1Data.Buff, 0, sizeof(Hils1Data.Buff));
	memset((void *)Hils2Data.Buff, 0, sizeof(Hils2Data.Buff));

	if(SaveDataFlag == true)
	{
		HilsDataFile = open((SavePath + "HilsData.txt").c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0664);
		// HilsDataFile = open((SavePath + "HilsData.txt").c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0664);
		if(HilsDataFile < 0)
		{
			cerr << "Error: open: Failed to open Hils Data file..." << endl;
		}
		else
		{
			write(HilsDataFile, "%%RecvIPTime\tNy\tNz\tWidth\tHeight\tConfidance\tStatus\tFrameTime\tAIStartTime\tAIEndTime\tIPTime\n", 88U);
		}
	}

	return;
}


// ---------- Constructor ----------
ObcRS422 :: ObcRS422(void)
{
	TargetDataTime = 0U;
	DataTime1 = 0U;
	DataTime2 = 0U;

	// Create ePoll
	ePollFD = epoll_create1(0);

	// Open OBC RS422 port
	openObcPort();

	// Open HILS RS422 port
	openHilsPort();

	return;
}


// ---------- Destructor ----------
ObcRS422 :: ~ObcRS422(void)
{
	close(ObcRawFile);
	close(ObcDataFile);
	close(HilsDataFile);

	close(ObcTransmitFD);
	close(ObcRecvFD);

	if(HilsComm == 1U)
	{
		close(HilsUdpSock);
	}
	else if(HilsComm == 2U)
	{
		close(HilsRecvFD);
	}
	else
	{

	}

	return;
}


// ---------- Checksum Calculation ----------
UInt8_t ObcRS422 :: calcCheckSum(UInt8_t *data, UInt16_t len)
{
	UInt8_t CheckSum = 0U;
	UInt16_t charCnt = 0U;

	for(charCnt = 0U; charCnt < len; charCnt++)
	{
		CheckSum ^= data[charCnt];
	}

	return CheckSum;
}


// ---------- Send Message ----------
void ObcRS422 :: sendMsg(union _ObcResp_ ObcResp)
{
	UInt16_t charCnt = 0U;
	Int8_t printBuff[200];

	// Read structure and send it
	write(ObcTransmitFD, ObcResp.ObcRespBuff, (ObcResp.ObcRespBuff[3] + 5U));
	tcdrain(ObcTransmitFD);	// Transmit physically

	if(SaveDataFlag == true)
	{
		memset((void *)printBuff, 0, sizeof(printBuff));
		sprintf(printBuff, "Transmit : 0x%02X 0x%02X 0x%02X 0x%02X ", ObcResp.ObcRespBuff[0], ObcResp.ObcRespBuff[1], ObcResp.ObcRespBuff[2], ObcResp.ObcRespBuff[3]);

		for(charCnt = 0U; charCnt < ObcResp.ObcRespBuff[3]; charCnt++)
		{
			sprintf((printBuff + strlen(printBuff)), "0x%02X ", ObcResp.ObcRespBuff[charCnt + 4U]);
		}

		sprintf((printBuff + strlen(printBuff)), "0x%02X  %s\n%c", ObcResp.ObcRespBuff[charCnt + 4U], to_string(GetCurrMillis()).c_str(), 0);
		write(ObcRawFile, printBuff, strlen(printBuff));
	}

	cout << "Sent to OBC : CMD-0x" << hex << uppercase << (UInt32_t)ObcResp.ObcRespBuff[2] << " L-" << dec << (UInt32_t)(ObcResp.ObcRespBuff[3] + 5U) << endl << flush;
	memset((void *)ObcResp.ObcRespBuff, 0, sizeof(ObcResp.ObcRespBuff));

	return;
}


// ---------- Send Ack Nack ----------
void ObcRS422 :: sendAckNack(UInt8_t CmdID, UInt8_t Type)
{
	// Send NACK
	ObcResp.ObcRespBuff[0] = IPCard_ID;
	ObcResp.ObcRespBuff[1] = OBCCard_ID;
	ObcResp.ObcRespBuff[2] = CmdID;

	ObcResp.ObcRespBuff[3] = 1U;

	if(Type == 0)
	{
		ObcResp.AckNackResp.Ack = 0xB2U;
	}
	else if(Type == 1)
	{
		ObcResp.AckNackResp.Ack = 0xE5U;
	}
	else
	{

	}

	ObcResp.AckNackResp.CheckSum = calcCheckSum(ObcResp.ObcRespBuff, (sizeof(ObcResp.AckNackResp) - 1U));

	sendMsg(ObcResp);
	return;
}


// ---------- Send Health ----------
void ObcRS422 :: sendHealth(void)
{
	ObcResp.ObcRespBuff[0] = IPCard_ID;
	ObcResp.ObcRespBuff[1] = OBCCard_ID;
	ObcResp.ObcRespBuff[2] = HealthCmdID;

	ObcResp.ObcRespBuff[3] = sizeof(ObcResp.HealthResp) - 5U;

	memcpy((void *)ObcResp.HealthResp.SwVersion, (const void *)(SW_Health.c_str()), 18U);
	ObcResp.HealthResp.SWCheckSum = SW_CheckSum;

	memset((void *)&ObcResp.HealthResp.IpStatus, 0, sizeof(ObcResp.HealthResp.IpStatus));
	ObcResp.HealthResp.IpStatus.CameraStatus = SeekerStatus;
	ObcResp.HealthResp.IpStatus.NUCStatus = NUCStatus;
	ObcResp.HealthResp.IpStatus.IPAddrStatus = IPAddrStatus;
	ObcResp.HealthResp.IpStatus.AIStatusFlag = AIStatusFlag;

	ObcResp.ObcRespBuff[ObcResp.ObcRespBuff[3] + 4U] = calcCheckSum(ObcResp.ObcRespBuff, (ObcResp.ObcRespBuff[3] + 4U));
	sendMsg(ObcResp);

	return;
}


// ---------- Target Data Send ----------
void ObcRS422 :: sendTargetData(void)
{
	Int8_t Buffer[200];
	struct _TargetData_ currentTarget;
	bool targetDataAvailable;
	{
		lock_guard<mutex> lock(TargetDataMutex);
		currentTarget = TargetData;
		targetDataAvailable = TargetDataFlag;
		TargetDataFlag = false;
	}

	memset((void *)ObcStat.ObcRespBuff, 0, sizeof(ObcStat.ObcRespBuff));

	ObcStat.ObcRespBuff[0] = IPCard_ID;
	ObcStat.ObcRespBuff[1] = OBCCard_ID;
	ObcStat.ObcRespBuff[2] = TgtDataCmdID;

	if(IPCardMode == 0U) // Mission Mode
	{
		ObcStat.TargetDataResp.IPTime = GetCurrMillis();

		if(targetDataAvailable == false)
		{
			ObcStat.TargetDataResp.DetectStatus = 0U;
			goto SEND;
		}

		ObcStat.TargetDataResp.Ny = currentTarget.CenterPoint.x - (VideoDim.width / 2);
		ObcStat.TargetDataResp.Nz = currentTarget.CenterPoint.y - (VideoDim.height / 2);

		ObcStat.TargetDataResp.Width = currentTarget.BoundingBox.width;
		ObcStat.TargetDataResp.Height = currentTarget.BoundingBox.height;

		ObcStat.TargetDataResp.Confidance = currentTarget.Confidance * 100U;

		if(currentTarget.ValidData == 0U)
		{
			ObcStat.TargetDataResp.Ny = 0;
			ObcStat.TargetDataResp.Nz = 0;

			ObcStat.TargetDataResp.Width = 0;
			ObcStat.TargetDataResp.Height = 0;

			ObcStat.TargetDataResp.Confidance = 0;
		}

		ObcStat.TargetDataResp.DetectStatus = currentTarget.ValidData;

		ObcStat.TargetDataResp.FrameTime = currentTarget.FrameTime;
		ObcStat.TargetDataResp.AIStartTime = currentTarget.AIStartTime;
		ObcStat.TargetDataResp.AIEndTime = currentTarget.AIEndTime;
	}
	else if(IPCardMode == 1U)  // LoopBack Mode
	{
		ObcStat.TargetDataResp.IPTime = GetCurrMillis();

		if(targetDataAvailable == false)
		{
			ObcStat.TargetDataResp.DetectStatus = 0U;
			goto SEND;
		}

		ObcStat.TargetDataResp.Ny = ROI_Loc[0] - (VideoDim.width / 2);
		ObcStat.TargetDataResp.Nz = ROI_Loc[1] - (VideoDim.height / 2);

		ObcStat.TargetDataResp.Width = ROI_Dim[0];
		ObcStat.TargetDataResp.Height = ROI_Dim[1];

		ObcStat.TargetDataResp.Confidance = 95U;
		ObcStat.TargetDataResp.DetectStatus = 1U;

		ObcStat.TargetDataResp.FrameTime = currentTarget.FrameTime;
		ObcStat.TargetDataResp.AIStartTime = currentTarget.AIStartTime;
		ObcStat.TargetDataResp.AIEndTime = currentTarget.AIEndTime;
	}
	else if(IPCardMode == 2U)  // Hils Mode (Timings -> 6DOF)
	{
		ObcStat.TargetDataResp.Ny = Hils2Data.HilsDataStruct.Ny;
		ObcStat.TargetDataResp.Nz = Hils2Data.HilsDataStruct.Nz;

		ObcStat.TargetDataResp.Width = Hils2Data.HilsDataStruct.Width;
		ObcStat.TargetDataResp.Height = Hils2Data.HilsDataStruct.Height;

		ObcStat.TargetDataResp.Confidance = Hils2Data.HilsDataStruct.Confidance;
		ObcStat.TargetDataResp.DetectStatus = Hils2Data.HilsDataStruct.DetectStatus;

		ObcStat.TargetDataResp.FrameTime = Hils2Data.HilsDataStruct.FrameTime;
		ObcStat.TargetDataResp.AIStartTime = Hils2Data.HilsDataStruct.AIStartTime;
		ObcStat.TargetDataResp.AIEndTime = Hils2Data.HilsDataStruct.AIEndTime;
		ObcStat.TargetDataResp.IPTime = Hils2Data.HilsDataStruct.IPTime;
	}
	else if(IPCardMode == 3U)  // Hils Mode (Timings -> IPCard)
	{
		ObcStat.TargetDataResp.Ny = Hils2Data.HilsDataStruct.Ny;
		ObcStat.TargetDataResp.Nz = Hils2Data.HilsDataStruct.Nz;

		ObcStat.TargetDataResp.Width = Hils2Data.HilsDataStruct.Width;
		ObcStat.TargetDataResp.Height = Hils2Data.HilsDataStruct.Height;

		ObcStat.TargetDataResp.Confidance = Hils2Data.HilsDataStruct.Confidance;
		ObcStat.TargetDataResp.DetectStatus = Hils2Data.HilsDataStruct.DetectStatus;

		ObcStat.TargetDataResp.FrameTime = DataTime2;
		ObcStat.TargetDataResp.AIStartTime = DataTime2 + 1U;
		ObcStat.TargetDataResp.AIEndTime = DataTime2 + 36U;
		ObcStat.TargetDataResp.IPTime = GetCurrMillis();
	}
	else if(IPCardMode == 4U) // Hils Data sync with Camera
	{
		ObcStat.TargetDataResp.IPTime = GetCurrMillis();

		if(targetDataAvailable == false)
		{
			ObcStat.TargetDataResp.DetectStatus = 0U;
			goto SEND;
		}

		ObcStat.TargetDataResp.Ny = Hils2Data.HilsDataStruct.Ny;
		ObcStat.TargetDataResp.Nz = Hils2Data.HilsDataStruct.Nz;

		ObcStat.TargetDataResp.Width = Hils2Data.HilsDataStruct.Width;
		ObcStat.TargetDataResp.Height = Hils2Data.HilsDataStruct.Height;

		ObcStat.TargetDataResp.Confidance = Hils2Data.HilsDataStruct.Confidance;
		ObcStat.TargetDataResp.DetectStatus = Hils2Data.HilsDataStruct.DetectStatus;

		ObcStat.TargetDataResp.FrameTime = currentTarget.FrameTime;
		ObcStat.TargetDataResp.AIStartTime = currentTarget.AIStartTime;
		ObcStat.TargetDataResp.AIEndTime = currentTarget.AIEndTime;
	}
	else
	{

	}

	SEND:

	ObcStat.TargetDataResp.IpStatus.CameraStatus = SeekerStatus;
	ObcStat.TargetDataResp.IpStatus.NUCStatus = NUCStatus;
	ObcStat.TargetDataResp.IpStatus.IPAddrStatus = IPAddrStatus;
	ObcStat.TargetDataResp.IpStatus.AIStatusFlag = AIStatusFlag;

	ObcStat.TargetDataResp.Length = sizeof(ObcStat.TargetDataResp) - 5U;
	ObcStat.ObcRespBuff[ObcStat.ObcRespBuff[3] + 4U] = calcCheckSum(ObcStat.ObcRespBuff, (ObcStat.ObcRespBuff[3] + 4U));

	TargetDataTime = GetCurrMillis();
	sendMsg(ObcStat);

	if(SaveDataFlag == true)
	{
		memset((void *)Buffer, 0, 200);
		sprintf(Buffer, "%d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %u\t\t  %u\t\t  %u\t\t  %u\n", ObcStat.ObcRespBuff[30], ObcStat.TargetDataResp.Ny, ObcStat.TargetDataResp.Nz, ObcStat.TargetDataResp.Width, ObcStat.TargetDataResp.Height, ObcStat.TargetDataResp.Confidance, ObcStat.TargetDataResp.DetectStatus, ObcStat.TargetDataResp.FrameTime, ObcStat.TargetDataResp.AIStartTime, ObcStat.TargetDataResp.AIEndTime, ObcStat.TargetDataResp.IPTime);
		write(ObcDataFile, Buffer, strlen(Buffer));
	}

	return;
}


// ---------- Process Obc Data ----------
void ObcRS422 :: processObcData(void)
{
	UInt16_t charCnt = 0U;
	Int8_t printBuff[200];

	if(SaveDataFlag == true)
	{
		memset((void *)printBuff, 0, sizeof(printBuff));
		sprintf(printBuff, "Receive : 0x%02X 0x%02X 0x%02X 0x%02X ", ObcCmd.ObcCmdBuff[0], ObcCmd.ObcCmdBuff[1], ObcCmd.ObcCmdBuff[2], ObcCmd.ObcCmdBuff[3]);

		for(charCnt = 0U; charCnt < ObcCmd.ObcCmdBuff[3]; charCnt++)
		{
			sprintf((printBuff + strlen(printBuff)), "0x%02X ", ObcCmd.ObcCmdBuff[charCnt + 4U]);
		}

		sprintf((printBuff + strlen(printBuff)), "0x%02X  %s\n%c", ObcCmd.ObcCmdBuff[charCnt + 4U], to_string(GetCurrMillis()).c_str(), 0);
		write(ObcRawFile, printBuff, strlen(printBuff));
	}

	cout << "Recv from OBC : CMD-0x" << hex << uppercase << (UInt32_t)ObcCmd.ObcCmdBuff[2] << " L-" << dec << (UInt32_t)(ObcCmd.ObcCmdBuff[3] + 5U) << endl << flush;

	if(calcCheckSum(ObcCmd.ObcCmdBuff, (ObcCmd.ObcCmdBuff[3] + 4U)) != ObcCmd.ObcCmdBuff[ObcCmd.ObcCmdBuff[3] + 4U]
		|| ObcCmd.ObcCmdBuff[0] != OBCCard_ID || ObcCmd.ObcCmdBuff[1] != IPCard_ID)
	{
		sendAckNack(ObcCmd.ObcCmdBuff[2], 0);
		return;
	}

	ObcResp.ObcRespBuff[0] = IPCard_ID;
	ObcResp.ObcRespBuff[1] = OBCCard_ID;
	ObcResp.ObcRespBuff[2] = ObcCmd.ObcCmdBuff[2];

	switch(ObcCmd.ObcCmdBuff[2])
	{
		// ConfigData
		case ConfigCmdID:
			if(!(1U <= ObcCmd.ConfigCmd.MissileID && ObcCmd.ConfigCmd.MissileID <= 64U))
			{
				sendAckNack(ObcCmd.ObcCmdBuff[2], 0);
				break;
			}

			UpdateTime(ObcCmd.ConfigCmd.Day, ObcCmd.ConfigCmd.Month, ObcCmd.ConfigCmd.Year, ObcCmd.ConfigCmd.Time);

			if(IPAddrStatus == false)
			{
				MissileID = ObcCmd.ConfigCmd.MissileID;
				DL_UDPPort = DL_UDPPort + (MissileID - 1U);
				modifyIPAddr(IP_IPAddr, (MissileID - 1U));
				IPAddrStatus = setIPAddr(IP_IPAddr, NetMask_Addr, GateWay_Addr);

				// Set Saving path for results
				if(SaveDataFlag == true)
				{
					SavePath = getPath(3);
				}
			}

			sendAckNack(ObcCmd.ObcCmdBuff[2], 1);

			break;


		// Seeker NUC Command
		case NucCmdID:
			if(CamPortStatus == true)
			{
				CamRS422Obj->Nuc_1PT(0);
			}
			sendAckNack(ObcCmd.ObcCmdBuff[2], 1);
			break;


		case HealthCmdID:
			sendHealth();
			usleep(1000 * 100);
			ObcCmdFlag = true; // Start Sending Target Data to Obc
			break;


		case TgtDataCmdID:
			ROI_Loc[0] = ObcCmd.TargetDataCmd.Ny + (VideoDim.width / 2);
			ROI_Loc[1] = ObcCmd.TargetDataCmd.Nz + (VideoDim.height / 2);
			ROI_Dim[0] = ObcCmd.TargetDataCmd.Width;
			ROI_Dim[1] = ObcCmd.TargetDataCmd.Height;
			IPCardMode = ObcCmd.TargetDataCmd.IPCardMode;

			DetectObjectFlag = true;
			sendAckNack(ObcCmd.ObcCmdBuff[2], 1);
			break;

		case ShutDownCmdID:
			sendAckNack(ObcCmd.ObcCmdBuff[2], 1);
			systemPowerOff();
			break;

		default:
			sendAckNack(ObcCmd.ObcCmdBuff[2], 0); // Send NACK
			break;
	}

	return;
}


// ---------- Process Hils Data ----------
void ObcRS422 :: processHilsData(void)
{
	Int8_t printBuff[200];

	cout << "Recv from 6DOF : CMD-0x" << hex << uppercase << (UInt32_t)RecvHils.Buff[2] << " L-" << dec << (UInt32_t)(RecvHils.Buff[3] + 5U) << endl << flush;

	if(calcCheckSum(RecvHils.Buff, (RecvHils.Buff[3] + 4U)) != RecvHils.Buff[RecvHils.Buff[3] + 4U] || RecvHils.Buff[0] != HilsPC_ID || RecvHils.Buff[1] != IPCard_ID)
	{
		return;
	}

	switch(RecvHils.Buff[2])
	{
		case TgtDataCmdID:
			DataTime2 = DataTime1;
			DataTime1 = GetCurrMillis();
			Hils2Data = Hils1Data;
			Hils1Data = RecvHils;
			if(IPCardMode == 2U || IPCardMode == 3U)
			{
				SendTargetDataFlag = true;
			}

			if(SaveDataFlag == true)
			{
				memset((void *)printBuff, 0, 200);
				sprintf(printBuff, "%d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %d\t\t  %u\t\t  %u\t\t  %u\t\t  %u\n", DataTime1, Hils1Data.HilsDataStruct.Ny, Hils1Data.HilsDataStruct.Nz, Hils1Data.HilsDataStruct.Width, Hils1Data.HilsDataStruct.Height, Hils1Data.HilsDataStruct.Confidance, Hils1Data.HilsDataStruct.DetectStatus, Hils1Data.HilsDataStruct.FrameTime, Hils1Data.HilsDataStruct.AIStartTime, Hils1Data.HilsDataStruct.AIEndTime, Hils1Data.HilsDataStruct.IPTime);
				write(HilsDataFile, printBuff, strlen(printBuff));
			}

			break;

		default:
			break;
	}

	return;
}


// ---------- Obc Data ----------
void ObcRS422 :: ObcData(void)
{
	UInt32_t TimeDiff = 0U, IPTime = 0U;

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 500;	// 500 microseconds

	while(ObcDataThreadFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(ObcCmdFlag == false)
		{
			continue;
		}

		IPTime = GetCurrMillis();
		TimeDiff = (IPTime < TargetDataTime) ? ((86400000U + IPTime) - TargetDataTime) : (IPTime - TargetDataTime);

		if(IPCardReadyFlag == false)
		{
			if(TimeDiff >= 40U)
			{
				SendTargetDataFlag = true;
			}
		}
		else
		{
			if(SeekerStatus == false && TimeDiff >= 40U)
			{
				SendTargetDataFlag = true;
			}
		}

		// Send Target Data
		if(SendTargetDataFlag == true)
		{
			SendTargetDataFlag = false;
			sendTargetData();
		}
	}

	return;
}


// ---------- Data Receive ----------
void ObcRS422 :: DataRecv(void)
{
	Int16_t Bytes = 0;
	UInt16_t charCnt = 0U;
	Int32_t nfd = -1, i = 0;

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 10;		// 10 microseconds

	while(DataRecvThreadFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		nfd = epoll_wait(ePollFD, events, 2, 2000);

		for(i = 0; i < nfd; i++)
		{
			if(events[i].data.fd == ObcRecvFD)
			{
				while((Bytes = read(ObcRecvFD, (ObcCmd.ObcCmdBuff + charCnt), 1)) > 0)
				{
					charCnt += Bytes;
					if(charCnt >= sizeof(ObcCmd.ObcCmdBuff))
					{
						charCnt--;
					}

					if(ObcCmd.ObcCmdBuff[0] != OBCCard_ID || (2 <= charCnt && ObcCmd.ObcCmdBuff[1] != IPCard_ID))
					{
						charCnt = 0;
					}
					else
					{

					}
				}

				if(charCnt < 5)
				{
					memset((void *)ObcCmd.ObcCmdBuff, 0, sizeof(ObcCmd.ObcCmdBuff));
					charCnt = 0;
					continue;
				}

				processObcData();
				memset((void *)ObcCmd.ObcCmdBuff, 0, sizeof(ObcCmd.ObcCmdBuff));
				charCnt = 0;
			}

			if(events[i].data.fd == HilsRecvFD || events[i].data.fd == HilsUdpSock)
			{
				if(HilsComm == 1U)
				{
					if((Bytes = recvfrom(HilsUdpSock, RecvHils.Buff, sizeof(RecvHils.Buff), MSG_DONTWAIT, (struct sockaddr *)&caddr, &len)) > 0)
					{
						charCnt = Bytes;
					}
				}
				else if(HilsComm == 2U)
				{
					while((Bytes = read(HilsRecvFD, (RecvHils.Buff + charCnt), 1)) > 0)
					{
						charCnt += Bytes;
						if(charCnt >= sizeof(RecvHils.Buff))
						{
							charCnt--;
						}

						if(RecvHils.Buff[0] != HilsPC_ID || (2 <= charCnt && RecvHils.Buff[1] != IPCard_ID))
						{
							charCnt = 0;
						}
						else
						{

						}
					}
				}
				else
				{
					return;
				}

				if(charCnt < 5)
				{
					memset((void *)RecvHils.Buff, 0, sizeof(RecvHils.Buff));
					charCnt = 0;
					continue;
				}

				processHilsData();
				memset((void *)RecvHils.Buff, 0, sizeof(RecvHils.Buff));
				charCnt = 0;
			}
		}
	}

	return;
}


// ---------- Timer Thread ----------
void * ObcRS422 :: ObcDataThread(void *args)
{
	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(5, &cpuset); // Bind to CPU 5
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 98;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	ObcRS422 *Instance = static_cast<ObcRS422 *>(args);

	Instance->ObcData();

	pthread_exit(NULL);
	return nullptr;
}


// ---------- ObcRS422 Receive Thread ----------
void * ObcRS422 :: DataRecvThread(void *args)
{
	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(4, &cpuset); // Bind to CPU 4
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 98;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	ObcRS422 *Instance = static_cast<ObcRS422 *>(args);

	Instance->DataRecv();

	pthread_exit(NULL);
	return nullptr;
}



