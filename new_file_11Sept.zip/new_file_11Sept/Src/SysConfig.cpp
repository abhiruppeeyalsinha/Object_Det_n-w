// ============================================================================
// Name		: SysConfig.cpp
// Date		: 21 Jan 2026
// ============================================================================


// ---------- Header Inclusion ----------
#include "SysConfig.h"


// ---------- Global Static Inclusion ----------
static UInt8_t Day = 0U, Month = 0U;
static UInt16_t Year = 0U;


// ---------- Get Current Time in MicroSeconds ----------
UInt64_t GetCurrMicros(void)
{
	tm tm_time;
	timespec ts;
	UInt64_t Micros = 0U;

	clock_gettime(CLOCK_REALTIME, &ts);
	localtime_r(&ts.tv_sec, &tm_time);

	Micros = static_cast<UInt64_t>(tm_time.tm_hour * 3600000000ULL) + static_cast<UInt64_t>(tm_time.tm_min * 60000000ULL) + static_cast<UInt64_t>(tm_time.tm_sec * 1000000ULL) + static_cast<UInt64_t>(ts.tv_nsec / 1000ULL);

    return Micros;
}


// ---------- Get Current Time in MilliSeconds ----------
UInt32_t GetCurrMillis(void)
{
	tm tm_time;
	timespec ts;
	UInt32_t Millis = 0U;

	clock_gettime(CLOCK_REALTIME, &ts);
	localtime_r(&ts.tv_sec, &tm_time);

	Millis = static_cast<UInt32_t>(tm_time.tm_hour * 3600000U) + static_cast<UInt32_t>(tm_time.tm_min * 60000U) + static_cast<UInt32_t>(tm_time.tm_sec * 1000U) + static_cast<UInt32_t>(ts.tv_nsec / 1000000U);

	return Millis;
}


// ---------- Get Current TimeStamp ----------
string GetTimeStamp(void)
{
	tm tm_time;
    timespec ts;
	ostringstream ss;

	clock_gettime(CLOCK_REALTIME, &ts);
	localtime_r(&ts.tv_sec, &tm_time);

	ss << setfill('0')
	   << setw(2) << tm_time.tm_mday << "/"
	   << setw(2) << (tm_time.tm_mon + 1U) << "/"
	   << setw(4) << (tm_time.tm_year + 1900U) << " "
	   << setw(2) << tm_time.tm_hour << ":"
	   << setw(2) << tm_time.tm_min << ":"
	   << setw(2) << tm_time.tm_sec << "."
	   << setw(3) << (ts.tv_nsec / 1000000UL);

	return ss.str();
}


// ---------- Update Time ----------
void UpdateTime(UInt8_t day, UInt8_t month, UInt16_t year, UInt32_t millis)
{
    time_t sec;
	timespec ts;
    tm tm_time{};

    if(millis >= 86400000U)
    {
    	millis %= 86400000U;
    }

    if(day < 1 || 31 < day)
    {
    	day = 1;
    }

    if(month < 1 || 12 < month)
	{
    	month = 1;
	}

    if(year < 2026)
	{
    	year = 2026;
	}

    tm_time.tm_mday = day;
    tm_time.tm_mon  = month - 1;
    tm_time.tm_year = year - 1900;

    tm_time.tm_hour = millis / 3600000U;
    tm_time.tm_min  = (millis % 3600000U) / 60000U;
    tm_time.tm_sec  = (millis % 60000U) / 1000U;
    tm_time.tm_isdst = -1;

    sec = mktime(&tm_time);

    ts.tv_sec  = sec;
    ts.tv_nsec = (millis % 1000U) * 1000000UL;

    clock_settime(CLOCK_REALTIME, &ts);

    return;
}


// ---------- CRC16 function ----------
UInt16_t crc16(UInt8_t *Data, UInt64_t Len)
{
	UInt16_t crc = 0xFFFFU;
	UInt64_t i = 0L;
	UInt8_t j = 0U;

	for(i = 0L; i < Len; i++)
	{
		crc ^= Data[i];
		for(j = 0U; j < 8U; j++)
		{
			if(crc & 0x01U)
			{
				crc = (crc >> 1U) ^ 0xA001U;
			}
			else
			{
				crc >>= 1U;
			}
		}
	}

	return crc;
}


// ---------- Calculate software checksum ----------
UInt16_t getSwCheckSum(string Path)
{
	ifstream file;
	string secName;
	Elf64_Ehdr ehdr;
	UInt16_t crc = 0U, i = 0U;

	// Open EXE file
	file.open(Path.c_str(), ios::binary);
	if(!file)
	{
		cout << "Failed to open EXE file..." << endl;
		return crc;
	}

	// Read EXE header
	file.read(reinterpret_cast<Int8_t *>(&ehdr), sizeof(ehdr));
	if(strncmp((Int8_t *)ehdr.e_ident, ELFMAG, SELFMAG) != 0)
	{
		cout << "Invalid EXE file..." << endl;
		return crc;
	}

	// Read section header
	file.seekg(ehdr.e_shoff, ios::beg);
	vector<Elf64_Shdr> shdrs(ehdr.e_shnum);
	file.read(reinterpret_cast<Int8_t *>(shdrs.data()), ehdr.e_shentsize * ehdr.e_shnum);

	// Read section header string table
	Elf64_Shdr shstr = shdrs[ehdr.e_shstrndx];
	vector<Int8_t> shstrtab(shstr.sh_size);
	file.seekg(shstr.sh_offset, ios::beg);
	file.read(shstrtab.data(), shstr.sh_size);

	// Find .text section
	for(i = 0; i < ehdr.e_shnum; i++)
	{
		secName = &shstrtab[shdrs[i].sh_name];
		if(secName == ".text")
		{
			vector<UInt8_t> buffer(shdrs[i].sh_size);
			file.seekg(shdrs[i].sh_offset, ios::beg);
			file.read(reinterpret_cast<Int8_t *>(buffer.data()), shdrs[i].sh_size);

			return crc16(buffer.data(), buffer.size());
		}
	}

	cout << "Failed to calculate Checksum..." << endl;

	return crc;
}


// ---------- Create Path ----------
string createPath(string Path)
{
	tm tm_time;
	timespec ts;
	Int8_t date[10];
	Int32_t testCnt = -1;

	Int32_t n = -1;
	bool valid = true;
	DIR *dir = nullptr;
	struct dirent *entry;
	char *numStr = nullptr;

	clock_gettime(CLOCK_REALTIME, &ts);
	localtime_r(&ts.tv_sec, &tm_time);

	strftime(date, sizeof(date), "%d%b%y/", &tm_time);

	Path = Path + (Path[Path.size() - 1] == '/' ? "" : "/") + "Res/" + date;

	mkdir(Path.c_str(), 0775);

	// ---------------- Find max Test number ----------------
	dir = opendir(Path.c_str());
	if(dir != nullptr)
	{
		while((entry = readdir(dir)) != nullptr)
		{
			// Must start with "Test"
			if(strncmp(entry->d_name, "Test", 4) != 0)
			{
				continue;
			}

			numStr = entry->d_name + 4;

			// Numeric check
			if(*numStr == '\0')
			{
				continue;
			}

			valid = true;
			for(const char *p = numStr; *p; ++p)
			{
				if(!isdigit(*p))
				{
					valid = false;
					break;
				}
			}
			if(!valid)
			{
				continue;
			}

			n = atoi(numStr);
			if(n > testCnt)
			{
				testCnt = n;
			}
		}
		closedir(dir);
	}

	// Next test number
	testCnt++;

	Path = Path + "Test" + to_string(testCnt) + "/";

	mkdir(Path.c_str(), 0775);

	return Path;
}


// ---------- Get Path ----------
string getPath(UInt8_t typ)
{
	string Path = "";
	ssize_t len = 0;
	Int8_t path[PATH_MAX], *tmp;

	timespec ts;
	tm tm_time;

	clock_gettime(CLOCK_REALTIME, &ts);
	localtime_r(&ts.tv_sec, &tm_time);

	// Get Exe OR Load Path
	if(typ == 0U || typ == 1U)
	{
		len = readlink("/proc/self/exe", path, PATH_MAX - 1);
		if(len != -1)
		{
			path[len] = '\0';

			if(typ == 1)
			{
				tmp = strrchr(path, '/');
				*(tmp + 1) = '\0';
			}

			Path = path;
		}
		else
		{
			Path = "";
		}
	}

	// Get Save Path
	else if(typ == 2U)
	{
		Day   = tm_time.tm_mday;
		Month = tm_time.tm_mon + 1U;
		Year  = tm_time.tm_year + 1900U;

		if(ParentPath != "")
		{
			Path = ParentPath;
		}
		else
		{
			Path = SDCardSaveFlag == false ? createPath(LoadPath) : createPath("/mnt/sdcard/IPData/");
		}
	}

	// Get New Save Path
	else if(typ == 3U)
	{
		if(SDCardSaveFlag == true)
		{
			return SavePath;
		}

		if(tm_time.tm_mday == Day && (tm_time.tm_mon + 1U) == Month && (tm_time.tm_year + 1900U) == Year)
		{
			return SavePath;
		}

		Day   = tm_time.tm_mday;
		Month = tm_time.tm_mon + 1U;
		Year  = tm_time.tm_year + 1900U;

		ParentPath = SavePath;

		Path = createPath(LoadPath);
		system(("sudo mv " + ParentPath + "* " + Path).c_str());
		system(("sudo rm -rf " + ParentPath).c_str());
	}

	else
	{

	}

	return Path;
}


// ---------- readFile ----------
string readFile(string path)
{
	Int32_t file = -1, dataCnt = 0;
	Int8_t *buff;
	string data;

	file = open(path.c_str(), O_RDONLY);
	if(file < 0)
	{
		cerr << "Error: open: Failed to open file" << endl;
		return "";
	}

	dataCnt = lseek(file, 0, SEEK_END);
	lseek(file, 0, SEEK_SET);

	buff = (Int8_t *)malloc(dataCnt+1);
	if(read(file, buff, dataCnt) < 0)
	{
		cerr << "Error: open: Failed to open file" << endl;
		free(buff);
		return "";
	}
	buff[dataCnt] = 0;

	data = (const Int8_t *)buff;
	free(buff);
	close(file);

	return data;
}


// ---------- load Config file Data ----------
void loadConfigData(void)
{
	string data, ipAddr;
	json parsedData;

	// Open file & read data
	data = readFile(LoadPath + "Config.json");

	if(data == "")
	{
		cout << "Failed to load config data..." << endl << flush;
		return;
	}

	// load config data
	try
	{
		parsedData = json::parse(data);

		ModelPath = parsedData["MODEL_FILE"];
		VideoSource = parsedData["VIDEO_SRC"];

		EthInterface = parsedData["ETH_INTERFACE"];
		EthConName = parsedData["ETH_CON_NAME"];

		HilsComm = parsedData["HILS_COMM"];
		HilsUdpPort = parsedData["HILS_UDPPORT"];

		DL_UDPPort = parsedData["DL_UDPPORT"];
		ipAddr = parsedData["DL_IPADDR"];
		if(validateIP(ipAddr.c_str()) == false)
		{
			cout << "Please enter valid DL_IPADDR in config file" << endl << flush;
			exit(1);
		}
		strcpy(DL_IPAddr, ipAddr.c_str());

		ipAddr = parsedData["IP_IPADDR"];
		if(validateIP(ipAddr.c_str()) == false)
		{
			cout << "Please enter valid IP_IPADDR in config file" << endl << flush;
			exit(1);
		}
		strcpy(IP_IPAddr, ipAddr.c_str());

		ipAddr = parsedData["GATEWAY_ADDR"];
		if(validateIP(ipAddr.c_str()) == false)
		{
			cout << "Please enter valid GATEWAY_ADDR in config file" << endl << flush;
			exit(1);
		}
		strcpy(GateWay_Addr, ipAddr.c_str());

		cout << "Config data loaded successfully..." << endl << flush;
	}
	catch(exception &e)
	{
		cerr << "Error in loading config data" << endl;
		cout << e.what() << endl << flush;
	}

	return;
}


// ----------system Power Off ----------
void systemPowerOff(void)
{
	string ShutDownCMD = "sudo shutdown -h now";
	Int8_t Status = 0;

	// Clear all the flags
	ObcDataThreadFlag = false;
	ProcessThreadFlag = false;
	DataRecvThreadFlag = false;
	VideoStreamThreadFlag = false;
	CamHandShakeThreadFlag = false;

	cout << "Forcing to ShutDown System..." << endl << flush;

	Status = system(ShutDownCMD.c_str());
	if(Status != 0)
	{
		cout << "Failed to ShutDown System" << endl << flush;
	}

	exit(1);

	return;
}


// ---------- Check Serial Port is available or not ----------
bool releaseUDPPort(Int32_t Port)
{
	string Command = "fuser -k " + to_string(Port) + "/udp >/dev/null 2>&1";
	system(Command.c_str());
	usleep(10 * 1000);

	return true;
}


// ---------- Compare String ----------
bool cmpStr(const Int8_t *Str1, const Int8_t *Str2, UInt32_t Len)
{
	UInt32_t i = 0U;

	for(i = 0U; i < Len; i++)
	{
		if(Str1[i] != Str2[i])
		{
			return false;
		}
	}

	return true;
}


// ---------- Get IP Address ----------
string getIPAddr(string &EthInterface)
{
	struct ifaddrs *ifa;
	void *tmpAddrPtr = nullptr;
	char IPAddr[INET_ADDRSTRLEN] = {0};
	struct ifaddrs *ifAddrStruct = nullptr;

	if(getifaddrs(&ifAddrStruct) != 0)
	{
		perror("getifaddrs failed");
		return "";
	}

	for(ifa = ifAddrStruct; ifa != nullptr; ifa = ifa->ifa_next)
	{
		if(!ifa->ifa_addr)
		{
			continue;
		}

		if(ifa->ifa_addr->sa_family == AF_INET && strcmp(ifa->ifa_name, EthInterface.c_str()) == 0)
		{
			tmpAddrPtr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
			if(inet_ntop(AF_INET, tmpAddrPtr, IPAddr, INET_ADDRSTRLEN) == nullptr)
			{
				perror("inet_ntop failed");
				IPAddr[0] = '\0';
			}

			break;
		}
	}

	freeifaddrs(ifAddrStruct);
	return string(IPAddr);
}


// ---------- Modify IP Address Last Byte ----------
void modifyIPAddr(Int8_t *IPAddr, Int32_t Delta)
{
	string ipAddr = IPAddr;

	size_t lastDot = ipAddr.rfind('.');
	if(lastDot <= 6 && ipAddr.size() <= lastDot)
	{
		return;
	}

	Int32_t lastPart = stoi(ipAddr.substr(lastDot+1));
	ipAddr = ipAddr.substr(0, (lastDot + 1)) + to_string(lastPart+Delta);

	memcpy((void *)IPAddr, (const void *)(ipAddr.c_str()), ipAddr.size());
	return;
}


// ---------- Set IP Address ----------
bool setIPAddr(Int8_t *IPAddr, Int8_t *NetMask, Int8_t *GateWay)
{
	bool Status = false;
	string IPAddr_CMD = "", IPAddress = "";

	IPAddress = getIPAddr(EthInterface);
	cout << "IP Address - " << IPAddress << endl;

	Status = cmpStr(IPAddr, IPAddress.c_str(), strlen(IPAddr));
	if(Status == true)
	{
		return Status;
	}

	IPAddr_CMD = string("sudo nmcli connection modify " + EthConName + " ipv4.address \"") + string(IPAddr) + string("/24\" && sudo nmcli device reapply " + EthInterface);
	system(IPAddr_CMD.c_str());

	IPAddress = getIPAddr(EthInterface);
	cout << "New IP Address - " << IPAddress << endl;

	Status = cmpStr(IPAddr, IPAddress.c_str(), strlen(IPAddr));

	return Status;
}


// ---------- Validate Integer ----------
bool validateInt(Int8_t *str)
{
	UInt8_t charCnt = 0U;

	do
	{
		if(isdigit(*str) == false)
		{
			if(! (charCnt == 0U && (*str == '-' || *str == '+')))
			{
				return false;
			}
		}

		charCnt++;

	} while(*(++str));

	return true;
}


// ---------- Validate IP Address ----------
bool validateIP(const Int8_t *Addr)
{
	// Local Variable
	Int8_t Result;
	struct sockaddr_in sa;

    Result = inet_pton(AF_INET, Addr, &(sa.sin_addr));
    return Result != 0;
}


// ---------- Validate Port Number ----------
Int32_t validatePORT(Int8_t *Port)
{
	Int32_t Result = -1;

	if(validateInt(Port) == false)
	{
		return -1;
	}

	// Convert & update the port number
	Result = atoi(Port);

	// Check port number is in valid range or not
	if(Result < 1024 || 49151 < Result)
	{
		return -2;
	}

	return Result;
}


// ---------- Check User Flags ----------
void checkFlags(Int32_t argc, Int8_t *argv[])
{
	Int32_t argcCnt = 0;

	// Check if flags are given or not
	if(argc == 1)
	{
		return;
	}

	// If flags are given
	while(argc > (++argcCnt))
	{
        // Enable Template Matching
		if(strcmp("-T", argv[argcCnt]) == 0)
		{
			TemplateMatchingFlag = true;
		}

		// Save All Data
		else if(strcmp("-S", argv[argcCnt]) == 0)
		{
			SaveDataFlag = true;
		}

		// Camera Not Available
		else if(strcmp("-H", argv[argcCnt]) == 0)
		{
			SeekerStatus = true;
			NUCStatus = true;
		}

		// Display frame when got this flag
		else if(strcmp("-DF", argv[argcCnt]) == 0)
		{
			DisplayFrameFlag = true;
		}

		// Save Data in SD Card
		else if(strcmp("-SD", argv[argcCnt]) == 0)
		{
			SaveDataFlag = true;
			SDCardSaveFlag = true;
		}

		else if(strcmp("-BP", argv[argcCnt]) == 0)
		{
			BirdPlaneDataFlag = true;
		}

		else if(strcmp("-TD", argv[argcCnt]) == 0)
		{
			TgtDataModeFlag = true;
		}

		else if(strcmp("-PT", argv[argcCnt]) == 0)
		{
			argcCnt++;
			if(argcCnt < argc)
			{
				ParentPath = argv[argcCnt];
				ParentPath = ParentPath + (ParentPath[ParentPath.size()-1] == '/' ? "" : "/");
			}
			else
			{
				cout << "Please provide path after like '-PT Path'" << endl << flush;
				exit(1);
			}
		}

		// Start Detection without RS422 Command
		else if(strcmp("-D", argv[argcCnt]) == 0)
		{
			DetectObjectFlag = true;
			if((argcCnt + 1) < argc && validateInt(argv[argcCnt + 1]) == true)
			{
				argcCnt++;
				IPCardMode = atoi(argv[argcCnt]);
				if(4U < IPCardMode)
				{
					cout << "Please provide valid Mode between 0 - 4" << endl << flush;
					exit(1);
				}

			}
		}

		else if(strcmp("-M", argv[argcCnt]) == 0)
		{
			argcCnt++;
			if(argcCnt < argc)
			{
				if(validateInt(argv[argcCnt]) == false)
				{
					cout << "Please provide valid Missile ID" << endl << flush;
					exit(1);
				}

				MissileID = atoi(argv[argcCnt]);

				if(MissileID < 1U || 64U < MissileID)
				{
					cout << "Please provide valid Missile ID between 1 - 64" << endl << flush;
					exit(1);
				}

				DL_UDPPort = DL_UDPPort + (MissileID - 1);
				IPAddrStatus = true;
				ObcCmdFlag = true;
			}
			else
			{
				cout << "Please provide Missile ID after like '-M MisileID'" << endl << flush;
				exit(1);
			}
		}

		// Wrong Flags are provided
		else
		{
			cout << "You have provided wrong flags" << endl << flush;

			cout << "Start Detection                           : -D" << endl << flush;
			cout << "Save All Data in Project directory        : -S" << endl << flush;
			cout << "Skip Camera Handshaking                   : -H" << endl << flush;
			cout << "Display Video Frames                      : -DF" << endl << flush;
			cout << "Save Data in SD Card (Only for IPCard)    : -SD" << endl << flush;
			cout << "Send target data of Birds & Plane         : -BP" << endl << flush;
			cout << "Send TargetData Sync with Detection       : -TD" << endl << flush;
			cout << "Missile ID Configuration                  : -M MissileID" << endl << flush;
			exit(1);
		}
	}

	return;
}




