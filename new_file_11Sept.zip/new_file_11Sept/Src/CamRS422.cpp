// ============================================================================
// Name		: CamRS422.cpp
// Date		: 21 Jan 2026
// ============================================================================


// ---------- Header Inclusion ----------
#include "CamRS422.h"


// ---------- Camera Commands ----------
Int8_t Cam_HandShake[1] = {(Int8_t)0xB6};
Int8_t Cam_ManNUC[7] = {(Int8_t)0xA5, (Int8_t)0x57, (Int8_t)0x37, (Int8_t)0x01, (Int8_t)0xC2, (Int8_t)0xA7, (Int8_t)0x2F};
Int8_t Cam_ExtNUC[7] = {(Int8_t)0xA5, (Int8_t)0x57, (Int8_t)0x37, (Int8_t)0x01, (Int8_t)0xE2, (Int8_t)0x83, (Int8_t)0x4D};

// ---------- Camera Response ----------
Int8_t Cam_HandShake_Resp_ANA[3] = {(Int8_t)0xB6, (Int8_t)0xA5, (Int8_t)0xC9};
Int8_t Cam_HandShake_Resp_IN[3] = {(Int8_t)0xB6, (Int8_t)0xA5, (Int8_t)0xCC};
Int8_t Cam_NUC_Resp[7] = {(Int8_t)0xA5, (Int8_t)0x00, (Int8_t)0x37, (Int8_t)0x00, (Int8_t)0xCA, (Int8_t)0x31, (Int8_t)0xAA};


// ---------- Constructor ----------
CamRS422 :: CamRS422(void)
{
	CamRecvFD = open(CamPort, O_RDONLY | O_NOCTTY | O_NONBLOCK | O_SYNC);
	CamTransmitFD = open(CamPort, O_WRONLY | O_NOCTTY | O_NONBLOCK | O_SYNC);

	if(CamRecvFD < 0 || CamTransmitFD < 0)
	{
		cout << "Error: open: Camera Serial Port is not available" << endl;
		CamPortStatus = false;
		return;
	}


	if(tcgetattr(CamRecvFD, &Camtty) != 0)
	{
		cout << "Error: tcgetattr: Camera Serial Port is not available" << endl;
		CamPortStatus = false;
		return;
	}

	// 8N1, no flow control
	Camtty.c_cflag &= ~PARENB;
	Camtty.c_cflag &= ~CSTOPB;
	Camtty.c_cflag &= ~CRTSCTS;
	Camtty.c_cflag &= ~CSIZE;
	Camtty.c_cflag |= CS8;
	Camtty.c_cflag |= (CLOCAL | CREAD);

	// Software flow control off
	Camtty.c_iflag &= ~(IXON | IXOFF | IXANY);

	// Set timeout
	Camtty.c_cc[VMIN]  = 0;   // No wait
	Camtty.c_cc[VTIME] = 0;   // No timeout

	// Set Speed
	cfmakeraw(&Camtty);					// raw mode
	cfsetspeed(&Camtty, CamBAUD);		// BaudRate

	// Flush Port, then applies attributes
	tcflush(CamRecvFD, TCIFLUSH);
	if(tcsetattr(CamRecvFD, TCSANOW, &Camtty) != 0)
	{
		cout << "Error: tcsetattr: Camera Serial Port is not available" << endl;
		CamPortStatus = false;
		return;
	}

	cout << "Camera RS422 opened successfully..." << endl << flush;
	memset((void *)rxBuff, 0, sizeof(rxBuff));

	// Empty the buffer
	while(read(CamRecvFD, rxBuff, 1) >= 1)
	{
		continue;
	}

	// Create ePoll
	ePollFD = epoll_create1(0);
	event.events = EPOLLIN;
	event.data.fd = CamRecvFD;
	epoll_ctl(ePollFD, EPOLL_CTL_ADD, CamRecvFD, &event);

	return;
}


// ---------- Destructor ----------
CamRS422 :: ~CamRS422(void)
{
	close(CamRecvFD);
	return;
}


// ---------- HandShake ----------
bool CamRS422 :: HandShake(void)
{
	Int32_t nfd = -1;
	Int16_t Bytes = 0;
	UInt16_t charCnt = 0;

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 1000;	// 1 milliseconds

	charCnt = 0;
	memset((void *)rxBuff, 0, sizeof(rxBuff));
	if(write(CamTransmitFD, Cam_HandShake, sizeof(Cam_HandShake)) !=
	   static_cast<ssize_t>(sizeof(Cam_HandShake)))
	{
		return false;
	}

	clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

	nfd = epoll_wait(ePollFD, &event, 1, 2000);
	if(nfd < 0)
	{
		return false;
	}

	while((Bytes = read(CamRecvFD, (rxBuff + charCnt), 1)) > 0)
	{
		charCnt += Bytes;
		if(charCnt >= sizeof(rxBuff))
		{
			charCnt--;
		}

		if(static_cast<UInt8_t>(rxBuff[0]) != 0xB6U)
		{
			charCnt = 0;

		}
	}

	if(charCnt <= 2)
	{
		cout << "Camera Handshaking failed..." << endl << flush;
		return false;
	}
	else
	{
			printf("CAM HandShake Recv - %02X %02X %02X\n",
				static_cast<UInt8_t>(rxBuff[0]), static_cast<UInt8_t>(rxBuff[1]),
				static_cast<UInt8_t>(rxBuff[2]));

		if(cmpStr(rxBuff, Cam_HandShake_Resp_ANA, 2) == true)
		{
			SeekerStatus = true;
			cout << "Camera handshaking successful..." << endl << flush;

			if(cmpStr(rxBuff, Cam_HandShake_Resp_ANA, 3) == true)
			{
				cout << "No need of NUC for Vendor Camera...." << endl;
				NUCStatus = true;
			}

			return true;
		}
		else
		{
			cout << "Camera Handshaking failed..." << endl << flush;
		}
	}

	return false;
}


// ---------- Nuc 1PT ----------
bool CamRS422 :: Nuc_1PT(UInt8_t Type)
{
	Int32_t nfd = -1;
	Int16_t Bytes = 0;
	UInt16_t charCnt = 0;

	struct timespec ts;
	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 1000;	// 1 milliseconds

	charCnt = 0;
	memset((void *)rxBuff, 0, sizeof(rxBuff));

	if(Type == 0x00U)
	{
		if(write(CamTransmitFD, Cam_ManNUC, sizeof(Cam_ManNUC)) !=
		   static_cast<ssize_t>(sizeof(Cam_ManNUC)))
			return false;
	}
	else if(Type == 0x01U)
	{
		if(write(CamTransmitFD, Cam_ExtNUC, sizeof(Cam_ExtNUC)) !=
		   static_cast<ssize_t>(sizeof(Cam_ExtNUC)))
			return false;
	}
	else
	{

	}

	clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

	nfd = epoll_wait(ePollFD, &event, 1, 2000);
	if(nfd < 0)
	{
		return false;
	}

	while((Bytes = read(CamRecvFD, (rxBuff + charCnt), 1)) > 0)
	{
		charCnt += Bytes;
		if(charCnt >= sizeof(rxBuff))
		{
			charCnt--;
		}

		if(static_cast<UInt8_t>(rxBuff[0]) != 0xA5U)
		{
			charCnt = 0;
		}
	}

	if(charCnt <= 6)
	{
		cout << "Error in NUC_1PT Manual..." << endl << flush;
		return false;
	}
	else
	{
		printf("CAM NUC Recv - %02X %02X %02X %02X %02X %02X %02X\n",
			static_cast<UInt8_t>(rxBuff[0]), static_cast<UInt8_t>(rxBuff[1]),
			static_cast<UInt8_t>(rxBuff[2]), static_cast<UInt8_t>(rxBuff[3]),
			static_cast<UInt8_t>(rxBuff[4]), static_cast<UInt8_t>(rxBuff[5]),
			static_cast<UInt8_t>(rxBuff[6]));

		if(static_cast<UInt8_t>(rxBuff[0]) == 0xA5U &&
		   static_cast<UInt8_t>(rxBuff[6]) == 0xAAU)
		{
			cout << "NUC_1PT Manual is successful..." << endl << flush;
			return true;
		}
		else
		{
			cout << "Error in NUC_1PT Manual..." << endl << flush;
			return false;
		}
	}

	return false;
}


// ---------- HandShake Thread ----------
void * CamRS422 :: HandShakeThread(void *args)
{
	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	CamRS422 *Instance = static_cast<CamRS422 *>(args);

	while(CamHandShakeThreadFlag == true)
	{
		if(SeekerStatus == false)
		{
			SeekerStatus = Instance->HandShake();
			usleep(100 * 1000);
		}

		if(SeekerStatus == true && NUCStatus == false)
		{
			Instance->Nuc_1PT(1);
			usleep(400 * 1000);
			Instance->Nuc_1PT(1);

			NUCStatus = true;
			CamHandShakeThreadFlag = false;
		}
	}

	pthread_exit(NULL);
	return nullptr;
}


