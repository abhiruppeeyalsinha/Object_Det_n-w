// ============================================================================
// Name		: ObjDetection.cu
// Date		: 21 Jan 2026
// ============================================================================

// // ---------- Header Inclusion ----------
// #include "ObjDetection.h"

// // ---------- Logger for TensorRT messages ----------
// class Logger : public ILogger
// {
// 	void log(Severity severity, const char *msg) noexcept override
// 	{
// 		if (severity <= Severity::kWARNING)
// 		{
// 			cout << "[TensorRT] : " << msg << endl;
// 		}
// 	}
// };

// Logger logger;

// __global__ void ConvToFP16_NormCHW(const float *ch0, const float *ch1, const float *ch2, __half *output, int32_t width, int32_t height)
// {
// 	int32_t x, y, idx, imgArea;

// 	x = blockIdx.x * blockDim.x + threadIdx.x;
// 	y = blockIdx.y * blockDim.y + threadIdx.y;

// 	if (x >= width || y >= height)
// 	{
// 		return;
// 	}

// 	idx = y * width + x;
// 	imgArea = width * height;
// 	output[0 * imgArea + idx] = __float2half(ch0[idx] / 255.0f);
// 	output[1 * imgArea + idx] = __float2half(ch1[idx] / 255.0f);
// 	output[2 * imgArea + idx] = __float2half(ch2[idx] / 255.0f);
// }

// __global__ void fp16_to_fp32(const __half *input, float *output, int32_t N)
// {
// 	int32_t idx = blockIdx.x * blockDim.x + threadIdx.x;
// 	if (idx < N)
// 	{
// 		output[idx] = __half2float(input[idx]);
// 	}
// }

// // ---------- Constructor ----------
// ObjDetection ::ObjDetection(void)
// {
// 	Yolov5_Dim.height = 640;
// 	Yolov5_Dim.width = 640;

// 	Detections = 25200U;
// 	DetectionSize = 9U;
// 	ClassCnt = 4U;

// 	ConfThreshold = 0.60f;
// 	IOUThreshold = 0.4f;

// 	TargetDataArr.clear();

// 	ActiveArr = 0;
// 	StoreArr = 1;
// 	TemplateArr[0].clear();
// 	TemplateArr[1].clear();

// 	MaxTemplateCnt = 10U;
// 	TemplateFrameCnt = 5U;
// 	TempConfThreshold = 0.85f;

// 	if (LoadEngineFile() == true)
// 	{
// 		AIStatusFlag = true;
// 		cout << "Engine Loaded Successfully" << endl;
// 	}
// 	else
// 	{
// 		AIStatusFlag = false;
// 		cout << "Failed to load Engine file" << endl;
// 	}

// 	return;
// }

// // ---------- Destructor ----------
// ObjDetection ::~ObjDetection(void)
// {
// 	try
// 	{
// 		for (void *ptr : Bindings)
// 		{
// 			if (ptr)
// 			{
// 				cudaFree(ptr);
// 			}
// 		}

// 		cudaStreamDestroy(rawStream);
// 	}
// 	catch (Exception &e)
// 	{
// 	}

// 	return;
// }

// // ---------- Get Memory Size ----------
// size_t ObjDetection ::getMemorySize(Dims dims, size_t ElementSize)
// {
// 	size_t size = ElementSize;

// 	for (Int32_t i = 0; i < dims.nbDims; i++)
// 	{
// 		size *= dims.d[i];
// 	}

// 	return size;
// }

// // ---------- Load Engine File ----------
// bool ObjDetection ::LoadEngineFile(void)
// {
// 	Dims dims;
// 	size_t elementSize;

// 	try
// 	{
// 		setenv("CUDA_MODULE_LOADING", "LAZY", 1);

// 		ifstream EngineFile(ModelPath, ios::binary);
// 		if (!EngineFile)
// 		{
// 			cerr << "Failed to open engine file." << endl;
// 			return false;
// 		}

// 		EngineFile.seekg(0, ios::end);

// 		auto fsize = EngineFile.tellg();
// 		EngineFile.seekg(0, ios::beg);

// 		vector<char> engine_data(fsize);
// 		EngineFile.read(engine_data.data(), fsize);

// 		runtime.reset(createInferRuntime(logger));
// 		engine.reset(runtime->deserializeCudaEngine(engine_data.data(), fsize));
// 		context.reset(engine->createExecutionContext());

// #pragma GCC diagnostic push
// #pragma GCC diagnostic ignored "-Wdeprecated-declarations"

// 		Int32_t nbBindings = engine->getNbBindings();
// 		Bindings.resize(nbBindings, nullptr);
// 		BindingSizes.resize(nbBindings, 0);

// 		for (Int32_t i = 0; i < nbBindings; i++)
// 		{
// 			dims = engine->getBindingDimensions(i);
// 			elementSize = sizeof(__half);

// 			BindingSizes[i] = getMemorySize(dims, elementSize);
// 			cudaMalloc(&Bindings[i], BindingSizes[i]);
// 		}

// #pragma GCC diagnostic pop

// 		rawStream = cuda::StreamAccessor::getStream(cvStream);
// 		return true;
// 	}
// 	catch (Exception &e)
// 	{
// 		return false;
// 	}

// 	return false;
// }

// // ---------- PreProcess ----------
// void ObjDetection ::preProcess(Mat VideoFrame, __half *InputBuff)
// {
// 	dim3 block(32, 32);
// 	cuda::GpuMat Frame, GpuCHW[3];
// 	dim3 grid((Yolov5_Dim.width + block.x - 1) / block.x, (Yolov5_Dim.height + block.y - 1) / block.y);

// 	Frame.upload(VideoFrame, cvStream);

// 	// Created padded output(resize by padding to 640x480 are within 640x640)
// 	cuda::GpuMat GpuFrame(Yolov5_Dim.width, Yolov5_Dim.height, Frame.type(), Scalar::all(0));
// 	Frame.copyTo(GpuFrame(Rect(0, 0, VideoDim.width, VideoDim.height)), cvStream);

// 	// Convert the float32 & normalize on GPU
// 	GpuFrame.convertTo(GpuFrame, CV_32FC3, cvStream);
// 	cuda::split(GpuFrame, GpuCHW, cvStream);

// 	// Launch custom FP16 kernel conversion & normalization kernel
// 	ConvToFP16_NormCHW<<<grid, block, 0, rawStream>>>(GpuCHW[0].ptr<float>(), GpuCHW[1].ptr<float>(), GpuCHW[2].ptr<float>(), static_cast<__half *>(InputBuff), Yolov5_Dim.width, Yolov5_Dim.height);

// 	return;
// }

// // ---------- PostProcess ----------
// void ObjDetection ::postProcess(UInt16_t VideoWidth, UInt16_t VideoHeight)
// {
// 	int32_t Total = DetectionSize * Detections;

// 	vector<Rect> Boxes;
// 	vector<Int32_t> Indices;
// 	vector<UInt8_t> ClassIds;
// 	vector<float> Confidances;

// 	float Confidence;
// 	float ClassScore[4];
// 	float ObjConf, ClassConf;
// 	UInt8_t ClassID = 0;

// 	float *FP32_OutBuff = nullptr;
// 	dim3 block(1024), grid((Total + 255) / 256);

// 	vector<float> Output(Total);

// 	Int16_t CentreX, CentreY, Width, Height;
// 	Int16_t X1, Y1, X2, Y2;

// 	struct _AIData_ Target;

// 	Boxes.clear();
// 	Indices.clear();
// 	ClassIds.clear();
// 	Confidances.clear();
// 	TargetDataArr.clear();

// 	// Allocate device memory for FP32
// 	cudaMalloc(&FP32_OutBuff, Total * sizeof(float));

// 	// Launch fp16->fp32 conversion
// 	fp16_to_fp32<<<grid, block, 0, rawStream>>>(static_cast<const __half *>(Bindings[1]), FP32_OutBuff, Total);

// 	cudaMemcpyAsync(Output.data(), FP32_OutBuff, Output.size() * sizeof(float), cudaMemcpyDeviceToHost);
// 	cudaFree(FP32_OutBuff);

// 	cvStream.waitForCompletion();

// 	for (UInt32_t i = 0; i < Detections; i++)
// 	{
// 		ObjConf = Output[(i * DetectionSize) + ClassCnt];

// 		// Skip if Object Confidence is less than Threshold
// 		if (ObjConf < ConfThreshold || ObjConf > 1.0f || isnan(ObjConf))
// 		{
// 			continue;
// 		}

// 		for (UInt32_t j = 0; j < ClassCnt; j++)
// 		{
// 			ClassScore[j] = Output[(i * DetectionSize) + 5 + j];
// 		}

// 		ClassID = max_element(ClassScore, ClassScore + ClassCnt) - ClassScore;
// 		ClassConf = ClassScore[ClassID];
// 		Confidence = ObjConf * ClassConf;

// 		// Calculate Bounding Box Co-Ordinate & Size
// 		CentreX = Output[i * DetectionSize + 0];
// 		CentreY = Output[i * DetectionSize + 1];
// 		Width = Output[i * DetectionSize + 2];
// 		Height = Output[i * DetectionSize + 3];

// 		// Skip if Confidence is less than Threshold
// 		if (CentreX < 0 || CentreX > Yolov5_Dim.width || CentreY < 0 || CentreY > Yolov5_Dim.height || Width <= 0 || Height <= 0 || Width > Yolov5_Dim.width || Height > Yolov5_Dim.height || isnan(CentreX) || isnan(CentreY) || isnan(Width) || isnan(Height))
// 		{
// 			continue;
// 		}

// 		X1 = FindMax(0, (CentreX - (Width / 2)));
// 		Y1 = FindMax(0, (CentreY - (Height / 2)));

// 		X2 = FindMin(VideoWidth - 1, (CentreX + (Width / 2)));
// 		Y2 = FindMin(VideoHeight - 1, (CentreY + (Height / 2)));

// 		if (X2 >= X1 && Y2 >= Y1)
// 		{
// 			Boxes.emplace_back(Rect(X1, Y1, X2 - X1, Y2 - Y1));
// 			Confidances.emplace_back(Confidence);
// 			ClassIds.emplace_back(ClassID);
// 		}
// 	}

// 	dnn::NMSBoxes(Boxes, Confidances, ConfThreshold, IOUThreshold, Indices);

// 	for (UInt32_t idx : Indices)
// 	{
// 		Target.Type = 0;
// 		Target.ClassID = ClassIds[idx];
// 		Target.Confidance = Confidances[idx];
// 		Target.BoundingBox = Boxes[idx];
// 		Target.CenterPoint = Point(Boxes[idx].x + Boxes[idx].width / 2, Boxes[idx].y + Boxes[idx].height / 2);

// 		TargetDataArr.push_back(Target);
// 	}

// 	return;
// }

// // ---------- Template Matching ----------
// void ObjDetection ::templateMatch(Mat &VideoFrame)
// {
// 	UInt16_t FrameWidth = VideoFrame.cols;
// 	UInt16_t FrameHeight = VideoFrame.rows;

// 	UInt32_t DetectionCnt = 0U;

// 	const float ROIScale = 8.0f;
// 	const float OverLapScale = 8.0f;
// 	const Int16_t StaticPixelTolerance = 3;	 // pixels of movement to consider "still moving"
// 	const UInt8_t StaticFrameThreshold = 4U; // frames of near-zero movement before dropping

// 	Rect bbox;
// 	float Confidance;
// 	Point minLoc, maxLoc;
// 	double minVal, maxVal;
// 	Mat ResFrame, ROIFrame;

// 	struct _AIData_ Target;
// 	struct _Template_ Template;

// 	// Count how many AI detections we got this frame (for the edge case of zero detections)
// 	for (auto &Tgtit : TargetDataArr)
// 	{
// 		if (Tgtit.ClassID < 4)
// 		{
// 			DetectionCnt++;
// 		}
// 	}

// 	// Phase 1: Remove OverLapping Templates & Save New Templates from AI detections
// 	for (auto &Tgtit : TargetDataArr)
// 	{
// 		if (4 <= Tgtit.ClassID)
// 		{
// 			continue;
// 		}

// 		// Remove OverLapping Templates
// 		for (auto Tmpit = TemplateArr[ActiveArr].begin(); Tmpit != TemplateArr[ActiveArr].end();)
// 		{
// 			if (Tmpit->OverLapBox.contains(Tgtit.CenterPoint) || Tgtit.BoundingBox.contains(Tmpit->CenterPoint))
// 			{
// 				Tmpit->Template.release();
// 				Tmpit = TemplateArr[ActiveArr].erase(Tmpit);
// 			}
// 			else
// 			{
// 				Tmpit++;
// 			}
// 		}

// 		if (BirdPlaneDataFlag == false && (Tgtit.ClassID == 0 || Tgtit.ClassID == 3))
// 		{
// 			continue;
// 		}

// 		// Save New Templates from AI detections
// 		bbox = Tgtit.BoundingBox & Rect(0, 0, FrameWidth, FrameHeight);

// 		Template.FrameCnt = 0U;
// 		Template.StaticCnt = 0U;				 // NEW: initialize static counter
// 		Template.LastCenter = Tgtit.CenterPoint; // NEW: seed the movement reference
// 		Template.ClassID = Tgtit.ClassID;
// 		Template.CenterPoint = Tgtit.CenterPoint;
// 		Template.BoundingBox = Tgtit.BoundingBox;

// 		Template.Template = VideoFrame(bbox).clone();

// 		Template.ROIBox.width = FindMin(FrameWidth, ((UInt16_t)(bbox.width * ROIScale)));
// 		Template.ROIBox.height = FindMin(FrameHeight, ((UInt16_t)(bbox.height * ROIScale)));
// 		Template.ROIBox.x = FindMax(0, (Tgtit.CenterPoint.x - (Template.ROIBox.width / 2)));
// 		Template.ROIBox.y = FindMax(0, (Tgtit.CenterPoint.y - (Template.ROIBox.height / 2)));
// 		Template.ROIBox = Template.ROIBox & Rect(0, 0, FrameWidth, FrameHeight);

// 		Template.OverLapBox.width = FindMin(FrameWidth, ((UInt16_t)(bbox.width * OverLapScale)));
// 		Template.OverLapBox.height = FindMin(FrameHeight, ((UInt16_t)(bbox.height * OverLapScale)));
// 		Template.OverLapBox.x = FindMax(0, (Tgtit.CenterPoint.x - (Template.OverLapBox.width / 2)));
// 		Template.OverLapBox.y = FindMax(0, (Tgtit.CenterPoint.y - (Template.OverLapBox.height / 2)));
// 		Template.OverLapBox = Template.OverLapBox & Rect(0, 0, FrameWidth, FrameHeight);

// 		if (TemplateArr[StoreArr].size() < MaxTemplateCnt)
// 		{
// 			TemplateArr[StoreArr].push_back(Template);
// 		}
// 	}

// 	// Phase 2: Template Matching - track every active template independently
// 	for (auto Tmpit = TemplateArr[ActiveArr].begin(); Tmpit != TemplateArr[ActiveArr].end();)
// 	{
// 		ResFrame.release();
// 		ROIFrame.release();

// 		ROIFrame = VideoFrame(Tmpit->ROIBox).clone();

// 		matchTemplate(ROIFrame, Tmpit->Template, ResFrame, TM_SQDIFF_NORMED);
// 		minMaxLoc(ResFrame, &minVal, &maxVal, &minLoc, &maxLoc);

// 		Confidance = 1.0f - static_cast<float>(minVal);

// 		// Quality check - drop if confidence too low
// 		if (minVal > TempConfThreshold)
// 		{
// 			Tmpit->Template.release();
// 			Tmpit = TemplateArr[ActiveArr].erase(Tmpit);
// 			continue;
// 		}

// 		bbox.x = Tmpit->ROIBox.x + minLoc.x;
// 		bbox.y = Tmpit->ROIBox.y + minLoc.y;
// 		bbox.width = Tmpit->Template.cols;
// 		bbox.height = Tmpit->Template.rows;
// 		bbox = bbox & Rect(0, 0, FrameWidth, FrameHeight);

// 		Point newCenter(bbox.x + bbox.width / 2, bbox.y + bbox.height / 2);

// 		// --- Static-target rejection ---
// 		// Compute how much the target moved since last frame
// 		double movement = norm(newCenter - Tmpit->LastCenter);

// 		cerr <<"Moment count:~ "<<movement << endl;
// 		cerr <<"Static~Pixel~Tolerance count:~ "<<StaticPixelTolerance << endl;
// 		if (movement < StaticPixelTolerance)

// 		{
// 			Tmpit->StaticCnt++;
// 		}
// 		else
// 		{
// 			Tmpit->StaticCnt = 0U;
// 		}

// 		// If stationary for too many consecutive frames, drop it
// 		if (Tmpit->StaticCnt >= StaticFrameThreshold)
// 		{
// 			Tmpit->Template.release();
// 			Tmpit = TemplateArr[ActiveArr].erase(Tmpit);
// 			continue; // don't report or refresh
// 		}
// 		// --- END new section ---

// 		// Add Template Data Targets Data
// 		Target.Type = 1;
// 		Target.ClassID = Tmpit->ClassID;
// 		Target.Confidance = Confidance;
// 		Target.BoundingBox = bbox;
// 		Target.CenterPoint = newCenter;

// 		TargetDataArr.push_back(Target);

// 		// --- FIXED: Refresh EVERY valid template independently (multi-target fix) ---
// 		// Old bug: only refreshed if Tmpit->CenterPoint == TargetData.CenterPoint
// 		// Now: refresh whenever FrameCnt < (TemplateFrameCnt - 1), or on zero-detection singleton fallback

// 		if ((Tmpit->FrameCnt < (TemplateFrameCnt - 1)) ||
// 			(DetectionCnt == 0U && TemplateArr[StoreArr].size() == 0U && TemplateArr[ActiveArr].size() == 1U))
// 		{
// 			Template.BoundingBox = bbox;
// 			Template.ClassID = Target.ClassID;
// 			Template.FrameCnt = Tmpit->FrameCnt + 1U;
// 			Template.StaticCnt = Tmpit->StaticCnt; // carry forward the static counter
// 			Template.LastCenter = newCenter;	   // update movement reference
// 			Template.CenterPoint = newCenter;

// 			// cerr<<"Static~ Cnt"<<Template.StaticCnt<<endl;
// 			Template.Template = VideoFrame(bbox).clone();

// 			Template.ROIBox.width = FindMin(FrameWidth, ((UInt16_t)(bbox.width * ROIScale)));
// 			Template.ROIBox.height = FindMin(FrameHeight, ((UInt16_t)(bbox.height * ROIScale)));
// 			Template.ROIBox.x = FindMax(0, (newCenter.x - (Template.ROIBox.width / 2)));
// 			Template.ROIBox.y = FindMax(0, (newCenter.y - (Template.ROIBox.height / 2)));
// 			Template.ROIBox = Template.ROIBox & Rect(0, 0, FrameWidth, FrameHeight);

// 			Template.OverLapBox.width = FindMin(FrameWidth, ((UInt16_t)(bbox.width * OverLapScale)));
// 			Template.OverLapBox.height = FindMin(FrameHeight, ((UInt16_t)(bbox.height * OverLapScale)));
// 			Template.OverLapBox.x = FindMax(0, (newCenter.x - (Template.OverLapBox.width / 2)));
// 			Template.OverLapBox.y = FindMax(0, (newCenter.y - (Template.OverLapBox.height / 2)));
// 			Template.OverLapBox = Template.OverLapBox & Rect(0, 0, FrameWidth, FrameHeight);

// 			if (TemplateArr[StoreArr].size() < MaxTemplateCnt)
// 			{
// 				TemplateArr[StoreArr].push_back(Template);
// 			}
// 		}
// 		// else: FrameCnt reached TemplateFrameCnt-1 → refresh skipped, template dies naturally

// 		// Delete Current Template
// 		Tmpit->Template.release();
// 		Tmpit = TemplateArr[ActiveArr].erase(Tmpit);
// 	}

// 	ResFrame.release();
// 	ROIFrame.release();

// 	// Switch Template Array
// 	ActiveArr = !ActiveArr;
// 	StoreArr = !StoreArr;

// 	return;
// }

// // ---------- Draw Boxes & Sort Using ROI ----------
// void ObjDetection ::drawBoxes(Mat &VideoFrame)
// {
// 	Int8_t thin = 1;
// 	string Label = "";
// 	Scalar white(255, 255, 255);

// 	UInt16_t FrameWidth = VideoFrame.cols;
// 	UInt16_t FrameHeight = VideoFrame.rows;
// 	Point FrameCentre(FrameWidth / 2, FrameHeight / 2);

// 	bool found = false;
// 	struct _AIData_ best;
// 	vector<struct _AIData_> Targets;
// 	double Dist, MinDist = numeric_limits<double>::max();

// 	// AOI Search
// 	Int16_t xExpStep = 10, yExpStep = 8;
// 	Rect AOI((ROI_Loc[0] - ROI_Dim[0] / 2), (ROI_Loc[1] - ROI_Dim[1] / 2), ROI_Dim[0], ROI_Dim[1]);
// 	AOI = AOI & Rect(0, 0, FrameWidth, FrameHeight);

// 	memset((void *)&TargetData, 0, sizeof(TargetData));

// 	// Draw Bounding Boxes
// 	for (auto &Target : TargetDataArr)
// 	{
// 		if (4 <= Target.ClassID)
// 		{
// 			continue;
// 		}

// 		rectangle(VideoFrame, Target.BoundingBox, white, thin);
// 		Label = ((Target.Type == 1) ? "TM: " : "AI: ") + ClassName[Target.ClassID] + " " + to_string((UInt32_t)(Target.Confidance * 100)) + "% (" + to_string(Target.CenterPoint.x - VideoFrame.cols / 2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows / 2) + ")";
// 		putText(VideoFrame, Label, Target.BoundingBox.tl(), FONT_HERSHEY_SIMPLEX, 0.45, white, thin);

// 		cout << ((Target.Type == 1) ? "TM : " : "AI : ") << ClassName[Target.ClassID] << " ID:" << (UInt32_t)Target.ClassID << " Conf:" << (UInt32_t)(Target.Confidance * 100) << "% Ny:" << (Target.CenterPoint.x - VideoFrame.cols / 2) << " Nz:" << (Target.CenterPoint.y - VideoFrame.rows / 2) << " W:" << Target.BoundingBox.width << " H:" << Target.BoundingBox.height << endl
// 			 << flush;
// 	}

// 	// Sort Targets using ROI
// 	while (found == false)
// 	{
// 		Targets.clear();

// 		if (AOI.x < 0)
// 		{
// 			AOI.x = 0;
// 		}

// 		if (AOI.y < 0)
// 		{
// 			AOI.y = 0;
// 		}

// 		if (FrameWidth < (AOI.x + AOI.width))
// 		{
// 			AOI.width = FrameWidth - AOI.x;
// 		}

// 		if (FrameHeight < (AOI.y + AOI.height))
// 		{
// 			AOI.height = FrameHeight - AOI.y;
// 		}

// 		AOI = AOI & Rect(0, 0, FrameWidth, FrameHeight);

// 		for (auto &Target : TargetDataArr)
// 		{
// 			if (4 <= Target.ClassID || (BirdPlaneDataFlag == false && (Target.ClassID == 0 || Target.ClassID == 3)))
// 			{
// 				continue;
// 			}

// 			if (AOI.contains(Target.CenterPoint))
// 			{
// 				Targets.push_back(Target);
// 			}
// 		}

// 		if (!Targets.empty())
// 		{
// 			found = true;
// 			MinDist = 1e9;

// 			for (auto &Target : Targets)
// 			{
// 				Dist = norm(Target.CenterPoint - FrameCentre);
// 				if (Dist < MinDist)
// 				{
// 					MinDist = Dist;
// 					best = Target;
// 				}
// 			}

// 			TargetData.ClassID = best.ClassID;
// 			TargetData.Confidance = best.Confidance;
// 			TargetData.CenterPoint = best.CenterPoint;
// 			TargetData.BoundingBox = best.BoundingBox;
// 			TargetData.ValidData = 1;

// 			break;
// 		}

// 		if (AOI.width >= FrameWidth && AOI.height >= FrameHeight)
// 		{
// 			TargetData.ValidData = 0;
// 			break;
// 		}

// 		AOI.x -= xExpStep;
// 		AOI.y -= yExpStep;
// 		AOI.width += (xExpStep * 2);
// 		AOI.height += (yExpStep * 2);
// 	}

// 	// Draw ROI
// 	rectangle(VideoFrame, AOI, white, thin);

// 	// Draw Line from Frame Center to Target
// 	if (TargetData.ValidData == 1)
// 	{
// 		line(VideoFrame, FrameCentre, TargetData.CenterPoint, white, thin);
// 	}

// 	return;
// }

// // ---------- Detect Object Function ----------
// void ObjDetection ::RunEnqueueV2(Mat &VideoFrame)
// {
// 	// PreProcess
// 	preProcess(VideoFrame, static_cast<__half *>(Bindings[0]));

// #pragma GCC diagnostic push
// #pragma GCC diagnostic ignored "-Wdeprecated-declarations"

// 	// Inference
// 	context->enqueueV2(Bindings.data(), rawStream, nullptr);
// 	cudaStreamSynchronize(rawStream);
// 	cvStream.waitForCompletion();

// #pragma GCC diagnostic pop

// 	// PostProcess
// 	postProcess(VideoFrame.cols, VideoFrame.rows);

// 	// Template Matching
// 	if (DetectObjectFlag == true && TemplateMatchingFlag == true)
// 	{
// 		templateMatch(VideoFrame);
// 	}

// 	// Draw Boxes
// 	drawBoxes(VideoFrame);

// 	return;
// }

// =============== @2 =================================
#include "ObjDetection.h"
#include <chrono>
#include <algorithm>
#include <cmath>
#include <stdexcept>

// ---------- Logger for TensorRT messages ----------
class Logger : public ILogger
{
	void log(Severity severity, const char* msg) noexcept override
	{
		if (severity <= Severity::kWARNING)
		{
			cerr << "[TensorRT] : " << msg << endl;
		}
	}
};

Logger logger;

__global__ void U8ToFP16CHW(const unsigned char* input, size_t inputStep, int32_t inputChannels,
	__half* output, int32_t inputWidth, int32_t inputHeight,
	int32_t outputWidth, int32_t outputHeight)
{
	int32_t x = blockIdx.x * blockDim.x + threadIdx.x;
	int32_t y = blockIdx.y * blockDim.y + threadIdx.y;

	if (x >= outputWidth || y >= outputHeight)
		return;

	const int32_t dstIndex = y * outputWidth + x;
	const int32_t imageArea = outputWidth * outputHeight;
	float c0 = 0.0f, c1 = 0.0f, c2 = 0.0f;
	if (x < inputWidth && y < inputHeight)
	{
		const unsigned char* pixel = input + y * inputStep + x * inputChannels;
		c0 = pixel[0] * (1.0f / 255.0f);
		c1 = (inputChannels == 3 ? pixel[1] : pixel[0]) * (1.0f / 255.0f);
		c2 = (inputChannels == 3 ? pixel[2] : pixel[0]) * (1.0f / 255.0f);
	}
	output[dstIndex] = __float2half(c0);
	output[imageArea + dstIndex] = __float2half(c1);
	output[2 * imageArea + dstIndex] = __float2half(c2);
}

__global__ void U8ToFP32CHW(const unsigned char* input, size_t inputStep, int32_t inputChannels,
	float* output, int32_t inputWidth, int32_t inputHeight,
	int32_t outputWidth, int32_t outputHeight)
{
	int32_t x = blockIdx.x * blockDim.x + threadIdx.x;
	int32_t y = blockIdx.y * blockDim.y + threadIdx.y;

	if (x >= outputWidth || y >= outputHeight)
		return;

	const int32_t dstIndex = y * outputWidth + x;
	const int32_t imageArea = outputWidth * outputHeight;
	float c0 = 0.0f, c1 = 0.0f, c2 = 0.0f;
	if (x < inputWidth && y < inputHeight)
	{
		const unsigned char* pixel = input + y * inputStep + x * inputChannels;
		c0 = pixel[0] * (1.0f / 255.0f);
		c1 = (inputChannels == 3 ? pixel[1] : pixel[0]) * (1.0f / 255.0f);
		c2 = (inputChannels == 3 ? pixel[2] : pixel[0]) * (1.0f / 255.0f);
	}
	output[dstIndex] = c0;
	output[imageArea + dstIndex] = c1;
	output[2 * imageArea + dstIndex] = c2;
}

// ---------- Constructor ----------
ObjDetection::ObjDetection(void)
	: nextTrackId(1),
	InputDataType(nvinfer1::DataType::kHALF),
	OutputDataType(nvinfer1::DataType::kHALF),
	hostInputPinned(nullptr), deviceInputFrame(nullptr), deviceInputPitch(0),
	hostOutputPinned(nullptr), outputElementCount(0), rawStream(nullptr),
	pipelineStartEvent(nullptr), preprocessDoneEvent(nullptr),
	inferenceDoneEvent(nullptr), outputReadyEvent(nullptr),
	lastCpuDecodeMs(0.0), processedFrameCount(0)
{
	Yolov5_Dim.height = 640;
	Yolov5_Dim.width = 640;

	Detections = 25200U;
	DetectionSize = 9U;
	ClassCnt = 4U;

	ConfThreshold = 0.45f;
	IOUThreshold = 0.4f;

	TargetDataArr.clear();
	tracks.clear();

	MaxTemplateCnt = static_cast<UInt8_t>(MAX_TRACKS);
	TemplateFrameCnt = 5U;
	TempConfThreshold = TM_SCORE_THRESHOLD;

	if (LoadEngineFile())
	{
		AIStatusFlag = true;
		cerr << "Engine Loaded Successfully" << endl;
	}
	else
	{
		AIStatusFlag = false;
		cerr << "Failed to load Engine file" << endl;
	}
}

// ---------- Destructor ----------
ObjDetection::~ObjDetection(void)
{
	try
	{
		for (auto& pair : DeviceBuffers)
		{
			if (pair.second)
			{
				cudaFree(pair.second);
			}
		}
		if (hostOutputPinned)
		{
			cudaFreeHost(hostOutputPinned);
		}
		if (hostInputPinned)
			cudaFreeHost(hostInputPinned);
		if (deviceInputFrame)
			cudaFree(deviceInputFrame);
		if (pipelineStartEvent)
			cudaEventDestroy(pipelineStartEvent);
		if (preprocessDoneEvent)
			cudaEventDestroy(preprocessDoneEvent);
		if (inferenceDoneEvent)
			cudaEventDestroy(inferenceDoneEvent);
		if (outputReadyEvent)
			cudaEventDestroy(outputReadyEvent);
		if (rawStream)
			cudaStreamDestroy(rawStream);
	}
	catch (...)
	{
	}
}

// ---------- Get Memory Size ----------
size_t ObjDetection::getMemorySize(Dims dims, size_t ElementSize)
{
	size_t size = ElementSize;
	for (Int32_t i = 0; i < dims.nbDims; i++)
	{
		size *= dims.d[i];
	}
	return size;
}

// ---------- Load Engine File ----------
bool ObjDetection::LoadEngineFile(void)
{
	try
	{
		setenv("CUDA_MODULE_LOADING", "LAZY", 1);

		ifstream EngineFile(ModelPath, ios::binary);
		if (!EngineFile)
		{
			cerr << "Failed to open engine file." << endl;
			return false;
		}

		EngineFile.seekg(0, ios::end);
		auto fsize = EngineFile.tellg();
		if (fsize <= 0)
			throw runtime_error("TensorRT engine file is empty");
		EngineFile.seekg(0, ios::beg);

		vector<char> engine_data(fsize);
		EngineFile.read(engine_data.data(), fsize);
		if (!EngineFile)
			throw runtime_error("TensorRT engine file could not be read completely");

		runtime.reset(createInferRuntime(logger));
		if (!runtime)
			throw runtime_error("TensorRT runtime creation failed");
		engine.reset(runtime->deserializeCudaEngine(engine_data.data(), fsize));
		if (!engine)
			throw runtime_error("TensorRT engine deserialization failed");
		inference.reset(engine->createExecutionContext());
		if (!inference)
			throw runtime_error("TensorRT execution-context creation failed");
		if (cudaStreamCreateWithFlags(&rawStream, cudaStreamNonBlocking) != cudaSuccess)
			throw runtime_error("Failed to create CUDA stream");

		// Modern TensorRT Named IO Tensor API Configuration
		int32_t nbTensors = engine->getNbIOTensors();
		for (int32_t i = 0; i < nbTensors; ++i)
		{
			string name = engine->getIOTensorName(i);
			Dims dims = engine->getTensorShape(name.c_str());
			nvinfer1::DataType dtype = engine->getTensorDataType(name.c_str());
			if (dtype != nvinfer1::DataType::kHALF && dtype != nvinfer1::DataType::kFLOAT)
				throw runtime_error("Only FP16/FP32 IO tensors are supported: " + name);
			for (int d = 0; d < dims.nbDims; ++d)
			{
				if (dims.d[d] <= 0)
					throw runtime_error("Dynamic/invalid tensor shape is unsupported: " + name);
			}

			if (engine->getTensorIOMode(name.c_str()) == nvinfer1::TensorIOMode::kINPUT)
			{
				if (!InputTensorName.empty())
					throw runtime_error("Expected exactly one input tensor");
				InputTensorName = name;
				InputDataType = dtype;
			}
			else
			{
				if (!OutputTensorName.empty())
					throw runtime_error("Expected exactly one output tensor");
				OutputTensorName = name;
				OutputDataType = dtype;
			}

			size_t elementSize = dtype == nvinfer1::DataType::kHALF ? sizeof(__half) : sizeof(float);
			size_t totalSize = getMemorySize(dims, elementSize);

			BufferSizes[name] = totalSize;

			void* devicePtr = nullptr;
			if (cudaMalloc(&devicePtr, totalSize) != cudaSuccess)
				throw runtime_error("Failed to allocate device tensor: " + name);
			DeviceBuffers[name] = devicePtr;

			if (!inference->setTensorAddress(name.c_str(), devicePtr))
				throw runtime_error("Failed to register tensor address: " + name);
		}

		if (InputTensorName.empty() || OutputTensorName.empty())
			throw runtime_error("Engine input/output tensor was not found");

		Dims inputDims = engine->getTensorShape(InputTensorName.c_str());
		if (inputDims.nbDims != 4 || inputDims.d[0] != 1 || inputDims.d[1] != 3)
			throw runtime_error("Expected a static NCHW input with shape [1,3,H,W]");
		Yolov5_Dim.height = inputDims.d[2];
		Yolov5_Dim.width = inputDims.d[3];

		Dims outputDims = engine->getTensorShape(OutputTensorName.c_str());
		DetectionSize = static_cast<UInt32_t>(outputDims.d[outputDims.nbDims - 1]);
		outputElementCount = getMemorySize(outputDims, 1U);
		if (DetectionSize < 6U || outputElementCount % DetectionSize != 0U)
			throw runtime_error("Unexpected YOLO output shape");
		Detections = static_cast<UInt32_t>(outputElementCount / DetectionSize);
		ClassCnt = DetectionSize - 5U;
		if (ClassCnt != 4U)
			throw runtime_error("This application expects exactly four YOLO classes");

		const size_t maxInputBytes = static_cast<size_t>(Yolov5_Dim.width) *
			Yolov5_Dim.height * 3U;
		if (cudaMallocHost(&hostInputPinned, maxInputBytes) != cudaSuccess)
			throw runtime_error("Failed to allocate pinned input memory");
		if (cudaMallocPitch(reinterpret_cast<void**>(&deviceInputFrame), &deviceInputPitch,
			static_cast<size_t>(Yolov5_Dim.width) * 3U, Yolov5_Dim.height) != cudaSuccess)
			throw runtime_error("Failed to allocate device input staging memory");
		if (cudaMallocHost(&hostOutputPinned, BufferSizes[OutputTensorName]) != cudaSuccess)
			throw runtime_error("Failed to allocate pinned output memory");

		if (cudaEventCreate(&pipelineStartEvent) != cudaSuccess ||
			cudaEventCreate(&preprocessDoneEvent) != cudaSuccess ||
			cudaEventCreate(&inferenceDoneEvent) != cudaSuccess ||
			cudaEventCreate(&outputReadyEvent) != cudaSuccess)
			throw runtime_error("Failed to create CUDA timing events");

		// Resolve lazy CUDA modules and TensorRT tactics before processing live frames.
		cudaMemsetAsync(DeviceBuffers[InputTensorName], 0, BufferSizes[InputTensorName], rawStream);
		for (int warmup = 0; warmup < 3; ++warmup)
		{
			if (!inference->enqueueV3(rawStream))
				throw runtime_error("TensorRT warm-up enqueue failed");
		}
		if (cudaStreamSynchronize(rawStream) != cudaSuccess)
			throw runtime_error("TensorRT warm-up synchronization failed");
		return true;
	}
	catch (const exception& e)
	{
		cerr << "TensorRT initialization error: " << e.what() << endl;
		return false;
	}
}

// ---------- PreProcess ----------
void ObjDetection::preProcess(const Mat& VideoFrame, void* InputBuff)
{
	if (VideoFrame.empty() || (VideoFrame.type() != CV_8UC1 && VideoFrame.type() != CV_8UC3))
		throw runtime_error("Expected a non-empty CV_8UC1/CV_8UC3 video frame");
	if (VideoFrame.cols > Yolov5_Dim.width || VideoFrame.rows > Yolov5_Dim.height)
		throw runtime_error("Video frame is larger than the TensorRT input");

	dim3 block(16, 16);
	dim3 grid((Yolov5_Dim.width + block.x - 1) / block.x,
		(Yolov5_Dim.height + block.y - 1) / block.y);

	const size_t rowBytes = static_cast<size_t>(VideoFrame.cols) * VideoFrame.channels();
	if (VideoFrame.isContinuous() && VideoFrame.step == rowBytes)
	{
		memcpy(hostInputPinned, VideoFrame.data, rowBytes * VideoFrame.rows);
	}
	else
	{
		for (int y = 0; y < VideoFrame.rows; ++y)
			memcpy(hostInputPinned + y * rowBytes, VideoFrame.ptr(y), rowBytes);
	}
	if (cudaMemcpy2DAsync(deviceInputFrame, deviceInputPitch, hostInputPinned, rowBytes,
		rowBytes, VideoFrame.rows, cudaMemcpyHostToDevice, rawStream) != cudaSuccess)
		throw runtime_error("CUDA input upload failed");
	if (InputDataType == nvinfer1::DataType::kHALF)
	{
		U8ToFP16CHW << <grid, block, 0, rawStream >> > (deviceInputFrame,
			deviceInputPitch, VideoFrame.channels(), static_cast<__half*>(InputBuff),
			VideoFrame.cols, VideoFrame.rows, Yolov5_Dim.width, Yolov5_Dim.height);
	}
	else
	{
		U8ToFP32CHW << <grid, block, 0, rawStream >> > (deviceInputFrame,
			deviceInputPitch, VideoFrame.channels(), static_cast<float*>(InputBuff),
			VideoFrame.cols, VideoFrame.rows, Yolov5_Dim.width, Yolov5_Dim.height);
	}
	if (cudaPeekAtLastError() != cudaSuccess)
		throw runtime_error("CUDA preprocessing kernel launch failed");
}

// ---------- PostProcess ----------
void ObjDetection::postProcess(UInt16_t VideoWidth, UInt16_t VideoHeight)
{
	vector<Rect> Boxes;
	vector<Int32_t> Indices;
	vector<UInt8_t> ClassIds;
	vector<float> Confidances;
	Boxes.reserve(256);
	ClassIds.reserve(256);
	Confidances.reserve(256);
	TargetDataArr.clear();

	if (cudaMemcpyAsync(hostOutputPinned, DeviceBuffers[OutputTensorName],
		BufferSizes[OutputTensorName], cudaMemcpyDeviceToHost, rawStream) != cudaSuccess)
		throw runtime_error("TensorRT output copy failed");
	cudaEventRecord(outputReadyEvent, rawStream);
	if (cudaEventSynchronize(outputReadyEvent) != cudaSuccess)
		throw runtime_error("TensorRT output synchronization failed");

	auto cpuStart = steady_clock::now();
	auto outputValue = [this](size_t index) -> float
		{
			if (OutputDataType == nvinfer1::DataType::kHALF)
				return __half2float(static_cast<const __half*>(hostOutputPinned)[index]);
			return static_cast<const float*>(hostOutputPinned)[index];
		};

	const float candidateThreshold = tracks.empty() ? ConfThreshold : 0.15f;

	for (UInt32_t i = 0; i < Detections; i++)
	{
		const size_t row = static_cast<size_t>(i) * DetectionSize;
		float ObjConf = outputValue(row + 4U);

		if (!isfinite(ObjConf) || ObjConf < candidateThreshold || ObjConf > 1.0f)
			continue;

		float ClassScore[4];
		for (UInt32_t j = 0; j < ClassCnt; j++)
			ClassScore[j] = outputValue(row + 5U + j);

		UInt8_t ClassID = max_element(ClassScore, ClassScore + ClassCnt) - ClassScore;
		float Confidence = ObjConf * ClassScore[ClassID];
		if (!isfinite(Confidence) || Confidence < candidateThreshold || Confidence > 1.0f)
			continue;

		float CentreX = outputValue(row);
		float CentreY = outputValue(row + 1U);
		float Width = outputValue(row + 2U);
		float Height = outputValue(row + 3U);

		if (!isfinite(CentreX) || !isfinite(CentreY) || !isfinite(Width) || !isfinite(Height) ||
			CentreX < 0.0f || CentreX >= VideoWidth || CentreY < 0.0f || CentreY >= VideoHeight ||
			Width <= 0.0f || Height <= 0.0f || Width > Yolov5_Dim.width || Height > Yolov5_Dim.height)
		{
			continue;
		}

		int X1 = max(0, static_cast<int>(floor(CentreX - Width / 2.0f)));
		int Y1 = max(0, static_cast<int>(floor(CentreY - Height / 2.0f)));
		int X2 = min(static_cast<int>(VideoWidth), static_cast<int>(ceil(CentreX + Width / 2.0f)));
		int Y2 = min(static_cast<int>(VideoHeight), static_cast<int>(ceil(CentreY + Height / 2.0f)));

		if (X2 > X1 && Y2 > Y1)
		{
			if (Confidence < ConfThreshold)
			{
				bool nearExistingTrack = false;
				Point2f candidateCenter(CentreX, CentreY);
				for (const auto& track : tracks)
				{
					if (track.isActive && norm(candidateCenter - track.center) <= 120.0f)
					{
						nearExistingTrack = true;
						break;
					}
				}
				if (!nearExistingTrack)
					continue;
			}
			Boxes.emplace_back(X1, Y1, X2 - X1, Y2 - Y1);
			Confidances.emplace_back(Confidence);
			ClassIds.emplace_back(ClassID);
		}
	}

	dnn::NMSBoxes(Boxes, Confidances, candidateThreshold, IOUThreshold, Indices);

	struct _AIData_ Target;
	for (UInt32_t idx : Indices)
	{
		Target.Type = 0;
		Target.ClassID = ClassIds[idx];
		Target.Confidance = Confidances[idx];
		Target.BoundingBox = Boxes[idx];
		Target.CenterPoint = Point(Boxes[idx].x + Boxes[idx].width / 2,
			Boxes[idx].y + Boxes[idx].height / 2);
		TargetDataArr.push_back(Target);
	}
	lastCpuDecodeMs = duration<double, milli>(steady_clock::now() - cpuStart).count();
}

// ============================================================================
//  KALMAN FILTER HELPERS  (4-state constant velocity: x, y, vx, vy)
// ============================================================================
void ObjDetection::initKalman(Track& track)
{
	track.kf.init(4, 2, 0, CV_32F);

	// State transition:  x' = x + vx , y' = y + vy , vx' = vx , vy' = vy  (dt = 1 frame)
	track.kf.transitionMatrix = (Mat_<float>(4, 4) << 1, 0, 1, 0,
		0, 1, 0, 1,
		0, 0, 1, 0,
		0, 0, 0, 1);

	setIdentity(track.kf.measurementMatrix, Scalar::all(1.0f));
	setIdentity(track.kf.processNoiseCov, Scalar::all(KALMAN_PROCESS_NOISE));
	setIdentity(track.kf.measurementNoiseCov, Scalar::all(KALMAN_MEASUREMENT_NOISE));
	setIdentity(track.kf.errorCovPost, Scalar::all(1.0f));

	track.kf.statePost.at<float>(0) = track.center.x;
	track.kf.statePost.at<float>(1) = track.center.y;
	track.kf.statePost.at<float>(2) = 0.0f;
	track.kf.statePost.at<float>(3) = 0.0f;
}

Point2f ObjDetection::predictKalman(Track& track)
{
	Mat pred = track.kf.predict();
	return Point2f(pred.at<float>(0), pred.at<float>(1));
}

Point2f ObjDetection::updateKalman(Track& track, Point2f measurement)
{
	Mat meas = (Mat_<float>(2, 1) << measurement.x, measurement.y);
	Mat corr = track.kf.correct(meas);
	return Point2f(corr.at<float>(0), corr.at<float>(1));
}

// ============================================================================
//  TEMPLATE QUALITY & ROI COMPUTATION
// ============================================================================
bool ObjDetection::isValidTemplate(const Mat& templ)
{
	if (templ.empty() || templ.cols < 2 || templ.rows < 2)
		return false;

	Mat gray;
	if (templ.channels() == 3)
		cvtColor(templ, gray, COLOR_BGR2GRAY);
	else
		gray = templ;

	Scalar m, stdev;
	meanStdDev(gray, m, stdev);
	double minValue = 0.0, maxValue = 0.0;
	minMaxLoc(gray, &minValue, &maxValue);

	// Reject uniform/background patches. A valid white-hot target must have local contrast.
	return stdev[0] > 1.5 && (maxValue - minValue) >= 4.0;
}

Rect ObjDetection::computeSearchRoi(const Track& track, int frameW, int frameH)
{
	// bbox is always the object box; template context and scale must not compound it.
	int baseW = max(4, track.bbox.width);
	int baseH = max(4, track.bbox.height);

	const int MIN_SEARCH = 48;

	// Velocity-adaptive margin: allow up to 5 frames of free-flight movement
	float vx = abs(track.kf.statePost.at<float>(2));
	float vy = abs(track.kf.statePost.at<float>(3));
	int marginX = int(max(float(baseW) * 2.0f, vx * 5.0f));
	int marginY = int(max(float(baseH) * 2.0f, vy * 5.0f));

	int roiW = max(MIN_SEARCH, baseW + 2 * marginX);
	int roiH = max(MIN_SEARCH, baseH + 2 * marginY);

	int cx = cvRound(track.predictedCenter.x);
	int cy = cvRound(track.predictedCenter.y);

	Rect roi(cx - roiW / 2, cy - roiH / 2, roiW, roiH);
	roi &= Rect(0, 0, frameW, frameH);

	return roi;
}

// ============================================================================
//  SUB-PIXEL REFINEMENT  (parabolic fit on correlation peak)
// ============================================================================
Point2f ObjDetection::subPixelRefine(const Mat& response, Point peak)
{
	if (peak.x <= 0 || peak.x >= response.cols - 1 ||
		peak.y <= 0 || peak.y >= response.rows - 1)
	{
		return Point2f((float)peak.x, (float)peak.y);
	}

	float a = response.at<float>(peak.y, peak.x - 1);
	float b = response.at<float>(peak.y, peak.x);
	float c = response.at<float>(peak.y, peak.x + 1);
	float d = response.at<float>(peak.y - 1, peak.x);
	float e = response.at<float>(peak.y + 1, peak.x);

	float denomX = 2.0f * (a - 2.0f * b + c);
	float denomY = 2.0f * (d - 2.0f * b + e);

	float dx = (fabs(denomX) > 1e-5f) ? (a - c) / denomX : 0.0f;
	float dy = (fabs(denomY) > 1e-5f) ? (d - e) / denomY : 0.0f;

	return Point2f(peak.x + dx, peak.y + dy);
}

// ============================================================================
//  MULTI-SCALE TEMPLATE MATCHING  (grayscale, 7 scales, sub-pixel)
// ============================================================================
float ObjDetection::multiScaleTemplateMatch(Mat& frame, Track& track, Point2f& outCenter, Rect& outBbox)
{
	if (track.templateImg.empty() || track.templateImg.cols < 2 || track.templateImg.rows < 2)
		return 0.0f;

	int frameW = frame.cols;
	int frameH = frame.rows;

	// Kalman was advanced exactly once in updateTracksWithAI().
	Rect searchRoi = computeSearchRoi(track, frameW, frameH);
	if (searchRoi.width < track.templateImg.cols || searchRoi.height < track.templateImg.rows)
		return 0.0f;

	Mat searchImg = frame(searchRoi);

	// Work in grayscale — critical for IR imagery and 3× faster
	Mat searchGray, templGray;
	if (searchImg.channels() == 3)
		cvtColor(searchImg, searchGray, COLOR_BGR2GRAY);
	else
		searchGray = searchImg;

	if (track.templateImg.channels() == 3)
		cvtColor(track.templateImg, templGray, COLOR_BGR2GRAY);
	else
		templGray = track.templateImg;

	// 3. Multi-scale pyramid (critical for 600 m approach / recede)
	const float scales[] = { 0.82f, 0.90f, 0.96f, 1.0f, 1.04f, 1.10f, 1.18f };
	const int numScales = sizeof(scales) / sizeof(scales[0]);

	float bestScore = -1.0f;
	Point2f bestLoc;
	float bestScale = 1.0f;
	Mat bestResult;
	Size bestTemplateSize;
	vector<Size> testedSizes;

	for (int i = 0; i < numScales; ++i)
	{
		float s = scales[i];
		int newW = max(2, int(templGray.cols * s));
		int newH = max(2, int(templGray.rows * s));

		if (newW > searchRoi.width || newH > searchRoi.height)
			continue;
		Size scaledSize(newW, newH);
		if (find(testedSizes.begin(), testedSizes.end(), scaledSize) != testedSizes.end())
			continue; // Several scales round to the same size for a 5 px target.
		testedSizes.push_back(scaledSize);

		Mat resizedTempl;
		resize(templGray, resizedTempl, scaledSize, 0, 0, INTER_LINEAR);

		Mat result;
		// CCOEFF_NORMED is far more robust to IR brightness drift than SQDIFF
		matchTemplate(searchGray, resizedTempl, result, TM_CCOEFF_NORMED);

		double minVal, maxVal;
		Point minLoc, maxLoc;
		minMaxLoc(result, &minVal, &maxVal, &minLoc, &maxLoc);

		if (isfinite(maxVal) && maxVal > bestScore)
		{
			bestScore = (float)maxVal;
			bestLoc = Point2f((float)maxLoc.x, (float)maxLoc.y);
			bestScale = 0.5f * (static_cast<float>(newW) / templGray.cols +
				static_cast<float>(newH) / templGray.rows);
			bestResult = result.clone();
			bestTemplateSize = scaledSize;
		}
	}

	if (bestResult.empty() || bestScore < TempConfThreshold)
		return bestScore;

	// Reject ambiguous responses where another hot point has nearly the same score.
	Mat sidelobes = bestResult.clone();
	int suppressX = max(2, bestTemplateSize.width / 2);
	int suppressY = max(2, bestTemplateSize.height / 2);
	Rect suppressRect(cvRound(bestLoc.x) - suppressX, cvRound(bestLoc.y) - suppressY,
		2 * suppressX + 1, 2 * suppressY + 1);
	suppressRect &= Rect(0, 0, sidelobes.cols, sidelobes.rows);
	sidelobes(suppressRect).setTo(Scalar(-1.0f));
	double secondPeak = -1.0;
	minMaxLoc(sidelobes, nullptr, &secondPeak);
	if (isfinite(secondPeak) && bestScore - static_cast<float>(secondPeak) < TM_PEAK_MARGIN)
		return 0.0f;

	// 4. Sub-pixel peak refinement (essential when target is only 4–5 px)
	Point2f subLoc = subPixelRefine(bestResult, Point((int)bestLoc.x, (int)bestLoc.y));

	// Keep template context separate from the actual object box to prevent growth.
	float objectW = max(MIN_TEMPLATE_SIZE, track.aiBoxSize.width * bestScale);
	float objectH = max(MIN_TEMPLATE_SIZE, track.aiBoxSize.height * bestScale);
	float matchedTemplateW = static_cast<float>(bestTemplateSize.width);
	float matchedTemplateH = static_cast<float>(bestTemplateSize.height);

	outCenter.x = searchRoi.x + subLoc.x + matchedTemplateW / 2.0f;
	outCenter.y = searchRoi.y + subLoc.y + matchedTemplateH / 2.0f;

	outBbox.x = cvRound(outCenter.x - objectW / 2.0f);
	outBbox.y = cvRound(outCenter.y - objectH / 2.0f);
	outBbox.width = max(1, cvRound(objectW));
	outBbox.height = max(1, cvRound(objectH));
	outBbox &= Rect(0, 0, frameW, frameH);

	track.bestScale = bestScale;
	return bestScore;
}

// ============================================================================
//  TEMPLATE UPDATE  (rate-limited to avoid drift)
// ============================================================================
void ObjDetection::updateTemplate(Mat& frame, Track& track, const Rect& newBbox)
{
	// Update only every N frames, or when scale has drifted significantly
	if (track.templateAge < 5 && abs(track.bestScale - 1.0f) < 0.08f)
		return;

	// Add 1 px context around detection — helps for 4–5 px targets
	Rect templRect = newBbox;
	templRect.x -= 1;
	templRect.y -= 1;
	templRect.width += 2;
	templRect.height += 2;
	templRect &= Rect(0, 0, frame.cols, frame.rows);

	Mat newTempl = frame(templRect).clone();
	if (newTempl.channels() == 3)
		cvtColor(newTempl, newTempl, COLOR_BGR2GRAY);

	if (isValidTemplate(newTempl))
	{
		track.templateImg = newTempl;
		track.templateAge = 0;
		track.bestScale = 1.0f;
	}
}

// ============================================================================
//  TRACK CREATION  (only from high-quality AI detections)
// ============================================================================
void ObjDetection::createTrack(Mat& frame, const struct _AIData_& detection)
{
	if (tracks.size() >= MAX_TRACKS)
		return;
	if (detection.BoundingBox.width < MIN_TEMPLATE_SIZE ||
		detection.BoundingBox.height < MIN_TEMPLATE_SIZE)
		return;

	Track t;
	t.id = nextTrackId++;
	t.classId = detection.ClassID;
	t.bbox = detection.BoundingBox;
	t.aiBoxSize = Size2f((float)detection.BoundingBox.width, (float)detection.BoundingBox.height);
	t.center = Point2f((float)detection.CenterPoint.x, (float)detection.CenterPoint.y);
	t.predictedCenter = t.center;
	t.confidence = detection.Confidance;
	t.age = 1;
	t.missedFrames = 0;
	t.aiMissedFrames = 0;
	t.templateAge = 0;
	t.isActive = true;
	t.isTemplateBased = false;
	t.isPredictedOnly = false;
	t.updatedThisFrame = true;
	t.bestScale = 1.0f;

	// Extract template with 1 px border for context, store as grayscale
	Rect templRect = detection.BoundingBox;
	templRect.x -= 1;
	templRect.y -= 1;
	templRect.width += 2;
	templRect.height += 2;
	templRect &= Rect(0, 0, frame.cols, frame.rows);

	Mat roi = frame(templRect).clone();
	if (roi.channels() == 3)
		cvtColor(roi, t.templateImg, COLOR_BGR2GRAY);
	else
		t.templateImg = roi;

	if (!isValidTemplate(t.templateImg))
	{
		// Template quality must never discard an otherwise valid AI detection.
		// The track remains AI/Kalman capable; TM simply stays unavailable.
		t.templateImg.release();
	}

	initKalman(t);
	tracks.push_back(t);

}

// ============================================================================
//  AI → TRACK ASSOCIATION  (nearest neighbour + adaptive gate)
// ============================================================================
void ObjDetection::updateTracksWithAI(Mat& frame, vector<struct _AIData_>& detections)
{
	vector<bool> detAssigned(detections.size(), false);
	vector<bool> trackAssigned(tracks.size(), false);

	// Advance each Kalman filter exactly once for this frame.
	for (auto& track : tracks)
	{
		if (!track.isActive)
			continue;
		track.predictedCenter = predictKalman(track);
		track.updatedThisFrame = false;
		track.isPredictedOnly = false;
		track.age++;
		track.templateAge++;
	}

	// Build all geometrically valid associations and greedily take the global
	// lowest-cost pairs. Class disagreement is a small penalty, not a hard gate:
	// a 5 px target cannot provide reliable subtype classification every frame.
	struct Association
	{
		size_t trackIndex;
		size_t detectionIndex;
		float cost;
	};
	vector<Association> associations;
	for (size_t trackIndex = 0; trackIndex < tracks.size(); ++trackIndex)
	{
		const Track& track = tracks[trackIndex];
		if (!track.isActive)
			continue;
		for (size_t i = 0; i < detections.size(); ++i)
		{
			const auto& det = detections[i];
			if (det.ClassID >= ClassCnt)
				continue;

			Point2f detCenter((float)det.CenterPoint.x, (float)det.CenterPoint.y);
			float dist = (float)norm(detCenter - track.predictedCenter);

			float areaDet = float(det.BoundingBox.width * det.BoundingBox.height);
			float areaTrack = float(track.bbox.width * track.bbox.height);
			float areaRatio = areaDet / (areaTrack + 1e-6f);
			if (areaRatio < 0.15f || areaRatio > 6.5f)
				continue;

			float gate = (track.age > 5) ? 120.0f : 50.0f;
			if (dist > gate)
				continue;

			float classPenalty = det.ClassID == track.classId ? 0.0f : 12.0f;
			float sizePenalty = 10.0f * fabs(log(max(areaRatio, 1e-6f)));
			associations.push_back({ trackIndex, i, dist + classPenalty + sizePenalty });
		}
	}

	sort(associations.begin(), associations.end(), [](const Association& a, const Association& b)
		{
			return a.cost < b.cost;
		});

	for (const Association& association : associations)
	{
		if (trackAssigned[association.trackIndex] || detAssigned[association.detectionIndex])
			continue;
		Track& track = tracks[association.trackIndex];
		auto& det = detections[association.detectionIndex];
		trackAssigned[association.trackIndex] = true;
		detAssigned[association.detectionIndex] = true;

		track.bbox = det.BoundingBox;
		track.aiBoxSize = Size2f((float)det.BoundingBox.width, (float)det.BoundingBox.height);
		track.center = Point2f((float)det.CenterPoint.x, (float)det.CenterPoint.y);
		track.predictedCenter = track.center;
		track.classId = det.ClassID;
		track.confidence = det.Confidance;
		track.missedFrames = 0;
		track.aiMissedFrames = 0;
		track.isTemplateBased = false;
		track.isPredictedOnly = false;
		track.updatedThisFrame = true;

		updateKalman(track, track.center);
		// Only an AI-confirmed box is allowed to refresh the template.
		updateTemplate(frame, track, track.bbox);
	}

	for (size_t trackIndex = 0; trackIndex < tracks.size(); ++trackIndex)
	{
		if (tracks[trackIndex].isActive && !trackAssigned[trackIndex])
			tracks[trackIndex].aiMissedFrames++;
	}

	// Spawn tracks only from high-confidence detections. Low-confidence candidates
	// are available for association but cannot create persistent false tracks.
	for (size_t i = 0; i < detections.size(); ++i)
	{
		if (detAssigned[i] || detections[i].Confidance < ConfThreshold)
			continue;
		if (detections[i].ClassID >= ClassCnt)
			continue;
		if (BirdPlaneDataFlag == false && (detections[i].ClassID == 0 || detections[i].ClassID == 3))
			continue;
		createTrack(frame, detections[i]);
	}
}

// ============================================================================
//  TEMPLATE MATCHING FALLBACK  (for tracks AI missed this frame)
// ============================================================================
void ObjDetection::updateTracksWithTemplate(Mat& frame)
{
	int frameW = frame.cols;
	int frameH = frame.rows;

	for (auto& track : tracks)
	{
		if (!track.isActive || track.updatedThisFrame)
			continue; // Already updated by AI

		Point2f matchedCenter;
		Rect matchedBbox;
		float score = multiScaleTemplateMatch(frame, track, matchedCenter, matchedBbox);

		if (score >= TempConfThreshold)
		{
			track.bbox = matchedBbox;
			track.center = matchedCenter;
			track.predictedCenter = matchedCenter;
			track.confidence = score;
			track.missedFrames = 0;
			track.isTemplateBased = true;
			track.isPredictedOnly = false;
			track.updatedThisFrame = true;

			updateKalman(track, matchedCenter);
		}
		else
		{
			// Both AI and TM failed: extrapolate using Kalman prediction
			track.missedFrames++;
			track.center = track.predictedCenter;
			track.isTemplateBased = false;
			track.isPredictedOnly = true;
			track.confidence *= 0.85f;

			// Keep last known size, just shift centre
			track.bbox.x = cvRound(track.center.x - track.bbox.width / 2.0f);
			track.bbox.y = cvRound(track.center.y - track.bbox.height / 2.0f);
			track.bbox &= Rect(0, 0, frameW, frameH);
		}
	}
}

// ============================================================================
//  TRACK LIFECYCLE  (very aggressive retention for 600 m drone)
// ============================================================================
void ObjDetection::maintainTracks()
{
	auto it = tracks.begin();
	while (it != tracks.end())
	{
		if (it->missedFrames > MAX_MISSED_FRAMES ||
			it->aiMissedFrames > MAX_AI_MISSED_FRAMES || it->bbox.empty())
		{
			it = tracks.erase(it);
		}
		else
		{
			++it;
		}
	}
}

// ============================================================================
//  LEGACY ENTRY POINT  (now dispatches the full fusion pipeline)
// ============================================================================
void ObjDetection::templateMatch(Mat& VideoFrame)
{
	updateTracksWithAI(VideoFrame, TargetDataArr);
	if (TemplateMatchingFlag)
	{
		updateTracksWithTemplate(VideoFrame);
	}
	else
	{
		// Detection must continue to work without the optional template fallback.
		for (auto& track : tracks)
		{
			if (!track.isActive || track.updatedThisFrame)
				continue;
			track.missedFrames++;
			track.center = track.predictedCenter;
			track.isTemplateBased = false;
			track.isPredictedOnly = true;
			track.confidence *= 0.85f;
			track.bbox.x = cvRound(track.center.x - track.bbox.width / 2.0f);
			track.bbox.y = cvRound(track.center.y - track.bbox.height / 2.0f);
			track.bbox &= Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
		}
	}
	maintainTracks();
}

// ============================================================================
//  DRAW BOXES & ROI SORTING
// ============================================================================
void ObjDetection::drawBoxes(Mat& VideoFrame)
{
	Int8_t thin = 1;
	Scalar white(255, 255, 255);
	UInt16_t FrameWidth = VideoFrame.cols;
	UInt16_t FrameHeight = VideoFrame.rows;
	Point FrameCentre(FrameWidth / 2, FrameHeight / 2);

	// Clear global target output
	memset((void*)&TargetData, 0, sizeof(TargetData));

	// Draw every active track
	for (auto& track : tracks)
	{
		if (!track.isActive)
			continue;
		if (track.classId >= 4)
			continue;
		if (BirdPlaneDataFlag == false && (track.classId == 0 || track.classId == 3))
			continue;

		string source = track.isPredictedOnly ? "KF: " : (track.isTemplateBased ? "TM: " : "AI: ");
		string label = source + ClassName[track.classId] + " " +
			to_string((UInt32_t)(track.confidence * 100)) + "%" +
			" A" + to_string(track.age) + " M" + to_string(track.missedFrames);

		if (!track.bbox.empty())
		{
			rectangle(VideoFrame, track.bbox, white, thin);
			putText(VideoFrame, label, track.bbox.tl(), FONT_HERSHEY_SIMPLEX, 0.40, white, thin);
		}

		// Visualise predicted centre
		circle(VideoFrame, Point((int)track.center.x, (int)track.center.y), 2, white, -1);
	}

	// ---------- ROI-based target selection ----------
	bool found = false;
	double minDist = numeric_limits<double>::max();
	Int16_t xExpStep = 10, yExpStep = 8;
	const int requestedWidth = min<int>(FrameWidth, max<int>(1, ROI_Dim[0]));
	const int requestedHeight = min<int>(FrameHeight, max<int>(1, ROI_Dim[1]));
	const int requestedCenterX = min<int>(FrameWidth - 1, max<int>(0, ROI_Loc[0]));
	const int requestedCenterY = min<int>(FrameHeight - 1, max<int>(0, ROI_Loc[1]));
	Rect AOI(requestedCenterX - requestedWidth / 2,
		requestedCenterY - requestedHeight / 2, requestedWidth, requestedHeight);
	AOI &= Rect(0, 0, FrameWidth, FrameHeight);

	Track* bestTrack = nullptr;

	while (!found)
	{
		if (AOI.x < 0)
			AOI.x = 0;
		if (AOI.y < 0)
			AOI.y = 0;
		if (FrameWidth < (AOI.x + AOI.width))
			AOI.width = FrameWidth - AOI.x;
		if (FrameHeight < (AOI.y + AOI.height))
			AOI.height = FrameHeight - AOI.y;

		vector<Track*> candidates;
		for (auto& track : tracks)
		{
			if (!track.isActive)
				continue;
			if (track.classId >= 4)
				continue;
			if (BirdPlaneDataFlag == false && (track.classId == 0 || track.classId == 3))
				continue;
			// Never command against a long, measurement-free extrapolation.
			if (track.isPredictedOnly && track.missedFrames > 2)
				continue;

			if (AOI.contains(Point((int)track.center.x, (int)track.center.y)))
				candidates.push_back(&track);
		}

		if (!candidates.empty())
		{
			found = true;
			minDist = 1e9;
			for (auto* t : candidates)
			{
				double dist = norm(t->center - Point2f((float)FrameCentre.x, (float)FrameCentre.y));
				if (t->isPredictedOnly)
					dist *= 1.3;
				else if (!t->isTemplateBased)
					dist *= 0.7;
				if (dist < minDist)
				{
					minDist = dist;
					bestTrack = t;
				}
			}
			break;
		}

		if (AOI.width >= FrameWidth && AOI.height >= FrameHeight)
		{
			// Last resort: any active track anywhere in the image
			for (auto& track : tracks)
			{
				if (!track.isActive)
					continue;
				if (track.classId >= 4)
					continue;
				if (BirdPlaneDataFlag == false && (track.classId == 0 || track.classId == 3))
					continue;
				if (track.isPredictedOnly && track.missedFrames > 2)
					continue;

				double dist = norm(track.center - Point2f((float)FrameCentre.x, (float)FrameCentre.y));
				if (track.isPredictedOnly)
					dist *= 1.3;
				else if (!track.isTemplateBased)
					dist *= 0.7;
				if (dist < minDist)
				{
					minDist = dist;
					bestTrack = &track;
					found = true;
				}
			}
			break;
		}

		AOI.x -= xExpStep;
		AOI.y -= yExpStep;
		AOI.width += (xExpStep * 2);
		AOI.height += (yExpStep * 2);
	}

	rectangle(VideoFrame, AOI, white, thin);

	if (bestTrack != nullptr)
	{
		TargetData.ClassID = bestTrack->classId;
		TargetData.Confidance = bestTrack->confidence;
		TargetData.CenterPoint = Point((int)bestTrack->center.x, (int)bestTrack->center.y);
		TargetData.BoundingBox = bestTrack->bbox;
		TargetData.ValidData = 1;

		line(VideoFrame, FrameCentre, TargetData.CenterPoint, white, thin);
	}
}

// ============================================================================
//  MAIN PIPELINE
// ============================================================================
void ObjDetection::RunEnqueueV3(Mat& VideoFrame, UInt32_t FrameTime, UInt32_t AIStartTime)
{
	if (!AIStatusFlag || !inference || VideoFrame.empty())
		return;

	auto totalStart = steady_clock::now();
	try
	{
		cudaEventRecord(pipelineStartEvent, rawStream);
		preProcess(VideoFrame, DeviceBuffers[InputTensorName]);
		cudaEventRecord(preprocessDoneEvent, rawStream);

		if (!inference->enqueueV3(rawStream))
			throw runtime_error("TensorRT enqueueV3 failed");
		cudaEventRecord(inferenceDoneEvent, rawStream);

		// Prepare one grayscale tracking frame on the CPU while TensorRT is running.
		// This replaces repeated per-track color conversions and overlaps useful work.
		Mat trackingFrame;
		if (DetectObjectFlag)
		{
			if (VideoFrame.channels() == 3)
				cvtColor(VideoFrame, trackingFrame, COLOR_BGR2GRAY);
			else
				trackingFrame = VideoFrame;
		}

		postProcess(VideoFrame.cols, VideoFrame.rows);

		float preprocessMs = 0.0f, inferenceMs = 0.0f, copyMs = 0.0f;
		cudaEventElapsedTime(&preprocessMs, pipelineStartEvent, preprocessDoneEvent);
		cudaEventElapsedTime(&inferenceMs, preprocessDoneEvent, inferenceDoneEvent);
		cudaEventElapsedTime(&copyMs, inferenceDoneEvent, outputReadyEvent);

		auto trackStart = steady_clock::now();
		if (DetectObjectFlag)
			templateMatch(trackingFrame);
		double trackMs = duration<double, milli>(steady_clock::now() - trackStart).count();

		{
			lock_guard<mutex> lock(TargetDataMutex);
			drawBoxes(VideoFrame);
			TargetData.FrameTime = FrameTime;
			TargetData.AIStartTime = AIStartTime;
			TargetData.AIEndTime = GetCurrMillis();
			TargetDataFlag = DetectObjectFlag;
		}
		double totalMs = duration<double, milli>(steady_clock::now() - totalStart).count();

		processedFrameCount++;
		if (processedFrameCount == 1U || processedFrameCount % 30U == 0U)
		{
			cerr << "GPU preprocess: " << preprocessMs << " ms | "
				<< "TensorRT: " << inferenceMs << " ms | "
				<< "D2H: " << copyMs << " ms | "
				<< "CPU decode/NMS: " << lastCpuDecodeMs << " ms | "
				<< "Track: " << trackMs << " ms | "
				<< "End-to-end: " << totalMs << " ms | "
				<< "ActiveTracks: " << tracks.size() << endl;
		}
	}
	catch (const exception& e)
	{
		TargetDataArr.clear();
		{
			lock_guard<mutex> lock(TargetDataMutex);
			memset((void*)&TargetData, 0, sizeof(TargetData));
			TargetDataFlag = false;
		}
		AIStatusFlag = false;
		cerr << "Detection pipeline error: " << e.what() << endl;
	}
}
