#ifndef OBJDETECTION_H_
#define OBJDETECTION_H_

// ---------- Header Inclusion ----------
#include "Includes.h"
#include "Struct.h"

// ---------- IPCard Status Variables ----------
extern bool AIStatusFlag;

// ---------- AI Flag Variables ----------
extern bool TargetDataFlag;
extern bool DetectObjectFlag;
extern bool BirdPlaneDataFlag;
extern bool TemplateMatchingFlag;

// ---------- Camera Variables ----------
extern Size VideoDim;

// ---------- AI Parameters ----------
extern string ModelPath;
extern string VerifyModelPath;   // NEW: second-stage YOLOv5 TensorRT engine
extern Int16_t ROI_Loc[2];
extern UInt16_t ROI_Dim[2];
extern string ClassName[4];
extern struct _TargetData_ TargetData;

// ---------- Class Declaration ----------
class ObjDetection
{
private:
    // ================= PRIMARY DETECTOR =================
    UInt32_t Detections;
    UInt32_t DetectionSize;
    UInt32_t ClassCnt;
    UInt32_t DetectionCnt = 0U;  // Final Stage-2 verified detection count

    Size Yolov5_Dim;
    float ConfThreshold;
    float IOUThreshold;

    vector<struct _AIData_> TargetDataArr;

    // ================= TEMPLATE TRACKING =================
    float TempConfThreshold;
    UInt16_t TemplateFrameCnt;
    UInt8_t ActiveArr, StoreArr, MaxTemplateCnt;
    vector<struct _Template_> TemplateArr[2];

    // ================= PRIMARY TENSORRT =================
    unique_ptr<IRuntime> runtime;
    unique_ptr<ICudaEngine> engine;
    unique_ptr<IExecutionContext> context;

    vector<void *> Bindings;
    vector<size_t> BindingSizes;

    cudaStream_t rawStream;
    cuda::Stream cvStream;

    // ================= SECOND-STAGE VERIFIER =================
    unique_ptr<IRuntime> verifyRuntime;
    unique_ptr<ICudaEngine> verifyEngine;
    unique_ptr<IExecutionContext> verifyContext;

    vector<void *> VerifyBindings;
    vector<size_t> VerifyBindingSizes;

    cudaStream_t verifyRawStream;
    cuda::Stream verifyCvStream;

    bool VerifyEngineLoaded;

    float VerifyConfThreshold;
    float VerifyIOUThreshold;
    float VerifyROIScale;

    // Load second-stage engine
    bool LoadVerifyEngineFile(void);

    // Pre-process ROI for second YOLO model
    void verifyPreProcess(const Mat &VideoFrame, __half *InputBuff);

    // Run second YOLO model on a Stage-1 candidate ROI
    bool verifyDetection(const Mat &VideoFrame,
                         const struct _AIData_ &PrimaryTarget,
                         float &VerifyConfidence);

    // Decode second-model output and check expected class
    bool verifyPostProcess(UInt8_t ExpectedClass,
                           float &VerifyConfidence);

    // Expand Stage-1 bounding box before verification
    Rect expandVerifyBBox(const Rect &bbox,
                          const Size &frameSize,
                          float scale);

public:
    // Constructor
    ObjDetection(void);

    // Destructor
    ~ObjDetection(void);

    // Get Memory Size
    size_t getMemorySize(Dims dims, size_t ElementSize);

    // Load Primary Engine File
    bool LoadEngineFile(void);

    // Primary PreProcess
    void preProcess(Mat VideoFrame, __half *InputBuff);

    // Primary PostProcess + Second-stage Verification
    void postProcess(Mat &VideoFrame);

    // Template Matching
    bool template_matching(const cv::Mat &frame,
                           const cv::Mat &template_img,
                           const cv::Rect &last_bbox,
                           cv::Rect &matched_rect,
                           float &match_score,
                           float search_scale);

    void draw_template_match_result(cv::Mat &VideoFrame,
                                    bool detection_found);

    // Existing project declarations retained
    void templateMatch(Mat &VideoFrame);
    void drawBoxes(Mat &VideoFrame);

    // Detect Object Function
    void RunEnqueueV2(Mat &VideoFrame);
};

#endif /* OBJDETECTION_H_ */
