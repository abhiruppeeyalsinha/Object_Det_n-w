// ============================================================================
// ObjDetection.cpp
// Two-stage YOLOv5 TensorRT detection:
// Stage-1 full-frame detection -> ROI -> Stage-2 YOLO verification -> tracking
// ============================================================================

#include "ObjDetection.h"
#include "SysConfig.h"

// IMPORTANT:
// Define VerifyModelPath only here if it is NOT already defined elsewhere.
// If SysConfig/Main already defines it, remove this definition and keep only
// the 'extern string VerifyModelPath;' declaration from ObjDetection.h.
string VerifyModelPath = "./VerifyModel.engine";

// Logger for TensorRT messages
class Logger : public ILogger
{
    void log(Severity severity, const char *msg) noexcept override
    {
        if (severity <= Severity::kWARNING)
        {
            cout << "[TensorRT] : " << msg << endl;
        }
    }
};

Logger logger;

// Template matching parameters
static float TEMPLATE_MATCH_THRESHOLD = 0.55f;
static float SEARCH_REGION_SCALE = 5.5f;

// Single object tracking variables
static cv::Mat last_template;
static cv::Rect last_template_bbox;
static string last_template_label;
static float last_template_confidence;
static bool has_stored_template = false;
static int frames_without_detection = 0;

Scalar white(255, 255, 255);
Int8_t thin = 1;

// ============================================================================
// CUDA KERNELS
// ============================================================================

__global__ void ConvToFP16_NormCHW(const float *ch0,
                                   const float *ch1,
                                   const float *ch2,
                                   __half *output,
                                   int32_t width,
                                   int32_t height)
{
    int32_t x = blockIdx.x * blockDim.x + threadIdx.x;
    int32_t y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height)
        return;

    int32_t idx = y * width + x;
    int32_t imgArea = width * height;

    output[0 * imgArea + idx] = __float2half(ch0[idx] / 255.0f);
    output[1 * imgArea + idx] = __float2half(ch1[idx] / 255.0f);
    output[2 * imgArea + idx] = __float2half(ch2[idx] / 255.0f);
}

__global__ void fp16_to_fp32(const __half *input,
                             float *output,
                             int32_t N)
{
    int32_t idx = blockIdx.x * blockDim.x + threadIdx.x;

    if (idx < N)
        output[idx] = __half2float(input[idx]);
}

// ============================================================================
// CONSTRUCTOR
// ============================================================================

ObjDetection::ObjDetection(void)
{
    Yolov5_Dim.height = 640;
    Yolov5_Dim.width = 640;

    // Both models use the same YOLOv5 output format.
    Detections = 25200U;
    DetectionSize = 9U;
    ClassCnt = 4U;

    // Stage-1 thresholds
    ConfThreshold = 0.60f;
    IOUThreshold = 0.60f;

    // Stage-2 thresholds
    // Keep this slightly stricter because this model validates Stage-1.
    VerifyConfThreshold = 0.65f;
    VerifyIOUThreshold = 0.60f;

    // Add context around the first detection before second inference.
    VerifyROIScale = 1.30f;

    VerifyEngineLoaded = false;
    rawStream = nullptr;
    verifyRawStream = nullptr;

    // ---------------- PRIMARY ENGINE ----------------
    if (LoadEngineFile() == true)
    {
        AIStatusFlag = true;
        cerr << "Primary Engine Loaded Successfully" << endl;
    }
    else
    {
        AIStatusFlag = false;
        cerr << "Failed to load Primary Engine file" << endl;
    }

    // ---------------- VERIFICATION ENGINE ----------------
    // Model-2 is loaded ONLY when runtime flag -R is supplied.
    VerifyEngineLoaded = false;

    if(ReVerificationFlag == true)
    {
        VerifyEngineLoaded = LoadVerifyEngineFile();

        if(VerifyEngineLoaded == true)
        {
            cerr << "Verification Engine Loaded Successfully" << endl;
        }
        else
        {
            cerr << "Failed to load Verification Engine file: "
                 << VerifyModelPath << endl;
        }
    }
}

// ============================================================================
// DESTRUCTOR
// ============================================================================

ObjDetection::~ObjDetection(void)
{
    try
    {
        for (void *ptr : Bindings)
        {
            if (ptr)
                cudaFree(ptr);
        }

        for (void *ptr : VerifyBindings)
        {
            if (ptr)
                cudaFree(ptr);
        }

        // rawStream/verifyRawStream are obtained from OpenCV CUDA streams,
        // therefore the owning cv::cuda::Stream objects handle their lifetime.
    }
    catch (Exception &e)
    {
    }
}

// ============================================================================
// MEMORY SIZE
// ============================================================================

size_t ObjDetection::getMemorySize(Dims dims, size_t ElementSize)
{
    size_t size = ElementSize;

    for (Int32_t i = 0; i < dims.nbDims; i++)
        size *= dims.d[i];

    return size;
}

// ============================================================================
// TEMPLATE MATCHING
// ============================================================================

bool ObjDetection::template_matching(const cv::Mat &frame,
                                     const cv::Mat &template_img,
                                     const cv::Rect &last_bbox,
                                     cv::Rect &matched_rect,
                                     float &match_score,
                                     float search_scale)
{
    if (frame.empty() || template_img.empty())
        return false;

    cv::Rect bbox = last_bbox & cv::Rect(0, 0, frame.cols, frame.rows);

    if (bbox.width <= 0 || bbox.height <= 0)
        return false;

    int center_x = bbox.x + bbox.width / 2;
    int center_y = bbox.y + bbox.height / 2;

    int search_region_w = max((int)(bbox.width * search_scale),
                              template_img.cols * 2);

    int search_region_h = max((int)(bbox.height * search_scale),
                              template_img.rows * 2);

    int search_region_x1 = max(0, center_x - search_region_w / 2);
    int search_region_y1 = max(0, center_y - search_region_h / 2);
    int search_region_x2 = min(frame.cols, center_x + search_region_w / 2);
    int search_region_y2 = min(frame.rows, center_y + search_region_h / 2);

    if (search_region_x2 - search_region_x1 < template_img.cols ||
        search_region_y2 - search_region_y1 < template_img.rows)
    {
        return false;
    }

    cv::Rect search_roi(search_region_x1,
                        search_region_y1,
                        search_region_x2 - search_region_x1,
                        search_region_y2 - search_region_y1);

    cv::Mat search_region = frame(search_roi).clone();

    static bool isWindowCreated = false;
    if (!isWindowCreated)
    {
//         cv::namedWindow("search_region", WINDOW_NORMAL);
        isWindowCreated = true;
    }

//     imshow("search_region", search_region);

    cv::Mat result;
    cv::matchTemplate(search_region,
                      template_img,
                      result,
                      cv::TM_SQDIFF_NORMED);

    double minVal, maxVal;
    cv::Point minLoc, maxLoc;

    cv::minMaxLoc(result,
                  &minVal,
                  &maxVal,
                  &minLoc,
                  &maxLoc);

    match_score = 1.0f - static_cast<float>(minVal);

    if (minVal > TEMPLATE_MATCH_THRESHOLD)
        return false;

    matched_rect = cv::Rect(search_roi.x + minLoc.x,
                            search_roi.y + minLoc.y,
                            template_img.cols,
                            template_img.rows);

    matched_rect &= cv::Rect(0, 0, frame.cols, frame.rows);

    if (matched_rect.width <= 0 || matched_rect.height <= 0)
        return false;

    return true;
}

// ============================================================================
// LOAD PRIMARY ENGINE
// ============================================================================

bool ObjDetection::LoadEngineFile(void)
{
    try
    {
        setenv("CUDA_MODULE_LOADING", "LAZY", 1);

        ifstream EngineFile(ModelPath, ios::binary);

        if (!EngineFile)
        {
            cerr << "Failed to open Primary engine file: "
                 << ModelPath << endl;
            return false;
        }

        EngineFile.seekg(0, ios::end);
        auto fsize = EngineFile.tellg();
        EngineFile.seekg(0, ios::beg);

        vector<char> engine_data(fsize);
        EngineFile.read(engine_data.data(), fsize);

        runtime.reset(createInferRuntime(logger));

        if (!runtime)
            return false;

        engine.reset(runtime->deserializeCudaEngine(engine_data.data(),
                                                    fsize));

        if (!engine)
            return false;

        context.reset(engine->createExecutionContext());

        if (!context)
            return false;

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

        Int32_t nbBindings = engine->getNbBindings();

        Bindings.resize(nbBindings, nullptr);
        BindingSizes.resize(nbBindings, 0);

        for (Int32_t i = 0; i < nbBindings; i++)
        {
            Dims dims = engine->getBindingDimensions(i);
            nvinfer1::DataType dtype = engine->getBindingDataType(i);

            size_t elementSize =
                (dtype == nvinfer1::DataType::kFLOAT)
                    ? sizeof(float)
                    : (dtype == nvinfer1::DataType::kHALF)
                          ? sizeof(__half)
                          : sizeof(float);

            BindingSizes[i] = getMemorySize(dims, elementSize);

            if (cudaMalloc(&Bindings[i], BindingSizes[i]) != cudaSuccess)
            {
                cerr << "Primary cudaMalloc failed for binding " << i << endl;
                return false;
            }
        }

#pragma GCC diagnostic pop

        rawStream = cv::cuda::StreamAccessor::getStream(cvStream);

        return true;
    }
    catch (Exception &e)
    {
        cerr << "Exception while loading Primary TensorRT engine" << endl;
        return false;
    }

    return false;
}

// ============================================================================
// LOAD SECOND-STAGE VERIFICATION ENGINE
// ============================================================================

bool ObjDetection::LoadVerifyEngineFile(void)
{
    try
    {
        setenv("CUDA_MODULE_LOADING", "LAZY", 1);

        ifstream EngineFile(VerifyModelPath, ios::binary);

        if (!EngineFile)
        {
            cerr << "[VERIFY] Failed to open engine file: "
                 << VerifyModelPath << endl;
            return false;
        }

        EngineFile.seekg(0, ios::end);
        auto fsize = EngineFile.tellg();
        EngineFile.seekg(0, ios::beg);

        vector<char> engine_data(fsize);
        EngineFile.read(engine_data.data(), fsize);

        verifyRuntime.reset(createInferRuntime(logger));

        if (!verifyRuntime)
            return false;

        verifyEngine.reset(
            verifyRuntime->deserializeCudaEngine(engine_data.data(), fsize));

        if (!verifyEngine)
            return false;

        verifyContext.reset(verifyEngine->createExecutionContext());

        if (!verifyContext)
            return false;

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

        Int32_t nbBindings = verifyEngine->getNbBindings();

        VerifyBindings.resize(nbBindings, nullptr);
        VerifyBindingSizes.resize(nbBindings, 0);

        for (Int32_t i = 0; i < nbBindings; i++)
        {
            Dims dims = verifyEngine->getBindingDimensions(i);
            nvinfer1::DataType dtype = verifyEngine->getBindingDataType(i);

            size_t elementSize =
                (dtype == nvinfer1::DataType::kFLOAT)
                    ? sizeof(float)
                    : (dtype == nvinfer1::DataType::kHALF)
                          ? sizeof(__half)
                          : sizeof(float);

            VerifyBindingSizes[i] = getMemorySize(dims, elementSize);

            if (cudaMalloc(&VerifyBindings[i],
                           VerifyBindingSizes[i]) != cudaSuccess)
            {
                cerr << "[VERIFY] cudaMalloc failed for binding "
                     << i << endl;
                return false;
            }
        }

#pragma GCC diagnostic pop

        verifyRawStream =
            cv::cuda::StreamAccessor::getStream(verifyCvStream);

        return true;
    }
    catch (Exception &e)
    {
        cerr << "[VERIFY] Exception while loading TensorRT engine" << endl;
        return false;
    }

    return false;
}

// ============================================================================
// PRIMARY PREPROCESS
// ============================================================================

void ObjDetection::preProcess(Mat VideoFrame, __half *InputBuff)
{
    dim3 block(32, 32);

    dim3 grid((Yolov5_Dim.width + block.x - 1) / block.x,
              (Yolov5_Dim.height + block.y - 1) / block.y);

    cuda::GpuMat Frame;
    cuda::GpuMat GpuCHW[3];

    Frame.upload(VideoFrame, cvStream);

    // Same preprocessing behavior as original code.
    cuda::GpuMat GpuFrame(Yolov5_Dim.height,
                          Yolov5_Dim.width,
                          Frame.type(),
                          Scalar::all(0));

    int copyWidth = min(VideoFrame.cols, Yolov5_Dim.width);
    int copyHeight = min(VideoFrame.rows, Yolov5_Dim.height);

    cuda::GpuMat SourceROI = Frame(Rect(0, 0, copyWidth, copyHeight));
    cuda::GpuMat DestinationROI = GpuFrame(Rect(0, 0, copyWidth, copyHeight));

    SourceROI.copyTo(DestinationROI, cvStream);

    GpuFrame.convertTo(GpuFrame, CV_32FC3, cvStream);
    cv::cuda::split(GpuFrame, GpuCHW, cvStream);

    ConvToFP16_NormCHW<<<grid, block, 0, rawStream>>>(
        GpuCHW[0].ptr<float>(),
        GpuCHW[1].ptr<float>(),
        GpuCHW[2].ptr<float>(),
        InputBuff,
        Yolov5_Dim.width,
        Yolov5_Dim.height);
}

// ============================================================================
// SECOND-STAGE PREPROCESS
// ROI is resized to fit inside 640x640 while preserving aspect ratio.
// The resize scale is not needed for validation because Stage-2 only needs to
// confirm whether the expected class exists in the ROI.
// ============================================================================

void ObjDetection::verifyPreProcess(const Mat &VideoFrame,
                                    __half *InputBuff)
{
    if (VideoFrame.empty())
        return;

    float scale = min(
        static_cast<float>(Yolov5_Dim.width) /
            static_cast<float>(VideoFrame.cols),
        static_cast<float>(Yolov5_Dim.height) /
            static_cast<float>(VideoFrame.rows));

    int resizedWidth = max(1,
                           static_cast<int>(VideoFrame.cols * scale));

    int resizedHeight = max(1,
                            static_cast<int>(VideoFrame.rows * scale));

    resizedWidth = min(resizedWidth, Yolov5_Dim.width);
    resizedHeight = min(resizedHeight, Yolov5_Dim.height);

    cv::Mat ResizedFrame;

    cv::resize(VideoFrame,
               ResizedFrame,
               cv::Size(resizedWidth, resizedHeight),
               0.0,
               0.0,
               cv::INTER_LINEAR);

    cuda::GpuMat Frame;
    cuda::GpuMat GpuCHW[3];

    Frame.upload(ResizedFrame, verifyCvStream);

    cuda::GpuMat GpuFrame(Yolov5_Dim.height,
                          Yolov5_Dim.width,
                          Frame.type(),
                          Scalar::all(0));

    Frame.copyTo(
        GpuFrame(Rect(0,
                      0,
                      resizedWidth,
                      resizedHeight)),
        verifyCvStream);

    GpuFrame.convertTo(GpuFrame,
                       CV_32FC3,
                       verifyCvStream);

    cv::cuda::split(GpuFrame,
                    GpuCHW,
                    verifyCvStream);

    dim3 block(32, 32);

    dim3 grid((Yolov5_Dim.width + block.x - 1) / block.x,
              (Yolov5_Dim.height + block.y - 1) / block.y);

    ConvToFP16_NormCHW<<<grid, block, 0, verifyRawStream>>>(
        GpuCHW[0].ptr<float>(),
        GpuCHW[1].ptr<float>(),
        GpuCHW[2].ptr<float>(),
        InputBuff,
        Yolov5_Dim.width,
        Yolov5_Dim.height);
}

// ============================================================================
// EXPAND STAGE-1 BOUNDING BOX FOR SECOND-STAGE VALIDATION
// ============================================================================

Rect ObjDetection::expandVerifyBBox(const Rect &bbox,
                                    const Size &frameSize,
                                    float scale)
{
    float cx = bbox.x + (bbox.width * 0.5f);
    float cy = bbox.y + (bbox.height * 0.5f);

    int newWidth = max(1,
                       static_cast<int>(bbox.width * scale));

    int newHeight = max(1,
                        static_cast<int>(bbox.height * scale));

    int x = static_cast<int>(cx - newWidth * 0.5f);
    int y = static_cast<int>(cy - newHeight * 0.5f);

    Rect expanded(x, y, newWidth, newHeight);

    expanded &= Rect(0,
                     0,
                     frameSize.width,
                     frameSize.height);

    return expanded;
}

// ============================================================================
// SECOND-STAGE YOLO OUTPUT DECODER
//
// Verification rule:
//   1. valid YOLO prediction
//   2. class must equal Stage-1 class
//   3. confidence >= VerifyConfThreshold
//   4. at least one expected-class prediction survives NMS
// ============================================================================

bool ObjDetection::verifyPostProcess(UInt8_t ExpectedClass,
                                     float &VerifyConfidence)
{
    VerifyConfidence = 0.0f;

    if (!VerifyEngineLoaded || VerifyBindings.size() < 2)
        return false;

    const int32_t Total = DetectionSize * Detections;

    vector<float> Output(Total);

    float *FP32_OutBuff = nullptr;

    if (cudaMalloc(&FP32_OutBuff,
                   Total * sizeof(float)) != cudaSuccess)
    {
        cerr << "[VERIFY] FP32 output allocation failed" << endl;
        return false;
    }

    dim3 block(256);
    dim3 grid((Total + block.x - 1) / block.x);

    fp16_to_fp32<<<grid, block, 0, verifyRawStream>>>(
        static_cast<const __half *>(VerifyBindings[1]),
        FP32_OutBuff,
        Total);

    cudaMemcpyAsync(Output.data(),
                    FP32_OutBuff,
                    Output.size() * sizeof(float),
                    cudaMemcpyDeviceToHost,
                    verifyRawStream);

    verifyCvStream.waitForCompletion();
    cudaStreamSynchronize(verifyRawStream);

    cudaFree(FP32_OutBuff);

    vector<Rect> Boxes;
    vector<float> Confidences;

    for (UInt32_t i = 0; i < Detections; i++)
    {
        float *det = &Output[i * DetectionSize];

        float ObjConf = det[4];

        if (ObjConf <= 0.0f ||
            ObjConf > 1.0f ||
            isnan(ObjConf))
        {
            continue;
        }

        float ClassScore[4];

        for (UInt32_t j = 0; j < ClassCnt; j++)
            ClassScore[j] = det[5 + j];

        UInt8_t ClassID =
            static_cast<UInt8_t>(
                max_element(ClassScore,
                            ClassScore + ClassCnt) -
                ClassScore);

        float ClassConf = ClassScore[ClassID];
        float Confidence = ObjConf * ClassConf;

        // Stage-2 must independently agree with Stage-1 class.
        if (ClassID != ExpectedClass)
            continue;

        if (Confidence < VerifyConfThreshold ||
            Confidence > 1.0f ||
            isnan(Confidence))
        {
            continue;
        }

        float CentreX = det[0];
        float CentreY = det[1];
        float Width = det[2];
        float Height = det[3];

        if (isnan(CentreX) ||
            isnan(CentreY) ||
            isnan(Width) ||
            isnan(Height) ||
            Width <= 0.0f ||
            Height <= 0.0f)
        {
            continue;
        }

        int X1 = max(0,
                     static_cast<int>(CentreX - Width / 2.0f));

        int Y1 = max(0,
                     static_cast<int>(CentreY - Height / 2.0f));

        int X2 = min(Yolov5_Dim.width - 1,
                     static_cast<int>(CentreX + Width / 2.0f));

        int Y2 = min(Yolov5_Dim.height - 1,
                     static_cast<int>(CentreY + Height / 2.0f));

        if (X2 <= X1 || Y2 <= Y1)
            continue;

        Boxes.emplace_back(
            Rect(X1,
                 Y1,
                 X2 - X1,
                 Y2 - Y1));

        Confidences.emplace_back(Confidence);
    }

    if (Boxes.empty())
        return false;

    vector<Int32_t> Indices;

    dnn::NMSBoxes(Boxes,
                  Confidences,
                  VerifyConfThreshold,
                  VerifyIOUThreshold,
                  Indices);

    if (Indices.empty())
        return false;

    // Use the strongest surviving expected-class detection.
    for (Int32_t idx : Indices)
    {
        if (idx >= 0 &&
            static_cast<size_t>(idx) < Confidences.size())
        {
            VerifyConfidence = max(VerifyConfidence,
                                   Confidences[idx]);
        }
    }

    return VerifyConfidence >= VerifyConfThreshold;
}

// ============================================================================
// RUN SECOND MODEL ON ONE STAGE-1 DETECTION
// ============================================================================

bool ObjDetection::verifyDetection(const Mat &VideoFrame,
                                   const struct _AIData_ &PrimaryTarget,
                                   float &VerifyConfidence)
{
    VerifyConfidence = 0.0f;

    if (!VerifyEngineLoaded ||
        !verifyContext ||
        VerifyBindings.size() < 2)
    {
        return false;
    }

    if (VideoFrame.empty())
        return false;

    Rect bbox = PrimaryTarget.BoundingBox &
                Rect(0,
                     0,
                     VideoFrame.cols,
                     VideoFrame.rows);

    if (bbox.width <= 1 || bbox.height <= 1)
        return false;

    Rect verifyBBox = expandVerifyBBox(
        bbox,
        VideoFrame.size(),
        VerifyROIScale);

    if (verifyBBox.width <= 1 ||
        verifyBBox.height <= 1)
    {
        return false;
    }

    Mat TargetROI = VideoFrame(verifyBBox).clone();

    if (TargetROI.empty())
        return false;

    // Optional debug display.
    // imshow("Verification_ROI", TargetROI);

    verifyPreProcess(
        TargetROI,
        static_cast<__half *>(VerifyBindings[0]));

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

    bool enqueueStatus = verifyContext->enqueueV2(
        VerifyBindings.data(),
        verifyRawStream,
        nullptr);

#pragma GCC diagnostic pop

    if (!enqueueStatus)
    {
        cerr << "[VERIFY] TensorRT enqueue failed" << endl;
        return false;
    }

    cudaStreamSynchronize(verifyRawStream);
    verifyCvStream.waitForCompletion();

    return verifyPostProcess(
        PrimaryTarget.ClassID,
        VerifyConfidence);
}

// ============================================================================
// PRIMARY POSTPROCESS + SECOND-STAGE VERIFICATION
// ============================================================================

void ObjDetection::postProcess(Mat &VideoFrame)
{
    UInt16_t VideoWidth =
        static_cast<UInt16_t>(VideoFrame.cols);

    UInt16_t VideoHeight =
        static_cast<UInt16_t>(VideoFrame.rows);

    int32_t Total = DetectionSize * Detections;

    vector<Rect> Boxes;
    vector<Int32_t> Indices;
    vector<UInt8_t> ClassIds;
    vector<float> Confidances;

    float Confidence;
    float ClassScore[4];
    float ObjConf, ClassConf;
    UInt8_t ClassID = 0;

    float *FP32_OutBuff = nullptr;

    dim3 block(256);
    dim3 grid((Total + block.x - 1) / block.x);

    vector<float> Output(Total);

    Int16_t CentreX, CentreY, Width, Height;
    Int16_t X1, Y1, X2, Y2;

    struct _AIData_ Target;

    Boxes.clear();
    Indices.clear();
    ClassIds.clear();
    Confidances.clear();

    // IMPORTANT:
    // TargetDataArr now contains only Stage-2 verified detections.
    TargetDataArr.clear();
    DetectionCnt = 0;

    if (cudaMalloc(&FP32_OutBuff,
                   Total * sizeof(float)) != cudaSuccess)
    {
        cerr << "Primary FP32 output allocation failed" << endl;
        return;
    }

    fp16_to_fp32<<<grid, block, 0, rawStream>>>(
        static_cast<const __half *>(Bindings[1]),
        FP32_OutBuff,
        Total);

    cudaMemcpyAsync(Output.data(),
                    FP32_OutBuff,
                    Output.size() * sizeof(float),
                    cudaMemcpyDeviceToHost,
                    rawStream);

    cvStream.waitForCompletion();
    cudaStreamSynchronize(rawStream);

    cudaFree(FP32_OutBuff);

    // ------------------------------------------------------------------------
    // STAGE-1 YOLO DECODE
    // ------------------------------------------------------------------------

    for (UInt32_t i = 0; i < Detections; i++)
    {
        float *det = &Output[i * DetectionSize];

        ObjConf = det[4];

        if (ObjConf < ConfThreshold ||
            ObjConf > 1.0f ||
            isnan(ObjConf))
        {
            continue;
        }

        for (UInt32_t j = 0; j < ClassCnt; j++)
        {
            ClassScore[j] = det[5 + j];
        }

        ClassID = static_cast<UInt8_t>(
            max_element(ClassScore,
                        ClassScore + ClassCnt) -
            ClassScore);

        ClassConf = ClassScore[ClassID];
        Confidence = ObjConf * ClassConf;

        // The original code used ConfThreshold during NMS as well.
        // Reject low combined confidence here so only valid candidates enter NMS.
        if (Confidence < ConfThreshold ||
            Confidence > 1.0f ||
            isnan(Confidence))
        {
            continue;
        }

        CentreX = static_cast<Int16_t>(det[0]);
        CentreY = static_cast<Int16_t>(det[1]);
        Width = static_cast<Int16_t>(det[2]);
        Height = static_cast<Int16_t>(det[3]);

        if (CentreX < 0 ||
            CentreX > Yolov5_Dim.width ||
            CentreY < 0 ||
            CentreY > Yolov5_Dim.height ||
            Width <= 0 ||
            Height <= 0 ||
            Width > Yolov5_Dim.width ||
            Height > Yolov5_Dim.height)
        {
            continue;
        }

        X1 = FindMax(0,
                     CentreX - (Width / 2));

        Y1 = FindMax(0,
                     CentreY - (Height / 2));

        X2 = FindMin(VideoWidth - 1,
                     CentreX + (Width / 2));

        Y2 = FindMin(VideoHeight - 1,
                     CentreY + (Height / 2));

        if (X2 > X1 && Y2 > Y1)
        {
            Boxes.emplace_back(
                Rect(X1,
                     Y1,
                     X2 - X1,
                     Y2 - Y1));

            Confidances.emplace_back(Confidence);
            ClassIds.emplace_back(ClassID);
        }
    }

    dnn::NMSBoxes(Boxes,
                  Confidances,
                  ConfThreshold,
                  IOUThreshold,
                  Indices);

    // ------------------------------------------------------------------------
    // STAGE-2 VERIFICATION
    // ------------------------------------------------------------------------

    for (Int32_t idx : Indices)
    {
        if (idx < 0 ||
            static_cast<size_t>(idx) >= Boxes.size())
        {
            continue;
        }

        Target.ClassID = ClassIds[idx];
        Target.Confidance = Confidances[idx];
        Target.BoundingBox = Boxes[idx];

        Target.CenterPoint = Point(
            Boxes[idx].x + Boxes[idx].width / 2,
            Boxes[idx].y + Boxes[idx].height / 2);

        if(ReVerificationFlag == true) cout << "[STAGE-1] Candidate"
             << " Class:" << ClassName[Target.ClassID]
             << " ID:" << static_cast<UInt32_t>(Target.ClassID)
             << " Conf:"
             << static_cast<UInt32_t>(Target.Confidance * 100.0f)
             << "%"
             << " Ny:"
             << (Target.CenterPoint.x - VideoFrame.cols / 2)
             << " Nz:"
             << (Target.CenterPoint.y - VideoFrame.rows / 2)
             << " W:" << Target.BoundingBox.width
             << " H:" << Target.BoundingBox.height
             << endl;

        float VerifyConfidence = 0.0f;

        // Original single-model behavior when -R is NOT supplied
        if(ReVerificationFlag == false)
        {
            TargetDataArr.push_back(Target);
            DetectionCnt++;
            continue;
        }

        bool Verified = verifyDetection(
            VideoFrame,
            Target,
            VerifyConfidence);

        if (!Verified)
        {
            cout << "[STAGE-2] REJECTED"
                 << " Class:" << ClassName[Target.ClassID]
                 << " Stage1:"
                 << static_cast<UInt32_t>(Target.Confidance * 100.0f)
                 << "%"
                 << " Stage2:"
                 << static_cast<UInt32_t>(VerifyConfidence * 100.0f)
                 << "%"
                 << endl;

            // DO NOT send to TargetDataArr.
            // DO NOT initialize/update template tracking.
            continue;
        }

        cout << "[STAGE-2] VERIFIED"
             << " Class:" << ClassName[Target.ClassID]
             << " Stage1:"
             << static_cast<UInt32_t>(Target.Confidance * 100.0f)
             << "%"
             << " Stage2:"
             << static_cast<UInt32_t>(VerifyConfidence * 100.0f)
             << "%"
             << endl;

        // ================================================================
        // ONLY VERIFIED TARGETS ARE ACCEPTED.
        // ================================================================
        TargetDataArr.push_back(Target);
    }

    DetectionCnt = static_cast<int>(TargetDataArr.size());

    if(ReVerificationFlag == true) cout << "[DOUBLE-DETECTION] Verified Targets: "
         << DetectionCnt << endl;
}

// ============================================================================
// TEMPLATE MATCHING VISUALIZATION
// TargetDataArr contains only second-stage verified targets.
// ============================================================================

void ObjDetection::draw_template_match_result(cv::Mat &VideoFrame,
                                              bool detection_found)
{
    string Label = "";

    Point frame_center(VideoFrame.cols / 2,
                       VideoFrame.rows / 2);

    bool template_updated_this_frame = false;

    if (detection_found)
    {
        frames_without_detection = 0;

        for (const auto &Target : TargetDataArr)
        {
            string label = ClassName[Target.ClassID];

            // Retained from your original tracking behavior.
            if (label == "Bird" || label == "Plane")
                continue;

            cv::Rect bbox = Target.BoundingBox &
                            cv::Rect(0,
                                     0,
                                     VideoFrame.cols,
                                     VideoFrame.rows);

            if (bbox.width <= 0 || bbox.height <= 0)
                continue;

            cv::Mat crop = VideoFrame(bbox).clone();

            static bool isWindowCreated = false;

            if (!isWindowCreated)
            {
//                 cv::namedWindow("crop", WINDOW_NORMAL);
                isWindowCreated = true;
            }

//             imshow("crop", crop);

            if (crop.empty())
                continue;

            // IMPORTANT:
            // Template can only be initialized/updated from a target that has
            // already passed the second YOLO verification model.
            last_template = crop.clone();
            last_template_bbox = bbox;
            last_template_label = label;
            last_template_confidence = Target.Confidance;

            has_stored_template = true;
            template_updated_this_frame = true;

            rectangle(VideoFrame,
                      bbox,
                      white,
                      thin);

            Point bbox_center(
                bbox.x + bbox.width / 2,
                bbox.y + bbox.height / 2);

            line(VideoFrame,
                 frame_center,
                 bbox_center,
                 white,
                 1);

            Label = "VERIFIED " +
                    ClassName[Target.ClassID] +
                    " " +
                    to_string(
                        static_cast<UInt32_t>(
                            Target.Confidance * 100.0f)) +
                    "% (" +
                    to_string(Target.CenterPoint.x -
                              VideoFrame.cols / 2) +
                    ", " +
                    to_string(Target.CenterPoint.y -
                              VideoFrame.rows / 2) +
                    ")";

            cout << "AI VERIFIED : "
                 << ClassName[Target.ClassID]
                 << " ID:"
                 << static_cast<UInt32_t>(Target.ClassID)
                 << " Conf:"
                 << static_cast<UInt32_t>(
                        Target.Confidance * 100.0f)
                 << "% Ny:"
                 << (Target.CenterPoint.x - VideoFrame.cols / 2)
                 << " Nz:"
                 << (Target.CenterPoint.y - VideoFrame.rows / 2)
                 << " W:"
                 << Target.BoundingBox.width
                 << " H:"
                 << Target.BoundingBox.height
                 << endl
                 << flush;

            putText(VideoFrame,
                    Label,
                    Target.BoundingBox.tl(),
                    FONT_HERSHEY_SIMPLEX,
                    0.45,
                    white,
                    thin);

            // Single-object tracking behavior retained.
            break;
        }
    }

    // ------------------------------------------------------------------------
    // If no verified detection exists in this frame, use the stored template.
    // ------------------------------------------------------------------------

    if (!template_updated_this_frame &&
        has_stored_template)
    {
        frames_without_detection++;

        cv::Rect matched_rect;
        float match_score = 0.0f;

        if (template_matching(VideoFrame,
                              last_template,
                              last_template_bbox,
                              matched_rect,
                              match_score,
                              SEARCH_REGION_SCALE))
        {
            last_template_bbox = matched_rect;

            cv::rectangle(VideoFrame,
                          matched_rect,
                          white,
                          1);

            Point bbox_center(
                matched_rect.x + matched_rect.width / 2,
                matched_rect.y + matched_rect.height / 2);

            line(VideoFrame,
                 frame_center,
                 bbox_center,
                 white,
                 1);

            string label =
                "TM : " +
                last_template_label +
                " " +
                to_string(static_cast<int>(match_score * 100)) +
                "% (" +
                to_string(bbox_center.x - VideoFrame.cols / 2) +
                ", " +
                to_string(bbox_center.y - VideoFrame.rows / 2) +
                ")";

            cout << "TM : "
                 << last_template_label
                 << " Conf:"
                 << static_cast<int>(match_score * 100)
                 << "% Ny:"
                 << (bbox_center.x - VideoFrame.cols / 2)
                 << " Nz:"
                 << (bbox_center.y - VideoFrame.rows / 2)
                 << " W:"
                 << matched_rect.width
                 << " H:"
                 << matched_rect.height
                 << endl
                 << flush;

            putText(VideoFrame,
                    label,
                    Point(matched_rect.x,
                          max(0, matched_rect.y - 5)),
                    FONT_HERSHEY_SIMPLEX,
                    0.5,
                    white,
                    1);
        }
    }
}

// ============================================================================
// DETECT OBJECT FUNCTION
// ============================================================================

void ObjDetection::RunEnqueueV2(Mat &VideoFrame)
{
    if (VideoFrame.empty() ||
        !context ||
        Bindings.size() < 2)
    {
        DetectionCnt = 0;
        return;
    }

    // ------------------------------------------------------------------------
    // STAGE-1 PRIMARY YOLO
    // ------------------------------------------------------------------------

    preProcess(
        VideoFrame,
        static_cast<__half *>(Bindings[0]));

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

    bool enqueueStatus = context->enqueueV2(
        Bindings.data(),
        rawStream,
        nullptr);

#pragma GCC diagnostic pop

    if (!enqueueStatus)
    {
        cerr << "Primary TensorRT enqueue failed" << endl;
        DetectionCnt = 0;
        return;
    }

    cudaStreamSynchronize(rawStream);
    cvStream.waitForCompletion();

    // ------------------------------------------------------------------------
    // Stage-1 postprocess -> Stage-2 verification.
    // postProcess() leaves only verified targets in TargetDataArr.
    // ------------------------------------------------------------------------

    postProcess(VideoFrame);

    bool verified_detection_found =
        (DetectionCnt > 0);

    // ------------------------------------------------------------------------
    // Tracking receives ONLY second-stage verified detections.
    // ------------------------------------------------------------------------

    draw_template_match_result(
        VideoFrame,
        verified_detection_found);
}
