// ============================================================================
// Name		: Seeker.cpp
// Date		: 08 Jan 2026
// ============================================================================


// ---------- Header Inclusion ----------
#include "Seeker.h"


// ---------- Constructor ----------
Seeker :: Seeker(void)
{
	VideoInd = 0;

	// Create UDP/UDP Socket
	UDPSock = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
	if(UDPSock < 0)
	{
		cerr << "Error: socket: failed to open VIDEO_UDP socket" << endl;
		raise(SIGINT);
	}

	len = sizeof(caddr);
	memset((void *)&caddr, 0, len);

	caddr.sin_family = AF_INET;
	caddr.sin_addr.s_addr = inet_addr(DL_IPAddr);
	caddr.sin_port = htons(DL_UDPPort);


#if _VIDEO_FFMPEG_

	avdic = NULL;
	LastIOTime = 0;
	videoStream = -1;
	inpFormat = nullptr;

	pFormatCtx = avformat_alloc_context();

	if(VideoSource.find("rtsp://") == 0 || VideoSource.find("http://") == 0 || VideoSource.find("https://") == 0
	   || VideoSource.find("udp://") == 0 || VideoSource.find("tcp://") == 0 || VideoSource.find("rtmp://") == 0)
	{
		avformat_network_init();					// Initialize FFmpeg network module

		av_dict_set(&avdic, "rtsp_transport", "tcp", 0);
		av_dict_set(&avdic, "max_delay", "0", 0);
//		av_dict_set(&avdic, "stimeout", "3000000", 0);   // 3s connect
//		av_dict_set(&avdic, "rw_timeout", "5000000", 0); // 5s read

		if(avformat_open_input(&pFormatCtx, VideoSource.c_str(), NULL,  &avdic) != 0)
		{
			cerr << "Can't open the VideoSource" << endl;
			SeekerStatus = false;
			return;
		}
	}
	else if(VideoSource.find("/dev/video") == 0)
	{
		avdevice_register_all();
		inpFormat = av_find_input_format("v4l2");

		av_dict_set(&avdic, "video_size", "640x480", 0);
		av_dict_set(&avdic, "framerate", "25", 0);

		av_dict_set(&avdic, "pixel_format", "yuyv422", 0);
		av_dict_set(&avdic, "input_format", "yuyv422", 0);

		if(avformat_open_input(&pFormatCtx, VideoSource.c_str(), inpFormat,  &avdic) != 0)
		{
			cerr << "Can't open the VideoSource" << endl;
			SeekerStatus = false;
			return;
		}

	}
	else
	{

		if(avformat_open_input(&pFormatCtx, VideoSource.c_str(), NULL,  &avdic) != 0)
		{
			cerr << "Can't open the VideoSource" << endl;
			SeekerStatus = false;
			return;
		}

	}

	// Get stream information
	if(avformat_find_stream_info(pFormatCtx, NULL) < 0)
	{
		cerr << "Couldn't find stream information" << endl;
		SeekerStatus = false;
		return;
	}

	// Find the video stream
	for(UInt32_t i = 0; i < pFormatCtx->nb_streams; i++)
	{
		if(pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			videoStream = i;
			break;
		}
	}

	if(videoStream == -1)
	{
		cerr << "Didn't find a video stream" << endl;
		SeekerStatus = false;
		return;
	}

	// Get codec context
	pCodecCtx = avcodec_alloc_context3(NULL);
	avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[videoStream]->codecpar);
	pCodec = avcodec_find_decoder(pCodecCtx->codec_id);

	if(pCodec == NULL)
	{
		cerr << "Codec not found" << endl;
		SeekerStatus = false;
		return;
	}

	pCodecCtx->bit_rate = 0;
	pCodecCtx->time_base.num = 1;
	pCodecCtx->time_base.den = 10;
	pCodecCtx->frame_number = 1;

	// Open codec
	if(avcodec_open2(pCodecCtx, pCodec, NULL) < 0)
	{
		cerr << "Could not open codec" << endl;
		SeekerStatus = false;
		return;
	}

	// Allocate memory for frames
	pFrame = av_frame_alloc();
	pFrameEO = av_frame_alloc();

	// Get the required buffer size for RGB conversion
	img_convert_ctx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);

	//numBytes = avpicture_get_size(AV_PIX_FMT_RGB32, pCodecCtx->width,pCodecCtx->height);
	numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);

	//out_buffer = (uint8_t *) av_malloc(numBytes * sizeof(uint8_t));
	out_buffer = (UInt8_t *)av_malloc(numBytes);

	av_image_fill_arrays(pFrameEO->data, pFrameEO->linesize, out_buffer, AV_PIX_FMT_BGR24, pCodecCtx->width, pCodecCtx->height, 1);

	packet = av_packet_alloc();

#else

	CAM.open(VideoSource);
	// CAM.set(CAP_PROP_BUFFERSIZE, 1); // drop old frames

	if(!CAM.isOpened())
	{
		cerr << "ERROR! Unable to open video source " << VideoSource << endl;
		SeekerStatus = false;
	}

#endif


	if(SaveDataFlag == true)
	{
		// Open VideoWriter
		OutVid.open(SavePath + "IPVideo" + to_string(VideoInd) + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, false);
		if(!OutVid.isOpened())
		{
			cerr << "Error in opening new video file" << endl;
			raise(SIGINT);
		}
	}

	return;
}


// ---------- Destructor ----------
Seeker :: ~Seeker(void)
{
	close(UDPSock);
	OutVid.release();

#if _VIDEO_FFMPEG_
	av_packet_free(&packet);
	av_frame_free(&pFrame);
	av_frame_free(&pFrameEO);

	sws_freeContext(img_convert_ctx);

	avcodec_free_context(&pCodecCtx);
	avformat_close_input(&pFormatCtx);
	avformat_network_deinit();

#else

	CAM.release();

#endif


	return;
}


// ---------- Read Frames ----------
void Seeker :: ReadFrames(void)
{
#if _VIDEO_FFMPEG_

	Int32_t ret;
	Mat VideoFrame;
	string timestamp;
	Int32_t sleepTime;
	struct timespec ts, ts1;
	UInt32_t timCntStart, timCntEnd, totalTime;

	ts.tv_sec = 0;
	ts.tv_nsec = 1000 * 10;

	ts1.tv_sec = 0;
	ts1.tv_nsec = 0;


	// Wait Until IP Card Gets ready
	while(IPCardReadyFlag == false)
	{
		if(ProcessThreadFlag == false)
		{
			break;
		}

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
	}

	VideoFrame.create(pCodecCtx->height, pCodecCtx->width, CV_8UC3);
	LastIOTime = GetCurrMillis();

	while(ProcessThreadFlag == true && SeekerStatus == true)
	{
		// Start measuring execution time
		timCntStart = GetCurrMillis();

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		ret = av_read_frame(pFormatCtx, packet);

		if(ret == AVERROR_EXIT || ret < 0)
		{
			if(GetCurrMillis() - LastIOTime > 3000)
			{
				cout << "Failed to read Video" << endl;
				SeekerStatus = false;
				destroyAllWindows();
				break;
			}

			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
			continue;
		}

		if(packet->stream_index == videoStream)
		{
			if(avcodec_send_packet(pCodecCtx, packet) == 0 && avcodec_receive_frame(pCodecCtx, pFrame) == 0)
			{
				sws_scale(img_convert_ctx, pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameEO->data, pFrameEO->linesize);
				memcpy(VideoFrame.data, pFrameEO->data[0], pCodecCtx->height * pFrameEO->linesize[0]);

				// Set and add timestamp in VideoFrame
				timestamp = GetTimeStamp();
				putText(VideoFrame, timestamp, Point(10, 20), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1);

				if(CameraData.FrameFlag == true)
				{
					CameraData.FrameFlag = false;
					CameraData.VideoFrame.release();
					cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
				}

				CameraData.VideoFrame = VideoFrame.clone();
				CameraData.FrameTime = GetCurrMillis();

				resize(CameraData.VideoFrame, CameraData.VideoFrame, VideoDim);				// Resize it if needed
				LastIOTime = CameraData.FrameTime;

				CameraData.FrameFlag = true;

				// Send Target Data sync with Camera
				if(TgtDataModeFlag == false && IPCardMode != 2U && IPCardMode != 3U)
				{
					SendTargetDataFlag = true;
				}
			}
		}

		av_packet_unref(packet);

		// Stop Measuring execution time
		timCntEnd =  GetCurrMillis();

		// Calculate the reading & sleep time in milliseconds
		totalTime = (timCntEnd < timCntStart) ? ((86400000U + timCntEnd) - timCntStart) : (timCntEnd - timCntStart);
		sleepTime = FrameDelay - totalTime;

		// cout << "Frame Reading Time - " << totalTime << " ms" << endl << flush;

		// Give Delay in Video Reading only for video files
		if(!(VideoSource.find("/dev/video") == 0 || VideoSource.find("rtsp://") == 0 || VideoSource.find("http://") == 0 ||
			VideoSource.find("https://") == 0 || VideoSource.find("udp://") == 0 || VideoSource.find("tcp://") == 0 ||
			VideoSource.find("rtmp://") == 0) && sleepTime > 0)
		{
			ts1.tv_nsec = (sleepTime * 1000 * 1000) - 30;
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts1, nullptr);
		}
	}

	return;

#else

	bool ret;
	Mat VideoFrame;
	string timestamp;
	Int32_t sleepTime;
	struct timespec ts, ts1;
	UInt32_t timCntStart, timCntEnd, totalTime;

	ts.tv_sec = 0;
	ts.tv_nsec = 1000 * 5;

	ts1.tv_sec = 0;
	ts1.tv_nsec = 0;

	// Wait Until IP Card Gets ready
	while(IPCardReadyFlag == false)
	{
		if(ProcessThreadFlag == false)
		{
			break;
		}

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
	}

	while(ProcessThreadFlag == true && SeekerStatus == true)
	{
		// Start measuring execution time
		timCntStart = GetCurrMillis();

		// Reading VideoFrame using OpenCV
		VideoFrame.release();
		ret = CAM.read(VideoFrame);

		if(ret == false)
		{
			cerr << "Error! Failed to read video" << endl;

			if(VideoSource == "/dev/video0")
			{
				CAM.release();
				CAM.open(VideoSource);

				if(!CAM.isOpened())
				{
					cerr << "ERROR! Unable to open video source " << VideoSource << endl;
					SeekerStatus = false;
					destroyAllWindows();
					break;
				}
				else
				{
					continue;
				}
			}
			else
			{
				SeekerStatus = false;
				destroyAllWindows();
				break;
			}
		}

		resize(VideoFrame, VideoFrame, VideoDim);				// Resize it if needed

		// Set and add timestamp in VideoFrame
		timestamp = GetTimeStamp();
		putText(VideoFrame, timestamp, Point(10, 20), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1);

		if(CameraData.FrameFlag == true)
		{
			CameraData.FrameFlag = false;
			cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
		}

		CameraData.VideoFrame.release();
		CameraData.VideoFrame = VideoFrame;
		CameraData.FrameTime = GetCurrMillis();
		CameraData.FrameFlag = true;


		// Send Target Data sync with Camera
		if(TgtDataModeFlag == false && IPCardMode != 2U && IPCardMode != 3U)
		{
			SendTargetDataFlag = true;
		}

		// Stop Measuring execution time
		timCntEnd =  GetCurrMillis();

		// Calculate the reading & sleep time in milliseconds
		totalTime = (timCntEnd < timCntStart) ? ((86400000U + timCntEnd) - timCntStart) : (timCntEnd - timCntStart);
		sleepTime = FrameDelay - totalTime;

		// cout << endl << "Frame Reading Time - " << totalTime << " ms" << endl << flush;

		// Give Delay in Video Reading only for video files
		if(VideoSource.find("/dev/video") != 0 && sleepTime > 0)
		{
			ts1.tv_nsec = (sleepTime * 1000 * 1000) - 30;
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts1, nullptr);
		}
	}

	CAM.release();

	return;

#endif
}


// ---------- Video Stream ----------
void Seeker :: VideoStream(void)
{
	Mat VideoFrame;
	struct timespec ts, ts1;
	UInt16_t SaveFrameCnt = 0U;

	UInt32_t FrameCnt = 0U;
	UInt8_t PacketNo = 0U, PacketCnt = 0U;
	UInt32_t PacketStart = 0U, PacketEnd = 0U;
	UInt32_t FrameLength = 0U;
	const UInt32_t UDPSegSize = 60U * 1024U;

	vector<UInt8_t> DataPacket;
	vector<UInt8_t> FrameBuff;
	vector<Int32_t> FrameCompress = {IMWRITE_JPEG_QUALITY, 60};

	ts.tv_sec = 0;         				// seconds
	ts.tv_nsec = 1000 * 500;			// 500 microseconds

	ts1.tv_sec = 0;         			// seconds
	ts1.tv_nsec = 1000 * 1000 * 3;		// 3 milliseconds

	while(VideoStreamThreadFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(ProcessedData.FrameFlag == false)
		{
			continue;
		}

		VideoFrame.release();
		VideoFrame = ProcessedData.VideoFrame;
		ProcessedData.FrameFlag = false;

		// Convert VideoFrame to grayscale
		cvtColor(VideoFrame, VideoFrame, COLOR_BGR2GRAY);

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		// Video Stream
		PacketNo = 0U;
		PacketCnt = 0U;
		PacketEnd = 0U;
		PacketStart = 0U;
		FrameLength = 0U;


		imencode(".jpeg", VideoFrame, FrameBuff, FrameCompress);					// Encode to JPEG
		FrameLength = FrameBuff.size();												// Calculate FrameBuff length
		PacketCnt = (FrameLength + (UDPSegSize - 1)) / UDPSegSize;					// Calculate Packet Count

		for(PacketNo = 0; PacketNo < PacketCnt; PacketNo++)
		{
			// Split The VideoFrame data
			PacketStart = PacketNo * UDPSegSize;
			PacketEnd = min(PacketStart + UDPSegSize, FrameLength);

			// Insert the split VideoFrame data Into DataPacket
			DataPacket.insert(DataPacket.begin(), (UInt8_t *)(FrameBuff.data()+PacketStart), (UInt8_t *)(FrameBuff.data()+PacketEnd));

			// Add header in the DataPacket
			DataPacket.insert(DataPacket.begin(), (UInt8_t)(PacketNo));							// Add DataPacket number
			DataPacket.insert(DataPacket.begin(), (UInt8_t)(PacketCnt));						// Add DataPacket count

			// Add VideoFrame number
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 24U) & 0xFFU));			// Frame no 4th byte
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 16U) & 0xFFU));			// Frame no 3rd byte
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 8U) & 0xFFU));				// Frame no 2nd byte
			DataPacket.insert(DataPacket.begin(), (UInt8_t)((FrameCnt >> 0U) & 0xFFU));				// Frame no 1st byte

			// Add Header
			DataPacket.insert(DataPacket.begin(), (UInt8_t)MissileID);							// Add missile id
			DataPacket.insert(DataPacket.begin(), DataLink_ID);									// Add Destination ID
			DataPacket.insert(DataPacket.begin(), IPCard_ID);									// Add Source ID

			cout << "Frame Sent ID-" << (UInt32_t)MissileID << " F-" << FrameCnt << " PC-" << (UInt32_t)PacketCnt << " PN-" <<
			(UInt32_t)(PacketNo + 1U) << " FL-" << FrameLength << " PL-" << PacketEnd-PacketStart << " " << endl << flush;

			try
			{
				sendto(UDPSock, (UInt8_t *)DataPacket.data(), (PacketEnd - PacketStart + 9U), 0, (sockaddr *)&caddr, len);
			}
			catch(Exception &e)
			{
				cout << "Error in sending DataPacket..." << endl << flush;
			}

			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts1, nullptr);

			// Clear all previous DataPacket data
			DataPacket.clear();
			DataPacket.shrink_to_fit();
		}
		cout << endl;
		FrameCnt++;

		FrameBuff.clear();
		FrameBuff.shrink_to_fit();


		if(DisplayFrameFlag == true)
		{
			imshow("IP Card - " + to_string((UInt32_t)MissileID), VideoFrame);
			if(waitKey(1) == 'q')
			{
				ProcessThreadFlag = false;
				VideoStreamThreadFlag = false;
				break;
			}
		}

		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);

		if(SaveDataFlag == true)
		{
			OutVid.write(VideoFrame);
			SaveFrameCnt++;

			if(SaveFrameCnt >= 7500U)
			{
				OutVid.release();
				SaveFrameCnt = 0U;
				VideoInd++;

				OutVid.open(SavePath + "IPVideo" + to_string(VideoInd) + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, false);
				if(!OutVid.isOpened())
				{
					cerr << "Error in opening new video file" << endl;
					SaveDataFlag = false;
				}
			}
		}
	}

	close(UDPSock);
	OutVid.release();

	return;
}


// ---------- Read Frames Thread ----------
void * Seeker :: ReadFramesThread(void *args)
{
	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(3, &cpuset); // Bind to CPU 3
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 98;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->ReadFrames();

	pthread_exit(NULL);
	return nullptr;
}


// ---------- Video Stream Thread ----------
void * Seeker :: VideoStreamThread(void *args)
{
	if(CpuAffinityFlag == true)
	{
		// Set CPU Affinity
		cpu_set_t cpuset;
		CPU_ZERO(&cpuset);
		CPU_SET(4, &cpuset); // Bind to CPU 4
		pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

		// Set Self Thread Priority
		struct sched_param param;
		param.sched_priority = 95;
		pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
	}

	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->VideoStream();

	pthread_exit(NULL);
	return nullptr;
}




