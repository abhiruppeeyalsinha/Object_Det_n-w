#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <cmath>

using namespace cv;
using namespace std;

double varianceOfLaplacian(const Mat &gray)
{
    CV_Assert(gray.type() == CV_8UC1);

    // 3x3 Laplacian kernel
    int kernel[3][3] = {{0, 1, 0}, {1, -4, 1}, {0, 1, 0}};

    vector<double> lapValues;

    // Ignore image borders
    for (int y = 1; y < gray.rows - 1; y++)
    {
        for (int x = 1; x < gray.cols - 1; x++)
        {
            double lap = 0.0;

            // Manual convolution
            for (int ky = -1; ky <= 1; ky++)
            {
                for (int kx = -1; kx <= 1; kx++)
                {
                    lap += kernel[ky + 1][kx + 1] * gray.at<uchar>(y + ky, x + kx);
                }
            }

            lapValues.push_back(lap);
        }
    }

    // Compute mean
    double mean = 0.0;
    for (double v : lapValues)
        mean += v;

    mean /= lapValues.size();

    // Compute variance
    double variance = 0.0;
    for (double v : lapValues)
        variance += (v - mean) * (v - mean);

    variance /= lapValues.size();

    return variance;
}

int main()
{
    Mat image, gray;
    image = imread("/home/abhirup/Pictures/image-motion-blur.jpg");
    if (image.empty())
    {
        cout << "Could not open image." << endl;
        return -1;
    }

    gray;
    cvtColor(image, gray, COLOR_BGR2GRAY);

    double blurScore = varianceOfLaplacian(gray);

    cout << "Blur Score = " << blurScore << endl;

    if (blurScore < 100)
        cout << "Image is blurry." << endl;
    else
        cout << "Image is sharp." << endl;

    return 0;
}

// What's happening mathematically?

// For every pixel (except the border), the Laplacian is computed as L(x,y)=I(x−1,y)+I(x+1,y)+I(x,y−1)+I(x,y+1)−4I(x,y)
// This is exactly what the nested loops calculate.

// For example, if the neighborhood is 40   50   60 45  100   55 35   50   45 then

// L = 50 + 50 + 45 + 55 - 4×100
//   = 200 - 400
//   = -200

// You repeat this for every pixel.

// Next, compute the mean:

// μ=
// N
// 1
// 	​

// i=1
// ∑
// N
// 	​

// L
// i
// 	​

// Finally, compute the variance:

// σ
// 2
// =
// N
// 1
// 	​

// i=1
// ∑
// N
// 	​

// (L
// i
// 	​

// −μ)
// 2

// The resulting variance is your blur score:

// Large variance → many strong edge responses → sharp image.
// Small variance → weak edge responses → blurry image.

// How it works
// Convert the image to grayscale.
// Apply the Laplacian operator to compute the second derivative of the image.
// Calculate the variance (or standard deviation) of the Laplacian response.
// Use the variance as a sharpness score.
// High variance → Many strong edges → Sharp image
// Low variance → Few or weak edges → Blurry image
// Formula

// If L is the Laplacian image, the blur score is:

// Blur Score=Var(L)

// where

// Var(L)=N1
// 	​

// i=1
// ∑
// N
// 	​

// (L
// i
// 	​

// −μ)
// 2
// L
// i
// 	​

// : Laplacian value at pixel i
// μ: Mean Laplacian value
// N: Number of pixels
