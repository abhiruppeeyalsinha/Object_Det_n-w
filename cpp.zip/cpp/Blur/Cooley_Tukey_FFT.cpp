#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <opencv2/opencv.hpp>

using namespace std;

const double PI = 3.14159265358979323846;

// ============================================================
// Custom Complex Number
// ============================================================

struct MyComplex
{
    double real;
    double imag;

    MyComplex(double r = 0.0, double i = 0.0)
        : real(r), imag(i)
    {
    }

    MyComplex operator+(const MyComplex& c) const
    {
        return MyComplex(
            real + c.real,
            imag + c.imag);
    }

    MyComplex operator-(const MyComplex& c) const
    {
        return MyComplex(
            real - c.real,
            imag - c.imag);
    }

    MyComplex operator*(const MyComplex& c) const
    {
        return MyComplex(
            real * c.real - imag * c.imag,
            real * c.imag + imag * c.real);
    }
};


// ============================================================
// Check power of 2
// ============================================================

bool IsPowerOfTwo(int n)
{
    return n > 0 && (n & (n - 1)) == 0;
}


// ============================================================
// Get next power of 2
// ============================================================

int NextPowerOfTwo(int n)
{
    int power = 1;

    while (power < n)
    {
        power *= 2;
    }

    return power;
}


// ============================================================
// 1D Recursive Cooley-Tukey FFT
// ============================================================

void FFT(vector<MyComplex>& a)
{
    int n = static_cast<int>(a.size());

    if (n <= 1)
        return;

    if (!IsPowerOfTwo(n))
    {
        cerr << "FFT Error: Input size must be power of 2. Size = "
            << n << endl;
        return;
    }

    vector<MyComplex> even(n / 2);
    vector<MyComplex> odd(n / 2);

    for (int i = 0; i < n / 2; i++)
    {
        even[i] = a[2 * i];
        odd[i] = a[2 * i + 1];
    }

    FFT(even);
    FFT(odd);

    for (int k = 0; k < n / 2; k++)
    {
        double angle =
            -2.0 * PI * static_cast<double>(k) /
            static_cast<double>(n);

        MyComplex w(
            cos(angle),
            sin(angle));

        MyComplex t = w * odd[k];

        a[k] = even[k] + t;
        a[k + n / 2] = even[k] - t;
    }
}


// ============================================================
// 2D FFT
// ============================================================

vector<vector<MyComplex>> FFT2D(const cv::Mat& gray)
{
    int rows = gray.rows;
    int cols = gray.cols;

    vector<vector<MyComplex>> image(
        rows,
        vector<MyComplex>(cols));

    // Copy grayscale image into complex array
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            image[i][j].real =
                static_cast<double>(gray.at<uchar>(i, j));

            image[i][j].imag = 0.0;
        }
    }

    // --------------------------------------------------------
    // FFT along rows
    // --------------------------------------------------------

    for (int i = 0; i < rows; i++)
    {
        FFT(image[i]);
    }

    // --------------------------------------------------------
    // FFT along columns
    // --------------------------------------------------------

    for (int j = 0; j < cols; j++)
    {
        vector<MyComplex> column(rows);

        for (int i = 0; i < rows; i++)
        {
            column[i] = image[i][j];
        }

        FFT(column);

        for (int i = 0; i < rows; i++)
        {
            image[i][j] = column[i];
        }
    }

    return image;
}


// ============================================================
// Magnitude
// ============================================================

double Magnitude(const MyComplex& c)
{
    return sqrt(
        c.real * c.real +
        c.imag * c.imag);
}


// ============================================================
// FFT Shift
// Move low frequencies to center
// ============================================================

void FFTShift(vector<vector<double>>& mag)
{
    int rows = static_cast<int>(mag.size());
    int cols = static_cast<int>(mag[0].size());

    int halfRows = rows / 2;
    int halfCols = cols / 2;

    for (int i = 0; i < halfRows; i++)
    {
        for (int j = 0; j < halfCols; j++)
        {
            // Top-left <-> Bottom-right
            swap(
                mag[i][j],
                mag[i + halfRows][j + halfCols]);

            // Bottom-left <-> Top-right
            swap(
                mag[i + halfRows][j],
                mag[i][j + halfCols]);
        }
    }
}


// ============================================================
// Calculate Blur Score
// ============================================================

double BlurScore(
    const vector<vector<MyComplex>>& fft)
{
    int rows = static_cast<int>(fft.size());
    int cols = static_cast<int>(fft[0].size());

    vector<vector<double>> mag(
        rows,
        vector<double>(cols));

    // Calculate FFT magnitude
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            mag[i][j] = Magnitude(fft[i][j]);
        }
    }

    // Move DC/low frequency components to center
    FFTShift(mag);

    double totalEnergy = 0.0;
    double highEnergy = 0.0;

    int cx = rows / 2;
    int cy = cols / 2;

    // Low-frequency radius
    double radius =
        static_cast<double>(min(rows, cols)) / 6.0;

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            // Spectral energy
            double e =
                mag[i][j] * mag[i][j];

            totalEnergy += e;

            double dx =
                static_cast<double>(i - cx);

            double dy =
                static_cast<double>(j - cy);

            double dist =
                sqrt(dx * dx + dy * dy);

            // Outside central low-frequency region
            if (dist > radius)
            {
                highEnergy += e;
            }
        }
    }

    if (totalEnergy <= 0.0)
    {
        return 0.0;
    }

    return highEnergy / totalEnergy;
}


// ============================================================
// Main
// ============================================================

int main()
{
    string imagePath = "/home/abhirup/Pictures/image-motion-blur.jpg";

    cv::Mat img =
        cv::imread(
            imagePath,
            cv::IMREAD_GRAYSCALE);

    if (img.empty())
    {
        cerr << "Error: Could not load image: "
            << imagePath << endl;

        return -1;
    }

    cout << "Original Image Size : "
        << img.cols << " x "
        << img.rows << endl;


    // ========================================================
    // Pad image to power-of-two dimensions
    // ========================================================

    int newRows = NextPowerOfTwo(img.rows);
    int newCols = NextPowerOfTwo(img.cols);

    cv::Mat padded;

    cv::copyMakeBorder(
        img,
        padded,
        0,
        newRows - img.rows,
        0,
        newCols - img.cols,
        cv::BORDER_CONSTANT,
        cv::Scalar(0));


    cout << "FFT Image Size      : "
        << padded.cols << " x "
        << padded.rows << endl;


    // ========================================================
    // Perform 2D FFT
    // ========================================================

    auto fft = FFT2D(padded);


    // ========================================================
    // Calculate Blur Score
    // ========================================================

    double score = BlurScore(fft);

    cout << "Blur Score = "
        << score << endl;


    // ========================================================
    // Classification
    // ========================================================

    const double BLUR_THRESHOLD = 0.15;

    if (score < BLUR_THRESHOLD)
    {
        cout << "Result: Blurry" << endl;
    }
    else
    {
        cout << "Result: Sharp" << endl;
    }

    return 0;
}