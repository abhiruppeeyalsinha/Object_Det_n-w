#include <opencv2/opencv.hpp>
#include <cmath>

using namespace cv;
using namespace std;

double HaarBlurScore(const Mat &gray)
{
    double energy = 0.0;
    int count = 0;
    cerr << gray.cols << "," << gray.rows << endl;
    for (int i = 0; i < gray.rows - 1; i += 2)
    {
        for (int j = 0; j < gray.cols - 1; j += 2)
        {
            double a = gray.at<uchar>(i, j);
            double b = gray.at<uchar>(i, j + 1);
            double c = gray.at<uchar>(i + 1, j);
            double d = gray.at<uchar>(i + 1, j + 1);
            double LL = (a + b + c + d) / 4.0;
            double LH = (a + b - c - d) / 4.0;
            double HL = (a + c - b - d) / 4.0;
            double HH = (a - b - c + d) / 4.0;

            energy += LH * LH + HL * HL + HH * HH;
            count++;
        }
    }

    return energy / count;
}

int main()
{
    Mat test_img, gray_img;
    test_img = imread("/home/abhirup/Pictures/image-motion-blur.jpg");
    cvtColor(test_img, gray_img, COLOR_BGR2GRAY);
    double res_blur_scr = HaarBlurScore(gray_img);

    cerr << "Blur Score = " << res_blur_scr << endl;

    if (res_blur_scr < 100)
        cerr << "Image is blurry." << endl;
    else
        cerr << "Image is sharp." << endl;

    return 0;
}