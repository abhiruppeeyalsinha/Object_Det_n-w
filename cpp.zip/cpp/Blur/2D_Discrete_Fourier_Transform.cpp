// #include <opencv2/opencv.hpp>
// #include <vector>
// #include <complex>
// #include <cmath>
// #include <iostream>

// using namespace std;
// using namespace cv;

// const double PI = 3.14159265358979323846;

// vector<vector<complex<double>>> DFT2D(const Mat &gray)
// {
//     int M = gray.rows;
//     int N = gray.cols;

//     vector<vector<complex<double>>> F(M, vector<complex<double>>(N));

//     for (int u = 0; u < M; u++)
//     {
//         for (int v = 0; v < N; v++)
//         {
//             complex<double> sum(0, 0);
//             for (int x = 0; x < M; x++)
//             {
//                 for (int y = 0; y < N; y++)
//                 {
//                     double theta = -2.0 * PI * ((double)u * x / M + (double)v * y / N);
//                     double pixel = gray.at<uchar>(x, y);
//                     sum += pixel * complex<double>(cos(theta), sin(theta));
//                 }
//             }

//             F[u][v] = sum;
//         }
//     }

//     return F;
// }

// double magnitude(complex<double> c)
// {
//     return sqrt(c.real() * c.real() + c.imag() * c.imag());
// }

// double FFTBlurScore(const vector<vector<complex<double>>> &F)
// {
//     int M = F.size();
//     int N = F[0].size();
//     double highEnergy = 0;
//     double totalEnergy = 0;
//     int cx = M / 2;
//     int cy = N / 2;

//     double radius = min(M, N) / 6.0;

//     for (int i = 0; i < M; i++)
//     {
//         for (int j = 0; j < N; j++)
//         {
//             double mag = magnitude(F[i][j]);
//             double e = mag * mag;

//             totalEnergy += e;

//             double dx = i - cx;
//             double dy = j - cy;
//             double d = sqrt(dx * dx + dy * dy);

//             if (d > radius)
//                 highEnergy += e;
//         }
//     }

//     return highEnergy / totalEnergy;
// }

// int main()
// {
//     Mat test_img, gray_img;
//     test_img = imread("/home/abhirup/Pictures/image-motion-blur.jpg");
//     cvtColor(test_img, gray_img, COLOR_BGR2GRAY);

//     vector<vector<complex<double>>> F = DFT2D(gray_img);
//     double blurScore = FFTBlurScore(F);

//     cout << "Blur Score = " << blurScore << endl;

//     if (blurScore < 100)
//         cout << "Image is blurry." << endl;
//     else
//         cout << "Image is sharp." << endl;

//     return 0;
// }



// ===================@2==============================

// ============================================================================
// FFT-Based Image Blur Detection
//
// Method:
//   1. Read image
//   2. Convert to grayscale
//   3. Convert image to float
//   4. Apply Hanning window
//   5. Compute 2D FFT using OpenCV DFT
//   6. Shift zero frequency to image center
//   7. Calculate power spectrum
//   8. Calculate high-frequency energy ratio
//   9. Classify image as BLURRY or SHARP
//
// Build:
// g++ fft_blur.cpp -o fft_blur `pkg-config --cflags --libs opencv4`
//
// Run:
// ./fft_blur
// ============================================================================

#include <opencv2/opencv.hpp>

#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>

using namespace std;
using namespace cv;


// ============================================================================
// Configuration
// ============================================================================

// Radius divisor used to separate low and high frequencies.
//
// Larger divisor -> smaller central low-frequency region.
// Smaller divisor -> larger central low-frequency region.
//
// 6.0 is a reasonable starting point.
// Tune this using your own dataset.
static constexpr double LOW_FREQ_RADIUS_DIVISOR = 6.0;


// Blur threshold.
//
// IMPORTANT:
// This value is NOT universal.
// It must be calibrated using your camera/images.
//
// Lower FFT score = less high-frequency information = more blur.
// Higher FFT score = more high-frequency information = sharper image.
//
static constexpr double BLUR_THRESHOLD = 0.01;


// Enable/disable Hanning window.
//
// Hanning window reduces FFT artifacts caused by discontinuity
// at image boundaries.
static constexpr bool USE_HANNING_WINDOW = true;


// ============================================================================
// FFT Shift
// ============================================================================
//
// OpenCV DFT output initially stores the zero-frequency/DC component
// at the top-left corner.
//
// For easier radial frequency analysis, we move the DC component to
// the center:
//
// Before:
//
//      DC ----------------> High Frequency
//
// After:
//
//      High       High
//
//           DC
//
//      High       High
//
// ============================================================================

void FFTShift(Mat& image)
{
    // Ensure even width and height.
    //
    // The quadrant swapping operation requires equal-sized quadrants.
    image = image(
        Rect(
            0,
            0,
            image.cols & -2,
            image.rows & -2
        )
    );

    int cx = image.cols / 2;
    int cy = image.rows / 2;


    // Define four quadrants
    Mat q0(image, Rect(0, 0, cx, cy));   // Top-left
    Mat q1(image, Rect(cx, 0, cx, cy));   // Top-right
    Mat q2(image, Rect(0, cy, cx, cy));   // Bottom-left
    Mat q3(image, Rect(cx, cy, cx, cy));   // Bottom-right


    Mat temp;


    // Swap q0 <-> q3
    q0.copyTo(temp);
    q3.copyTo(q0);
    temp.copyTo(q3);


    // Swap q1 <-> q2
    q1.copyTo(temp);
    q2.copyTo(q1);
    temp.copyTo(q2);
}


// ============================================================================
// Generate FFT Magnitude Spectrum
// ============================================================================

Mat CalculateFFTMagnitude(const Mat& gray)
{
    // ------------------------------------------------------------------------
    // Convert image to floating point
    // ------------------------------------------------------------------------

    Mat floatImage;

    gray.convertTo(
        floatImage,
        CV_32F
    );


    // ------------------------------------------------------------------------
    // Optional Hanning Window
    // ------------------------------------------------------------------------
    //
    // FFT assumes the image repeats periodically.
    //
    // Image edges may therefore introduce artificial high-frequency
    // components.
    //
    // Hanning window reduces this effect.
    // ------------------------------------------------------------------------

    if (USE_HANNING_WINDOW)
    {
        Mat hanningWindow;

        createHanningWindow(
            hanningWindow,
            floatImage.size(),
            CV_32F
        );

        floatImage = floatImage.mul(hanningWindow);
    }


    // ------------------------------------------------------------------------
    // Create complex image
    // ------------------------------------------------------------------------
    //
    // DFT input:
    //
    // Real      = image
    // Imaginary = 0
    //
    // ------------------------------------------------------------------------

    Mat planes[] =
    {
        floatImage,
        Mat::zeros(
            floatImage.size(),
            CV_32F
        )
    };


    Mat complexImage;

    merge(
        planes,
        2,
        complexImage
    );


    // ------------------------------------------------------------------------
    // Perform 2D FFT
    // ------------------------------------------------------------------------

    dft(complexImage,complexImage);


    // ------------------------------------------------------------------------
    // Separate Real and Imaginary components
    // ------------------------------------------------------------------------

    split(complexImage,planes);


    // ------------------------------------------------------------------------
    // Calculate magnitude
    //
    // magnitude = sqrt(real^2 + imaginary^2)
    // ------------------------------------------------------------------------

    Mat magnitudeImage;

    cv::magnitude(
        planes[0],
        planes[1],
        magnitudeImage
    );


    // ------------------------------------------------------------------------
    // Move zero-frequency component to center
    // ------------------------------------------------------------------------

    FFTShift(magnitudeImage);


    return magnitudeImage;
}


// ============================================================================
// Calculate FFT Blur Score
// ============================================================================
//
// Blur removes high-frequency information.
//
// Therefore:
//
//       Sharp image
//          ↓
//       More high-frequency energy
//          ↓
//       Higher score
//
//
//       Blurred image
//          ↓
//       Less high-frequency energy
//          ↓
//       Lower score
//
//
// Score:
//
//                 High Frequency Energy
//      Score = -----------------------------
//                    Total Energy
//
// ============================================================================

double FFTBlurScore(const Mat& gray)
{
    if (gray.empty())
    {
        cerr << "ERROR: Empty grayscale image." << endl;

        return 0.0;
    }


    // ------------------------------------------------------------------------
    // Calculate FFT magnitude
    // ------------------------------------------------------------------------

    Mat magnitudeImage =
        CalculateFFTMagnitude(gray);


    if (magnitudeImage.empty())
    {
        cerr << "ERROR: FFT magnitude calculation failed." << endl;

        return 0.0;
    }


    int rows = magnitudeImage.rows;
    int cols = magnitudeImage.cols;


    // ------------------------------------------------------------------------
    // FFT center
    // ------------------------------------------------------------------------

    int centerX = cols / 2;
    int centerY = rows / 2;


    // ------------------------------------------------------------------------
    // Define low-frequency radius
    // ------------------------------------------------------------------------

    double radius =
        static_cast<double>(
            min(rows, cols)
            ) / LOW_FREQ_RADIUS_DIVISOR;


    // Squared radius avoids unnecessary sqrt() inside the loop.
    double radiusSquared =
        radius * radius;


    double totalEnergy = 0.0;
    double highFrequencyEnergy = 0.0;


    // ------------------------------------------------------------------------
    // Calculate frequency energy
    // ------------------------------------------------------------------------

    for (int y = 0; y < rows; ++y)
    {
        const float* ptr =
            magnitudeImage.ptr<float>(y);


        double dy =
            static_cast<double>(
                y - centerY
                );


        for (int x = 0; x < cols; ++x)
        {
            double magnitudeValue =
                static_cast<double>(
                    ptr[x]
                    );


            // Power spectrum
            //
            // Energy = magnitude^2

            double energy =
                magnitudeValue *
                magnitudeValue;


            totalEnergy += energy;


            // Distance from FFT center

            double dx =
                static_cast<double>(
                    x - centerX
                    );


            double distanceSquared =
                dx * dx +
                dy * dy;


            // Outside central circle = high frequency

            if (distanceSquared > radiusSquared)
            {
                highFrequencyEnergy += energy;
            }
        }
    }


    // ------------------------------------------------------------------------
    // Protect against division by zero
    // ------------------------------------------------------------------------

    if (totalEnergy <= 1e-12)
    {
        return 0.0;
    }


    // ------------------------------------------------------------------------
    // High-frequency energy ratio
    // ------------------------------------------------------------------------

    double score =
        highFrequencyEnergy /
        totalEnergy;


    return score;
}


// ============================================================================
// Create FFT Visualization
// ============================================================================

Mat CreateFFTVisualization(const Mat& gray)
{
    Mat magnitudeImage =
        CalculateFFTMagnitude(gray);


    // ------------------------------------------------------------------------
    // Logarithmic scale
    //
    // FFT values have a very large dynamic range.
    //
    // log(1 + magnitude)
    // ------------------------------------------------------------------------

    magnitudeImage += Scalar::all(1);

    log(
        magnitudeImage,
        magnitudeImage
    );


    // ------------------------------------------------------------------------
    // Normalize for display
    // ------------------------------------------------------------------------

    normalize(
        magnitudeImage,
        magnitudeImage,
        0,
        255,
        NORM_MINMAX
    );


    Mat displayImage;

    magnitudeImage.convertTo(
        displayImage,
        CV_8U
    );


    return displayImage;
}


// ============================================================================
// Main
// ============================================================================

int main()
{
    // ------------------------------------------------------------------------
    // Image path
    // ------------------------------------------------------------------------

    string imagePath =
        "/home/abhirup/Pictures/image-motion-blur.jpg";


    cout << "==============================================" << endl;
    cout << "       FFT IMAGE BLUR DETECTION" << endl;
    cout << "==============================================" << endl;

    cout << endl;

    cout << "Loading image:" << endl;
    cout << imagePath << endl;

    cout << endl;


    // ------------------------------------------------------------------------
    // Load image
    // ------------------------------------------------------------------------

    Mat inputImage =
        imread(
            imagePath,
            IMREAD_COLOR
        );


    if (inputImage.empty())
    {
        cerr << "ERROR: Unable to load image." << endl;

        cerr << "Check image path:" << endl;
        cerr << imagePath << endl;

        return -1;
    }


    cout << "Image loaded successfully." << endl;

    cout << "Resolution : "
        << inputImage.cols
        << " x "
        << inputImage.rows
        << endl;


    // ------------------------------------------------------------------------
    // Convert to grayscale
    // ------------------------------------------------------------------------

    Mat grayImage;

    cvtColor(
        inputImage,
        grayImage,
        COLOR_BGR2GRAY
    );


    // ------------------------------------------------------------------------
    // Calculate blur score
    // ------------------------------------------------------------------------

    double blurScore =
        FFTBlurScore(
            grayImage
        );


    // ------------------------------------------------------------------------
    // Classification
    // ------------------------------------------------------------------------

    bool isBlurry =
        blurScore < BLUR_THRESHOLD;


    // ------------------------------------------------------------------------
    // Print result
    // ------------------------------------------------------------------------

    cout << endl;

    cout << "----------------------------------------------" << endl;

    cout << fixed
        << setprecision(8);

    cout << "FFT Blur Score : "
        << blurScore
        << endl;

    cout << "Threshold      : "
        << BLUR_THRESHOLD
        << endl;


    cout << "Result         : ";

    if (isBlurry)
    {
        cout << "BLURRY";
    }
    else
    {
        cout << "SHARP";
    }

    cout << endl;

    cout << "----------------------------------------------" << endl;


    // ------------------------------------------------------------------------
    // Prepare output display
    // ------------------------------------------------------------------------

    Mat resultImage =
        inputImage.clone();


    string scoreText =
        "FFT Score: " +
        to_string(blurScore);


    string resultText;

    Scalar resultColor;


    if (isBlurry)
    {
        resultText = "BLURRY";

        // Red
        resultColor =
            Scalar(0, 0, 255);
    }
    else
    {
        resultText = "SHARP";

        // Green
        resultColor =
            Scalar(0, 255, 0);
    }


    // ------------------------------------------------------------------------
    // Draw information
    // ------------------------------------------------------------------------

    putText(resultImage, resultText, Point(20, 40), FONT_HERSHEY_SIMPLEX, 1.0, resultColor, 2, LINE_AA);

    putText(resultImage, scoreText, Point(20, 80), FONT_HERSHEY_SIMPLEX, 0.7, resultColor, 2, LINE_AA);
    // ------------------------------------------------------------------------
    // Create FFT spectrum visualization
    // ------------------------------------------------------------------------

    Mat fftDisplay = CreateFFTVisualization(grayImage);


    // ------------------------------------------------------------------------
    // Display
    // ------------------------------------------------------------------------

    imshow("Original Image", inputImage);
    imshow("Blur Detection Result", resultImage);
    imshow("FFT Magnitude Spectrum", fftDisplay);


    cout << endl;
    cout << "Press any key to exit..." << endl;

    waitKey(0);
    destroyAllWindows();


    return 0;
}