// #include <opencv2/opencv.hpp>
// #include <iostream>
// #include <cmath>
// #include <iomanip>

// using namespace cv;
// using namespace std;


// // ============================================================================
// // Configuration
// // ============================================================================

// // Radius used to separate low and high frequency components
// const double LOW_FREQ_RADIUS_DIVISOR = 6.0;

// // Temporary threshold.
// // Must be calibrated using actual video data.
// const double BLUR_THRESHOLD = 0.01;


// // ============================================================================
// // FFT Shift
// // ============================================================================
// //
// // OpenCV DFT keeps the DC / zero-frequency component at the corner.
// // This function moves it to the center of the frequency spectrum.
// //
// // ============================================================================

// void FFTShift(Mat &image)
// {
//     // Make dimensions even
//     image = image(Rect(0,0,image.cols & -2,image.rows & -2));

//     int cx = image.cols / 2;
//     int cy = image.rows / 2;


//     // Four quadrants
//     Mat q0(image, Rect(0, 0, cx, cy));
//     Mat q1(image, Rect(cx, 0, cx, cy));
//     Mat q2(image, Rect(0, cy, cx, cy));
//     Mat q3(image, Rect(cx, cy, cx, cy));


//     Mat temp;


//     // Swap q0 and q3
//     q0.copyTo(temp);
//     q3.copyTo(q0);
//     temp.copyTo(q3);


//     // Swap q1 and q2
//     q1.copyTo(temp);
//     q2.copyTo(q1);
//     temp.copyTo(q2);
// }


// // ============================================================================
// // Calculate FFT Blur Score
// // ============================================================================

// double FFTBlurScore(const Mat &gray)
// {
//     // ------------------------------------------------------------------------
//     // Check input
//     // ------------------------------------------------------------------------

//     if (gray.empty())
//     {
//         return 0.0;
//     }


//     // ------------------------------------------------------------------------
//     // Convert grayscale image to floating point
//     // ------------------------------------------------------------------------

//     Mat floatImage;

//     gray.convertTo(
//         floatImage,
//         CV_32F
//     );


//     // ------------------------------------------------------------------------
//     // Apply Hanning Window
//     //
//     // This reduces artificial high-frequency components generated at
//     // image boundaries.
//     // ------------------------------------------------------------------------

//     Mat hanningWindow;

//     createHanningWindow(
//         hanningWindow,
//         floatImage.size(),
//         CV_32F
//     );


//     floatImage =
//         floatImage.mul(hanningWindow);


//     // ------------------------------------------------------------------------
//     // Prepare complex image
//     //
//     // Real part      = image
//     // Imaginary part = 0
//     // ------------------------------------------------------------------------

//     Mat planes[] ={ floatImage, Mat::zeros(floatImage.size(),CV_32F)};


//     Mat complexImage;
//     merge(planes,2,complexImage);


//     // ------------------------------------------------------------------------
//     // Calculate 2D FFT
//     // ------------------------------------------------------------------------

//     dft(complexImage,complexImage);


//     // ------------------------------------------------------------------------
//     // Separate real and imaginary components
//     // ------------------------------------------------------------------------

//     split(complexImage,planes);


//     // ------------------------------------------------------------------------
//     // Calculate FFT magnitude
//     //
//     // magnitude = sqrt(real^2 + imaginary^2)
//     // ------------------------------------------------------------------------

//     Mat magnitudeImage;

//     magnitude(
//         planes[0],
//         planes[1],
//         magnitudeImage
//     );


//     // ------------------------------------------------------------------------
//     // Shift low frequencies to center
//     // ------------------------------------------------------------------------

//     FFTShift( magnitudeImage);


//     // ------------------------------------------------------------------------
//     // Image dimensions
//     // ------------------------------------------------------------------------

//     int rows = magnitudeImage.rows;
//     int cols = magnitudeImage.cols;


//     // FFT center
//     int centerX = cols / 2;
//     int centerY = rows / 2;


//     // ------------------------------------------------------------------------
//     // Define low-frequency radius
//     // ------------------------------------------------------------------------

//     double radius =static_cast<double>(min(rows, cols) ) / LOW_FREQ_RADIUS_DIVISOR;


//     double radiusSquared =radius * radius;


//     // ------------------------------------------------------------------------
//     // Energy variables
//     // ------------------------------------------------------------------------

//     double totalEnergy = 0.0;

//     double highFrequencyEnergy = 0.0;


//     // ------------------------------------------------------------------------
//     // Calculate frequency energy
//     // ------------------------------------------------------------------------

//     for (int y = 0; y < rows; ++y)
//     {
//         const float *ptr =  magnitudeImage.ptr<float>(y);
//         double dy =static_cast<double>( y - centerY);


//         for (int x = 0; x < cols; ++x)
//         {
//             double mag =static_cast<double>(ptr[x]);


//             // Energy = magnitude²
//             double energy =mag * mag;


//             totalEnergy += energy;


//             // Distance from FFT center
//             double dx =static_cast<double>(x - centerX);
//             double distanceSquared =dx * dx +dy * dy;


//             // Outside center region = high frequency
//             if (distanceSquared > radiusSquared)
//             {
//                 highFrequencyEnergy += energy;
//             }
//         }
//     }


//     // ------------------------------------------------------------------------
//     // Prevent division by zero
//     // ------------------------------------------------------------------------

//     if (totalEnergy <= 1e-12)
//     {
//         return 0.0;
//     }


//     // ------------------------------------------------------------------------
//     // Blur Score
//     //
//     //              High Frequency Energy
//     // Score = -------------------------------
//     //                  Total Energy
//     //
//     // Lower score  -> More Blur
//     // Higher score -> More Sharpness
//     // ------------------------------------------------------------------------

//     return highFrequencyEnergy / totalEnergy;
// }


// // ============================================================================
// // Main
// // ============================================================================

// int main()
// {
//     // ------------------------------------------------------------------------
//     // Open Video
//     // ------------------------------------------------------------------------

//     VideoCapture cap("/home/abhirup/Videos/test_vid.mp4");


//     if (!cap.isOpened())
//     {
//         cerr<< "ERROR: Unable to open the video file!"<< endl;

//         return -1;
//     }


//     // ------------------------------------------------------------------------
//     // Get Video Information
//     // ------------------------------------------------------------------------

//     double fps = cap.get(CAP_PROP_FPS);


//     int totalFrames =static_cast<int>(cap.get(CAP_PROP_FRAME_COUNT));


//     cout << "==============================================" << endl;
//     cout << "       FFT VIDEO BLUR DETECTION" << endl;
//     cout << "==============================================" << endl;

//     cout << "FPS          : "
//          << fps
//          << endl;

//     cout << "Total Frames : "
//          << totalFrames
//          << endl;

//     cout << "Threshold    : "
//          << BLUR_THRESHOLD
//          << endl;

//     cout << "==============================================" << endl;


//     // ------------------------------------------------------------------------
//     // Variables
//     // ------------------------------------------------------------------------

//     Mat frame;
//     Mat grayFrame;

//     int frameCount = 0;


//     // ------------------------------------------------------------------------
//     // Process Video
//     // ------------------------------------------------------------------------

//     while (true)
//     {
//         // Read frame
//         cap >> frame;


//         // End of video
//         if (frame.empty())
//         {
//             break;
//         }


//         frameCount++;


//         // --------------------------------------------------------------------
//         // Convert BGR frame to grayscale
//         // --------------------------------------------------------------------

//         cvtColor( frame,grayFrame,COLOR_BGR2GRAY);


//         // --------------------------------------------------------------------
//         // Calculate FFT blur score
//         // --------------------------------------------------------------------

//         double blurScore =FFTBlurScore(grayFrame);


//         // --------------------------------------------------------------------
//         // Blur / Sharp Decision
//         // --------------------------------------------------------------------

//         bool isBlurry =blurScore < BLUR_THRESHOLD;


//         string status;
//         Scalar color;


//         if (isBlurry)
//         {
//             status = "BLURRY";

//             // Red
//             color = Scalar(0, 0, 255);
//         }
//         else
//         {
//             status = "SHARP";

//             // Green
//             color = Scalar(0, 255, 0);
//         }


//         // --------------------------------------------------------------------
//         // Print frame information
//         // --------------------------------------------------------------------

//         cout << fixed
//              << setprecision(8);

//         cout << "Frame "
//              << frameCount
//              << " | Score: "
//              << blurScore
//              << " | "
//              << status
//              << endl;


//         // --------------------------------------------------------------------
//         // Draw result
//         // --------------------------------------------------------------------

//         string scoreText =
//             "FFT Score: " +
//             to_string(blurScore);


//         putText(
//             frame,
//             status,
//             Point(20, 40),
//             FONT_HERSHEY_SIMPLEX,
//             1.0,
//             color,
//             2,
//             LINE_AA
//         );


//         putText(
//             frame,
//             scoreText,
//             Point(20, 75),
//             FONT_HERSHEY_SIMPLEX,
//             0.65,
//             color,
//             2,
//             LINE_AA
//         );


//         // --------------------------------------------------------------------
//         // Display
//         // --------------------------------------------------------------------

//         imshow(
//             "FFT Blur Detection",
//             frame
//         );


//         // --------------------------------------------------------------------
//         // Keyboard
//         //
//         // ESC / Q -> Exit
//         // --------------------------------------------------------------------

//         int key = waitKey(1);


//         if (key == 27 ||
//             key == 'q' ||
//             key == 'Q')
//         {
//             break;
//         }
//     }


//     // ------------------------------------------------------------------------
//     // Cleanup
//     // ------------------------------------------------------------------------

//     cap.release();

//     destroyAllWindows();


//     cout << endl;

//     cout << "==============================================" << endl;

//     cout << "Processed Frames : "
//          << frameCount
//          << endl;

//     cout << "==============================================" << endl;


//     return 0;
// }





// ========================@2=================================
#include <opencv2/opencv.hpp>

#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>
#include <filesystem>
#include <chrono>
#include <ctime>
#include <sstream>

using namespace cv;
using namespace std;

namespace fs = std::filesystem;


// ============================================================================
// Configuration
// ============================================================================

// Radius used to separate low and high frequency components
const double LOW_FREQ_RADIUS_DIVISOR = 6.0;

// Temporary threshold.
// Must be calibrated using actual video data.
const double BLUR_THRESHOLD = 0.01;

// Main output directory.
// This directory is used only when -S flag is given.
const string MAIN_OUTPUT_FOLDER = "./Output";


// ============================================================================
// Print Usage
// ============================================================================

void PrintUsage(const char* programName)
{
    cout << endl;

    cout << "Usage:" << endl;

    cout << "  " << programName << " -V <video_path> [-S]" << endl;
    cout << endl;
    cout << "Flags:" << endl;

    cout << "  -V <path>    Input video file" << endl;
    cout << "  -S           Save output video and runlog.txt" << endl;
    cout << "  -h           Show help" << endl;

    cout << endl;
    cout << "Examples:" << endl;

    cout << endl;

    cout << "Process only:" << endl;

    cout << "  " << programName << " -V /home/abhirup/Videos/test_vid.mp4" << endl;

    cout << endl;

    cout << "Process and save:" << endl;

    cout << "  " << programName << " -V /home/abhirup/Videos/test_vid.mp4 -S" << endl;

    cout << endl;
}


// ============================================================================
// Get Current Date
// ============================================================================

string GetCurrentDate()
{
    auto now =        chrono::system_clock::now();

    time_t currentTime =
        chrono::system_clock::to_time_t(now);

    tm localTime{};

#ifdef _WIN32

    localtime_s(
        &localTime,
        &currentTime
    );

#else

    localtime_r(
        &currentTime,
        &localTime
    );

#endif

    stringstream ss;

    ss << put_time(
        &localTime,
        "%d-%m-%Y"
    );

    return ss.str();
}


// ============================================================================
// Get Current Date and Time
// ============================================================================

string GetCurrentDateTime()
{
    auto now =
        chrono::system_clock::now();

    time_t currentTime =
        chrono::system_clock::to_time_t(now);

    tm localTime{};

#ifdef _WIN32

    localtime_s(
        &localTime,
        &currentTime
    );

#else

    localtime_r(
        &currentTime,
        &localTime
    );

#endif

    stringstream ss;

    ss << put_time(
        &localTime,
        "%d-%m-%Y %H:%M:%S"
    );

    return ss.str();
}


// ============================================================================
// Create Run Directory
// ============================================================================
//
// Output structure:
//
// Output/
// └── DD-MM-YYYY/
//     ├── run1/
//     ├── run2/
//     ├── run3/
//     └── ...
//
// ============================================================================

fs::path CreateRunDirectory()
{
    // Main output directory
    fs::path mainDirectory =
        MAIN_OUTPUT_FOLDER;


    fs::create_directories(
        mainDirectory
    );


    // Current date
    string currentDate =
        GetCurrentDate();


    // Date directory
    fs::path dateDirectory =
        mainDirectory /
        currentDate;


    fs::create_directories(
        dateDirectory
    );


    // ------------------------------------------------------------------------
    // Find next available run number
    // ------------------------------------------------------------------------

    int runNumber = 1;

    fs::path runDirectory;


    while (true)
    {
        runDirectory =
            dateDirectory /
            (
                "run" +
                to_string(runNumber)
                );


        if (!fs::exists(runDirectory))
        {
            break;
        }


        runNumber++;
    }


    // Create run directory
    fs::create_directories(
        runDirectory
    );


    return runDirectory;
}


// ============================================================================
// FFT Shift
// ============================================================================

void FFTShift(Mat& image)
{
    // Make dimensions even
    image =
        image(
            Rect(
                0,
                0,
                image.cols & -2,
                image.rows & -2
            )
        );


    int cx =
        image.cols / 2;

    int cy =
        image.rows / 2;


    // Four quadrants
    Mat q0(
        image,
        Rect(0, 0, cx, cy)
    );

    Mat q1(
        image,
        Rect(cx, 0, cx, cy)
    );

    Mat q2(
        image,
        Rect(0, cy, cx, cy)
    );

    Mat q3(
        image,
        Rect(cx, cy, cx, cy)
    );


    Mat temp;


    // Swap q0 and q3
    q0.copyTo(temp);

    q3.copyTo(q0);

    temp.copyTo(q3);


    // Swap q1 and q2
    q1.copyTo(temp);

    q2.copyTo(q1);

    temp.copyTo(q2);
}


// ============================================================================
// Calculate FFT Blur Score
// ============================================================================

double FFTBlurScore(const Mat& gray)
{
    // Check input
    if (gray.empty())
    {
        return 0.0;
    }


    // ------------------------------------------------------------------------
    // Convert grayscale image to floating point
    // ------------------------------------------------------------------------

    Mat floatImage;

    gray.convertTo(
        floatImage,
        CV_32F
    );


    // ------------------------------------------------------------------------
    // Apply Hanning Window
    // ------------------------------------------------------------------------

    Mat hanningWindow;

    createHanningWindow(
        hanningWindow,
        floatImage.size(),
        CV_32F
    );


    floatImage =
        floatImage.mul(
            hanningWindow
        );


    // ------------------------------------------------------------------------
    // Prepare complex image
    // ------------------------------------------------------------------------

    Mat planes[] =
    {
        floatImage,

        Mat::zeros(
            floatImage.size(),
            CV_32F
        )
    };


    Mat complexImage;


    merge(
        planes,
        2,
        complexImage
    );


    // ------------------------------------------------------------------------
    // Calculate 2D FFT
    // ------------------------------------------------------------------------

    dft(
        complexImage,
        complexImage
    );


    // ------------------------------------------------------------------------
    // Separate real and imaginary components
    // ------------------------------------------------------------------------

    split(
        complexImage,
        planes
    );


    // ------------------------------------------------------------------------
    // Calculate FFT magnitude
    // ------------------------------------------------------------------------

    Mat magnitudeImage;


    magnitude(
        planes[0],
        planes[1],
        magnitudeImage
    );


    // ------------------------------------------------------------------------
    // Shift low frequencies to center
    // ------------------------------------------------------------------------

    FFTShift(
        magnitudeImage
    );


    // ------------------------------------------------------------------------
    // Image dimensions
    // ------------------------------------------------------------------------

    int rows =
        magnitudeImage.rows;

    int cols =
        magnitudeImage.cols;


    int centerX =
        cols / 2;

    int centerY =
        rows / 2;


    // ------------------------------------------------------------------------
    // Define low-frequency radius
    // ------------------------------------------------------------------------

    double radius =
        static_cast<double>(
            min(rows, cols)
            )
        /
        LOW_FREQ_RADIUS_DIVISOR;


    double radiusSquared =
        radius * radius;


    // ------------------------------------------------------------------------
    // Energy variables
    // ------------------------------------------------------------------------

    double totalEnergy = 0.0;

    double highFrequencyEnergy = 0.0;


    // ------------------------------------------------------------------------
    // Calculate frequency energy
    // ------------------------------------------------------------------------

    for (int y = 0; y < rows; ++y)
    {
        const float* ptr =
            magnitudeImage.ptr<float>(y);


        double dy =
            static_cast<double>(
                y - centerY
                );


        for (int x = 0; x < cols; ++x)
        {
            double mag =
                static_cast<double>(
                    ptr[x]
                    );


            // Energy = magnitude²
            double energy =
                mag * mag;


            totalEnergy +=
                energy;


            // Distance from FFT center
            double dx =
                static_cast<double>(
                    x - centerX
                    );


            double distanceSquared =
                dx * dx +
                dy * dy;


            // Outside center region = high frequency
            if (distanceSquared > radiusSquared)
            {
                highFrequencyEnergy +=
                    energy;
            }
        }
    }


    // Prevent division by zero
    if (totalEnergy <= 1e-12)
    {
        return 0.0;
    }


    // ------------------------------------------------------------------------
    // Blur Score
    //
    //              High Frequency Energy
    // Score = -------------------------------
    //                  Total Energy
    //
    // Lower score  -> More Blur
    // Higher score -> More Sharpness
    // ------------------------------------------------------------------------

    return
        highFrequencyEnergy /
        totalEnergy;
}


// ============================================================================
// Main
// ============================================================================

int main(int argc, char* argv[])
{
    // ------------------------------------------------------------------------
    // Runtime Parameters
    // ------------------------------------------------------------------------

    string videoPath;

    bool saveOutput = false;


    // ------------------------------------------------------------------------
    // Parse Command-Line Arguments
    // ------------------------------------------------------------------------

    for (int i = 1; i < argc; ++i)
    {
        string arg =
            argv[i];


        // --------------------------------------------------------------------
        // -V : Input Video
        // --------------------------------------------------------------------

        if (arg == "-V")
        {
            if (i + 1 >= argc)
            {
                cerr
                    << "ERROR: Missing video path after -V"
                    << endl;


                PrintUsage(
                    argv[0]
                );


                return -1;
            }


            videoPath =
                argv[++i];
        }


        // --------------------------------------------------------------------
        // -S : Enable Saving
        // --------------------------------------------------------------------

        else if (arg == "-S")
        {
            saveOutput = true;
        }


        // --------------------------------------------------------------------
        // Help
        // --------------------------------------------------------------------

        else if (
            arg == "-h" ||
            arg == "--help"
            )
        {
            PrintUsage(
                argv[0]
            );


            return 0;
        }


        // --------------------------------------------------------------------
        // Unknown argument
        // --------------------------------------------------------------------

        else
        {
            cerr
                << "ERROR: Unknown argument: "
                << arg
                << endl;


            PrintUsage(
                argv[0]
            );


            return -1;
        }
    }


    // ------------------------------------------------------------------------
    // Validate Video Argument
    // ------------------------------------------------------------------------

    if (videoPath.empty())
    {
        cerr
            << "ERROR: Input video is required."
            << endl;


        PrintUsage(
            argv[0]
        );


        return -1;
    }


    // ------------------------------------------------------------------------
    // Check Input File
    // ------------------------------------------------------------------------

    if (!fs::exists(videoPath))
    {
        cerr
            << "ERROR: Video file does not exist:"
            << endl;

        cerr
            << videoPath
            << endl;


        return -1;
    }


    // ------------------------------------------------------------------------
    // Open Input Video
    // ------------------------------------------------------------------------

    VideoCapture cap(
        videoPath
    );


    if (!cap.isOpened())
    {
        cerr
            << "ERROR: Unable to open video file!"
            << endl;


        return -1;
    }


    // ------------------------------------------------------------------------
    // Video Information
    // ------------------------------------------------------------------------

    double fps =
        cap.get(
            CAP_PROP_FPS
        );


    int frameWidth =
        static_cast<int>(
            cap.get(
                CAP_PROP_FRAME_WIDTH
            )
            );


    int frameHeight =
        static_cast<int>(
            cap.get(
                CAP_PROP_FRAME_HEIGHT
            )
            );


    int totalFrames =
        static_cast<int>(
            cap.get(
                CAP_PROP_FRAME_COUNT
            )
            );


    // Invalid FPS fallback
    if (fps <= 0.0)
    {
        fps = 25.0;
    }


    // ========================================================================
    // SAVE CONFIGURATION
    // ========================================================================

    fs::path runDirectory;

    fs::path outputVideoPath;

    fs::path logFilePath;


    VideoWriter writer;

    ofstream logFile;


    // ------------------------------------------------------------------------
    // Create output only if -S is given
    // ------------------------------------------------------------------------

    if (saveOutput)
    {
        try
        {
            runDirectory =
                CreateRunDirectory();
        }
        catch (const fs::filesystem_error& e)
        {
            cerr
                << "ERROR: Unable to create output directory."
                << endl;

            cerr
                << e.what()
                << endl;


            cap.release();


            return -1;
        }


        // --------------------------------------------------------------------
        // Output paths
        // --------------------------------------------------------------------

        outputVideoPath =
            runDirectory /
            "result.mp4";


        logFilePath =
            runDirectory /
            "runlog.txt";


        // --------------------------------------------------------------------
        // Open Output Video
        // --------------------------------------------------------------------

        int fourcc =
            VideoWriter::fourcc(
                'm',
                'p',
                '4',
                'v'
            );


        writer.open(
            outputVideoPath.string(),
            fourcc,
            fps,
            Size(
                frameWidth,
                frameHeight
            ),
            true
        );


        if (!writer.isOpened())
        {
            cerr
                << "ERROR: Unable to create output video."
                << endl;


            cap.release();


            return -1;
        }


        // --------------------------------------------------------------------
        // Open Run Log
        // --------------------------------------------------------------------

        logFile.open(
            logFilePath
        );


        if (!logFile.is_open())
        {
            cerr
                << "ERROR: Unable to create runlog.txt"
                << endl;


            cap.release();

            writer.release();


            return -1;
        }


        // --------------------------------------------------------------------
        // Run Log Header
        // --------------------------------------------------------------------

        logFile
            << "============================================================"
            << endl;

        logFile
            << "             FFT VIDEO BLUR DETECTION RUN LOG"
            << endl;

        logFile
            << "============================================================"
            << endl;


        logFile
            << "Date / Time      : "
            << GetCurrentDateTime()
            << endl;


        logFile
            << "Input Video      : "
            << videoPath
            << endl;


        logFile
            << "Output Video     : "
            << outputVideoPath.string()
            << endl;


        logFile
            << "Video Resolution : "
            << frameWidth
            << " x "
            << frameHeight
            << endl;


        logFile
            << "FPS              : "
            << fps
            << endl;


        logFile
            << "Total Frames     : "
            << totalFrames
            << endl;


        logFile
            << "FFT Threshold    : "
            << fixed
            << setprecision(8)
            << BLUR_THRESHOLD
            << endl;


        logFile
            << "============================================================"
            << endl;


        logFile << endl;

        logFile
            << left
            << setw(15)
            << "Frame Number"
            << setw(25)
            << "FFT Blur Score"
            << setw(15)
            << "Status"
            << endl;


        logFile
            << "------------------------------------------------------------"
            << endl;
    }


    // ========================================================================
    // PROGRAM INFORMATION
    // ========================================================================

    cout << endl;

    cout
        << "============================================================"
        << endl;

    cout
        << "               FFT VIDEO BLUR DETECTION"
        << endl;

    cout
        << "============================================================"
        << endl;


    cout
        << "Input Video    : "
        << videoPath
        << endl;


    cout
        << "Resolution     : "
        << frameWidth
        << " x "
        << frameHeight
        << endl;


    cout
        << "FPS            : "
        << fps
        << endl;


    cout
        << "Total Frames   : "
        << totalFrames
        << endl;


    cout
        << "FFT Threshold  : "
        << BLUR_THRESHOLD
        << endl;


    cout
        << "Save Output    : "
        << (
            saveOutput
            ? "YES"
            : "NO"
            )
        << endl;


    if (saveOutput)
    {
        cout
            << "Output Folder  : "
            << runDirectory.string()
            << endl;


        cout
            << "Output Video   : "
            << outputVideoPath.string()
            << endl;


        cout
            << "Run Log        : "
            << logFilePath.string()
            << endl;
    }


    cout
        << "============================================================"
        << endl;


    // ========================================================================
    // FRAME PROCESSING
    // ========================================================================

    Mat frame;

    Mat grayFrame;


    int frameCount = 0;

    int blurryFrameCount = 0;

    int sharpFrameCount = 0;


    while (true)
    {
        // --------------------------------------------------------------------
        // Read Frame
        // --------------------------------------------------------------------

        cap >> frame;


        if (frame.empty())
        {
            break;
        }


        frameCount++;


        // --------------------------------------------------------------------
        // Convert to Grayscale
        // --------------------------------------------------------------------

        cvtColor(
            frame,
            grayFrame,
            COLOR_BGR2GRAY
        );


        // --------------------------------------------------------------------
        // Calculate FFT Blur Score
        // --------------------------------------------------------------------

        double blurScore =
            FFTBlurScore(
                grayFrame
            );


        // --------------------------------------------------------------------
        // Blur / Sharp Decision
        // --------------------------------------------------------------------

        bool isBlurry =
            blurScore <
            BLUR_THRESHOLD;


        string status;

        Scalar color;


        if (isBlurry)
        {
            status =
                "BLURRY";


            color =
                Scalar(
                    0,
                    0,
                    255
                );


            blurryFrameCount++;
        }
        else
        {
            status =
                "SHARP";


            color =
                Scalar(
                    0,
                    255,
                    0
                );


            sharpFrameCount++;
        }


        // --------------------------------------------------------------------
        // Terminal Output
        // --------------------------------------------------------------------

        cout
            << fixed
            << setprecision(8);


        cout
            << "Frame "
            << frameCount
            << " / "
            << totalFrames
            << " | Score: "
            << blurScore
            << " | "
            << status
            << endl;


        // --------------------------------------------------------------------
        // Save Frame Information To Log
        // --------------------------------------------------------------------

        if (saveOutput)
        {
            logFile
                << left
                << setw(15)
                << frameCount

                << setw(25)
                << fixed
                << setprecision(8)
                << blurScore

                << setw(15)
                << status

                << endl;
        }


        // --------------------------------------------------------------------
        // Draw Information On Frame
        // --------------------------------------------------------------------

        string frameText =
            "Frame: " +
            to_string(
                frameCount
            );


        ostringstream scoreStream;

        scoreStream
            << fixed
            << setprecision(8)
            << blurScore;


        string scoreText =
            "FFT Score: " +
            scoreStream.str();


        string statusText =
            "Status: " +
            status;


        putText(
            frame,
            frameText,
            Point(
                20,
                40
            ),
            FONT_HERSHEY_SIMPLEX,
            0.7,
            Scalar(
                255,
                255,
                255
            ),
            2,
            LINE_AA
        );


        putText(
            frame,
            scoreText,
            Point(
                20,
                75
            ),
            FONT_HERSHEY_SIMPLEX,
            0.65,
            color,
            2,
            LINE_AA
        );


        putText(
            frame,
            statusText,
            Point(
                20,
                110
            ),
            FONT_HERSHEY_SIMPLEX,
            0.8,
            color,
            2,
            LINE_AA
        );


        // --------------------------------------------------------------------
        // Save Processed Frame
        // --------------------------------------------------------------------

        if (saveOutput)
        {
            writer.write(
                frame
            );
        }


        // --------------------------------------------------------------------
        // Display
        // --------------------------------------------------------------------

        imshow(
            "FFT Blur Detection",
            frame
        );


        // --------------------------------------------------------------------
        // Keyboard
        //
        // ESC / Q = Exit
        // --------------------------------------------------------------------

        int key =
            waitKey(1);


        if (
            key == 27 ||
            key == 'q' ||
            key == 'Q'
            )
        {
            cout
                << "Processing stopped by user."
                << endl;


            break;
        }
    }


    // ========================================================================
    // FINAL RUN LOG INFORMATION
    // ========================================================================

    if (saveOutput)
    {
        double blurryPercentage = 0.0;

        double sharpPercentage = 0.0;


        if (frameCount > 0)
        {
            blurryPercentage =
                (
                    static_cast<double>(
                        blurryFrameCount
                        )
                    /
                    frameCount
                    )
                *
                100.0;


            sharpPercentage =
                (
                    static_cast<double>(
                        sharpFrameCount
                        )
                    /
                    frameCount
                    )
                *
                100.0;
        }


        logFile << endl;

        logFile
            << "============================================================"
            << endl;

        logFile
            << "                    RUN SUMMARY"
            << endl;

        logFile
            << "============================================================"
            << endl;


        logFile
            << "Processed Frames  : "
            << frameCount
            << endl;


        logFile
            << "Blurry Frames     : "
            << blurryFrameCount
            << endl;


        logFile
            << "Sharp Frames      : "
            << sharpFrameCount
            << endl;


        logFile
            << fixed
            << setprecision(2);


        logFile
            << "Blurry Percentage : "
            << blurryPercentage
            << "%"
            << endl;


        logFile
            << "Sharp Percentage  : "
            << sharpPercentage
            << "%"
            << endl;


        logFile
            << "============================================================"
            << endl;
    }


    // ========================================================================
    // CLEANUP
    // ========================================================================

    cap.release();


    if (saveOutput)
    {
        writer.release();

        logFile.close();
    }


    destroyAllWindows();


    // ========================================================================
    // FINAL TERMINAL INFORMATION
    // ========================================================================

    cout << endl;

    cout
        << "============================================================"
        << endl;

    cout
        << "                 PROCESSING COMPLETED"
        << endl;

    cout
        << "============================================================"
        << endl;


    cout
        << "Processed Frames : "
        << frameCount
        << endl;


    cout
        << "Blurry Frames    : "
        << blurryFrameCount
        << endl;


    cout
        << "Sharp Frames     : "
        << sharpFrameCount
        << endl;


    if (saveOutput)
    {
        cout
            << "Output saved at  : "
            << runDirectory.string()
            << endl;
    }
    else
    {
        cout
            << "Output Saving    : DISABLED"
            << endl;
    }


    cout
        << "============================================================"
        << endl;


    return 0;
}