// // ============================================================================
// // Name        : Classical_Det_EOVideo.cpp
// // ============================================================================

// #include "Classical_Det_EOVideo.h"

// namespace
// {
// enum class DetMode
// {
// 	DoG,
// 	HoughCircles,
// 	Hybrid
// };

// struct TrackerConfig
// {
// 	float CONF_THRESH = 0.5f;
// 	float HYBRID_LOG_WEIGHT = 0.5f;
// };

// struct BBox
// {
// 	int x, y, w, h;
// 	float score = 0.0f;
// 	string type = "detection";
// 	double area = 0.0;
// 	double aspect = 0.0;
// 	double extent = 0.0;
// 	double dog_mean = 0.0;

// 	int cx() const { return x + w / 2; }
// 	int cy() const { return y + h / 2; }
// 	Rect rect() const { return Rect(x, y, w, h); }
// };

// class BlobDetector
// {
// public:
// 	BlobDetector(const TrackerConfig &cfg, int roi_w, int roi_h)
// 		: cfg_(cfg), roi_w_(roi_w), roi_h_(roi_h)
// 	{
// 	}

// 	Mat blob_mask(const Mat &r32, float thresh = 18.f) const
// 	{
// 		Mat pos_clip, neg_clip;
// 		Mat pos_mask, neg_mask;

// 		max(r32, 0, pos_clip);
// 		pos_clip.convertTo(pos_clip, CV_8U);
// 		threshold(pos_clip, pos_mask, thresh, 255, THRESH_BINARY);

// 		Mat neg_r32 = -r32;
// 		max(neg_r32, 0, neg_clip);
// 		neg_clip.convertTo(neg_clip, CV_8U);
// 		threshold(neg_clip, neg_mask, thresh, 255, THRESH_BINARY);

// 		Mat out;
// 		bitwise_or(pos_mask, neg_mask, out);
// 		return out;
// 	}

// 	vector<BBox> apply_nms(vector<BBox> &boxes, float iou_threshold = 0.12f) const
// 	{
// 		if (boxes.empty())
// 		{
// 			return {};
// 		}

// 		sort(boxes.begin(), boxes.end(), [](const BBox &a, const BBox &b)
// 			 { return a.score > b.score; });

// 		vector<BBox> result;
// 		vector<bool> suppressed(boxes.size(), false);

// 		for (size_t i = 0; i < boxes.size(); ++i)
// 		{
// 			if (suppressed[i])
// 			{
// 				continue;
// 			}
// 			result.push_back(boxes[i]);

// 			for (size_t j = i + 1; j < boxes.size(); ++j)
// 			{
// 				if (suppressed[j])
// 				{
// 					continue;
// 				}

// 				Rect intersection = boxes[i].rect() & boxes[j].rect();
// 				float intersection_area = intersection.area();
// 				float union_area = boxes[i].rect().area() + boxes[j].rect().area() - intersection_area;
// 				float iou = (union_area > 0) ? (intersection_area / union_area) : 0.0f;

// 				if (iou > iou_threshold)
// 				{
// 					suppressed[j] = true;
// 				}
// 			}
// 		}
// 		return result;
// 	}

// 	vector<BBox> select_all(const Mat &gray,
// 							const Mat &fused_mask,
// 							const Mat &dog_conf,
// 							const Mat &log_conf,
// 							float hybrid_w) const
// 	{
// 		vector<vector<Point>> contours;
// 		findContours(fused_mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

// 		const double roi_area = static_cast<double>(roi_w_) * roi_h_;
// 		vector<BBox> candidates;

// 		for (auto &cnt : contours)
// 		{
// 			double area = contourArea(cnt);
// 			if (area <= 5)
// 			{
// 				continue;
// 			}

// 			Rect r = boundingRect(cnt);
// 			if (r.width <= 0 || r.height <= 0)
// 			{
// 				continue;
// 			}
// 			if (r.x < 0 || r.y < 0 || r.x + r.width > gray.cols || r.y + r.height > gray.rows)
// 			{
// 				continue;
// 			}
// 			if (r.y > gray.rows * 0.88)
// 			{
// 				continue;
// 			}

// 			double aspect = static_cast<double>(r.width) / r.height;
// 			double extent = area / (r.width * r.height);
// 			double rel = (area / roi_area) * 100.0;

// 			if (!(0.12 < aspect && aspect < 8.0 && extent > 0.06 && rel < 35.0))
// 			{
// 				continue;
// 			}

// 			double dog_mean = dog_conf.empty() ? 0.0 : mean(dog_conf(r))[0];
// 			double log_mean = log_conf.empty() ? 0.0 : mean(log_conf(r))[0];

// 			double dog_n = min(dog_mean / 50.0, 1.0);
// 			double log_n = min(log_mean / 50.0, 1.0);
// 			double hyb_conf = (1.0 - hybrid_w) * dog_n + hybrid_w * log_n;
// 			double score = area * (0.5 + hyb_conf);

// 			candidates.push_back(BBox{r.x, r.y, r.width, r.height, (float)score, "detected", area, aspect, extent, dog_mean});
// 		}

// 		return apply_nms(candidates, 0.18f);
// 	}

// 	vector<BBox> detect_dog_all(const Mat &roi, Mat &out_conf_map, Mat &out_mask) const
// 	{
// 		if (roi.empty())
// 		{
// 			out_conf_map = Mat();
// 			out_mask = Mat();
// 			return {};
// 		}

// 		Mat gray;
// 		if (roi.channels() == 3)
// 		{
// 			cvtColor(roi, gray, COLOR_BGR2GRAY);
// 		}
// 		else
// 		{
// 			gray = roi.clone();
// 		}

// 		Mat g1a, g2a, dog_a;
// 		GaussianBlur(gray, g1a, {3, 3}, 0.8);
// 		GaussianBlur(gray, g2a, {7, 7}, 2.0);
// 		subtract(g1a, g2a, dog_a, noArray(), CV_16S);

// 		Mat g1b, g2b, dog_b;
// 		GaussianBlur(gray, g1b, {5, 5}, 1.5);
// 		GaussianBlur(gray, g2b, {11, 11}, 3.5);
// 		subtract(g1b, g2b, dog_b, noArray(), CV_16S);

// 		Mat dog_a32, dog_b32;
// 		dog_a.convertTo(dog_a32, CV_32F);
// 		dog_b.convertTo(dog_b32, CV_32F);

// 		Mat abs_a, abs_b;
// 		absdiff(dog_a32, Scalar(0), abs_a);
// 		absdiff(dog_b32, Scalar(0), abs_b);
// 		max(abs_a, abs_b, out_conf_map);

// 		Mat m1 = blob_mask(dog_a32, 18.f);
// 		Mat m2 = blob_mask(dog_b32, 18.f);
// 		bitwise_or(m1, m2, out_mask);

// 		return select_all(gray, out_mask, out_conf_map, Mat{}, 0.0f);
// 	}

// 	vector<BBox> detect_dog_all(const Mat &roi) const
// 	{
// 		Mat conf, mask;
// 		return detect_dog_all(roi, conf, mask);
// 	}

// 	vector<BBox> detect_hough_circles(const Mat &img, Mat &out_conf_map, Mat &out_mask) const
// 	{
// 		if (img.empty())
// 		{
// 			out_conf_map = Mat();
// 			out_mask = Mat();
// 			return {};
// 		}

// 		Mat gray;
// 		if (img.channels() == 3)
// 		{
// 			cvtColor(img, gray, COLOR_BGR2GRAY);
// 		}
// 		else
// 		{
// 			gray = img.clone();
// 		}

// 		Mat smoothed;
// 		GaussianBlur(gray, smoothed, Size(5, 5), 1.2);

// 		vector<Vec3f> circles;
// 		HoughCircles(smoothed, circles, HOUGH_GRADIENT, 1.2, gray.rows / 12, 70, 22, 8, 28);

// 		out_conf_map = Mat::zeros(gray.size(), CV_32F);
// 		out_mask = Mat::zeros(gray.size(), CV_8U);

// 		vector<BBox> boxes;
// 		for (const auto &c : circles)
// 		{
// 			int cx = cvRound(c[0]);
// 			int cy = cvRound(c[1]);
// 			int r = cvRound(c[2]);

// 			int x = max(0, cx - r);
// 			int y = max(0, cy - r);
// 			int w = min(img.cols - x, 2 * r);
// 			int h = min(img.rows - y, 2 * r);

// 			if ((y + h) < (img.rows * 0.88))
// 			{
// 				Rect r_box(x, y, w, h);
// 				out_conf_map(r_box).setTo(Scalar(25.0f));
// 				out_mask(r_box).setTo(Scalar(255));

// 				double area_approx = CV_PI * r * r;
// 				boxes.push_back(BBox{x, y, w, h, 0.95f, "hough_circle", area_approx, 1.0, 0.78, 25.0});
// 			}
// 		}

// 		return apply_nms(boxes, 0.12f);
// 	}

// 	vector<BBox> detect_hough_circles(const Mat &img) const
// 	{
// 		Mat conf, mask;
// 		return detect_hough_circles(img, conf, mask);
// 	}

// 	vector<BBox> detect_hybrid_all(const Mat &img) const
// 	{
// 		Mat gray = (img.channels() == 3) ? Mat() : img.clone();
// 		if (img.channels() == 3)
// 		{
// 			cvtColor(img, gray, COLOR_BGR2GRAY);
// 		}

// 		Mat dog_conf, dog_mask;
// 		detect_dog_all(img, dog_conf, dog_mask);

// 		Mat hough_conf, hough_mask;
// 		detect_hough_circles(img, hough_conf, hough_mask);

// 		Mat combined_mask;
// 		bitwise_or(dog_mask, hough_mask, combined_mask);

// 		return select_all(gray, combined_mask, dog_conf, hough_conf, cfg_.HYBRID_LOG_WEIGHT);
// 	}

// private:
// 	TrackerConfig cfg_;
// 	int roi_w_;
// 	int roi_h_;
// };

// DetMode getDetMode(UInt8_t DetectorType)
// {
// 	if (DetectorType == 1)
// 	{
// 		return DetMode::DoG;
// 	}
// 	if (DetectorType == 3)
// 	{
// 		return DetMode::Hybrid;
// 	}
// 	return DetMode::HoughCircles;
// }
// }

// void runClassicalEODetection(Mat &VideoFrame, UInt8_t DetectorType, vector<struct _AIData_> &TargetDataArr)
// {
// 	TrackerConfig cfg;
// 	BlobDetector detector(cfg, VideoFrame.cols, VideoFrame.rows);
// 	vector<BBox> Detections;

// 	switch (getDetMode(DetectorType))
// 	{
// 	case DetMode::DoG:
// 		Detections = detector.detect_dog_all(VideoFrame);
// 		break;
// 	case DetMode::HoughCircles:
// 		Detections = detector.detect_hough_circles(VideoFrame);
// 		break;
// 	case DetMode::Hybrid:
// 		Detections = detector.detect_hybrid_all(VideoFrame);
// 		break;
// 	}

// 	TargetDataArr.clear();
// 	for (const auto &Box : Detections)
// 	{
// 		struct _AIData_ DetectData;
// 		DetectData.Type = 0;
// 		DetectData.ClassID = 1;
// 		DetectData.TrackID = 0;
// 		DetectData.Confidance = (Box.score <= 1.0f) ? Box.score : (float)min(0.99, Box.score / (Box.score + 100.0));
// 		DetectData.BoundingBox = Rect(Box.x, Box.y, Box.w, Box.h) & Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
// 		DetectData.CenterPoint = Point(DetectData.BoundingBox.x + DetectData.BoundingBox.width / 2,
// 										DetectData.BoundingBox.y + DetectData.BoundingBox.height / 2);

// 		if (DetectData.BoundingBox.width > 0 && DetectData.BoundingBox.height > 0)
// 		{
// 			TargetDataArr.push_back(DetectData);
// 		}
// 	}

// 	return;
// }








//======================= @2 ==================

// ============================================================================
// Name        : Classical_Det_EOVideo.cpp
// ============================================================================

#include "Classical_Det_EOVideo.h"

extern bool CentreTarget;

namespace
{
enum class DetMode
{
	DoG,
	HoughCircles,
	Hybrid
};

struct TrackerConfig
{
	float CONF_THRESH = 0.5f;
	float HYBRID_LOG_WEIGHT = 0.5f;
	float MIN_OUTPUT_CONF = 0.55f;

	// ---- Blob / mask generation ----
	float DOG_BLOB_THRESH = 18.f;
	float MIN_DOG_MEAN = 18.f;

	// ---- Geometric gating (select_all) ----
	double MIN_AREA = 14.0;
	double MAX_REL_AREA_PCT = 2.5;
	double MIN_ASPECT = 0.18;
	double MAX_ASPECT = 6.5;
	double MIN_EXTENT = 0.12;
	double TOP_IGNORE_PCT = 0.06;
	double BOTTOM_IGNORE_PCT = 0.86;
	double EDGE_IGNORE_PCT = 0.02;
};

struct BBox
{
	int x, y, w, h;
	float score = 0.0f;
	string type = "detection";
	double area = 0.0;
	double aspect = 0.0;
	double extent = 0.0;
	double dog_mean = 0.0;

	int cx() const { return x + w / 2; }
	int cy() const { return y + h / 2; }
	Rect rect() const { return Rect(x, y, w, h); }
};

class BlobDetector
{
public:
	BlobDetector(const TrackerConfig &cfg, int roi_w, int roi_h)
		: cfg_(cfg), roi_w_(roi_w), roi_h_(roi_h)
	{
	}

	Mat dark_blob_mask(const Mat &r32, float thresh = 18.f) const
	{
		Mat dark_clip, out;
		max(r32, 0, dark_clip);
		dark_clip.convertTo(dark_clip, CV_8U);
		threshold(dark_clip, out, thresh, 255, THRESH_BINARY);
		return out;
	}

	vector<BBox> apply_nms(vector<BBox> &boxes, float iou_threshold = 0.12f) const
	{
		if (boxes.empty())
		{
			return {};
		}

		sort(boxes.begin(), boxes.end(), [](const BBox &a, const BBox &b)
			 { return a.score > b.score; });

		vector<BBox> result;
		vector<bool> suppressed(boxes.size(), false);

		for (size_t i = 0; i < boxes.size(); ++i)
		{
			if (suppressed[i])
			{
				continue;
			}
			result.push_back(boxes[i]);

			for (size_t j = i + 1; j < boxes.size(); ++j)
			{
				if (suppressed[j])
				{
					continue;
				}

				Rect intersection = boxes[i].rect() & boxes[j].rect();
				float intersection_area = intersection.area();
				float union_area = boxes[i].rect().area() + boxes[j].rect().area() - intersection_area;
				float iou = (union_area > 0) ? (intersection_area / union_area) : 0.0f;

				if (iou > iou_threshold)
				{
					suppressed[j] = true;
				}
			}
		}
		return result;
	}

	vector<BBox> select_all(const Mat &gray,
							const Mat &fused_mask_in,
							const Mat &dog_conf,
							const Mat &log_conf,
							float hybrid_w) const
	{
		// Clean up the raw blob mask before contour extraction: opening removes
		// isolated single/few-pixel noise, closing fills small gaps in a real
		// target's blob so it doesn't get chopped into several tiny candidates.
		Mat fused_mask;
		Mat open_kernel = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
		Mat close_kernel = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
		morphologyEx(fused_mask_in, fused_mask, MORPH_OPEN, open_kernel);
		morphologyEx(fused_mask, fused_mask, MORPH_CLOSE, close_kernel);

		vector<vector<Point>> contours;
		findContours(fused_mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

		const double roi_area = static_cast<double>(roi_w_) * roi_h_;
		vector<BBox> candidates;

		for (auto &cnt : contours)
		{
			double area = contourArea(cnt);
			if (area <= cfg_.MIN_AREA)
			{
				continue;
			}

			Rect r = boundingRect(cnt);
			if (r.width <= 0 || r.height <= 0)
			{
				continue;
			}
			if (r.x < 0 || r.y < 0 || r.x + r.width > gray.cols || r.y + r.height > gray.rows)
			{
				continue;
			}
			if (r.y < gray.rows * cfg_.TOP_IGNORE_PCT || (r.y + r.height) > gray.rows * cfg_.BOTTOM_IGNORE_PCT)
			{
				continue;
			}
			if (r.x < gray.cols * cfg_.EDGE_IGNORE_PCT || (r.x + r.width) > gray.cols * (1.0 - cfg_.EDGE_IGNORE_PCT))
			{
				continue;
			}

			double aspect = static_cast<double>(r.width) / r.height;
			double extent = area / (r.width * r.height);
			double rel = (area / roi_area) * 100.0;

			if (!(cfg_.MIN_ASPECT < aspect && aspect < cfg_.MAX_ASPECT && extent > cfg_.MIN_EXTENT && rel < cfg_.MAX_REL_AREA_PCT))
			{
				continue;
			}

			double dog_mean = dog_conf.empty() ? 0.0 : mean(dog_conf(r))[0];
			double log_mean = log_conf.empty() ? 0.0 : mean(log_conf(r))[0];

			if (dog_mean < cfg_.MIN_DOG_MEAN)
			{
				continue;
			}

			double dog_n = min(dog_mean / 50.0, 1.0);
			double log_n = min(log_mean / 50.0, 1.0);
			double hyb_conf = (1.0 - hybrid_w) * dog_n + hybrid_w * log_n;

			// Actually enforce the confidence gate (previously computed but
			// never used to reject anything, so weak/noisy blobs always
			// fell through to the output regardless of CONF_THRESH).
			if (hyb_conf < cfg_.CONF_THRESH)
			{
				continue;
			}

			double score = area * (0.35 + hyb_conf);

			candidates.push_back(BBox{r.x, r.y, r.width, r.height, (float)score, "detected", area, aspect, extent, dog_mean});
		}

		return apply_nms(candidates, 0.18f);
	}

	vector<BBox> detect_dog_all(const Mat &roi, Mat &out_conf_map, Mat &out_mask) const
	{
		if (roi.empty())
		{
			out_conf_map = Mat();
			out_mask = Mat();
			return {};
		}

		Mat gray;
		if (roi.channels() == 3)
		{
			cvtColor(roi, gray, COLOR_BGR2GRAY);
		}
		else
		{
			gray = roi.clone();
		}

		Mat g1a, g2a, dog_a;
		GaussianBlur(gray, g1a, {3, 3}, 0.8);
		GaussianBlur(gray, g2a, {31, 31}, 7.0);
		subtract(g2a, g1a, dog_a, noArray(), CV_16S);

		Mat g1b, g2b, dog_b;
		GaussianBlur(gray, g1b, {5, 5}, 1.5);
		GaussianBlur(gray, g2b, {41, 41}, 9.0);
		subtract(g2b, g1b, dog_b, noArray(), CV_16S);

		Mat dog_a32, dog_b32;
		dog_a.convertTo(dog_a32, CV_32F);
		dog_b.convertTo(dog_b32, CV_32F);

		max(dog_a32, 0, dog_a32);
		max(dog_b32, 0, dog_b32);
		max(dog_a32, dog_b32, out_conf_map);

		Mat m1 = dark_blob_mask(dog_a32, cfg_.DOG_BLOB_THRESH);
		Mat m2 = dark_blob_mask(dog_b32, cfg_.DOG_BLOB_THRESH);
		bitwise_or(m1, m2, out_mask);

		return select_all(gray, out_mask, out_conf_map, Mat{}, 0.0f);
	}

	vector<BBox> detect_dog_all(const Mat &roi) const
	{
		Mat conf, mask;
		return detect_dog_all(roi, conf, mask);
	}

	vector<BBox> detect_hough_circles(const Mat &img, Mat &out_conf_map, Mat &out_mask) const
	{
		if (img.empty())
		{
			out_conf_map = Mat();
			out_mask = Mat();
			return {};
		}

		Mat gray;
		if (img.channels() == 3)
		{
			cvtColor(img, gray, COLOR_BGR2GRAY);
		}
		else
		{
			gray = img.clone();
		}

		Mat smoothed;
		GaussianBlur(gray, smoothed, Size(5, 5), 1.2);

		vector<Vec3f> circles;
		HoughCircles(smoothed, circles, HOUGH_GRADIENT, 1.2, gray.rows / 12, 70, 22, 8, 28);

		out_conf_map = Mat::zeros(gray.size(), CV_32F);
		out_mask = Mat::zeros(gray.size(), CV_8U);

		vector<BBox> boxes;
		for (const auto &c : circles)
		{
			int cx = cvRound(c[0]);
			int cy = cvRound(c[1]);
			int r = cvRound(c[2]);

			int x = max(0, cx - r);
			int y = max(0, cy - r);
			int w = min(img.cols - x, 2 * r);
			int h = min(img.rows - y, 2 * r);

			if ((y + h) < (img.rows * 0.88))
			{
				Rect r_box(x, y, w, h);
				out_conf_map(r_box).setTo(Scalar(25.0f));
				out_mask(r_box).setTo(Scalar(255));

				double area_approx = CV_PI * r * r;
				boxes.push_back(BBox{x, y, w, h, 0.95f, "hough_circle", area_approx, 1.0, 0.78, 25.0});
			}
		}

		return apply_nms(boxes, 0.12f);
	}

	vector<BBox> detect_hough_circles(const Mat &img) const
	{
		Mat conf, mask;
		return detect_hough_circles(img, conf, mask);
	}

	vector<BBox> detect_hybrid_all(const Mat &img) const
	{
		Mat gray = (img.channels() == 3) ? Mat() : img.clone();
		if (img.channels() == 3)
		{
			cvtColor(img, gray, COLOR_BGR2GRAY);
		}

		Mat dog_conf, dog_mask;
		detect_dog_all(img, dog_conf, dog_mask);

		Mat hough_conf, hough_mask;
		detect_hough_circles(img, hough_conf, hough_mask);

		Mat combined_mask;
		bitwise_or(dog_mask, hough_mask, combined_mask);

		return select_all(gray, combined_mask, dog_conf, hough_conf, cfg_.HYBRID_LOG_WEIGHT);
	}

private:
	TrackerConfig cfg_;
	int roi_w_;
	int roi_h_;
};

DetMode getDetMode(UInt8_t DetectorType)
{
	if (DetectorType == 1)
	{
		return DetMode::DoG;
	}
	if (DetectorType == 3)
	{
		return DetMode::Hybrid;
	}
	return DetMode::HoughCircles;
}
}

void runClassicalEODetection(Mat &VideoFrame, UInt8_t DetectorType, vector<struct _AIData_> &TargetDataArr)
{
	TrackerConfig cfg;
	BlobDetector detector(cfg, VideoFrame.cols, VideoFrame.rows);
	vector<BBox> Detections;

	switch (getDetMode(DetectorType))
	{
	case DetMode::DoG:
		Detections = detector.detect_dog_all(VideoFrame);
		break;
	case DetMode::HoughCircles:
		Detections = detector.detect_hough_circles(VideoFrame);
		break;
	case DetMode::Hybrid:
		Detections = detector.detect_hybrid_all(VideoFrame);
		break;
	}

	TargetDataArr.clear();

	if (CentreTarget == true && Detections.size() > 1)
	{
		auto BestDetection = max_element(Detections.begin(), Detections.end(), [](const BBox &a, const BBox &b)
										 { return a.score < b.score; });
		Detections = {*BestDetection};
	}

	for (const auto &Box : Detections)
	{
		struct _AIData_ DetectData;
		DetectData.Type = 0;
		DetectData.ClassID = 1;
		DetectData.TrackID = 0;
		DetectData.Confidance = (Box.score <= 1.0f) ? Box.score : (float)min(0.99, Box.score / (Box.score + 100.0));
		DetectData.BoundingBox = Rect(Box.x, Box.y, Box.w, Box.h) & Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
		DetectData.CenterPoint = Point(DetectData.BoundingBox.x + DetectData.BoundingBox.width / 2,
										DetectData.BoundingBox.y + DetectData.BoundingBox.height / 2);

		if (DetectData.Confidance >= cfg.MIN_OUTPUT_CONF && DetectData.BoundingBox.width > 0 && DetectData.BoundingBox.height > 0)
		{
			TargetDataArr.push_back(DetectData);
		}
	}

	return;
}
