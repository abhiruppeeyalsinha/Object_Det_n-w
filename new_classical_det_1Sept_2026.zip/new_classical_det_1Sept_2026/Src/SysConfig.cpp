// // ============================================================================
// // Name        : SysConfig.cpp
// // Created On  : 11 Nov 2025
// // ============================================================================

// //SysConfig.cpp
// // ---------- Header Inclusion ----------
// #include "SysConfig.h"


// // ---------- CRC16 function ----------
// UInt16_t crc16(UInt8_t *Data, UInt64_t Len)
// {
// 	UInt16_t crc = 0xFFFF;
// 	UInt64_t i = 0;
// 	UInt8_t j = 0;

// 	for(i = 0; i < Len; i++)
// 	{
// 		crc ^= Data[i];
// 		for(j = 0; j < 8; j++)
// 		{
// 			if(crc & 0x01)
// 			{
// 				crc = (crc >> 1) ^ 0xA001;
// 			}
// 			else
// 			{
// 				crc >>= 1;
// 			}
// 		}
// 	}

// 	return crc;
// }


// // ---------- Calculate software checksum ----------
// UInt16_t getSwCheckSum(string Path)
// {
// 	ifstream file;
// 	string secName;
// 	Elf64_Ehdr ehdr;
// 	UInt16_t crc = 0, i = 0;

// 	// Open EXE file
// 	file.open(Path.c_str(), ios::binary);
// 	if(!file)
// 	{
// 		cout << "Failed to open EXE file..." << endl;
// 		return crc;
// 	}

// 	// Read EXE header
// 	file.read(reinterpret_cast<Int8_t *>(&ehdr), sizeof(ehdr));
// 	if(strncmp((Int8_t *)ehdr.e_ident, ELFMAG, SELFMAG) != 0)
// 	{
// 		cout << "Invalid EXE file..." << endl;
// 		return crc;
// 	}

// 	// Read section header
// 	file.seekg(ehdr.e_shoff, ios::beg);
// 	vector<Elf64_Shdr> shdrs(ehdr.e_shnum);
// 	file.read(reinterpret_cast<Int8_t *>(shdrs.data()), ehdr.e_shentsize * ehdr.e_shnum);

// 	// Read section header string table
// 	Elf64_Shdr shstr = shdrs[ehdr.e_shstrndx];
// 	vector<Int8_t> shstrtab(shstr.sh_size);
// 	file.seekg(shstr.sh_offset, ios::beg);
// 	file.read(shstrtab.data(), shstr.sh_size);

// 	// Find .text section
// 	for(i = 0; i < ehdr.e_shnum; i++)
// 	{
// 		secName = &shstrtab[shdrs[i].sh_name];
// 		if(secName == ".text")
// 		{
// 			vector<UInt8_t> buffer(shdrs[i].sh_size);
// 			file.seekg(shdrs[i].sh_offset, ios::beg);
// 			file.read(reinterpret_cast<Int8_t *>(buffer.data()), shdrs[i].sh_size);

// 			return crc16(buffer.data(), buffer.size());
// 		}
// 	}

// 	cout << "Failed to calculate Checksum..." << endl;

// 	return crc;
// }


// // ---------- Force stop function for CNTL+C ----------
// void forceStop([[maybe_unused]]Int32_t Signal)
// {
// 	// Clear all flags
// 	SaveVideo = false;
// 	DisplayFrame = false;
// 	AutoSaveVideo = false;

// 	C4ICmdRecvFlag = false;
// 	C4IDataSendFlag = false;
// 	IRVideoReadFlag = false;
// 	EOVideoReadFlag = false;
// 	ProcessVideoFlag = false;

// 	destroyAllWindows();
// 	usleep(100);

// 	cout << "Terminating Forcefully by CNTL+C..." << endl << flush;

// 	return;
// }


// // ---------- Get TimeStamp ----------
// string getTimeStamp(void)
// {
// 	struct timeval tv;
// 	struct tm *tm_info;
// 	Int8_t timeStamp[30] = {0};

// 	gettimeofday(&tv, NULL);
// 	tm_info = localtime(&tv.tv_sec);

// 	strftime(timeStamp, sizeof(timeStamp), "%d-%m-%y %H:%M:%S.", tm_info);
// 	sprintf(timeStamp+strlen(timeStamp), "%03ld", tv.tv_usec/1000);

// 	return string(timeStamp);
// }


// // ---------- Check Serial Port is available or not ----------
// bool releaseUDPPort(Int32_t Port)
// {
// 	string Command = "fuser -k " + to_string(Port) + "/udp >/dev/null 2>&1";
// 	system(Command.c_str());
// 	usleep(100 * 1000);

// 	return true;
// }


// // ---------- Create Path ----------
// string createPath(string Path)
// {
// 	FILE *pipe;
// 	Int8_t date[10];
// 	Int32_t testCnt = -1;

// 	time_t t = time(nullptr);
// 	tm *now = localtime(&t);

// 	strftime(date, sizeof(date), "%d%b%y/", now);
// 	Path = Path + (Path[Path.size()-1] == '/' ? "" : "/") + "Res/" + date;
// 	system(("mkdir -p -m 775 " + Path).c_str());

// 	pipe = popen(("ls -d " + Path + "Test* 2>/dev/null | grep -oP 'Test\\K[0-9]+' | sort -nr | head -n1").c_str(), "r");
// 	if(!pipe)
// 	{
// 		cerr << "Error in opening pipe..." << endl;
// 		testCnt = 0;
// 	}
// 	else
// 	{
// 		fscanf(pipe, "%d", &testCnt);
// 		testCnt++;
// 	}

// 	Path = Path + "Test" + to_string(testCnt) + "/";
// 	system(("mkdir -p -m 775 " + Path).c_str());

// 	return Path;
// }


// // ---------- Get Path ----------
// string getPath(UInt8_t typ)
// {
// 	string Path = "";
// 	ssize_t len = 0;
// 	Int8_t path[PATH_MAX], *tmp;


// 	// Get Exe OR Load Path
// 	if(typ == 0 || typ == 1)
// 	{
// 		len = readlink("/proc/self/exe", path, PATH_MAX - 1);
// 		if(len != -1)
// 		{
// 			path[len] = '\0';

// 			if(typ == 1)
// 			{
// 				tmp = strrchr(path, '/');
// 				*(tmp + 1) = '\0';
// 			}

// 			Path = path;
// 		}
// 		else
// 		{
// 			Path = "";
// 		}
// 	}

// 	// Get Save Path
// 	else if(typ == 2)
// 	{
// 		if(InpPath == "")
// 		{
// 			Path = ParentPath == "" ? createPath(LoadPath) : ParentPath;
// 		}
// 		else
// 		{
// 			Path = createPath(InpPath);

// 			if(ParentPath != "")
// 			{
// 				system(("sudo mv " + ParentPath + "* " + Path).c_str());
// 				system(("sudo rm -rf " + ParentPath).c_str());
// 			}
// 		}
// 	}

// 	else
// 	{

// 	}

// 	return Path;
// }


// // ---------- CheckSum Calculation ----------
// UInt8_t calCheckSum(UInt8_t *inpBuff, UInt32_t Length)
// {
// 	UInt32_t byteCnt;
// 	UInt8_t checksum = 0;

// 	for(byteCnt = 0; byteCnt < Length; byteCnt++)
// 	{
// 		checksum = checksum ^ inpBuff[byteCnt];
// 	}

// 	return checksum;
// }


// // ---------- Validate Integer ----------
// bool validateInt(Int8_t *str)
// {
// 	Int8_t charCnt=0;

// 	do
// 	{
// 		if(!isdigit(*str))
// 		{
// 			if(! (charCnt == 0 && (*str == '-' || *str == '+')))
// 			{
// 				return false;
// 			}
// 		}
// 		charCnt++;
// 	} while(*++str);

// 	return true;
// }


// // ---------- Validate IP Address ----------
// bool validateIP(const Int8_t *Addr)
// {
// 	// Local Variable
// 	Int8_t Result;
// 	struct sockaddr_in sa;

//     Result = inet_pton(AF_INET, Addr, &(sa.sin_addr));
//     return Result != 0;
// }


// // ---------- readFile ----------
// string readFile(string path)
// {
// 	Int32_t file = -1, dataCnt = 0;
// 	Int8_t *buff;
// 	string data;

// 	file = open(path.c_str(), O_RDONLY);
// 	if(file < 0)
// 	{
// 		perror("Config File Open");
// 		return "";
// 	}

// 	dataCnt = lseek(file, 0, SEEK_END);
// 	lseek(file, 0, SEEK_SET);

// 	buff = (Int8_t *)malloc(dataCnt+1);
// 	if(read(file, buff, dataCnt) < 0)
// 	{
// 		perror("Config File Read");
// 		free(buff);
// 		return "";
// 	}
// 	buff[dataCnt] = 0;

// 	data = (const Int8_t *)buff;
// 	free(buff);

// 	return data;
// }


// // ---------- load Config file Data ----------
// void loadConfigData(void)
// {
// 	json parsedData;
// 	string data, ipAddr;

// 	// Open file & read data
// 	data = readFile(LoadPath + ConfigFile);

// 	if(data == "")
// 	{
// 		cout << "Failed to load config data..." << endl << flush;
// 		return;
// 	}

// 	// load config data
// 	try
// 	{
// 		parsedData = json::parse(data);

// 		InpPath  = parsedData["Data_SavePath"];


// 		ipAddr = parsedData["C4I_IPAddr"];
// 		if(ipAddr != "")
// 		{
// 			if(validateIP(ipAddr.c_str()) == false)
// 			{
// 				cout << "Please enter valid DL_IPADDR in config file" << endl << flush;
// 				exit(1);
// 			}
// 			C4I_IPAddr = ipAddr;
// 		}

// 		C4I_Port			= parsedData["C4I_Port"];
// 		AI_Port				= parsedData["AI_Port"];

// 		IR_VideoSrc			= parsedData["IR_VideoSrc"];
// 		EO_VideoSrc			= parsedData["EO_VideoSrc"];

// 			IR_Detect_Model		= parsedData["IR_Detect_Model"];
// 			EO_Detect_Model		= parsedData["EO_Detect_Model"];

// 		cout << "Config data loaded successfully..." << endl << flush;
// 	}
// 	catch(exception &e)
// 	{
// 		cerr << "Config data : " <<  e.what() << endl;
// 	}

// 	return;
// }


// // ---------- Check User CommandLine Flags ----------
// void checkFlags(Int32_t argc, Int8_t *argv[])
// {
// 	Int32_t ArgcCnt = 0;
// 	string Arg;
// 	string DetectorChoice;

// 	for(ArgcCnt = 1; ArgcCnt < argc; ArgcCnt++)
// 	{
// 		Arg = string(argv[ArgcCnt]);

// 		if(Arg == "-S")
// 		{
// 			AutoSaveVideo = true;
// 		}

// 		else if(Arg == "-T")
// 		{
// 			TrackingFlag = true;
// 		}

// 		else if(Arg == "-C")
// 		{
// 			CentreTarget = true;
// 		}

// 		else if(Arg == "-CR")
// 		{
// 			CentreTarget = false;
// 		}

// 		else if(Arg == "-DF")
// 		{
// 			DisplayFrame = true;
// 		}

// 		else if(Arg == "-BP")
// 		{
// 			BirdPlaneDataFlag = true;
// 		}

// 		else if(Arg == "-IR")
// 		{
// 			AI_Type = 1;
// 		}

// 		else if(Arg == "-EO")
// 		{
// 			AI_Type = 2;
// 		}

// 		else if(Arg == "-AI")
// 		{
// 			ClassicalDetectionFlag = false;
// 		}

// 		else if(Arg == "-CL")
// 		{
// 			ClassicalDetectionFlag = true;
// 		}

// 		else if(Arg == "-CD")
// 		{
// 			ArgcCnt++;
// 			if(ArgcCnt < argc && validateInt(argv[ArgcCnt]) == true)
// 			{
// 				ClassicalDetectorType = atoi(argv[ArgcCnt]);
// 				if(ClassicalDetectorType < 1 || ClassicalDetectorType > 3)
// 				{
// 					cout << "Classical detector must be 1, 2, or 3." << endl << flush;
// 					exit(1);
// 				}
// 				ClassicalDetectionFlag = true;
// 			}
// 			else
// 			{
// 				cout << "Please provide detector id after '-CD' like '-CD 2'" << endl << flush;
// 				exit(1);
// 			}
// 		}

// 		else if(Arg == "-SV")
// 		{
// 			SingleVideo = true;
// 		}

// 		else if(Arg == "-PT")
// 		{
// 			ArgcCnt++;
// 			if(ArgcCnt < argc)
// 			{
// 				ParentPath = argv[ArgcCnt];
// 				ParentPath = ParentPath + (ParentPath[ParentPath.size()-1] == '/' ? "" : "/");
// 			}
// 			else
// 			{
// 				cout << "Please provide path after like '-PT Path'" << endl << flush;
// 				exit(1);
// 			}
// 		}

// 		else
// 		{
// 			cout << "!!!!!!!! Given Wrong Parameters  !!!!!!!!" << endl;

// 				cout << "Save Video                         : -S" << endl;
// 				cout << "Start Template Tracking            : -T" << endl;
// 				cout << "Center Closest Target (Default)    : -C" << endl;
// 				cout << "Centroid Target Data               : -CR" << endl;
// 				cout << "Bird & Plane Track                 : -BP" << endl;
// 				cout << "Display Video Frames               : -DF" << endl;
// 				cout << "Single Video No C4I Cmd			: -SV" << endl;
// 				cout << "Run IR AI Model			        : -IR" << endl;
// 				cout << "Run EO AI Model                  	: -EO" << endl << endl;
// 				cout << "Run AI Detection (Default)         : -AI" << endl;
// 				cout << "Run EO Classical Detection         : -CL" << endl;
// 				cout << "EO Classical Detector 1/2/3        : -CD <1|2|3>" << endl << endl;
// 				exit(1);
// 			}
// 		}

// 	if(ClassicalDetectionFlag == true && ClassicalDetectorType == 0)
// 	{
// 		cout << "\n--- EO Classical Detection Engine ---\n";
// 		cout << " [1] Filtered DoG\n";
// 		cout << " [2] Optimized Hough Circle Transform\n";
// 		cout << " [3] Hybrid (DoG + Hough Conf Fusion)\n";
// 		cout << " Select (default 2): ";
// 		getline(cin, DetectorChoice);

// 		if(DetectorChoice == "1")
// 		{
// 			ClassicalDetectorType = 1;
// 		}
// 		else if(DetectorChoice == "3")
// 		{
// 			ClassicalDetectorType = 3;
// 		}
// 		else
// 		{
// 			ClassicalDetectorType = 2;
// 		}
// 	}

// 	return;
// }




// ==================== @2 ================


// ============================================================================
// Name        : SysConfig.cpp
// Created On  : 11 Nov 2025
// ============================================================================

//SysConfig.cpp
// ---------- Header Inclusion ----------
#include "SysConfig.h"


// ---------- CRC16 function ----------
UInt16_t crc16(UInt8_t *Data, UInt64_t Len)
{
	UInt16_t crc = 0xFFFF;
	UInt64_t i = 0;
	UInt8_t j = 0;

	for(i = 0; i < Len; i++)
	{
		crc ^= Data[i];
		for(j = 0; j < 8; j++)
		{
			if(crc & 0x01)
			{
				crc = (crc >> 1) ^ 0xA001;
			}
			else
			{
				crc >>= 1;
			}
		}
	}

	return crc;
}


// ---------- Calculate software checksum ----------
UInt16_t getSwCheckSum(string Path)
{
	ifstream file;
	string secName;
	Elf64_Ehdr ehdr;
	UInt16_t crc = 0, i = 0;

	// Open EXE file
	file.open(Path.c_str(), ios::binary);
	if(!file)
	{
		cout << "Failed to open EXE file..." << endl;
		return crc;
	}

	// Read EXE header
	file.read(reinterpret_cast<Int8_t *>(&ehdr), sizeof(ehdr));
	if(strncmp((Int8_t *)ehdr.e_ident, ELFMAG, SELFMAG) != 0)
	{
		cout << "Invalid EXE file..." << endl;
		return crc;
	}

	// Read section header
	file.seekg(ehdr.e_shoff, ios::beg);
	vector<Elf64_Shdr> shdrs(ehdr.e_shnum);
	file.read(reinterpret_cast<Int8_t *>(shdrs.data()), ehdr.e_shentsize * ehdr.e_shnum);

	// Read section header string table
	Elf64_Shdr shstr = shdrs[ehdr.e_shstrndx];
	vector<Int8_t> shstrtab(shstr.sh_size);
	file.seekg(shstr.sh_offset, ios::beg);
	file.read(shstrtab.data(), shstr.sh_size);

	// Find .text section
	for(i = 0; i < ehdr.e_shnum; i++)
	{
		secName = &shstrtab[shdrs[i].sh_name];
		if(secName == ".text")
		{
			vector<UInt8_t> buffer(shdrs[i].sh_size);
			file.seekg(shdrs[i].sh_offset, ios::beg);
			file.read(reinterpret_cast<Int8_t *>(buffer.data()), shdrs[i].sh_size);

			return crc16(buffer.data(), buffer.size());
		}
	}

	cout << "Failed to calculate Checksum..." << endl;

	return crc;
}


// ---------- Force stop function for CNTL+C ----------
void forceStop([[maybe_unused]]Int32_t Signal)
{
	// Clear all flags
	SaveVideo = false;
	DisplayFrame = false;
	AutoSaveVideo = false;

	C4ICmdRecvFlag = false;
	C4IDataSendFlag = false;
	IRVideoReadFlag = false;
	EOVideoReadFlag = false;
	ProcessVideoFlag = false;

	destroyAllWindows();
	usleep(100);

	cout << "Terminating Forcefully by CNTL+C..." << endl << flush;

	return;
}


// ---------- Get TimeStamp ----------
string getTimeStamp(void)
{
	struct timeval tv;
	struct tm *tm_info;
	Int8_t timeStamp[30] = {0};

	gettimeofday(&tv, NULL);
	tm_info = localtime(&tv.tv_sec);

	strftime(timeStamp, sizeof(timeStamp), "%d-%m-%y %H:%M:%S.", tm_info);
	sprintf(timeStamp+strlen(timeStamp), "%03ld", tv.tv_usec/1000);

	return string(timeStamp);
}


// ---------- Check Serial Port is available or not ----------
bool releaseUDPPort(Int32_t Port)
{
	string Command = "fuser -k " + to_string(Port) + "/udp >/dev/null 2>&1";
	system(Command.c_str());
	usleep(100 * 1000);

	return true;
}


// ---------- Create Path ----------
string createPath(string Path)
{
	FILE *pipe;
	Int8_t date[10];
	Int32_t testCnt = -1;

	time_t t = time(nullptr);
	tm *now = localtime(&t);

	strftime(date, sizeof(date), "%d%b%y/", now);
	Path = Path + (Path[Path.size()-1] == '/' ? "" : "/") + "Res/" + date;
	system(("mkdir -p -m 775 " + Path).c_str());

	pipe = popen(("ls -d " + Path + "Test* 2>/dev/null | grep -oP 'Test\\K[0-9]+' | sort -nr | head -n1").c_str(), "r");
	if(!pipe)
	{
		cerr << "Error in opening pipe..." << endl;
		testCnt = 0;
	}
	else
	{
		fscanf(pipe, "%d", &testCnt);
		testCnt++;
	}

	Path = Path + "Test" + to_string(testCnt) + "/";
	system(("mkdir -p -m 775 " + Path).c_str());

	return Path;
}


// ---------- Get Path ----------
string getPath(UInt8_t typ)
{
	string Path = "";
	ssize_t len = 0;
	Int8_t path[PATH_MAX], *tmp;


	// Get Exe OR Load Path
	if(typ == 0 || typ == 1)
	{
		len = readlink("/proc/self/exe", path, PATH_MAX - 1);
		if(len != -1)
		{
			path[len] = '\0';

			if(typ == 1)
			{
				tmp = strrchr(path, '/');
				*(tmp + 1) = '\0';
			}

			Path = path;
		}
		else
		{
			Path = "";
		}
	}

	// Get Save Path
	else if(typ == 2)
	{
		if(InpPath == "")
		{
			Path = ParentPath == "" ? createPath(LoadPath) : ParentPath;
		}
		else
		{
			Path = createPath(InpPath);

			if(ParentPath != "")
			{
				system(("sudo mv " + ParentPath + "* " + Path).c_str());
				system(("sudo rm -rf " + ParentPath).c_str());
			}
		}
	}

	else
	{

	}

	return Path;
}


// ---------- CheckSum Calculation ----------
UInt8_t calCheckSum(UInt8_t *inpBuff, UInt32_t Length)
{
	UInt32_t byteCnt;
	UInt8_t checksum = 0;

	for(byteCnt = 0; byteCnt < Length; byteCnt++)
	{
		checksum = checksum ^ inpBuff[byteCnt];
	}

	return checksum;
}


// ---------- Validate Integer ----------
bool validateInt(Int8_t *str)
{
	Int8_t charCnt=0;

	do
	{
		if(!isdigit(*str))
		{
			if(! (charCnt == 0 && (*str == '-' || *str == '+')))
			{
				return false;
			}
		}
		charCnt++;
	} while(*++str);

	return true;
}


// ---------- Validate IP Address ----------
bool validateIP(const Int8_t *Addr)
{
	// Local Variable
	Int8_t Result;
	struct sockaddr_in sa;

    Result = inet_pton(AF_INET, Addr, &(sa.sin_addr));
    return Result != 0;
}


// ---------- readFile ----------
string readFile(string path)
{
	Int32_t file = -1, dataCnt = 0;
	Int8_t *buff;
	string data;

	file = open(path.c_str(), O_RDONLY);
	if(file < 0)
	{
		perror("Config File Open");
		return "";
	}

	dataCnt = lseek(file, 0, SEEK_END);
	lseek(file, 0, SEEK_SET);

	buff = (Int8_t *)malloc(dataCnt+1);
	if(read(file, buff, dataCnt) < 0)
	{
		perror("Config File Read");
		free(buff);
		return "";
	}
	buff[dataCnt] = 0;

	data = (const Int8_t *)buff;
	free(buff);

	return data;
}


// ---------- load Config file Data ----------
void loadConfigData(void)
{
	json parsedData;
	string data, ipAddr;

	// Open file & read data
	data = readFile(LoadPath + ConfigFile);

	if(data == "")
	{
		cout << "Failed to load config data..." << endl << flush;
		return;
	}

	// load config data
	try
	{
		parsedData = json::parse(data);

		InpPath  = parsedData["Data_SavePath"];


		ipAddr = parsedData["C4I_IPAddr"];
		if(ipAddr != "")
		{
			if(validateIP(ipAddr.c_str()) == false)
			{
				cout << "Please enter valid DL_IPADDR in config file" << endl << flush;
				exit(1);
			}
			C4I_IPAddr = ipAddr;
		}

		C4I_Port			= parsedData["C4I_Port"];
		AI_Port				= parsedData["AI_Port"];

		IR_VideoSrc			= parsedData["IR_VideoSrc"];
		EO_VideoSrc			= parsedData["EO_VideoSrc"];

			IR_Detect_Model		= parsedData["IR_Detect_Model"];
			EO_Detect_Model		= parsedData["EO_Detect_Model"];

		cout << "Config data loaded successfully..." << endl << flush;
	}
	catch(exception &e)
	{
		cerr << "Config data : " <<  e.what() << endl;
	}

	return;
}


// ---------- Check User CommandLine Flags ----------
void checkFlags(Int32_t argc, Int8_t *argv[])
{
	Int32_t ArgcCnt = 0;
	string Arg;
	string DetectorChoice;

	for(ArgcCnt = 1; ArgcCnt < argc; ArgcCnt++)
	{
		Arg = string(argv[ArgcCnt]);

		if(Arg == "-S")
		{
			AutoSaveVideo = true;
		}

		else if(Arg == "-T")
		{
			TrackingFlag = true;
		}

		else if(Arg == "-CT")
		{
			ClassicalTrackingFlag = true;
		}

		else if(Arg == "-C")
		{
			CentreTarget = true;
		}

		else if(Arg == "-CR")
		{
			CentreTarget = false;
		}

		else if(Arg == "-DF")
		{
			DisplayFrame = true;
		}

		else if(Arg == "-BP")
		{
			BirdPlaneDataFlag = true;
		}

		else if(Arg == "-IR")
		{
			AI_Type = 1;
		}

		else if(Arg == "-EO")
		{
			AI_Type = 2;
		}

		else if(Arg == "-AI")
		{
			ClassicalDetectionFlag = false;
		}

		else if(Arg == "-CL")
		{
			ClassicalDetectionFlag = true;
		}

		else if(Arg == "-CD")
		{
			ArgcCnt++;
			if(ArgcCnt < argc && validateInt(argv[ArgcCnt]) == true)
			{
				ClassicalDetectorType = atoi(argv[ArgcCnt]);
				if(ClassicalDetectorType < 1 || ClassicalDetectorType > 3)
				{
					cout << "Classical detector must be 1, 2, or 3." << endl << flush;
					exit(1);
				}
				ClassicalDetectionFlag = true;
			}
			else
			{
				cout << "Please provide detector id after '-CD' like '-CD 2'" << endl << flush;
				exit(1);
			}
		}

		else if(Arg == "-SV")
		{
			SingleVideo = true;
		}

		else if(Arg == "-PT")
		{
			ArgcCnt++;
			if(ArgcCnt < argc)
			{
				ParentPath = argv[ArgcCnt];
				ParentPath = ParentPath + (ParentPath[ParentPath.size()-1] == '/' ? "" : "/");
			}
			else
			{
				cout << "Please provide path after like '-PT Path'" << endl << flush;
				exit(1);
			}
		}

		else
		{
			cout << "!!!!!!!! Given Wrong Parameters  !!!!!!!!" << endl;

				cout << "Save Video                         : -S" << endl;
				cout << "Start Template Tracking            : -T" << endl;
				cout << "Start Tracking with Classical EO   : -CT" << endl;
				cout << "Center Closest Target (Default)    : -C" << endl;
				cout << "Centroid Target Data               : -CR" << endl;
				cout << "Bird & Plane Track                 : -BP" << endl;
				cout << "Display Video Frames               : -DF" << endl;
				cout << "Single Video No C4I Cmd			: -SV" << endl;
				cout << "Run IR AI Model			        : -IR" << endl;
				cout << "Run EO AI Model                  	: -EO" << endl << endl;
				cout << "Run AI Detection (Default)         : -AI" << endl;
				cout << "Run EO Classical Detection         : -CL" << endl;
				cout << "EO Classical Detector 1/2/3        : -CD <1|2|3>" << endl << endl;
				exit(1);
			}
		}

	if(ClassicalDetectionFlag == true && ClassicalDetectorType == 0)
	{
		cout << "\n--- EO Classical Detection Engine ---\n";
		cout << " [1] Filtered DoG\n";
		cout << " [2] Optimized Hough Circle Transform\n";
		cout << " [3] Hybrid (DoG + Hough Conf Fusion)\n";
		cout << " Select (default 2): ";
		getline(cin, DetectorChoice);

		if(DetectorChoice == "1")
		{
			ClassicalDetectorType = 1;
		}
		else if(DetectorChoice == "3")
		{
			ClassicalDetectorType = 3;
		}
		else
		{
			ClassicalDetectorType = 2;
		}
	}

	if(ClassicalTrackingFlag == true && ClassicalDetectionFlag == false)
	{
		cout << "Note : '-CT' has no effect without '-CL' (Classical EO Detection). Ignoring." << endl << flush;
		ClassicalTrackingFlag = false;
	}

	return;
}