// ============================================================================
// Name        : Classical_Det_EOVideo.h
// ============================================================================

#ifndef CLASSICAL_DET_EOVIDEO_H_
#define CLASSICAL_DET_EOVIDEO_H_

#include "Struct.h"
#include "Includes.h"

void runClassicalEODetection(Mat &VideoFrame, UInt8_t DetectorType, vector<struct _AIData_> &TargetDataArr);

#endif /* CLASSICAL_DET_EOVIDEO_H_ */
