// ============================================================================
// Name        : IRVideoAI.h
// Created On  : 11 Nov 2025
// ============================================================================

#ifndef IRVIDEOAI_H_
#define IRVIDEOAI_H_

// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"

// ---------- Other Flag Variables ----------
extern bool SaveVideo;
extern bool AutoSaveVideo;

// ---------- AI Flag Variables ----------
extern bool CentreTarget;
extern bool TrackingFlag;
extern bool BirdPlaneDataFlag;
extern bool ClassicalDetectionFlag;
extern UInt8_t ClassicalDetectorType;

// ---------- Config Parameters ----------
extern UInt8_t AI_Type;

// ---------- Camera Variables ----------
extern Size IR_Size;
extern Size EO_Size;

// ---------- AI Parameters ----------
extern string IR_Detect_Model;

extern string EO_ClassName[3];
extern string IR_ClassName[4];

// ---------- Data Structures & Buffers ----------
extern union _TgtData_ TgtData;
extern struct _TargetData_ TargetData;

// ---------- Class Declaration ----------
class IRVideoAI
{
private:
    // ---------- Private Variables ----------
    Size Yolov5_DIM;
    Int32_t PadX, PadY;
    float ConfThreshold;
    float IOUThreshold;

    vector<struct _AIData_> TargetDataArr;

    vector<__half> InpBuff;
    vector<__half> OutBuff;

    unique_ptr<IRuntime> runtime;
    unique_ptr<ICudaEngine> engine;
    unique_ptr<IExecutionContext> context;

    vector<void *> Bindings;
    vector<size_t> BindingSizes;
    cudaStream_t Stream;

    // ---------- Template Matching Variables ----------
    UInt32_t TM_NextTrackID;
    UInt32_t MaxTemplateMissedFrames;
    float TempConfThreshold;
    float TemplateSearchScale;
    vector<struct _Template_> TemplateArr;

    // ---------- Private Functions ----------
    size_t getMemorySize(Dims dims, size_t ElementSize);
    bool LoadDetectModel(void);
    void preProcess(Mat VideoFrame, __half *InputBuff);
    void postProcess(vector<__half> &Output, UInt16_t VideoWidth, UInt16_t VideoHeight);
    
    void templateMatch(Mat &VideoFrame); // Template Matching Function
    void drawBoxes(Mat &VideoFrame);

public:
    // ---------- Public Functions ----------
    IRVideoAI(void);
    ~IRVideoAI(void);
    void Run_enqueueV2(Mat &VideoFrame);
};

#endif /* IRVIDEOAI_H_ */
