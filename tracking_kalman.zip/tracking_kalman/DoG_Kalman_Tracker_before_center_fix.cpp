// ============================================================================
// Name        : DoG_Kalman_Tracker.cpp
// Description : DoG Detection + Kalman Target Tracking + Runtime Plot
//
// Usage:
//      ./DoG_Kalman_Tracker -V input.mp4
//      ./DoG_Kalman_Tracker -V input.mp4 -S
//
// Compile:
//      g++ -std=c++17 -O2 DoG_Kalman_Tracker.cpp -o DoG_Kalman_Tracker \
//          $(pkg-config --cflags --libs opencv4)
//
// Controls:
//      ESC / q  : Exit
//      SPACE    : Pause / Resume
//      r        : Reset Kalman tracker
//
// Output with -S:
//
// RunFiles/
// └── YYYY-MM-DD/
//     └── Run_HHMMSS/
//         ├── tracking_output.mp4
//         ├── tracking_plot.mp4
//         ├── tracking_data.csv
//         └── final_tracking_plot.png
//
// ============================================================================

#include <opencv2/opencv.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <ctime>
#include <deque>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

using namespace cv;
using namespace std;

namespace fs = std::filesystem;

// ============================================================================
// Configuration
// ============================================================================

struct DetectorConfig
{
    // 0 = adaptive threshold
    float DOG_THRESHOLD = 0.0f;

    float DOG_STDDEV_FACTOR = 2.0f;

    float MIN_DOG_THRESHOLD = 4.0f;
    float MAX_DOG_THRESHOLD = 40.0f;

    double MIN_CONTOUR_AREA = 2.0;
    double MIN_AREA_FRAC = 0.000002;

    double MAX_AREA_FRAC = 0.02;

    double MIN_ASPECT = 0.15;
    double MAX_ASPECT = 6.0;

    double MIN_EXTENT = 0.15;

    // 1.0 means full image height is allowed.
    double MAX_VERTICAL_POSITION = 1.0;

    float NMS_IOU_THRESHOLD = 0.18f;

    // Association between DoG detection and Kalman prediction.
    float ASSOCIATION_DISTANCE = 100.0f;

    // Maximum frames Kalman can run without a measurement.
    int MAX_MISSED_FRAMES = 20;

    // Number of history points.
    size_t MAX_HISTORY = 300;
};

// ============================================================================
// Detection Structure
// ============================================================================

struct Detection
{
    Rect BoundingBox;
    Point2f Center;
    float Confidence = 0.0f;
};

// ============================================================================
// Tracking Record
// ============================================================================

struct TrackingRecord
{
    int FrameNumber = 0;

    double TimeSec = 0.0;

    bool DetectionAvailable = false;

    Point2f Measurement = Point2f(-1, -1);
    Point2f Prediction = Point2f(-1, -1);
    Point2f Estimate = Point2f(-1, -1);

    float Error = -1.0f;

    Rect BoundingBox;

    float Confidence = 0.0f;
};

// ============================================================================
// Utility
// ============================================================================

static string getDateString()
{
    auto Now = chrono::system_clock::now();
    time_t TimeNow = chrono::system_clock::to_time_t(Now);

    tm LocalTime{};

#ifdef _WIN32
    localtime_s(&LocalTime, &TimeNow);
#else
    localtime_r(&TimeNow, &LocalTime);
#endif

    stringstream SS;

    SS << put_time(&LocalTime, "%Y-%m-%d");

    return SS.str();
}

// ============================================================================

static string getTimeString()
{
    auto Now = chrono::system_clock::now();
    time_t TimeNow = chrono::system_clock::to_time_t(Now);

    tm LocalTime{};

#ifdef _WIN32
    localtime_s(&LocalTime, &TimeNow);
#else
    localtime_r(&TimeNow, &LocalTime);
#endif

    stringstream SS;

    SS << put_time(&LocalTime, "%H%M%S");

    return SS.str();
}

// ============================================================================
// Create Run Directory
// ============================================================================

static string createRunDirectory()
{
    string DateFolder =
        "RunFiles/" + getDateString();

    string RunFolder =
        DateFolder + "/Run_" + getTimeString();

    fs::create_directories(RunFolder);

    return RunFolder;
}

// ============================================================================
// IOU
// ============================================================================

static float rectIOU(
    const Rect& A,
    const Rect& B)
{
    int X1 = max(A.x, B.x);
    int Y1 = max(A.y, B.y);

    int X2 = min(
        A.x + A.width,
        B.x + B.width);

    int Y2 = min(
        A.y + A.height,
        B.y + B.height);

    int W = max(0, X2 - X1);
    int H = max(0, Y2 - Y1);

    float Intersection =
        static_cast<float>(W * H);

    float AreaA =
        static_cast<float>(
            A.width * A.height);

    float AreaB =
        static_cast<float>(
            B.width * B.height);

    float Union =
        AreaA +
        AreaB -
        Intersection +
        1e-6f;

    return Intersection / Union;
}

// ============================================================================
// NMS
// ============================================================================

static vector<Detection> applyNMS(
    vector<Detection> Detections,
    float IOUThreshold)
{
    vector<Detection> Result;

    if (Detections.empty())
    {
        return Result;
    }

    sort(
        Detections.begin(),
        Detections.end(),
        [](const Detection& A,
            const Detection& B)
        {
            return A.Confidence >
                B.Confidence;
        });

    vector<bool> Suppressed(
        Detections.size(),
        false);

    for (size_t i = 0;
        i < Detections.size();
        i++)
    {
        if (Suppressed[i])
        {
            continue;
        }

        Result.push_back(
            Detections[i]);

        for (size_t j = i + 1;
            j < Detections.size();
            j++)
        {
            if (Suppressed[j])
            {
                continue;
            }

            if (rectIOU(
                Detections[i].BoundingBox,
                Detections[j].BoundingBox) >
                IOUThreshold)
            {
                Suppressed[j] = true;
            }
        }
    }

    return Result;
}

// ============================================================================
// DoG Detector
// ============================================================================

class DoGDetector
{
private:

    DetectorConfig Config;

    // ------------------------------------------------------------------------
    // Adaptive DoG Threshold
    // ------------------------------------------------------------------------

    float adaptiveResponseThreshold(
        const Mat& Response)
    {
        if (Config.DOG_THRESHOLD > 0.0f)
        {
            return Config.DOG_THRESHOLD;
        }

        Mat AbsResponse;

        absdiff(
            Response,
            Scalar(0),
            AbsResponse);

        Scalar MeanValue;
        Scalar StdDevValue;

        meanStdDev(
            AbsResponse,
            MeanValue,
            StdDevValue);

        double Threshold =
            MeanValue[0] +
            Config.DOG_STDDEV_FACTOR *
            StdDevValue[0];

        Threshold =
            std::clamp(
                Threshold,
                static_cast<double>(
                    Config.MIN_DOG_THRESHOLD),
                static_cast<double>(
                    Config.MAX_DOG_THRESHOLD));

        return static_cast<float>(
            Threshold);
    }

    // ------------------------------------------------------------------------
    // Positive + Negative Blob Mask
    // ------------------------------------------------------------------------

    Mat blobMask(
        const Mat& Response,
        float ThresholdValue)
    {
        Mat Positive;
        Mat Negative;

        Mat Positive8;
        Mat Negative8;

        Mat PositiveMask;
        Mat NegativeMask;

        Mat Output;

        max(
            Response,
            0,
            Positive);

        max(
            -Response,
            0,
            Negative);

        Positive.convertTo(
            Positive8,
            CV_8U);

        Negative.convertTo(
            Negative8,
            CV_8U);

        threshold(
            Positive8,
            PositiveMask,
            ThresholdValue,
            255,
            THRESH_BINARY);

        threshold(
            Negative8,
            NegativeMask,
            ThresholdValue,
            255,
            THRESH_BINARY);

        bitwise_or(
            PositiveMask,
            NegativeMask,
            Output);

        return Output;
    }

    // ------------------------------------------------------------------------
    // Morphological Cleaning
    // ------------------------------------------------------------------------

    void cleanupMask(
        Mat& Mask)
    {
        if (Mask.empty())
        {
            return;
        }

        int MinDimension =
            max(
                1,
                min(
                    Mask.cols,
                    Mask.rows));

        int KernelSize =
            (MinDimension >= 720)
            ? 5
            : 3;

        Mat Kernel =
            getStructuringElement(
                MORPH_ELLIPSE,
                Size(
                    KernelSize,
                    KernelSize));

        morphologyEx(
            Mask,
            Mask,
            MORPH_OPEN,
            Kernel);

        morphologyEx(
            Mask,
            Mask,
            MORPH_CLOSE,
            Kernel);
    }

    // ------------------------------------------------------------------------
    // Centre Prior
    // ------------------------------------------------------------------------

    double priorWeight(
        const Rect& Box,
        Size ImageSize)
    {
        double DX =
            (Box.x +
                Box.width * 0.5) -
            ImageSize.width * 0.5;

        double DY =
            (Box.y +
                Box.height * 0.5) -
            ImageSize.height * 0.5;

        double MaxDistance =
            max(
                1.0,
                hypot(
                    ImageSize.width * 0.5,
                    ImageSize.height * 0.5));

        return
            0.75 +
            (1.0 -
                min(
                    hypot(DX, DY) /
                    MaxDistance,
                    1.0)) *
            0.35;
    }

public:

    explicit DoGDetector(
        const DetectorConfig& Cfg)
        : Config(Cfg)
    {
    }

    // ========================================================================
    // Detection
    // ========================================================================

    vector<Detection> detect(
        const Mat& InputFrame,
        Mat* DebugMask = nullptr)
    {
        vector<Detection> Candidates;

        if (InputFrame.empty())
        {
            return Candidates;
        }

        // --------------------------------------------------------------------
        // Keep same concept as original implementation:
        // EO/full-HD frames are processed at 640 width.
        // --------------------------------------------------------------------

        Mat DetectorFrame;

        double ScaleX = 1.0;
        double ScaleY = 1.0;

        if (InputFrame.cols > 640)
        {
            const int DetectorWidth = 640;

            const int DetectorHeight =
                cvRound(
                    static_cast<double>(
                        InputFrame.rows) *
                    DetectorWidth /
                    InputFrame.cols);

            resize(
                InputFrame,
                DetectorFrame,
                Size(
                    DetectorWidth,
                    DetectorHeight),
                0.0,
                0.0,
                INTER_AREA);

            ScaleX =
                static_cast<double>(
                    InputFrame.cols) /
                DetectorFrame.cols;

            ScaleY =
                static_cast<double>(
                    InputFrame.rows) /
                DetectorFrame.rows;
        }
        else
        {
            DetectorFrame =
                InputFrame;
        }

        // --------------------------------------------------------------------
        // Gray Conversion
        // --------------------------------------------------------------------

        Mat GrayFrame;

        if (DetectorFrame.channels() == 1)
        {
            DetectorFrame.copyTo(
                GrayFrame);
        }
        else if (DetectorFrame.channels() == 3)
        {
            cvtColor(
                DetectorFrame,
                GrayFrame,
                COLOR_BGR2GRAY);
        }
        else if (DetectorFrame.channels() == 4)
        {
            cvtColor(
                DetectorFrame,
                GrayFrame,
                COLOR_BGRA2GRAY);
        }
        else
        {
            cerr
                << "[DoG] Unsupported channel count: "
                << DetectorFrame.channels()
                << endl;

            return Candidates;
        }

        // --------------------------------------------------------------------
        // Dual Scale DoG
        //
        // Scale A:
        //      Gaussian 3x3 sigma 0.8
        //      Gaussian 7x7 sigma 2.0
        //
        // Scale B:
        //      Gaussian 5x5 sigma 1.5
        //      Gaussian 11x11 sigma 3.5
        // --------------------------------------------------------------------

        Mat G1A;
        Mat G2A;
        Mat DogA;

        Mat G1B;
        Mat G2B;
        Mat DogB;

        GaussianBlur(
            GrayFrame,
            G1A,
            Size(3, 3),
            0.8);

        GaussianBlur(
            GrayFrame,
            G2A,
            Size(7, 7),
            2.0);

        subtract(
            G1A,
            G2A,
            DogA,
            noArray(),
            CV_16S);

        GaussianBlur(
            GrayFrame,
            G1B,
            Size(5, 5),
            1.5);

        GaussianBlur(
            GrayFrame,
            G2B,
            Size(11, 11),
            3.5);

        subtract(
            G1B,
            G2B,
            DogB,
            noArray(),
            CV_16S);

        // --------------------------------------------------------------------
        // Convert DoG to Float
        // --------------------------------------------------------------------

        Mat DogA32;
        Mat DogB32;

        DogA.convertTo(
            DogA32,
            CV_32F);

        DogB.convertTo(
            DogB32,
            CV_32F);

        Mat AbsA;
        Mat AbsB;
        Mat DogConfidence;

        absdiff(
            DogA32,
            Scalar(0),
            AbsA);

        absdiff(
            DogB32,
            Scalar(0),
            AbsB);

        max(
            AbsA,
            AbsB,
            DogConfidence);

        // --------------------------------------------------------------------
        // Adaptive threshold
        // --------------------------------------------------------------------

        float DogThreshold =
            adaptiveResponseThreshold(
                DogConfidence);

        Mat MaskA =
            blobMask(
                DogA32,
                DogThreshold);

        Mat MaskB =
            blobMask(
                DogB32,
                DogThreshold);

        Mat CombinedMask;

        bitwise_or(
            MaskA,
            MaskB,
            CombinedMask);

        cleanupMask(
            CombinedMask);

        if (DebugMask != nullptr)
        {
            CombinedMask.copyTo(
                *DebugMask);
        }

        // --------------------------------------------------------------------
        // Contours
        // --------------------------------------------------------------------

        vector<vector<Point>> Contours;

        findContours(
            CombinedMask,
            Contours,
            RETR_EXTERNAL,
            CHAIN_APPROX_SIMPLE);

        double FrameArea =
            max(
                1.0,
                static_cast<double>(
                    GrayFrame.cols) *
                GrayFrame.rows);

        double MinimumArea =
            max(
                Config.MIN_CONTOUR_AREA,
                FrameArea *
                Config.MIN_AREA_FRAC);

        double MaximumAreaPercent =
            Config.MAX_AREA_FRAC *
            100.0;

        // --------------------------------------------------------------------
        // Candidate Generation
        // --------------------------------------------------------------------

        for (const auto& Contour :
            Contours)
        {
            double Area =
                contourArea(
                    Contour);

            if (Area <= MinimumArea)
            {
                continue;
            }

            Rect Box =
                boundingRect(
                    Contour);

            if (Box.width <= 0 ||
                Box.height <= 0)
            {
                continue;
            }

            if (Box.x < 0 ||
                Box.y < 0 ||
                Box.x + Box.width >
                GrayFrame.cols ||
                Box.y + Box.height >
                GrayFrame.rows)
            {
                continue;
            }

            if (Box.y >
                GrayFrame.rows *
                Config.MAX_VERTICAL_POSITION)
            {
                continue;
            }

            double Aspect =
                static_cast<double>(
                    Box.width) /
                Box.height;

            double Extent =
                Area /
                (Box.width *
                    Box.height);

            double RelativeArea =
                (Area /
                    FrameArea) *
                100.0;

            if (!(Config.MIN_ASPECT <
                Aspect &&
                Aspect <
                Config.MAX_ASPECT &&
                Extent >
                Config.MIN_EXTENT &&
                RelativeArea <
                MaximumAreaPercent))
            {
                continue;
            }

            double DogMean =
                mean(
                    DogConfidence(Box))[0];

            double DogNorm =
                min(
                    DogMean / 50.0,
                    1.0);

            double Score =
                DogNorm *
                priorWeight(
                    Box,
                    GrayFrame.size());

            Detection Det;

            Det.Confidence =
                static_cast<float>(
                    std::clamp(
                        0.40 +
                        Score *
                        0.55,
                        0.0,
                        0.99));

            // ----------------------------------------------------------------
            // Restore original image coordinates
            // ----------------------------------------------------------------

            Det.BoundingBox.x =
                cvRound(
                    Box.x *
                    ScaleX);

            Det.BoundingBox.y =
                cvRound(
                    Box.y *
                    ScaleY);

            Det.BoundingBox.width =
                max(
                    1,
                    cvRound(
                        Box.width *
                        ScaleX));

            Det.BoundingBox.height =
                max(
                    1,
                    cvRound(
                        Box.height *
                        ScaleY));

            Det.BoundingBox &=
                Rect(
                    0,
                    0,
                    InputFrame.cols,
                    InputFrame.rows);

            Det.Center =
                Point2f(
                    Det.BoundingBox.x +
                    Det.BoundingBox.width *
                    0.5f,
                    Det.BoundingBox.y +
                    Det.BoundingBox.height *
                    0.5f);

            Candidates.push_back(
                Det);
        }

        return applyNMS(
            Candidates,
            Config.NMS_IOU_THRESHOLD);
    }
};

// ============================================================================
// Kalman Target Tracker
// ============================================================================

class KalmanTargetTracker
{
private:

    KalmanFilter KF;

    bool Initialized = false;

    int MissedFrames = 0;

    int MaxMissedFrames = 20;

    Point2f Prediction =
        Point2f(-1, -1);

    Point2f Estimate =
        Point2f(-1, -1);

public:

    explicit KalmanTargetTracker(
        int MaxMissed = 20)
    {
        MaxMissedFrames =
            MaxMissed;
    }

    // ========================================================================
    // Initialize
    // ========================================================================

    void initialize(
        const Point2f& Point)
    {
        // State:
        //
        // [ x  ]
        // [ y  ]
        // [ vx ]
        // [ vy ]

        KF.init(
            4,
            2,
            0,
            CV_32F);

        KF.transitionMatrix =
            (Mat_<float>(4, 4) <<
                1, 0, 1, 0,
                0, 1, 0, 1,
                0, 0, 1, 0,
                0, 0, 0, 1);

        KF.measurementMatrix =
            (Mat_<float>(2, 4) <<
                1, 0, 0, 0,
                0, 1, 0, 0);

        setIdentity(
            KF.processNoiseCov,
            Scalar::all(1e-2));

        setIdentity(
            KF.measurementNoiseCov,
            Scalar::all(5.0));

        setIdentity(
            KF.errorCovPost,
            Scalar::all(1.0));

        KF.statePost =
            (Mat_<float>(4, 1) <<
                Point.x,
                Point.y,
                0.0f,
                0.0f);

        Prediction = Point;
        Estimate = Point;

        MissedFrames = 0;
        Initialized = true;

        cout
            << "[Kalman] Initialized at ("
            << Point.x
            << ", "
            << Point.y
            << ")"
            << endl;
    }

    // ========================================================================
    // Reset
    // ========================================================================

    void reset()
    {
        Initialized = false;

        MissedFrames = 0;

        Prediction =
            Point2f(-1, -1);

        Estimate =
            Point2f(-1, -1);

        cout
            << "[Kalman] Tracker reset."
            << endl;
    }

    // ========================================================================
    // Predict
    // ========================================================================

    bool predict()
    {
        if (!Initialized)
        {
            return false;
        }

        Mat State =
            KF.predict();

        Prediction =
            Point2f(
                State.at<float>(0),
                State.at<float>(1));

        Estimate =
            Prediction;

        return true;
    }

    // ========================================================================
    // Correct
    // ========================================================================

    Point2f correct(
        const Point2f& Measurement)
    {
        if (!Initialized)
        {
            initialize(
                Measurement);

            return Measurement;
        }

        Mat MeasurementMat =
            (Mat_<float>(2, 1) <<
                Measurement.x,
                Measurement.y);

        Mat State =
            KF.correct(
                MeasurementMat);

        Estimate =
            Point2f(
                State.at<float>(0),
                State.at<float>(1));

        MissedFrames = 0;

        return Estimate;
    }

    // ========================================================================
    // Miss
    // ========================================================================

    void markMissed()
    {
        if (!Initialized)
        {
            return;
        }

        MissedFrames++;

        Estimate =
            Prediction;

        if (MissedFrames >
            MaxMissedFrames)
        {
            cout
                << "[Kalman] Target lost after "
                << MissedFrames
                << " missed frames."
                << endl;

            reset();
        }
    }

    bool isInitialized() const
    {
        return Initialized;
    }

    Point2f getPrediction() const
    {
        return Prediction;
    }

    Point2f getEstimate() const
    {
        return Estimate;
    }

    int getMissedFrames() const
    {
        return MissedFrames;
    }
};

// ============================================================================
// Select Detection
//
// First acquisition:
//      Select target nearest frame centre.
//
// Tracking:
//      Select DoG detection nearest Kalman prediction.
// ============================================================================

static bool selectDetection(
    const vector<Detection>& Detections,
    const KalmanTargetTracker& Tracker,
    const Size& FrameSize,
    float AssociationDistance,
    Detection& Selected)
{
    if (Detections.empty())
    {
        return false;
    }

    float BestDistance =
        numeric_limits<float>::max();

    int BestIndex = -1;

    // ------------------------------------------------------------------------
    // Existing tracker -> associate against prediction
    // ------------------------------------------------------------------------

    if (Tracker.isInitialized())
    {
        Point2f Reference =
            Tracker.getPrediction();

        for (size_t i = 0;
            i < Detections.size();
            i++)
        {
            float Distance =
                static_cast<float>(
                    norm(
                        Detections[i].Center -
                        Reference));

            if (Distance <
                BestDistance)
            {
                BestDistance =
                    Distance;

                BestIndex =
                    static_cast<int>(i);
            }
        }

        if (BestIndex >= 0 &&
            BestDistance <=
            AssociationDistance)
        {
            Selected =
                Detections[BestIndex];

            return true;
        }

        return false;
    }

    // ------------------------------------------------------------------------
    // ------------------------------------------------------------------------
    // Initial acquisition:
    // Select DoG detection NEAREST TO FRAME CENTRE.
    // Same selection concept used in ClassicalDetector.
    // ------------------------------------------------------------------------

    const Point2f FrameCentre(
        FrameSize.width * 0.5f,
        FrameSize.height * 0.5f);

    BestDistance =
        numeric_limits<float>::max();

    BestIndex = -1;

    for (size_t i = 0;
         i < Detections.size();
         ++i)
    {
        const float DX =
            Detections[i].Center.x -
            FrameCentre.x;

        const float DY =
            Detections[i].Center.y -
            FrameCentre.y;

        const float Distance =
            std::hypot(DX, DY);

        if (Distance < BestDistance)
        {
            BestDistance = Distance;

            BestIndex =
                static_cast<int>(i);
        }
    }

    if (BestIndex >= 0)
    {
        Selected =
            Detections[
                static_cast<size_t>(
                    BestIndex)];

        cout
            << "[ACQUIRE] Nearest-to-centre target"
            << " | Center=("
            << Selected.Center.x
            << ", "
            << Selected.Center.y
            << ")"
            << " | DistanceFromCentre="
            << BestDistance
            << " px"
            << endl;

        return true;
    }

    return false;
}

// ============================================================================
// Draw Corner Box
// ============================================================================

static void drawCornerBox(
    Mat& Frame,
    const Rect& Box,
    const Scalar& Color,
    int Thickness = 2,
    int CornerLength = 20)
{
    if (Box.width <= 0 ||
        Box.height <= 0)
    {
        return;
    }

    int X1 = Box.x;
    int Y1 = Box.y;

    int X2 =
        Box.x +
        Box.width -
        1;

    int Y2 =
        Box.y +
        Box.height -
        1;

    int LX =
        min(
            CornerLength,
            Box.width / 3);

    int LY =
        min(
            CornerLength,
            Box.height / 3);

    LX = max(1, LX);
    LY = max(1, LY);

    line(Frame, Point(X1, Y1), Point(X1 + LX, Y1), Color, Thickness);
    line(Frame, Point(X1, Y1), Point(X1, Y1 + LY), Color, Thickness);

    line(Frame, Point(X2, Y1), Point(X2 - LX, Y1), Color, Thickness);
    line(Frame, Point(X2, Y1), Point(X2, Y1 + LY), Color, Thickness);

    line(Frame, Point(X1, Y2), Point(X1 + LX, Y2), Color, Thickness);
    line(Frame, Point(X1, Y2), Point(X1, Y2 - LY), Color, Thickness);

    line(Frame, Point(X2, Y2), Point(X2 - LX, Y2), Color, Thickness);
    line(Frame, Point(X2, Y2), Point(X2, Y2 - LY), Color, Thickness);
}

// ============================================================================
// Draw Tracking Overlay
// ============================================================================

static void drawTrackingOverlay(
    Mat& Frame,
    const TrackingRecord& Record,
    const deque<Point2f>& MeasurementHistory,
    const deque<Point2f>& EstimateHistory)
{
    // ------------------------------------------------------------------------
    // DoG measurement trajectory
    // ------------------------------------------------------------------------

    for (size_t i = 1;
        i < MeasurementHistory.size();
        i++)
    {
        if (MeasurementHistory[i - 1].x < 0 ||
            MeasurementHistory[i].x < 0)
        {
            continue;
        }

        line(
            Frame,
            MeasurementHistory[i - 1],
            MeasurementHistory[i],
            Scalar(0, 255, 0),
            1,
            LINE_AA);
    }

    // ------------------------------------------------------------------------
    // Kalman estimate trajectory
    // ------------------------------------------------------------------------

    for (size_t i = 1;
        i < EstimateHistory.size();
        i++)
    {
        if (EstimateHistory[i - 1].x < 0 ||
            EstimateHistory[i].x < 0)
        {
            continue;
        }

        line(
            Frame,
            EstimateHistory[i - 1],
            EstimateHistory[i],
            Scalar(255, 0, 0),
            2,
            LINE_AA);
    }

    // ------------------------------------------------------------------------
    // DoG measurement
    // ------------------------------------------------------------------------

    if (Record.DetectionAvailable)
    {
        drawCornerBox(
            Frame,
            Record.BoundingBox,
            Scalar(0, 255, 0),
            2,
            20);

        circle(
            Frame,
            Record.Measurement,
            6,
            Scalar(0, 255, 0),
            -1,
            LINE_AA);

        putText(
            Frame,
            "DoG Measurement",
            Point(
                static_cast<int>(
                    Record.Measurement.x) + 10,
                static_cast<int>(
                    Record.Measurement.y) - 10),
            FONT_HERSHEY_SIMPLEX,
            0.45,
            Scalar(0, 255, 0),
            1,
            LINE_AA);
    }

    // ------------------------------------------------------------------------
    // Kalman Prediction
    // ------------------------------------------------------------------------

    if (Record.Prediction.x >= 0 &&
        Record.Prediction.y >= 0)
    {
        circle(
            Frame,
            Record.Prediction,
            8,
            Scalar(0, 0, 255),
            2,
            LINE_AA);

        putText(
            Frame,
            "KF Prediction",
            Point(
                static_cast<int>(
                    Record.Prediction.x) + 10,
                static_cast<int>(
                    Record.Prediction.y) + 18),
            FONT_HERSHEY_SIMPLEX,
            0.45,
            Scalar(0, 0, 255),
            1,
            LINE_AA);
    }

    // ------------------------------------------------------------------------
    // Corrected estimate
    // ------------------------------------------------------------------------

    if (Record.Estimate.x >= 0 &&
        Record.Estimate.y >= 0)
    {
        // drawMarker(
        //     Frame,
        //     Record.Estimate,
        //     Scalar(255, 0, 0),
        //     MARKER_CROSS,
        //     18,
        //     2,
        //     LINE_AA);

        putText(
            Frame,
            "KF Estimate",
            Point(
                static_cast<int>(
                    Record.Estimate.x) + 10,
                static_cast<int>(
                    Record.Estimate.y) + 35),
            FONT_HERSHEY_SIMPLEX,
            0.45,
            Scalar(255, 0, 0),
            1,
            LINE_AA);
    }

    // ------------------------------------------------------------------------
    // Measurement -> Estimate error
    // ------------------------------------------------------------------------

    if (Record.DetectionAvailable &&
        Record.Estimate.x >= 0)
    {
        line(
            Frame,
            Record.Measurement,
            Record.Estimate,
            Scalar(0, 255, 255),
            1,
            LINE_AA);
    }

    // ------------------------------------------------------------------------
    // Information panel
    // ------------------------------------------------------------------------

    rectangle(
        Frame,
        Point(10, 10),
        Point(400, 145),
        Scalar(0, 0, 0),
        FILLED);

    stringstream SS;

    SS << "Frame: "
        << Record.FrameNumber;

    putText(
        Frame,
        SS.str(),
        Point(20, 35),
        FONT_HERSHEY_SIMPLEX,
        0.55,
        Scalar(255, 255, 255),
        1,
        LINE_AA);

    SS.str("");
    SS.clear();

    SS << fixed
        << setprecision(2)
        << "Time: "
        << Record.TimeSec
        << " sec";

    putText(
        Frame,
        SS.str(),
        Point(20, 58),
        FONT_HERSHEY_SIMPLEX,
        0.55,
        Scalar(255, 255, 255),
        1,
        LINE_AA);

    if (Record.DetectionAvailable)
    {
        SS.str("");
        SS.clear();

        SS << fixed
            << setprecision(1)
            << "DoG: ("
            << Record.Measurement.x
            << ", "
            << Record.Measurement.y
            << ")";

        putText(
            Frame,
            SS.str(),
            Point(20, 81),
            FONT_HERSHEY_SIMPLEX,
            0.5,
            Scalar(0, 255, 0),
            1,
            LINE_AA);
    }
    else
    {
        putText(
            Frame,
            "DoG: MISSED",
            Point(20, 81),
            FONT_HERSHEY_SIMPLEX,
            0.5,
            Scalar(0, 0, 255),
            1,
            LINE_AA);
    }

    if (Record.Estimate.x >= 0)
    {
        SS.str("");
        SS.clear();

        SS << fixed
            << setprecision(1)
            << "KF: ("
            << Record.Estimate.x
            << ", "
            << Record.Estimate.y
            << ")";

        putText(
            Frame,
            SS.str(),
            Point(20, 104),
            FONT_HERSHEY_SIMPLEX,
            0.5,
            Scalar(255, 0, 0),
            1,
            LINE_AA);
    }

    if (Record.Error >= 0)
    {
        SS.str("");
        SS.clear();

        SS << fixed
            << setprecision(2)
            << "Error: "
            << Record.Error
            << " px";

        putText(
            Frame,
            SS.str(),
            Point(20, 127),
            FONT_HERSHEY_SIMPLEX,
            0.5,
            Scalar(0, 255, 255),
            1,
            LINE_AA);
    }
}

// ============================================================================
// Runtime Plot
//
// Top    : X position vs frame
// Bottom : Y position vs frame
// ============================================================================

static Mat createTrackingPlot(
    const deque<TrackingRecord>& History,
    int Width = 900,
    int Height = 600)
{
    Mat Plot(
        Height,
        Width,
        CV_8UC3,
        Scalar(25, 25, 25));

    const int Left = 70;
    const int Right = 30;

    const int Top1 = 60;
    const int Bottom1 = 270;

    const int Top2 = 340;
    const int Bottom2 = 550;

    // ------------------------------------------------------------------------
    // Title
    // ------------------------------------------------------------------------

    putText(
        Plot,
        "DoG Measurement vs Kalman Estimate",
        Point(220, 30),
        FONT_HERSHEY_SIMPLEX,
        0.75,
        Scalar(255, 255, 255),
        2,
        LINE_AA);

    rectangle(
        Plot,
        Point(Left, Top1),
        Point(Width - Right, Bottom1),
        Scalar(150, 150, 150),
        1);

    rectangle(
        Plot,
        Point(Left, Top2),
        Point(Width - Right, Bottom2),
        Scalar(150, 150, 150),
        1);

    putText(
        Plot,
        "X Position",
        Point(10, Top1 + 20),
        FONT_HERSHEY_SIMPLEX,
        0.45,
        Scalar(255, 255, 255),
        1);

    putText(
        Plot,
        "Y Position",
        Point(10, Top2 + 20),
        FONT_HERSHEY_SIMPLEX,
        0.45,
        Scalar(255, 255, 255),
        1);

    putText(
        Plot,
        "Frame History",
        Point(
            Width / 2 - 50,
            Height - 15),
        FONT_HERSHEY_SIMPLEX,
        0.45,
        Scalar(255, 255, 255),
        1);

    // ------------------------------------------------------------------------
    // Legend
    // ------------------------------------------------------------------------

    line(
        Plot,
        Point(580, 42),
        Point(610, 42),
        Scalar(0, 255, 0),
        2);

    putText(
        Plot,
        "DoG Measurement",
        Point(620, 47),
        FONT_HERSHEY_SIMPLEX,
        0.4,
        Scalar(0, 255, 0),
        1);

    line(
        Plot,
        Point(750, 42),
        Point(780, 42),
        Scalar(255, 0, 0),
        2);

    putText(
        Plot,
        "KF Estimate",
        Point(790, 47),
        FONT_HERSHEY_SIMPLEX,
        0.4,
        Scalar(255, 0, 0),
        1);

    if (History.size() < 2)
    {
        putText(
            Plot,
            "Waiting for tracking data...",
            Point(300, 300),
            FONT_HERSHEY_SIMPLEX,
            0.7,
            Scalar(255, 255, 255),
            1);

        return Plot;
    }

    // ------------------------------------------------------------------------
    // Find ranges
    // ------------------------------------------------------------------------

    float MinX =
        numeric_limits<float>::max();

    float MaxX =
        -numeric_limits<float>::max();

    float MinY =
        numeric_limits<float>::max();

    float MaxY =
        -numeric_limits<float>::max();

    bool HasValue = false;

    for (const auto& R :
        History)
    {
        if (R.DetectionAvailable)
        {
            MinX =
                min(
                    MinX,
                    R.Measurement.x);

            MaxX =
                max(
                    MaxX,
                    R.Measurement.x);

            MinY =
                min(
                    MinY,
                    R.Measurement.y);

            MaxY =
                max(
                    MaxY,
                    R.Measurement.y);

            HasValue = true;
        }

        if (R.Estimate.x >= 0)
        {
            MinX =
                min(
                    MinX,
                    R.Estimate.x);

            MaxX =
                max(
                    MaxX,
                    R.Estimate.x);

            MinY =
                min(
                    MinY,
                    R.Estimate.y);

            MaxY =
                max(
                    MaxY,
                    R.Estimate.y);

            HasValue = true;
        }
    }

    if (!HasValue)
    {
        return Plot;
    }

    if (fabs(MaxX - MinX) < 1.0f)
    {
        MinX -= 1.0f;
        MaxX += 1.0f;
    }

    if (fabs(MaxY - MinY) < 1.0f)
    {
        MinY -= 1.0f;
        MaxY += 1.0f;
    }

    // Add some vertical margin.

    float XMargin =
        (MaxX - MinX) *
        0.10f;

    float YMargin =
        (MaxY - MinY) *
        0.10f;

    MinX -= XMargin;
    MaxX += XMargin;

    MinY -= YMargin;
    MaxY += YMargin;

    int PlotWidth =
        Width -
        Left -
        Right;

    auto ConvertX =
        [&](size_t Index)
        {
            return Left +
                static_cast<int>(
                    static_cast<double>(Index) /
                    std::max<size_t>(
                        static_cast<size_t>(1),
                        History.size() - 1) *
                    PlotWidth);
        };

    auto ConvertValue =
        [](float Value,
            float Minimum,
            float Maximum,
            int Top,
            int Bottom)
        {
            float Normalized =
                (Value - Minimum) /
                (Maximum - Minimum);

            return Bottom -
                static_cast<int>(
                    Normalized *
                    (Bottom - Top));
        };

    // ------------------------------------------------------------------------
    // Grid
    // ------------------------------------------------------------------------

    for (int i = 1;
        i < 5;
        i++)
    {
        int Y =
            Top1 +
            i *
            (Bottom1 - Top1) /
            5;

        line(
            Plot,
            Point(Left, Y),
            Point(Width - Right, Y),
            Scalar(60, 60, 60),
            1);

        Y =
            Top2 +
            i *
            (Bottom2 - Top2) /
            5;

        line(
            Plot,
            Point(Left, Y),
            Point(Width - Right, Y),
            Scalar(60, 60, 60),
            1);
    }

    // ------------------------------------------------------------------------
    // Plot data
    // ------------------------------------------------------------------------

    for (size_t i = 1;
        i < History.size();
        i++)
    {
        int PX1 =
            ConvertX(i - 1);

        int PX2 =
            ConvertX(i);

        const TrackingRecord& Previous =
            History[i - 1];

        const TrackingRecord& Current =
            History[i];

        // --------------------------------------------------------------------
        // Measurement X
        // --------------------------------------------------------------------

        if (Previous.DetectionAvailable &&
            Current.DetectionAvailable)
        {
            int Y1 =
                ConvertValue(
                    Previous.Measurement.x,
                    MinX,
                    MaxX,
                    Top1,
                    Bottom1);

            int Y2 =
                ConvertValue(
                    Current.Measurement.x,
                    MinX,
                    MaxX,
                    Top1,
                    Bottom1);

            line(
                Plot,
                Point(PX1, Y1),
                Point(PX2, Y2),
                Scalar(0, 255, 0),
                2,
                LINE_AA);

            // --------------------------------------------------------------
            // Measurement Y
            // --------------------------------------------------------------

            Y1 =
                ConvertValue(
                    Previous.Measurement.y,
                    MinY,
                    MaxY,
                    Top2,
                    Bottom2);

            Y2 =
                ConvertValue(
                    Current.Measurement.y,
                    MinY,
                    MaxY,
                    Top2,
                    Bottom2);

            line(
                Plot,
                Point(PX1, Y1),
                Point(PX2, Y2),
                Scalar(0, 255, 0),
                2,
                LINE_AA);
        }

        // --------------------------------------------------------------------
        // Kalman X
        // --------------------------------------------------------------------

        if (Previous.Estimate.x >= 0 &&
            Current.Estimate.x >= 0)
        {
            int Y1 =
                ConvertValue(
                    Previous.Estimate.x,
                    MinX,
                    MaxX,
                    Top1,
                    Bottom1);

            int Y2 =
                ConvertValue(
                    Current.Estimate.x,
                    MinX,
                    MaxX,
                    Top1,
                    Bottom1);

            line(
                Plot,
                Point(PX1, Y1),
                Point(PX2, Y2),
                Scalar(255, 0, 0),
                2,
                LINE_AA);

            // --------------------------------------------------------------
            // Kalman Y
            // --------------------------------------------------------------

            Y1 =
                ConvertValue(
                    Previous.Estimate.y,
                    MinY,
                    MaxY,
                    Top2,
                    Bottom2);

            Y2 =
                ConvertValue(
                    Current.Estimate.y,
                    MinY,
                    MaxY,
                    Top2,
                    Bottom2);

            line(
                Plot,
                Point(PX1, Y1),
                Point(PX2, Y2),
                Scalar(255, 0, 0),
                2,
                LINE_AA);
        }
    }

    // ------------------------------------------------------------------------
    // Min / Max labels
    // ------------------------------------------------------------------------

    stringstream SS;

    SS << fixed
        << setprecision(0)
        << MaxX;

    putText(
        Plot,
        SS.str(),
        Point(5, Top1 + 5),
        FONT_HERSHEY_SIMPLEX,
        0.4,
        Scalar(200, 200, 200),
        1);

    SS.str("");
    SS.clear();

    SS << fixed
        << setprecision(0)
        << MinX;

    putText(
        Plot,
        SS.str(),
        Point(5, Bottom1),
        FONT_HERSHEY_SIMPLEX,
        0.4,
        Scalar(200, 200, 200),
        1);

    SS.str("");
    SS.clear();

    SS << fixed
        << setprecision(0)
        << MaxY;

    putText(
        Plot,
        SS.str(),
        Point(5, Top2 + 5),
        FONT_HERSHEY_SIMPLEX,
        0.4,
        Scalar(200, 200, 200),
        1);

    SS.str("");
    SS.clear();

    SS << fixed
        << setprecision(0)
        << MinY;

    putText(
        Plot,
        SS.str(),
        Point(5, Bottom2),
        FONT_HERSHEY_SIMPLEX,
        0.4,
        Scalar(200, 200, 200),
        1);

    return Plot;
}

// ============================================================================
// CSV Header
// ============================================================================

static void writeCSVHeader(
    ofstream& CSV)
{
    CSV
        << "Frame,"
        << "TimeSec,"
        << "DetectionAvailable,"
        << "MeasuredX,"
        << "MeasuredY,"
        << "PredictedX,"
        << "PredictedY,"
        << "EstimatedX,"
        << "EstimatedY,"
        << "ErrorPixels,"
        << "BBoxX,"
        << "BBoxY,"
        << "BBoxWidth,"
        << "BBoxHeight,"
        << "Confidence"
        << "\n";
}

// ============================================================================
// CSV Row
// ============================================================================

static void writeCSVRow(
    ofstream& CSV,
    const TrackingRecord& R)
{
    CSV
        << R.FrameNumber << ","
        << fixed
        << setprecision(6)
        << R.TimeSec << ","
        << (R.DetectionAvailable ? 1 : 0)
        << ",";

    if (R.DetectionAvailable)
    {
        CSV
            << R.Measurement.x << ","
            << R.Measurement.y << ",";
    }
    else
    {
        CSV << "NaN,NaN,";
    }

    if (R.Prediction.x >= 0)
    {
        CSV
            << R.Prediction.x << ","
            << R.Prediction.y << ",";
    }
    else
    {
        CSV << "NaN,NaN,";
    }

    if (R.Estimate.x >= 0)
    {
        CSV
            << R.Estimate.x << ","
            << R.Estimate.y << ",";
    }
    else
    {
        CSV << "NaN,NaN,";
    }

    if (R.Error >= 0)
    {
        CSV
            << R.Error
            << ",";
    }
    else
    {
        CSV
            << "NaN,";
    }

    if (R.DetectionAvailable)
    {
        CSV
            << R.BoundingBox.x << ","
            << R.BoundingBox.y << ","
            << R.BoundingBox.width << ","
            << R.BoundingBox.height << ","
            << R.Confidence;
    }
    else
    {
        CSV
            << "NaN,NaN,NaN,NaN,NaN";
    }

    CSV << "\n";
}

// ============================================================================
// Usage
// ============================================================================

static void printUsage(
    const char* Program)
{
    cout
        << "\nUsage:\n\n"
        << "  "
        << Program
        << " -V <video_file>\n\n"
        << "  "
        << Program
        << " -V <video_file> -S\n\n"
        << "Options:\n"
        << "  -V <file>   Input video file\n"
        << "  -S          Save output video, plot video, CSV and final plot\n"
        << "  -h          Show help\n\n"
        << "Runtime Controls:\n"
        << "  ESC / q     Exit\n"
        << "  SPACE       Pause / Resume\n"
        << "  r           Reset Kalman tracker\n"
        << endl;
}

// ============================================================================
// MAIN
// ============================================================================

int main(
    int argc,
    char** argv)
{
    string VideoPath;

    bool SaveOutput = false;

    // ------------------------------------------------------------------------
    // Parse Arguments
    // ------------------------------------------------------------------------

    for (int i = 1;
        i < argc;
        i++)
    {
        string Argument =
            argv[i];

        if (Argument == "-V")
        {
            if (i + 1 >= argc)
            {
                cerr
                    << "ERROR: -V requires a video file."
                    << endl;

                return -1;
            }

            VideoPath =
                argv[++i];
        }

        else if (Argument == "-S")
        {
            SaveOutput = true;
        }

        else if (Argument == "-h" ||
            Argument == "--help")
        {
            printUsage(
                argv[0]);

            return 0;
        }

        else
        {
            cerr
                << "Unknown argument: "
                << Argument
                << endl;

            printUsage(
                argv[0]);

            return -1;
        }
    }

    if (VideoPath.empty())
    {
        cerr
            << "ERROR: Input video is required."
            << endl;

        printUsage(
            argv[0]);

        return -1;
    }

    // ------------------------------------------------------------------------
    // Open Video
    // ------------------------------------------------------------------------

    VideoCapture Capture(
        VideoPath);

    if (!Capture.isOpened())
    {
        cerr
            << "ERROR: Cannot open video: "
            << VideoPath
            << endl;

        return -1;
    }

    int FrameWidth =
        static_cast<int>(
            Capture.get(
                CAP_PROP_FRAME_WIDTH));

    int FrameHeight =
        static_cast<int>(
            Capture.get(
                CAP_PROP_FRAME_HEIGHT));

    double FPS =
        Capture.get(
            CAP_PROP_FPS);

    double FrameCount =
        Capture.get(
            CAP_PROP_FRAME_COUNT);

    if (FPS <= 0.0 ||
        !std::isfinite(FPS))
    {
        FPS = 30.0;
    }

    cout
        << "\n==============================================\n"
        << " DoG + Kalman Target Tracker\n"
        << "==============================================\n"
        << "Video      : "
        << VideoPath
        << "\nResolution : "
        << FrameWidth
        << " x "
        << FrameHeight
        << "\nFPS        : "
        << FPS
        << "\nFrames     : "
        << static_cast<long long>(
            FrameCount)
        << "\nSave       : "
        << (SaveOutput ? "YES" : "NO")
        << "\n==============================================\n"
        << endl;

    // ------------------------------------------------------------------------
    // Detector Configuration
    // ------------------------------------------------------------------------

    DetectorConfig Config;

    DoGDetector Detector(
        Config);

    KalmanTargetTracker Tracker(
        Config.MAX_MISSED_FRAMES);

    // ------------------------------------------------------------------------
    // History
    // ------------------------------------------------------------------------

    deque<TrackingRecord>
        TrackingHistory;

    deque<Point2f>
        MeasurementHistory;

    deque<Point2f>
        EstimateHistory;

    // ------------------------------------------------------------------------
    // Saving
    // ------------------------------------------------------------------------

    string RunDirectory;

    VideoWriter OutputWriter;
    VideoWriter PlotWriter;

    ofstream CSV;

    const Size PlotSize(
        900,
        600);

    if (SaveOutput)
    {
        RunDirectory =
            createRunDirectory();

        string OutputVideoPath =
            RunDirectory +
            "/tracking_output.mp4";

        string PlotVideoPath =
            RunDirectory +
            "/tracking_plot.mp4";

        string CSVPath =
            RunDirectory +
            "/tracking_data.csv";

        int FourCC =
            VideoWriter::fourcc(
                'm',
                'p',
                '4',
                'v');

        OutputWriter.open(
            OutputVideoPath,
            FourCC,
            FPS,
            Size(
                FrameWidth,
                FrameHeight),
            true);

        if (!OutputWriter.isOpened())
        {
            cerr
                << "WARNING: Could not open output video writer."
                << endl;
        }

        PlotWriter.open(
            PlotVideoPath,
            FourCC,
            FPS,
            PlotSize,
            true);

        if (!PlotWriter.isOpened())
        {
            cerr
                << "WARNING: Could not open plot video writer."
                << endl;
        }

        CSV.open(
            CSVPath);

        if (!CSV.is_open())
        {
            cerr
                << "WARNING: Could not create CSV."
                << endl;
        }
        else
        {
            writeCSVHeader(
                CSV);
        }

        cout
            << "[SAVE] Run directory:\n"
            << fs::absolute(
                RunDirectory)
            << "\n"
            << endl;
    }

    // ------------------------------------------------------------------------
    // Display Windows
    // ------------------------------------------------------------------------

    namedWindow(
        "DoG + Kalman Tracking",
        WINDOW_NORMAL);

    namedWindow(
        "Tracking Plot",
        WINDOW_NORMAL);

    resizeWindow(
        "Tracking Plot",
        PlotSize.width,
        PlotSize.height);

    // ------------------------------------------------------------------------
    // Main Processing Loop
    // ------------------------------------------------------------------------

    Mat Frame;

    int FrameNumber = 0;

    bool Paused = false;

    Mat LastPlot;

    while (true)
    {
        // --------------------------------------------------------------------
        // Pause
        // --------------------------------------------------------------------

        if (Paused)
        {
            int Key =
                waitKey(30);

            if (Key == 27 ||
                Key == 'q')
            {
                break;
            }

            if (Key == ' ')
            {
                Paused = false;
            }

            if (Key == 'r')
            {
                Tracker.reset();

                TrackingHistory.clear();
                MeasurementHistory.clear();
                EstimateHistory.clear();
            }

            continue;
        }

        // --------------------------------------------------------------------
        // Read Frame
        // --------------------------------------------------------------------

        if (!Capture.read(Frame))
        {
            cout
                << "\nEnd of video."
                << endl;

            break;
        }

        FrameNumber++;

        double TimeSec =
            FrameNumber /
            FPS;

        // --------------------------------------------------------------------
        // DoG Detection
        // --------------------------------------------------------------------

        vector<Detection> Detections =
            Detector.detect(
                Frame);

        // --------------------------------------------------------------------
        // Kalman prediction first
        // --------------------------------------------------------------------

        if (Tracker.isInitialized())
        {
            Tracker.predict();
        }

        // --------------------------------------------------------------------
        // Select measurement
        // --------------------------------------------------------------------

        Detection SelectedDetection;

        bool MeasurementAvailable =
            selectDetection(
                Detections,
                Tracker,
                Frame.size(),
                Config.ASSOCIATION_DISTANCE,
                SelectedDetection);

        // --------------------------------------------------------------------
        // Record
        // --------------------------------------------------------------------

        TrackingRecord Record;

        Record.FrameNumber =
            FrameNumber;

        Record.TimeSec =
            TimeSec;

        Record.DetectionAvailable =
            MeasurementAvailable;

        // --------------------------------------------------------------------
        // Kalman correction / prediction-only
        // --------------------------------------------------------------------

        if (MeasurementAvailable)
        {
            Record.Measurement =
                SelectedDetection.Center;

            Record.BoundingBox =
                SelectedDetection.BoundingBox;

            Record.Confidence =
                SelectedDetection.Confidence;

            // --------------------------------------------------------------
            // First acquisition
            // --------------------------------------------------------------

            if (!Tracker.isInitialized())
            {
                Tracker.initialize(
                    Record.Measurement);

                Record.Prediction =
                    Record.Measurement;

                Record.Estimate =
                    Record.Measurement;
            }

            // --------------------------------------------------------------
            // Existing tracker
            // --------------------------------------------------------------

            else
            {
                Record.Prediction =
                    Tracker.getPrediction();

                Record.Estimate =
                    Tracker.correct(
                        Record.Measurement);
            }

            Record.Error =
                static_cast<float>(
                    norm(
                        Record.Measurement -
                        Record.Estimate));

            MeasurementHistory.push_back(
                Record.Measurement);
        }

        else
        {
            // --------------------------------------------------------------
            // No DoG measurement.
            //
            // Kalman runs prediction-only.
            // --------------------------------------------------------------

            if (Tracker.isInitialized())
            {
                Record.Prediction =
                    Tracker.getPrediction();

                Tracker.markMissed();

                if (Tracker.isInitialized())
                {
                    Record.Estimate =
                        Tracker.getEstimate();
                }
            }

            // Negative value creates a trajectory break.
            MeasurementHistory.push_back(
                Point2f(-1, -1));
        }

        // --------------------------------------------------------------------
        // Estimate trajectory
        // --------------------------------------------------------------------

        if (Record.Estimate.x >= 0)
        {
            EstimateHistory.push_back(
                Record.Estimate);
        }
        else
        {
            EstimateHistory.push_back(
                Point2f(-1, -1));
        }

        // --------------------------------------------------------------------
        // Limit trajectory
        // --------------------------------------------------------------------

        while (MeasurementHistory.size() >
            Config.MAX_HISTORY)
        {
            MeasurementHistory.pop_front();
        }

        while (EstimateHistory.size() >
            Config.MAX_HISTORY)
        {
            EstimateHistory.pop_front();
        }

        // --------------------------------------------------------------------
        // Tracking history for plot
        // --------------------------------------------------------------------

        TrackingHistory.push_back(
            Record);

        while (TrackingHistory.size() >
            Config.MAX_HISTORY)
        {
            TrackingHistory.pop_front();
        }

        // --------------------------------------------------------------------
        // Draw Tracking
        // --------------------------------------------------------------------

        drawTrackingOverlay(
            Frame,
            Record,
            MeasurementHistory,
            EstimateHistory);

        // --------------------------------------------------------------------
        // Status
        // --------------------------------------------------------------------

        string Status;

        if (MeasurementAvailable)
        {
            Status =
                "DETECTED + KF CORRECTION";
        }
        else if (Tracker.isInitialized())
        {
            Status =
                "DoG MISS - KF PREDICTION";
        }
        else
        {
            Status =
                "SEARCHING TARGET";
        }

        putText(
            Frame,
            Status,
            Point(
                20,
                Frame.rows - 25),
            FONT_HERSHEY_SIMPLEX,
            0.65,
            MeasurementAvailable
            ? Scalar(0, 255, 0)
            : Scalar(0, 255, 255),
            2,
            LINE_AA);

        // --------------------------------------------------------------------
        // Runtime Plot
        // --------------------------------------------------------------------

        LastPlot =
            createTrackingPlot(
                TrackingHistory,
                PlotSize.width,
                PlotSize.height);

        // --------------------------------------------------------------------
        // Display
        // --------------------------------------------------------------------

        imshow(
            "DoG + Kalman Tracking",
            Frame);

        imshow(
            "Tracking Plot",
            LastPlot);

        // --------------------------------------------------------------------
        // Console
        // --------------------------------------------------------------------

        cout
            << "\rFrame:"
            << setw(6)
            << FrameNumber
            << " | DoG:"
            << (MeasurementAvailable
                ? "YES"
                : "NO ");

        if (MeasurementAvailable)
        {
            cout
                << " | M=("
                << fixed
                << setprecision(1)
                << Record.Measurement.x
                << ","
                << Record.Measurement.y
                << ")";
        }

        if (Record.Prediction.x >= 0)
        {
            cout
                << " | P=("
                << Record.Prediction.x
                << ","
                << Record.Prediction.y
                << ")";
        }

        if (Record.Estimate.x >= 0)
        {
            cout
                << " | E=("
                << Record.Estimate.x
                << ","
                << Record.Estimate.y
                << ")";
        }

        if (Record.Error >= 0)
        {
            cout
                << " | Err="
                << Record.Error
                << " px";
        }

        cout
            << "          "
            << flush;

        // --------------------------------------------------------------------
        // Save
        // --------------------------------------------------------------------

        if (SaveOutput)
        {
            if (OutputWriter.isOpened())
            {
                OutputWriter.write(
                    Frame);
            }

            if (PlotWriter.isOpened())
            {
                PlotWriter.write(
                    LastPlot);
            }

            if (CSV.is_open())
            {
                writeCSVRow(
                    CSV,
                    Record);
            }
        }

        // --------------------------------------------------------------------
        // Keyboard
        // --------------------------------------------------------------------

        int Delay =
            max(
                1,
                static_cast<int>(
                    1000.0 /
                    FPS));

        int Key =
            waitKey(Delay);

        if (Key == 27 ||
            Key == 'q')
        {
            break;
        }

        if (Key == ' ')
        {
            Paused = true;
        }

        if (Key == 'r')
        {
            Tracker.reset();

            TrackingHistory.clear();
            MeasurementHistory.clear();
            EstimateHistory.clear();
        }
    }

    // ========================================================================
    // Final Save
    // ========================================================================

    if (SaveOutput)
    {
        if (!LastPlot.empty())
        {
            string PlotImagePath =
                RunDirectory +
                "/final_tracking_plot.png";

            imwrite(
                PlotImagePath,
                LastPlot);
        }

        if (CSV.is_open())
        {
            CSV.close();
        }

        if (OutputWriter.isOpened())
        {
            OutputWriter.release();
        }

        if (PlotWriter.isOpened())
        {
            PlotWriter.release();
        }

        cout
            << "\n\n==============================================\n"
            << "OUTPUT SAVED\n"
            << "==============================================\n"
            << "Directory:\n"
            << fs::absolute(
                RunDirectory)
            << "\n\n"
            << "Files:\n"
            << "  tracking_output.mp4\n"
            << "  tracking_plot.mp4\n"
            << "  tracking_data.csv\n"
            << "  final_tracking_plot.png\n"
            << "==============================================\n";
    }

    Capture.release();

    destroyAllWindows();

    return 0;
}