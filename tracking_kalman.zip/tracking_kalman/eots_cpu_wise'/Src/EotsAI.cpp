// ============================================================================
// Name        : EotsAI.cpp
// Author      : Bhavesh
// Version     : V1.1.4
// Released On : 08 Sep 2026
// ============================================================================


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"

#include "Seeker.h"
// #include "IRVideoAI.h"
// #include "EOVideoAI.h"
#ifndef CPU_ONLY
#include "IRVideoAI.h"
#include "EOVideoAI.h"
#endif // CPU_ONLY

#include "C4IInterface.h"
#include "ClassicalDetector.h"
#include "ClassicalDetector2.h"


// ---------- Other Flag Variables ----------
bool SaveVideo = false;
bool SingleVideo = false;
bool DisplayFrame = false;
bool AutoSaveVideo = false;

// ---------- AI Flag Variables ----------
bool BirdPlaneDataFlag = false;

// ---------- Thread Flag Variables ----------
bool C4ICmdRecvFlag = true;
bool C4IDataSendFlag = true;
bool IRVideoReadFlag = true;
bool EOVideoReadFlag = true;
bool ProcessVideoFlag = true;


// ---------- Software Details ----------
UInt16_t SW_CheckSum = 0U;
string SW_Health = "08/09/26 V01.01.04";	// DD/MM/YY V01.00.00

// ---------- Config Parameters ----------
UInt8_t AI_Type = 1U;
UInt16_t TargetLimit = 1U;

string C4I_IPAddr = "0.0.0.0";
Int32_t C4I_Port;
Int32_t AI_Port;

// ---------- Camera Variables ----------
Size IR_Size(640, 512);
Size EO_Size(1920, 1080);

UInt16_t VideoFPS = 25U;
UInt16_t FrameDelay = 1000 / VideoFPS;

string IR_VideoSrc;
string EO_VideoSrc;

// ---------- AI Parameters ----------
string IR_Track_Model;
string EO_Track_Model;
string IR_Detect_Model;
string EO_Detect_Model;

string EO_ClassName[3] = { "Bird", "Drone" ,"Plane" };
string IR_ClassName[4] = { "Bird", "Fixed", "Hexa", "Plane" };

// ---------- Data Path ----------
string InpPath = "";
string LoadPath = "";
string SavePath = "";
string ParentPath = "";

// ---------- Data Structures & Buffers ----------
union _AICmd_ AICmd;
union _AIResp_ AIResp;
union _TgtData_ TgtData;
struct _TargetData_ TargetData;
struct _VideoData_ C4IVideoData, CameraData;

// ---------- Thread Variables ----------
pthread_t RecvC4ICmdThread;
pthread_t SendC4IDataThread;
pthread_t IRVideoReadThread;
pthread_t EOVideoReadThread;

// ---------- Shared Video Data Mutexes ----------
pthread_mutex_t CameraDataMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t C4IVideoDataMutex = PTHREAD_MUTEX_INITIALIZER;

// ---------- Class Objects ----------
Seeker* SeekerObj;
#ifndef CPU_ONLY
IRVideoAI* IRVideoAIObj;
EOVideoAI* EOVideoAIObj;
#endif // CPU_ONLY
C4IInterface* C4IInterfaceObj;
ClassicalDetector* IRDetectorObj;
ClassicalDetector* EODetectorObj;
ClassicalDetector2* IRDetector2Obj;
ClassicalDetector2* EODetector2Obj;


// ---------- signal Handler ----------
void signalHandler(Int32_t Signal);

// ---------- Close Process ----------
void closeProcess(void);



// ---------- Main Function ----------
int main(Int32_t argc, Int8_t* argv[])
{
	struct timespec ts;
	struct _VideoData_ VideoData;
        bool HasCameraFrame = false;

	high_resolution_clock::time_point timCntStart, timCntEnd;
	duration<double, milli> timDuration;

	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 5;		// 5 microseconds

	// Register force stop for CNTL+C
	signal(SIGINT, signalHandler);

	SW_CheckSum = getSwCheckSum(getPath(0));

	cout << "Software Details  : " << SW_Health << endl;
	cout << "Software Checksum : 0x" << hex << uppercase << SW_CheckSum << dec << endl;

	// Set load path for the files
	LoadPath = getPath(1);

	// Load Config file
	loadConfigData();

	// Check user flags
	checkFlags(argc, argv);

	// Set Saving path for results
	SavePath = getPath(2);

	// Create Class Objects
	SeekerObj = new Seeker();
	// IRVideoAIObj = new IRVideoAI();
    // EOVideoAIObj = new EOVideoAI();
#ifndef CPU_ONLY
    IRVideoAIObj = new IRVideoAI();
    EOVideoAIObj = new EOVideoAI();
#endif // CPU_ONLY
	C4IInterfaceObj = new C4IInterface();
	IRDetectorObj = new ClassicalDetector("IR C_Dog1");
	EODetectorObj = new ClassicalDetector("EO C_Dog1");
	IRDetector2Obj = new ClassicalDetector2("IR C_Dog2");
	EODetector2Obj = new ClassicalDetector2("EO C_Dog2");

	if (SingleVideo == false || AI_Type == 1 || AI_Type == 3 || AI_Type == 5)
	{
		// Create & Start IR Video Reading thread
		if (pthread_create(&IRVideoReadThread, NULL, SeekerObj->readIRFramesThread, SeekerObj))
		{
			perror("pthread_create");

			delete SeekerObj;
#ifndef CPU_ONLY
			delete IRVideoAIObj;
			delete EOVideoAIObj;
#endif // CPU_ONLY
			delete C4IInterfaceObj;
			delete IRDetectorObj;
			delete EODetectorObj;
			delete IRDetector2Obj;
			delete EODetector2Obj;

			exit(1);
		}
	}

	if (SingleVideo == false || AI_Type == 2 || AI_Type == 4 || AI_Type == 6)
	{
		// Create & Start EO Video Reading thread
		if (pthread_create(&EOVideoReadThread, NULL, SeekerObj->readEOFramesThread, SeekerObj))
		{
			perror("pthread_create");

			delete SeekerObj;
#ifndef CPU_ONLY
			delete IRVideoAIObj;
			delete EOVideoAIObj;
#endif // CPU_ONLY
			delete C4IInterfaceObj;
			delete IRDetectorObj;
			delete EODetectorObj;
			delete IRDetector2Obj;
			delete EODetector2Obj;

			exit(1);
		}
	}

	if (SingleVideo == false)
	{
		// Create & Start C4I Command Receive thread
		if (pthread_create(&RecvC4ICmdThread, NULL, C4IInterfaceObj->recvCmdC4IThread, C4IInterfaceObj))
		{
			perror("pthread_create");

			delete SeekerObj;
#ifndef CPU_ONLY
			delete IRVideoAIObj;
			delete EOVideoAIObj;
#endif // CPU_ONLY
			delete C4IInterfaceObj;
			delete IRDetectorObj;
			delete EODetectorObj;
			delete IRDetector2Obj;
			delete EODetector2Obj;

			exit(1);
		}
	}

	// Create & Start C4I Data Send thread
	if (pthread_create(&SendC4IDataThread, NULL, C4IInterfaceObj->sendDataC4IThread, C4IInterfaceObj))
	{
		perror("pthread_create");

		delete SeekerObj;
#ifndef CPU_ONLY
		delete IRVideoAIObj;
		delete EOVideoAIObj;
#endif // CPU_ONLY
		delete C4IInterfaceObj;
		delete IRDetectorObj;
		delete EODetectorObj;
		delete IRDetector2Obj;
		delete EODetector2Obj;

		exit(1);
	}

	cout << "Video Processing Started..." << endl << endl;


	while (ProcessVideoFlag == true)
	{
		clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
                HasCameraFrame = false;

                pthread_mutex_lock(&CameraDataMutex);

                if(CameraData.FrameFlag == true)
                {
                        VideoData.VideoFrame = CameraData.VideoFrame.clone();
                        VideoData.VideoType = CameraData.VideoType;
                        VideoData.FrameTime = CameraData.FrameTime;

                        CameraData.FrameFlag = false;
                        HasCameraFrame = true;
                }

                pthread_mutex_unlock(&CameraDataMutex);

                if(HasCameraFrame == false)
                {
                        continue;
                }

		// Start Measuring Execution Time
		timCntStart = high_resolution_clock::now();

		// Perform Object Detection
		if (AI_Type == 1U)
		{
#ifndef CPU_ONLY
			IRVideoAIObj->Run_enqueueV2(VideoData.VideoFrame);
#endif // CPU_ONLY
		}
		else if (AI_Type == 2U)
		{
#ifndef CPU_ONLY
			EOVideoAIObj->Run_enqueueV2(VideoData.VideoFrame);
#endif // CPU_ONLY
		}
		else if (AI_Type == 3U)
		{
			IRDetectorObj->Detector(VideoData.VideoFrame);
		}
		else if (AI_Type == 4U)
		{
			EODetectorObj->Detector(VideoData.VideoFrame);
		}
		else if (AI_Type == 5U)
		{
			IRDetector2Obj->Detector(VideoData.VideoFrame);
		}
		else if (AI_Type == 6U)
		{
			EODetector2Obj->Detector(VideoData.VideoFrame);
		}
		else
		{
			continue;
		}

        pthread_mutex_lock(&C4IVideoDataMutex);

        C4IVideoData.VideoFrame = VideoData.VideoFrame.clone();
        C4IVideoData.VideoType = VideoData.VideoType;
        C4IVideoData.FrameTime = VideoData.FrameTime;
        C4IVideoData.FrameFlag = true;

        pthread_mutex_unlock(&C4IVideoDataMutex);
		// Calculate Total Processing Time
		timCntEnd = high_resolution_clock::now();
		timDuration = timCntEnd - timCntStart;
		cout << "Total Process Time - " << timDuration.count() << " ms" << endl << flush;

	}

	// Close Whole Process & Clear Threads
	closeProcess();

	cout << "Terminated Successfully..." << endl << flush;
	return 0;
}


// ---------- signal Handler ----------
void signalHandler(Int32_t Signal)
{
	if (Signal == SIGINT)
	{
		cout << "Process Terminated by Cntl+C..." << endl << flush;
		ProcessVideoFlag = false;
	}

	return;
}


// ---------- Close Process ----------
void closeProcess(void)
{
	// Clear all the flags
	C4ICmdRecvFlag = false;
	C4IDataSendFlag = false;
	IRVideoReadFlag = false;
	EOVideoReadFlag = false;
	ProcessVideoFlag = false;


	// Try to Cancel Threads
	try
	{
		pthread_cancel(RecvC4ICmdThread);
		pthread_cancel(SendC4IDataThread);
		pthread_cancel(IRVideoReadThread);
		pthread_cancel(EOVideoReadThread);
	}
	catch (Exception& e)
	{
		cout << "Error : " << e.what() << endl;
	}

	// Close All Windows
	destroyAllWindows();

	// delete all the objects
	try
	{
		if (SeekerObj != nullptr)
		{
			delete SeekerObj;
		}

#ifndef CPU_ONLY
		if (IRVideoAIObj != nullptr)
		{
			delete IRVideoAIObj;
		}

		if (EOVideoAIObj != nullptr)
		{
			delete EOVideoAIObj;
		}

#endif // CPU_ONLY
		if (C4IInterfaceObj != nullptr)
		{
			delete C4IInterfaceObj;
		}

		if (IRDetectorObj != nullptr)
		{
			delete IRDetectorObj;
		}

		if (EODetectorObj != nullptr)
		{
			delete EODetectorObj;
		}

		if (IRDetector2Obj != nullptr)
		{
			delete IRDetector2Obj;
		}

		if (EODetector2Obj != nullptr)
		{
			delete EODetector2Obj;
		}
	}
	catch (Exception& e)
	{
		cout << "Error : " << e.what() << endl;
	}

	cout << "Process Closed Successfully..." << endl << flush;

	return;
}




