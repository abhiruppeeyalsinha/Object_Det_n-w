// // ============================================================================
// // Name        : Seeker.cpp
// // ============================================================================


// // ---------- Header Inclusion ----------
// #include "Seeker.h"


// // ---------- Init IR Video Stream ----------
// bool Seeker::initIRStream(void)
// {
// 	IR_avdic = NULL;
// 	IR_videoStream = -1;

// 	avformat_network_init();					// Initialize FFmpeg network module
// 	IR_pFormatCtx = avformat_alloc_context();	// Open the RTSP stream

// 	if (IR_VideoSrc.find("rtsp://") == 0)
// 	{
// 		av_dict_set(&IR_avdic, "rtsp_transport", "tcp", 0);
// 		av_dict_set(&IR_avdic, "max_delay", "0", 0);
// 	}
// 	else if (IR_VideoSrc.find("/dev/video") == 0)
// 	{

// 	}
// 	else
// 	{

// 	}

// 	if (avformat_open_input(&IR_pFormatCtx, IR_VideoSrc.c_str(), NULL, &IR_avdic) != 0)
// 	{
// 		cerr << "Can't open the RTSP_URL" << endl;
// 		return false;
// 	}

// 	// Get stream information
// 	if (avformat_find_stream_info(IR_pFormatCtx, NULL) < 0)
// 	{
// 		cerr << "Couldn't find stream information" << endl;
// 		return false;
// 	}

// 	// Find the video stream
// 	for (UInt32_t i = 0; i < IR_pFormatCtx->nb_streams; i++)
// 	{
// 		if (IR_pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
// 		{
// 			IR_videoStream = i;
// 			break;
// 		}
// 	}

// 	if (IR_videoStream == -1)
// 	{
// 		cerr << "Didn't find a video stream" << endl;
// 		return false;
// 	}

// 	// Get codec context
// 	IR_pCodecCtx = avcodec_alloc_context3(NULL);
// 	avcodec_parameters_to_context(IR_pCodecCtx, IR_pFormatCtx->streams[IR_videoStream]->codecpar);
// 	IR_pCodec = avcodec_find_decoder(IR_pCodecCtx->codec_id);

// 	IR_pCodecCtx->bit_rate = 0;
// 	IR_pCodecCtx->time_base.num = 1;
// 	IR_pCodecCtx->time_base.den = 10;
// 	IR_pCodecCtx->frame_number = 1;

// 	if (IR_pCodec == NULL)
// 	{
// 		cerr << "Codec not found" << endl;
// 		return false;
// 	}

// 	// Open codec
// 	if (avcodec_open2(IR_pCodecCtx, IR_pCodec, NULL) < 0)
// 	{
// 		cerr << "Could not open codec" << endl;
// 		return false;
// 	}

// 	// Allocate memory for frames
// 	IR_pFrame = av_frame_alloc();
// 	IR_pFrameEO = av_frame_alloc();

// 	// Get the required buffer size for RGB conversion
// 	IR_img_convert_ctx = sws_getContext(IR_pCodecCtx->width, IR_pCodecCtx->height, IR_pCodecCtx->pix_fmt, IR_pCodecCtx->width, IR_pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);

// 	//numBytes = avpicture_get_size(AV_PIX_FMT_RGB32, pCodecCtx->width,pCodecCtx->height);
// 	IR_numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, IR_pCodecCtx->width, IR_pCodecCtx->height, 1);

// 	IR_out_buffer = (uint8_t*)av_malloc(IR_numBytes * sizeof(uint8_t));

// 	av_image_fill_arrays(IR_pFrameEO->data, IR_pFrameEO->linesize, IR_out_buffer, AV_PIX_FMT_BGR24, IR_pCodecCtx->width, IR_pCodecCtx->height, 1);

// 	IR_packet = av_packet_alloc();

// 	return true;
// }


// // ---------- Init EO Video Stream ----------
// bool Seeker::initEOStream(void)
// {
// 	EO_avdic = NULL;
// 	EO_videoStream = -1;

// 	avformat_network_init();					// Initialize FFmpeg network module
// 	EO_pFormatCtx = avformat_alloc_context();	// Open the RTSP stream

// 	if (EO_VideoSrc.find("rtsp://") == 0)
// 	{
// 		av_dict_set(&EO_avdic, "rtsp_transport", "tcp", 0);
// 		av_dict_set(&EO_avdic, "max_delay", "0", 0);
// 	}
// 	else if (EO_VideoSrc.find("/dev/video") == 0)
// 	{

// 	}
// 	else
// 	{

// 	}

// 	if (avformat_open_input(&EO_pFormatCtx, EO_VideoSrc.c_str(), NULL, &EO_avdic) != 0)
// 	{
// 		cerr << "Can't open the RTSP_URL" << endl;
// 		return false;
// 	}

// 	// Get stream information
// 	if (avformat_find_stream_info(EO_pFormatCtx, NULL) < 0)
// 	{
// 		cerr << "Couldn't find stream information" << endl;
// 		return false;
// 	}

// 	// Find the video stream
// 	for (UInt32_t i = 0; i < EO_pFormatCtx->nb_streams; i++)
// 	{
// 		if (EO_pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
// 		{
// 			EO_videoStream = i;
// 			break;
// 		}
// 	}

// 	if (EO_videoStream == -1)
// 	{
// 		cerr << "Didn't find a video stream" << endl;
// 		return false;
// 	}

// 	// Get codec context
// 	EO_pCodecCtx = avcodec_alloc_context3(NULL);
// 	avcodec_parameters_to_context(EO_pCodecCtx, EO_pFormatCtx->streams[EO_videoStream]->codecpar);
// 	EO_pCodec = avcodec_find_decoder(EO_pCodecCtx->codec_id);

// 	EO_pCodecCtx->bit_rate = 0;
// 	EO_pCodecCtx->time_base.num = 1;
// 	EO_pCodecCtx->time_base.den = 10;
// 	EO_pCodecCtx->frame_number = 1;

// 	if (EO_pCodec == NULL)
// 	{
// 		cerr << "Codec not found" << endl;
// 		return false;
// 	}

// 	// Open codec
// 	if (avcodec_open2(EO_pCodecCtx, EO_pCodec, NULL) < 0)
// 	{
// 		cerr << "Could not open codec" << endl;
// 		return false;
// 	}

// 	// Allocate memory for frames
// 	EO_pFrame = av_frame_alloc();
// 	EO_pFrameEO = av_frame_alloc();

// 	// Get the required buffer size for RGB conversion
// 	EO_img_convert_ctx = sws_getContext(EO_pCodecCtx->width, EO_pCodecCtx->height, EO_pCodecCtx->pix_fmt, EO_pCodecCtx->width, EO_pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);

// 	//numBytes = avpicture_get_size(AV_PIX_FMT_RGB32, pCodecCtx->width,pCodecCtx->height);
// 	EO_numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, EO_pCodecCtx->width, EO_pCodecCtx->height, 1);

// 	EO_out_buffer = (uint8_t*)av_malloc(EO_numBytes * sizeof(uint8_t));

// 	av_image_fill_arrays(EO_pFrameEO->data, EO_pFrameEO->linesize, EO_out_buffer, AV_PIX_FMT_BGR24, EO_pCodecCtx->width, EO_pCodecCtx->height, 1);

// 	EO_packet = av_packet_alloc();

// 	return true;
// }


// // ---------- Read IR Video Frames ----------
// void Seeker::readIRFrames(void)
// {
// 	Mat VideoFrame;
// 	string timestamp;
// 	// double SleepTime = 0.0;
// 	double SleepTime = 0.0;
// 	bool ReadStatus = false;
// 	struct _VideoData_ VideoData;


// 	high_resolution_clock::time_point timCntStart, timCntEnd;
// 	duration<double, milli> timDuration;

// 	VideoFrame.create(IR_pCodecCtx->height, IR_pCodecCtx->width, CV_8UC3);

// 	while (IRVideoReadFlag == true)
// 	{
// 		// Start measuring execution time
// 		timCntStart = high_resolution_clock::now();
// 		ReadStatus = false;


// 		if (av_read_frame(IR_pFormatCtx, IR_packet) < 0)
// 		{
// 			cerr << "IR Video reading Failed..." << endl;
// 			raise(SIGINT);
// 		}

// 		if (IR_packet->stream_index == IR_videoStream)
// 		{
// 			IR_ret = avcodec_send_packet(IR_pCodecCtx, IR_packet);

// 			if (IR_ret < false)
// 			{
// 				cerr << "Decode error" << endl;
// 				raise(SIGINT);
// 			}

// 			IR_ret = avcodec_receive_frame(IR_pCodecCtx, IR_pFrame);

// 			if (IR_ret == false)
// 			{
// 				sws_scale(IR_img_convert_ctx, (uint8_t const* const*)IR_pFrame->data, IR_pFrame->linesize, 0, IR_pCodecCtx->height, IR_pFrameEO->data, IR_pFrameEO->linesize);
// 				memcpy(VideoFrame.data, IR_pFrameEO->data[0], IR_pCodecCtx->height * IR_pFrameEO->linesize[0]);

// 				//				resize(VideoFrame, VideoFrame, IR_Size);

// 								// timestamp = getTimeStamp();
// 								// putText(VideoFrame, timestamp, Point(10, 20), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1);

// 				if (AI_Type == 1U || AI_Type == 3U || AI_Type == 5U)
// 				{
// 					VideoData.VideoFrame = VideoFrame.clone();
// 					VideoData.VideoType = AI_Type;
// 					VideoData.FrameTime = steady_clock::now();

// 					if (CameraData.FrameFlag == true)
// 					{
// 						CameraData.FrameFlag = false;
// 						cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
// 					}

// 					CameraData.VideoFrame.release();
// 					CameraData = VideoData;
// 					CameraData.FrameFlag = true;
// 				}

// 				ReadStatus = true;
// 			}
// 		}
// 		av_packet_unref(IR_packet);

// 		if (ReadStatus == true)
// 		{
// 			// Calculate the reading time in milliseconds
// 			timCntEnd = high_resolution_clock::now();
// 			timDuration = timCntEnd - timCntStart;

// 			SleepTime = static_cast<double>(FrameDelay) - timDuration.count();
// 			// cout << "IR Reading Time - " << timDuration.count() << endl << flush;

// 			if (!(IR_VideoSrc.find("/dev/video") == 0 || IR_VideoSrc.find("rtsp://") == 0 || IR_VideoSrc.find("http://") == 0 || IR_VideoSrc.find("https://") == 0) && SleepTime > 0.0)
// 			{
// 				usleep(static_cast<useconds_t>(SleepTime * 1000.0));
// 			}
// 		}
// 	}

// 	return;
// }


// // ---------- Read EO Video Frames ----------
// void Seeker::readEOFrames(void)
// {
// 	Mat VideoFrame;
// 	string timestamp;
// 	// double SleepTime = 0.0;
// 	double SleepTime = 0.0;
// 	bool ReadStatus = false;
// 	struct _VideoData_ VideoData;


// 	high_resolution_clock::time_point timCntStart, timCntEnd;
// 	duration<double, milli> timDuration;

// 	VideoFrame.create(EO_pCodecCtx->height, EO_pCodecCtx->width, CV_8UC3);

// 	while (EOVideoReadFlag == true)
// 	{
// 		// Start measuring execution time
// 		timCntStart = high_resolution_clock::now();
// 		ReadStatus = false;


// 		if (av_read_frame(EO_pFormatCtx, EO_packet) < 0)
// 		{
// 			cerr << "EO Video reading Failed..." << endl;
// 			raise(SIGINT);
// 		}

// 		if (EO_packet->stream_index == EO_videoStream)
// 		{
// 			EO_ret = avcodec_send_packet(EO_pCodecCtx, EO_packet);

// 			if (EO_ret < false)
// 			{
// 				cerr << "Decode error" << endl;
// 				raise(SIGINT);
// 			}

// 			EO_ret = avcodec_receive_frame(EO_pCodecCtx, EO_pFrame);

// 			if (EO_ret == false)
// 			{
// 				sws_scale(EO_img_convert_ctx, (uint8_t const* const*)EO_pFrame->data, EO_pFrame->linesize, 0, EO_pCodecCtx->height, EO_pFrameEO->data, EO_pFrameEO->linesize);
// 				memcpy(VideoFrame.data, EO_pFrameEO->data[0], EO_pCodecCtx->height * EO_pFrameEO->linesize[0]);

// 				//				resize(VideoFrame, VideoFrame, EO_Size);

// 								// timestamp = getTimeStamp();
// 								// putText(VideoFrame, timestamp, Point(20, 40), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 255, 255), 2);

// 				if (AI_Type == 2U || AI_Type == 4U || AI_Type == 6U)
// 				{
// 					VideoData.VideoFrame = VideoFrame.clone();
// 					VideoData.VideoType = AI_Type;
// 					VideoData.FrameTime = steady_clock::now();

// 					if (CameraData.FrameFlag == true)
// 					{
// 						CameraData.FrameFlag = false;
// 						cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
// 					}

// 					CameraData.VideoFrame.release();
// 					CameraData = VideoData;
// 					CameraData.FrameFlag = true;
// 				}

// 				ReadStatus = true;
// 			}
// 		}
// 		av_packet_unref(EO_packet);

// 		if (ReadStatus == true)
// 		{
// 			// Calculate the reading time in milliseconds
// 			timCntEnd = high_resolution_clock::now();
// 			timDuration = timCntEnd - timCntStart;

// 			SleepTime = static_cast<double>(FrameDelay) - timDuration.count();
// 			// cout << "EO Reading Time - " << timDuration.count() << endl << flush;

// 			if (!(EO_VideoSrc.find("/dev/video") == 0 || EO_VideoSrc.find("rtsp://") == 0 || EO_VideoSrc.find("http://") == 0 || EO_VideoSrc.find("https://") == 0) && SleepTime > 0.0)
// 			{
// 				usleep(static_cast<useconds_t>(SleepTime * 1000.0));
// 			}
// 		}
// 	}

// 	return;
// }


// // ---------- Constructor ----------
// Seeker::Seeker(void)
// {
// 	if (SingleVideo == false || AI_Type == 1)
// 	{
// 		// Init IR Stream
// 		if (initIRStream() == false)
// 		{
// 			exit(1);
// 		}
// 		else
// 		{
// 			cout << "Successfully Opened IR Video Stream..." << endl;
// 		}
// 	}

// 	if (SingleVideo == false || AI_Type == 2)
// 	{
// 		// Init EO Stream
// 		if (initEOStream() == false)
// 		{
// 			exit(1);
// 		}
// 		else
// 		{
// 			cout << "Successfully Opened EO Video Stream..." << endl;
// 		}
// 	}

// 	return;
// }


// // ---------- Destructor ----------
// Seeker :: ~Seeker(void)
// {
// 	// Clear All Flags
// 	IRVideoReadFlag = false;
// 	EOVideoReadFlag = false;

// 	usleep(1000);

// 	// Close IR Stream
// 	av_free(IR_out_buffer);
// 	av_free(IR_pFrameEO);
// 	avcodec_close(IR_pCodecCtx);
// 	avformat_close_input(&IR_pFormatCtx);

// 	// Close EO Stream
// 	av_free(EO_out_buffer);
// 	av_free(EO_pFrameEO);
// 	avcodec_close(EO_pCodecCtx);
// 	avformat_close_input(&EO_pFormatCtx);
// }


// // ---------- Read IR Video Frames Thread ----------
// void* Seeker::readIRFramesThread(void* args)
// {
// 	// Enable deferred cancellation and set type to deferred
// 	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
// 	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

// 	Seeker* Instance = static_cast<Seeker*>(args);

// 	Instance->readIRFrames();

// 	pthread_exit(NULL);
// 	return nullptr;
// }


// // ---------- Read EO Video Frames Thread ----------
// void* Seeker::readEOFramesThread(void* args)
// {
// 	// Enable deferred cancellation and set type to deferred
// 	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
// 	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

// 	Seeker* Instance = static_cast<Seeker*>(args);

// 	Instance->readEOFrames();

// 	pthread_exit(NULL);
// 	return nullptr;
// }






//====================@2=====================================


// ============================================================================
// Name        : Seeker.cpp
// ============================================================================


// ---------- Header Inclusion ----------
#include "Seeker.h"


// ---------- Init IR Video Stream ----------
bool Seeker :: initIRStream(void)
{
	IR_avdic = NULL;
	IR_videoStream = -1;

	avformat_network_init();					// Initialize FFmpeg network module
	IR_pFormatCtx = avformat_alloc_context();	// Open the RTSP stream

	if(IR_VideoSrc.find("rtsp://") == 0)
	{
		av_dict_set(&IR_avdic, "rtsp_transport", "tcp", 0);
		av_dict_set(&IR_avdic, "max_delay", "0", 0);
	}
	else if(IR_VideoSrc.find("/dev/video") == 0)
	{

	}
	else
	{

	}

	if(avformat_open_input(&IR_pFormatCtx, IR_VideoSrc.c_str(), NULL,  &IR_avdic) != 0)
	{
		cerr << "Can't open the RTSP_URL" << endl;
		return false;
	}

	// Get stream information
	if(avformat_find_stream_info(IR_pFormatCtx, NULL) < 0)
	{
		cerr << "Couldn't find stream information" << endl;
		return false;
	}

	// Find the video stream
	for(UInt32_t i = 0; i < IR_pFormatCtx->nb_streams; i++)
	{
		if(IR_pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			IR_videoStream = i;
			break;
		}
	}

	if(IR_videoStream == -1)
	{
		cerr << "Didn't find a video stream" << endl;
		return false;
	}

	// Get codec context
	IR_pCodecCtx = avcodec_alloc_context3(NULL);
	avcodec_parameters_to_context(IR_pCodecCtx, IR_pFormatCtx->streams[IR_videoStream]->codecpar);
	IR_pCodec = avcodec_find_decoder(IR_pCodecCtx->codec_id);

	IR_pCodecCtx->bit_rate =0;
	IR_pCodecCtx->time_base.num=1;
	IR_pCodecCtx->time_base.den=10;
	IR_pCodecCtx->frame_number=1;

	if(IR_pCodec == NULL)
	{
		cerr << "Codec not found" << endl;
		return false;
	}

	// Open codec
	if(avcodec_open2(IR_pCodecCtx, IR_pCodec, NULL) < 0)
	{
		cerr << "Could not open codec" << endl;
		return false;
	}

	// Allocate memory for frames
	IR_pFrame = av_frame_alloc();
	IR_pFrameEO = av_frame_alloc();

	// Get the required buffer size for RGB conversion
	IR_img_convert_ctx = sws_getContext(IR_pCodecCtx->width, IR_pCodecCtx->height, IR_pCodecCtx->pix_fmt, IR_pCodecCtx->width, IR_pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);

	//numBytes = avpicture_get_size(AV_PIX_FMT_RGB32, pCodecCtx->width,pCodecCtx->height);
	IR_numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, IR_pCodecCtx->width, IR_pCodecCtx->height, 1);

	IR_out_buffer = (uint8_t *) av_malloc(IR_numBytes * sizeof(uint8_t));

	av_image_fill_arrays(IR_pFrameEO->data, IR_pFrameEO->linesize, IR_out_buffer, AV_PIX_FMT_BGR24, IR_pCodecCtx->width, IR_pCodecCtx->height, 1);

	IR_packet = av_packet_alloc();

	return true;
}


// ---------- Init EO Video Stream ----------
bool Seeker :: initEOStream(void)
{
	EO_avdic = NULL;
	EO_videoStream = -1;

	avformat_network_init();					// Initialize FFmpeg network module
	EO_pFormatCtx = avformat_alloc_context();	// Open the RTSP stream

	if(EO_VideoSrc.find("rtsp://") == 0)
	{
		av_dict_set(&EO_avdic, "rtsp_transport", "tcp", 0);
		av_dict_set(&EO_avdic, "max_delay", "0", 0);
	}
	else if(EO_VideoSrc.find("/dev/video") == 0)
	{

	}
	else
	{

	}

	if(avformat_open_input(&EO_pFormatCtx, EO_VideoSrc.c_str(), NULL,  &EO_avdic) != 0)
	{
		cerr << "Can't open the RTSP_URL" << endl;
		return false;
	}

	// Get stream information
	if(avformat_find_stream_info(EO_pFormatCtx, NULL) < 0)
	{
		cerr << "Couldn't find stream information" << endl;
		return false;
	}

	// Find the video stream
	for(UInt32_t i = 0; i < EO_pFormatCtx->nb_streams; i++)
	{
		if(EO_pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			EO_videoStream = i;
			break;
		}
	}

	if(EO_videoStream == -1)
	{
		cerr << "Didn't find a video stream" << endl;
		return false;
	}

	// Get codec context
	EO_pCodecCtx = avcodec_alloc_context3(NULL);
	avcodec_parameters_to_context(EO_pCodecCtx, EO_pFormatCtx->streams[EO_videoStream]->codecpar);
	EO_pCodec = avcodec_find_decoder(EO_pCodecCtx->codec_id);

	EO_pCodecCtx->bit_rate =0;
	EO_pCodecCtx->time_base.num=1;
	EO_pCodecCtx->time_base.den=10;
	EO_pCodecCtx->frame_number=1;

	if(EO_pCodec == NULL)
	{
		cerr << "Codec not found" << endl;
		return false;
	}

	// Open codec
	if(avcodec_open2(EO_pCodecCtx, EO_pCodec, NULL) < 0)
	{
		cerr << "Could not open codec" << endl;
		return false;
	}

	// Allocate memory for frames
	EO_pFrame = av_frame_alloc();
	EO_pFrameEO = av_frame_alloc();

	// Get the required buffer size for RGB conversion
	EO_img_convert_ctx = sws_getContext(EO_pCodecCtx->width, EO_pCodecCtx->height, EO_pCodecCtx->pix_fmt, EO_pCodecCtx->width, EO_pCodecCtx->height, AV_PIX_FMT_BGR24, SWS_BICUBIC, NULL, NULL, NULL);

	//numBytes = avpicture_get_size(AV_PIX_FMT_RGB32, pCodecCtx->width,pCodecCtx->height);
	EO_numBytes = av_image_get_buffer_size(AV_PIX_FMT_BGR24, EO_pCodecCtx->width, EO_pCodecCtx->height, 1);

	EO_out_buffer = (uint8_t *) av_malloc(EO_numBytes * sizeof(uint8_t));

	av_image_fill_arrays(EO_pFrameEO->data, EO_pFrameEO->linesize, EO_out_buffer, AV_PIX_FMT_BGR24, EO_pCodecCtx->width, EO_pCodecCtx->height, 1);

	EO_packet = av_packet_alloc();

	return true;
}


// ---------- Read IR Video Frames ----------
void Seeker :: readIRFrames(void)
{
	Mat VideoFrame;
	string timestamp;
	double SleepTime = 0.0;
	bool ReadStatus = false;
	struct _VideoData_ VideoData;


	high_resolution_clock::time_point timCntStart, timCntEnd;
	duration<double, milli> timDuration;

	VideoFrame.create(IR_pCodecCtx->height, IR_pCodecCtx->width, CV_8UC3);

	while(IRVideoReadFlag == true)
	{
		// Start measuring execution time
		timCntStart = high_resolution_clock::now();
		ReadStatus = false;


		if(av_read_frame(IR_pFormatCtx, IR_packet) < 0)
		{
			cerr << "IR Video reading Failed..." << endl;
			raise(SIGINT);
		}

		if(IR_packet->stream_index == IR_videoStream)
		{
			IR_ret = avcodec_send_packet(IR_pCodecCtx, IR_packet);

			if(IR_ret < false)
			{
				cerr << "Decode error" << endl;
				raise(SIGINT);
			}

			IR_ret = avcodec_receive_frame(IR_pCodecCtx, IR_pFrame);

			if(IR_ret == false)
			{
				sws_scale(IR_img_convert_ctx, (uint8_t const * const *) IR_pFrame->data, IR_pFrame->linesize, 0, IR_pCodecCtx->height, IR_pFrameEO->data, IR_pFrameEO->linesize);
				memcpy(VideoFrame.data, IR_pFrameEO->data[0], IR_pCodecCtx->height * IR_pFrameEO->linesize[0]);

//				resize(VideoFrame, VideoFrame, IR_Size);



				if(AI_Type == 1U || AI_Type == 3U || AI_Type == 5U)
				{
					VideoData.VideoFrame = VideoFrame.clone();
					VideoData.VideoType = AI_Type;
					VideoData.FrameTime = steady_clock::now();

					pthread_mutex_lock(&CameraDataMutex);

					if(CameraData.FrameFlag == true)
					{
						cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
					}

					CameraData.VideoFrame = VideoData.VideoFrame;
					CameraData.VideoType = VideoData.VideoType;
					CameraData.FrameTime = VideoData.FrameTime;
					CameraData.FrameFlag = true;

					pthread_mutex_unlock(&CameraDataMutex);
				}

				ReadStatus = true;
			}
		}
		av_packet_unref(IR_packet);

		if(ReadStatus == true)
		{
			// Calculate the reading time in milliseconds
			timCntEnd = high_resolution_clock::now();
			timDuration = timCntEnd - timCntStart;

			SleepTime = static_cast<double>(FrameDelay) - timDuration.count();
			// cout << "IR Reading Time - " << timDuration.count() << endl << flush;

			if(!(IR_VideoSrc.find("/dev/video") == 0 || IR_VideoSrc.find("rtsp://") == 0 || IR_VideoSrc.find("http://") == 0 || IR_VideoSrc.find("https://") == 0) && SleepTime > 0.0)
			{
				usleep(static_cast<useconds_t>(SleepTime * 1000.0));
			}
		}
	}

	return;
}


// ---------- Read EO Video Frames ----------
void Seeker :: readEOFrames(void)
{
	Mat VideoFrame;
	string timestamp;
	double SleepTime = 0.0;
	bool ReadStatus = false;
	struct _VideoData_ VideoData;


	high_resolution_clock::time_point timCntStart, timCntEnd;
	duration<double, milli> timDuration;

	VideoFrame.create(EO_pCodecCtx->height, EO_pCodecCtx->width, CV_8UC3);

	while(EOVideoReadFlag == true)
	{
		// Start measuring execution time
		timCntStart = high_resolution_clock::now();
		ReadStatus = false;


		if(av_read_frame(EO_pFormatCtx, EO_packet) < 0)
		{
			cerr << "EO Video reading Failed..." << endl;
			raise(SIGINT);
		}

		if(EO_packet->stream_index == EO_videoStream)
		{
			EO_ret = avcodec_send_packet(EO_pCodecCtx, EO_packet);

			if(EO_ret < false)
			{
				cerr << "Decode error" << endl;
				raise(SIGINT);
			}

			EO_ret = avcodec_receive_frame(EO_pCodecCtx, EO_pFrame);

			if(EO_ret == false)
			{
				sws_scale(EO_img_convert_ctx, (uint8_t const * const *) EO_pFrame->data, EO_pFrame->linesize, 0, EO_pCodecCtx->height, EO_pFrameEO->data, EO_pFrameEO->linesize);
				memcpy(VideoFrame.data, EO_pFrameEO->data[0], EO_pCodecCtx->height * EO_pFrameEO->linesize[0]);

//				resize(VideoFrame, VideoFrame, EO_Size);

			
				if(AI_Type == 2U || AI_Type == 4U || AI_Type == 6U)
				{
					VideoData.VideoFrame = VideoFrame.clone();
					VideoData.VideoType = AI_Type;
					VideoData.FrameTime = steady_clock::now();

					pthread_mutex_lock(&CameraDataMutex);

					if(CameraData.FrameFlag == true)
					{
						cout << "Dropping VideoFrames because inference is slow..." << endl << flush;
					}

					CameraData.VideoFrame = VideoData.VideoFrame;
					CameraData.VideoType = VideoData.VideoType;
					CameraData.FrameTime = VideoData.FrameTime;
					CameraData.FrameFlag = true;

					pthread_mutex_unlock(&CameraDataMutex);
				}

				ReadStatus = true;
			}
		}
		av_packet_unref(EO_packet);

		if(ReadStatus == true)
		{
			// Calculate the reading time in milliseconds
			timCntEnd = high_resolution_clock::now();
			timDuration = timCntEnd - timCntStart;

			SleepTime = static_cast<double>(FrameDelay) - timDuration.count();
			// cout << "EO Reading Time - " << timDuration.count() << endl << flush;

			if(!(EO_VideoSrc.find("/dev/video") == 0 || EO_VideoSrc.find("rtsp://") == 0 || EO_VideoSrc.find("http://") == 0 || EO_VideoSrc.find("https://") == 0) && SleepTime > 0.0)
			{
				usleep(static_cast<useconds_t>(SleepTime * 1000.0));
			}
		}
	}

	return;
}


// ---------- Constructor ----------
Seeker :: Seeker(void)
{
	if(SingleVideo == false || AI_Type == 1 || AI_Type == 3 || AI_Type == 5)
	{
		// Init IR Stream
		if(initIRStream() == false)
		{
			exit(1);
		}
		else
		{
			cout << "Successfully Opened IR Video Stream..." << endl;
		}
	}

	if(SingleVideo == false || AI_Type == 2 || AI_Type == 4 || AI_Type == 6)
	{
		// Init EO Stream
		if(initEOStream() == false)
		{
			exit(1);
		}
		else
		{
			cout << "Successfully Opened EO Video Stream..." << endl;
		}
	}

	return;
}


// ---------- Destructor ----------
Seeker :: ~Seeker(void)
{
	// Clear All Flags
	IRVideoReadFlag = false;
	EOVideoReadFlag = false;

	usleep(1000);

	// Close IR Stream
	av_free(IR_out_buffer);
	av_free(IR_pFrameEO);
	avcodec_close(IR_pCodecCtx);
	avformat_close_input(&IR_pFormatCtx);

	// Close EO Stream
	av_free(EO_out_buffer);
	av_free(EO_pFrameEO);
	avcodec_close(EO_pCodecCtx);
	avformat_close_input(&EO_pFormatCtx);
}


// ---------- Read IR Video Frames Thread ----------
void * Seeker :: readIRFramesThread(void *args)
{
	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->readIRFrames();

	pthread_exit(NULL);
	return nullptr;
}


// ---------- Read EO Video Frames Thread ----------
void * Seeker :: readEOFramesThread(void *args)
{
	// Enable deferred cancellation and set type to deferred
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, nullptr);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, nullptr);

	Seeker *Instance = static_cast<Seeker *>(args);

	Instance->readEOFrames();

	pthread_exit(NULL);
	return nullptr;
}


