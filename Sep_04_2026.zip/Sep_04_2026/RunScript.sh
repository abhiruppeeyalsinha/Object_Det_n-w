# ============================================================================
# Name        : RunScript.sh
# Created On  : 11 Nov 2025
# ============================================================================


#!/bin/bash

# Clear Previous RAM, Caches & kill previous Process
sudo pkill Exe-EotsAI
sudo sync && echo 3 | sudo tee /proc/sys/vm/drop_caches

# Get absolute path to the script and its executable
EXE_DIR=$(dirname "$(realpath "$0")")

# Get current date like 06Dec24
DATE=$(date +"%d%b%y")

# Result directory
RES_DIR="$EXE_DIR/Res/$DATE"

# Create the result directory if it dosent exists
mkdir -p -m 775 "$RES_DIR"

# Determine the next available test directory
TEST_NUM=$(ls -d "$RES_DIR"/Test* 2>/dev/null | grep -oP 'Test\K[0-9]+' | sort -nr | head -n1)

if [ -z "$TEST_NUM" ]; then TEST_NUM=0
else TEST_NUM=$((TEST_NUM + 1))
fi

# Create the new test directory
TEST_DIR="$RES_DIR/Test$TEST_NUM"
mkdir -p -m 775 "$TEST_DIR"

# Define the output log file
LOG_FILE="$TEST_DIR/RunLog.txt"

# Add Run Time in File
CURR_TIME=$(date +"%d-%m-%Y %H:%M:%S")
echo Test Running Time - "$CURR_TIME" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

echo Test Running Time - "$CURR_TIME"
echo ""

# Run the executable
LD_LIBRARY_PATH="$EXE_DIR"/Lib stdbuf -oL "$EXE_DIR"/Exe-EotsAI -PT "$TEST_DIR/" "$@" 2>&1 | tee -a "$LOG_FILE" & program_pid=$!

handle_sigint() {
	echo "Script Received SIGINT"
	kill -SIGINT "$program_pid"
	wait "$program_pid"
	echo "Output has been saved to : $TEST_DIR"
	exit 0
}
trap 'handle_sigint' SIGINT

wait $program_pid

echo "Output has been saved to : $TEST_DIR"






