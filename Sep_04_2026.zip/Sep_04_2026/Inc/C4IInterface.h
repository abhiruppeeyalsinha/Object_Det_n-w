// ============================================================================
// Name        : C4IInterface.h
// Created On  : 11 Nov 2025
// ============================================================================


#ifndef C4IINTERFACE_H_
#define C4IINTERFACE_H_

// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"



// ---------- Flag Variables ----------
extern bool DisplayFrame;

// ---------- Other Flag Variables ----------
extern bool SaveVideo;
extern bool SingleVideo;
extern bool DisplayFrame;
extern bool AutoSaveVideo;

// ---------- AI Flag Variables ----------
extern bool CentreTarget;

// ---------- Thread Flag Variables ----------
extern bool C4ICmdRecvFlag;
extern bool C4IDataSendFlag;
extern bool IRVideoReadFlag;
extern bool EOVideoReadFlag;
extern bool ProcessVideoFlag;

// ---------- Camera Variables ----------
extern UInt16_t VideoFPS;

// ---------- Data Path ----------
extern string SavePath;

// ---------- Data Structures & Buffers ----------
extern union _AICmd_ AICmd;
extern union _AIResp_ AIResp;
extern union _TgtData_ TgtData;
extern struct _VideoData_ C4IVideoData;



class C4IInterface
{
	private:
	// ---------- Private Variables ----------
	UInt32_t Len;
	Int32_t Flags;
	struct timeval timeout;
	Int32_t SendSock, RecvSock;
	struct sockaddr_in SAddr, CAddr, RAddr;


	public:
	// ---------- Public Functions ----------
	// Constructor
	C4IInterface(void);

	// Destructor
	~C4IInterface(void);

	// Receive Cmd Function
	void recvCmdC4I(void);

	// Send Data Function
	void sendDataC4I(void);

	// Receive Cmd Function
	static void *recvCmdC4IThread(void *args);

	// Send Data Function
	static void *sendDataC4IThread(void *args);
};


#endif /* C4IINTERFACE_H_ */




