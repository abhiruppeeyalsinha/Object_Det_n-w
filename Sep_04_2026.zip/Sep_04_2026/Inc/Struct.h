// ============================================================================
// Name        : Struct.h
// Created On  : 11 Nov 2025
// ============================================================================

#ifndef STRUCT_H_
#define STRUCT_H_

// ---------- Header Inclusion ----------
#include "Includes.h"

// Device & Cmd IDs
#define C4I_ID 0x07
#define AI_ID 0x55
#define SaveVideoCmd 0x86
#define AISwitchCmd 0x87
#define TgtDataCmd 0x88
#define VideoDataCmd 0x89

// ---------- Macros ----------
#define FindMin(A, B) ((A) < (B) ? (A) : (B))
#define FindMax(A, B) ((A) >= (B) ? (A) : (B))

#pragma pack(1)

// ---------- Video Data Structure ----------
struct _VideoData_
{
    Mat VideoFrame;
    UInt8_t VideoType;
    float FrameFlag;
    steady_clock::time_point FrameTime;

    ~_VideoData_(void)
    {
        VideoFrame.release();
    }
};

// ---------- AI Target Data Structure ----------
struct _AIData_
{
    UInt8_t Type; // Added for Template Matching distinction (0: AI, 1: TM)
    UInt8_t ClassID;
    Point CenterPoint;
    Rect BoundingBox;
    float Confidance;
    UInt16_t TrackID;
};

// ---------- Template Structure ----------
struct _Template_
{
    UInt8_t ClassID;
    UInt32_t FrameCnt;
    Point CenterPoint;
    Rect BoundingBox;
    Rect ROIBox;
    Rect OverLapBox;
    Mat Template;
};

// Tracking Data Structure
struct _DSTrack_
{
    UInt32_t TrackID;
    Point2f Center;
    Rect BBox;
    vector<float> Feature;
    KalmanFilter kf;
    Int32_t Missed;
    Int32_t Hits;
    _DSTrack_()
        : TrackID(0), Center(0, 0), BBox(), Feature(), kf(4, 2), Missed(0), Hits(0)
    {
    }
};

// ---------- C4I Target Data Structure ----------
union _AIResp_
{
    UInt8_t Buffer[10];

    struct _AIRespStruct_
    {
        UInt8_t Header[3];
        UInt8_t DataLen;
        UInt8_t AckByte;
        UInt8_t CheckSum;
    } AIRespStruct;
};

struct _TargetData_
{
    UInt8_t ClassID;
    UInt16_t TrackID;
    Int16_t Ny;
    Int16_t Nz;
    UInt16_t Width;
    UInt16_t Height;
    UInt8_t Confidance;
};

union _TgtData_
{
    UInt8_t Buffer[60500];

    struct _TgtDataStruct_
    {
        UInt8_t Header[3];
        UInt16_t DataLen;
        UInt8_t VideoType;
        UInt8_t TgtDataType;
        UInt8_t SaveStatus;
        UInt16_t TargetCnt;
        struct _TargetData_ TgtData[5000];
        UInt8_t CheckSum;
    } TgtDataStruct;
};

// ---------- C4I AI Command Structure ----------
union _AICmd_
{
    UInt8_t Buffer[10];

    struct _AICmdStruct_
    {
        UInt8_t Header[3];
        UInt8_t DataLen;
        UInt8_t AIType;
        UInt8_t TgtDataType;
        UInt8_t CheckSum;
    } AICmdStruct;

    struct _SaveCmdStruct_
    {
        UInt8_t Header[3];
        UInt8_t DataLen;
        UInt8_t Stat;
        UInt8_t CheckSum;
    } SaveCmdStruct;
};

#pragma pack()

#endif /* STRUCT_H_ */