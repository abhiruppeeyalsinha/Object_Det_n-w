// ============================================================================
// Name        : Includes.h
// Created On  : 11 Nov 2025
// ============================================================================


#ifndef INCLUDES_H_
#define INCLUDES_H_


// Includes

#include <regex>
#include <mutex>
#include <chrono>
#include <string>
#include <atomic>
#include <vector>
#include <limits>
#include <fstream>
#include <cstring>
#include <iostream>

#include <elf.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/time.h>
#include <arpa/inet.h>

#include <nlohmann/json.hpp>
#include <opencv2/opencv.hpp>

extern "C"
{
	#include "libavcodec/avcodec.h"
	#include "libavformat/avformat.h"
	#include "libavutil/pixfmt.h"
	#include "libswscale/swscale.h"
	#include "libavutil/imgutils.h"
}

// Warning Depecrartion
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"


#include <memory>
#include <numeric>
#include <NvInfer.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>


// Namespace
using namespace cv;
using namespace std;
using namespace nvinfer1;
using namespace std::chrono;
using json = nlohmann::json;

#pragma GCC diagnostic pop


// DataTypes TypeDef
#include "DataTypes.h"


#endif /* INCLUDES_H_ */




