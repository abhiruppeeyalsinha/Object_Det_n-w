// ============================================================================
// Name        : Seeker.h
// Created On  : 11 Nov 2025
// ============================================================================

// Seeker.h
#ifndef SEEKER_H_
#define SEEKER_H_

// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"


// ---------- Other Flag Variables ----------
extern bool SingleVideo;

// ---------- Thread Flag Variables ----------
extern bool IRVideoReadFlag;
extern bool EOVideoReadFlag;

// ---------- Config Parameters ----------
extern UInt8_t AI_Type;

// ---------- Camera Variables ----------
extern Size IR_Size;
extern Size EO_Size;
extern UInt16_t VideoFPS;
extern UInt16_t FrameDelay;
extern string IR_VideoSrc;
extern string EO_VideoSrc;

// ---------- Data Path ----------
extern string SavePath;

// ---------- Data Structures & Buffers ----------
extern struct _VideoData_ CameraData;



// ---------- Class Declaration ----------
class Seeker
{
private:
	// ---------- Private Variables ----------
	// IR Video Stream Variables
	AVFormatContext *IR_pFormatCtx;
	AVCodecContext *IR_pCodecCtx;

	AVFrame *IR_pFrame, *IR_pFrameEO;
	AVPacket *IR_packet;

	uint8_t *IR_out_buffer;
	struct SwsContext *IR_img_convert_ctx;

	AVDictionary *IR_avdic;
	const AVCodec *IR_pCodec;

	int IR_numBytes, IR_videoStream, IR_y_size, IR_ret;


	// EO Video Stream Variables
	AVFormatContext *EO_pFormatCtx;
	AVCodecContext *EO_pCodecCtx;

	AVFrame *EO_pFrame, *EO_pFrameEO;
	AVPacket *EO_packet;

	uint8_t *EO_out_buffer;
	struct SwsContext *EO_img_convert_ctx;

	AVDictionary *EO_avdic;
	const AVCodec *EO_pCodec;

	int EO_numBytes, EO_videoStream, EO_y_size, EO_ret;


	// ---------- Private Functions ----------
	// Init IR Video Stream
	bool initIRStream(void);

	// Init EO Video Stream
	bool initEOStream(void);

	// Read IR Video Frames
	void readIRFrames(void);

	// Read EO Video Frames
	void readEOFrames(void);


public:
	// ---------- Public Functions ----------
	// Constructor
	Seeker(void);

	// Destructor
	~Seeker(void);

	// Read IR Video Frames Thread
	static void *readIRFramesThread(void *args);

	// Read EO Video Frames Thread
	static void *readEOFramesThread(void *args);
};


#endif /* SEEKER_H_ */




