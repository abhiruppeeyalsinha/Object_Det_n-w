// ============================================================================
// Name        : IRVideoAI.h
// Created On  : 11 Nov 2025
// ============================================================================

#ifndef IRVIDEOAI_H_
#define IRVIDEOAI_H_

// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"

// ---------- Other Flag Variables ----------
extern bool SaveVideo;
extern bool AutoSaveVideo;

// ---------- AI Flag Variables ----------
extern bool CentreTarget;
extern bool TrackingFlag;
extern bool BirdPlaneDataFlag;

// ---------- Config Parameters ----------
extern UInt8_t AI_Type;

// ---------- Camera Variables ----------
extern Size IR_Size;
extern Size EO_Size;

// ---------- AI Parameters ----------
extern string IR_Track_Model;
extern string IR_Detect_Model;

extern string EO_ClassName[3];
extern string IR_ClassName[4];

// ---------- Data Structures & Buffers ----------
extern union _TgtData_ TgtData;
extern struct _TargetData_ TargetData;

// ---------- Class Declaration ----------
class IRVideoAI
{
private:
    // ---------- Private Variables ----------
    Size Yolov5_DIM;
    Int32_t PadX, PadY;
    float ConfThreshold;
    float IOUThreshold;

    vector<struct _AIData_> TargetDataArr;

    vector<__half> InpBuff;
    vector<__half> OutBuff;

    unique_ptr<IRuntime> runtime;
    unique_ptr<ICudaEngine> engine;
    unique_ptr<IExecutionContext> context;

    vector<void *> Bindings;
    vector<size_t> BindingSizes;
    cudaStream_t Stream;

    vector<float> ReIDInpBuff;
    vector<float> ReIDOutBuff;

    unique_ptr<IRuntime> ReIDruntime;
    unique_ptr<ICudaEngine> ReIDengine;
    unique_ptr<IExecutionContext> ReIDcontext;

    vector<void *> ReIDBindings;
    vector<size_t> ReIDBindingSizes;
    cudaStream_t ReIDStream;

    UInt32_t DS_NextTrackID;
    Int32_t MaxMissedFrames;
    float MaxAssocDist;
    float ReID_IoUWeight;
    float ReID_DistWeight;

    size_t ReIDOutputSize;
    nvinfer1::Dims ReIDInputDims;
    vector<struct _DSTrack_> DSTrackArr;

    // ---------- Template Matching Variables ----------
    bool TemplateMatchingFlag;
    UInt8_t ActiveArr;
    UInt8_t StoreArr;
    UInt32_t MaxTemplateCnt;
    UInt32_t TemplateFrameCnt;
    float TempConfThreshold;
    vector<struct _Template_> TemplateArr[2];

    // ---------- Private Functions ----------
    size_t getMemorySize(Dims dims, size_t ElementSize);
    void HungarianSolve(const vector<vector<float>> &cost, vector<int> &assignment);
    void l2Normalize(vector<float> &v);
    float RectIOU(const Rect &a, const Rect &b);
    bool LoadDetectModel(void);
    bool LoadTrackModel(void);
    void preProcess(Mat VideoFrame, __half *InputBuff);
    void postProcess(vector<__half> &Output, UInt16_t VideoWidth, UInt16_t VideoHeight);
    void templateMatch(Mat &VideoFrame); // Template Matching Function
    void ReIDInferance(Mat VideoFrame, vector<vector<float>> &OutFeatures);
    void ReIDpostProcess(vector<vector<float>> &ReIDFeatures, vector<struct _AIData_> &TargetDataArr);
    void drawBoxes(Mat &VideoFrame);

public:
    // ---------- Public Functions ----------
    IRVideoAI(void);
    ~IRVideoAI(void);
    void Run_enqueueV2(Mat &VideoFrame);
};

#endif /* IRVIDEOAI_H_ */