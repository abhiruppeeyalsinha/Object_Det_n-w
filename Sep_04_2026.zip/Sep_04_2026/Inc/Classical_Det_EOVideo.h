// ============================================================================
// Name        : Classical_Det_EOVideo.h
// Created On  : 04 Sep 2026
// ============================================================================

#ifndef CLASSICAL_DET_EOVIDEO_H_
#define CLASSICAL_DET_EOVIDEO_H_

// ---------- Header Inclusion ----------
#include "ClassicalVideoDetector.h"

// ---------- Class Declaration ----------
class Classical_Det_EOVideo
{
private:
	ClassicalVideoDetector Detector;

public:
	Classical_Det_EOVideo(void);
	~Classical_Det_EOVideo(void);
	void Run(Mat &VideoFrame);
};

#endif /* CLASSICAL_DET_EOVIDEO_H_ */
