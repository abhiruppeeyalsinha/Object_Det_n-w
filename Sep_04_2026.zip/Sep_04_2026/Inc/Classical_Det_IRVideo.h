// ============================================================================
// Name        : Classical_Det_IRVideo.h
// Created On  : 04 Sep 2026
// ============================================================================

#ifndef CLASSICAL_DET_IRVIDEO_H_
#define CLASSICAL_DET_IRVIDEO_H_

// ---------- Header Inclusion ----------
#include "ClassicalVideoDetector.h"

// ---------- Class Declaration ----------
class Classical_Det_IRVideo
{
private:
	ClassicalVideoDetector Detector;

public:
	Classical_Det_IRVideo(void);
	~Classical_Det_IRVideo(void);
	void Run(Mat &VideoFrame);
};

#endif /* CLASSICAL_DET_IRVIDEO_H_ */
