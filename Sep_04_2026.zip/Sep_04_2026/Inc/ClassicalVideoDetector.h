// ============================================================================
// Name        : ClassicalVideoDetector.h
// Created On  : 04 Sep 2026
// ============================================================================

#ifndef CLASSICALVIDEODETECTOR_H_
#define CLASSICALVIDEODETECTOR_H_

// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"

#include <algorithm>
#include <cmath>

// ---------- Other Flag Variables ----------
extern bool SaveVideo;
extern bool AutoSaveVideo;

// ---------- AI Flag Variables ----------
extern bool CentreTarget;
extern bool TrackingFlag;
extern bool BirdPlaneDataFlag;
extern Int32_t CentreTargetCount;
extern Int32_t StaticCoordFrames;

// ---------- Config Parameters ----------
extern UInt8_t AI_Type;

// ---------- Data Structures & Buffers ----------
extern union _TgtData_ TgtData;
extern struct _TargetData_ TargetData;

struct _ClassicalDetConfig_
{
	float DOG_THRESHOLD = -1.0f;
	float DOG_STDDEV_FACTOR = 1.25f;
	float MIN_DOG_THRESHOLD = 8.0f;
	float MAX_DOG_THRESHOLD = 48.0f;
	double MIN_AREA_FRAC = 0.00002;
	double MAX_AREA_FRAC = 0.35;
	double MIN_EXTENT = 0.05;
	double MIN_ASPECT = 0.10;
	double MAX_ASPECT = 10.0;
	double MAX_VERTICAL_POSITION = 0.92;
	Int32_t MIN_CONTOUR_AREA = 6;
};

class ClassicalVideoDetector
{
private:
	struct _ClassicalTrack_
	{
		UInt32_t TrackID = 0;
		UInt8_t ClassID = 0;
		Rect BoundingBox;
		Point2f Center;
		Mat TemplateImage;
		Int32_t Missed = 0;
		Int32_t Hits = 0;
		float TemplateScore = 0.0f;
		bool TemplateMatched = false;
	};

	struct _StationaryTrack_
	{
		Rect LastBox;
		vector<Rect> History;
		Int32_t MissedFrames = 0;
		bool Stationary = false;
	};

	struct _RepeatedCoordinateTrack_
	{
		Int32_t X = 0;
		Int32_t Y = 0;
		Int32_t ConsecutiveFrames = 0;
		long long LastSeenFrame = 0;
		bool SeenThisFrame = false;
	};

	_ClassicalDetConfig_ Config;
	vector<struct _AIData_> TargetDataArr;
	vector<struct _ClassicalTrack_> TrackArr;
	vector<struct _StationaryTrack_> StationaryTrackArr;
	vector<struct _RepeatedCoordinateTrack_> RepeatedCoordinateTrackArr;
	vector<struct _AIData_> LastCentreTargetArr;

	UInt32_t NextTrackID;
	Int32_t MaxMissedFrames;
	Int32_t StationaryStableFrames;
	Int32_t StationarySizeTolerance;
	Int32_t StationaryMaxMissedFrames;
	Int32_t CentreHoldMaxFrames;
	Int32_t CentreMissedFrames;
	long long RepeatedFrameNumber;
	float MaxAssocDist;
	float TemplateMatchThreshold;
	double StationaryPositionTolerance;
	double StationaryMatchDistance;
	string VideoLabel;
	string TargetName;
	UInt8_t OutputClassID;
	Int32_t BoxThickness;
	double LabelScale;

	float adaptiveResponseThreshold(const Mat &Response) const;
	Mat blobMask(const Mat &Response, float Threshold) const;
	void cleanupMask(Mat &Mask) const;
	double priorWeight(const Rect &Box, Size ImageSize) const;
	vector<struct _AIData_> applyNMS(vector<struct _AIData_> &Detections, float IOUThreshold) const;
	float rectIOU(const Rect &A, const Rect &B) const;
	float centerDistance(const Rect &A, const Rect &B) const;
	Point2d centerOf(const Rect &Box) const;
	bool isStationaryTrack(const vector<Rect> &History) const;
	void hungarianSolve(const vector<vector<float>> &Cost, vector<Int32_t> &Assignment) const;
	Mat extractTemplate(const Mat &GrayFrame, const Rect &Box) const;
	bool updateTrackByTemplate(struct _ClassicalTrack_ &Track, const Mat &GrayFrame);
	void templateTrack(Mat &VideoFrame);
	vector<struct _AIData_> filterStationaryTargets(const vector<struct _AIData_> &Detections);
	vector<struct _AIData_> filterRepeatedCoordinates(const vector<struct _AIData_> &Detections);
	void selectNearestCentreTargets(Size FrameSize);
	bool appendCentreHoldTargets(Size FrameSize);
	void drawCornerBox(Mat &VideoFrame, const Rect &Box, const Scalar &Color, Int32_t Thickness, Int32_t CornerLength) const;
	void drawBoxes(Mat &VideoFrame);

public:
	ClassicalVideoDetector(const string &VideoLabel, const string &TargetName, UInt8_t OutputClassID, Int32_t BoxThickness, double LabelScale);
	~ClassicalVideoDetector(void);
	void Run(Mat &VideoFrame);
};

#endif /* CLASSICALVIDEODETECTOR_H_ */
