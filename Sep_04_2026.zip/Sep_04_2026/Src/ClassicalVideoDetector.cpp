// ============================================================================
// Name        : ClassicalVideoDetector.cpp
// Created On  : 04 Sep 2026
// ============================================================================

// ---------- Header Inclusion ----------
#include "ClassicalVideoDetector.h"

// ---------- Adaptive DoG Response Threshold ----------
float ClassicalVideoDetector ::adaptiveResponseThreshold(const Mat &Response) const
{
	if (Config.DOG_THRESHOLD > 0.0f)
	{
		return Config.DOG_THRESHOLD;
	}

	Mat AbsResponse;
	absdiff(Response, Scalar(0), AbsResponse);

	Scalar MeanVal, StdDevVal;
	meanStdDev(AbsResponse, MeanVal, StdDevVal);

	const double RawThreshold = MeanVal[0] + Config.DOG_STDDEV_FACTOR * StdDevVal[0];
	return static_cast<float>(std::clamp(RawThreshold, static_cast<double>(Config.MIN_DOG_THRESHOLD), static_cast<double>(Config.MAX_DOG_THRESHOLD)));
}

// ---------- Create Positive/Negative DoG Blob Mask ----------
Mat ClassicalVideoDetector ::blobMask(const Mat &Response, float Threshold) const
{
	Mat PosClip, NegClip;
	Mat PosMask, NegMask;

	max(Response, 0, PosClip);
	PosClip.convertTo(PosClip, CV_8U);
	threshold(PosClip, PosMask, Threshold, 255, THRESH_BINARY);

	Mat NegResponse = -Response;
	max(NegResponse, 0, NegClip);
	NegClip.convertTo(NegClip, CV_8U);
	threshold(NegClip, NegMask, Threshold, 255, THRESH_BINARY);

	Mat OutMask;
	bitwise_or(PosMask, NegMask, OutMask);
	return OutMask;
}

// ---------- Clean DoG Mask ----------
void ClassicalVideoDetector ::cleanupMask(Mat &Mask) const
{
	if (Mask.empty())
	{
		return;
	}

	const Int32_t MinDim = max(1, min(Mask.cols, Mask.rows));
	const Int32_t KernelSize = (MinDim >= 720) ? 5 : 3;
	Mat Kernel = getStructuringElement(MORPH_ELLIPSE, Size(KernelSize, KernelSize));

	morphologyEx(Mask, Mask, MORPH_OPEN, Kernel);
	morphologyEx(Mask, Mask, MORPH_CLOSE, Kernel);
}

// ---------- Centre Prior For Candidate Ranking ----------
double ClassicalVideoDetector ::priorWeight(const Rect &Box, Size ImageSize) const
{
	const double DX = (Box.x + Box.width * 0.5) - ImageSize.width * 0.5;
	const double DY = (Box.y + Box.height * 0.5) - ImageSize.height * 0.5;
	const double MaxDist = max(1.0, hypot(ImageSize.width * 0.5, ImageSize.height * 0.5));

	return 0.75 + (1.0 - min(hypot(DX, DY) / MaxDist, 1.0)) * 0.35;
}

// ---------- Rect IOU ----------
float ClassicalVideoDetector ::rectIOU(const Rect &A, const Rect &B) const
{
	const Int32_t X1 = max(A.x, B.x);
	const Int32_t Y1 = max(A.y, B.y);
	const Int32_t X2 = min(A.x + A.width, B.x + B.width);
	const Int32_t Y2 = min(A.y + A.height, B.y + B.height);
	const Int32_t W = max(0, X2 - X1);
	const Int32_t H = max(0, Y2 - Y1);
	const float Inter = static_cast<float>(W * H);
	const float AreaA = static_cast<float>(A.width * A.height);
	const float AreaB = static_cast<float>(B.width * B.height);
	const float Uni = AreaA + AreaB - Inter + 1e-6f;

	return (Inter / Uni);
}

// ---------- Centre Distance ----------
float ClassicalVideoDetector ::centerDistance(const Rect &A, const Rect &B) const
{
	Point2f CA(A.x + A.width * 0.5f, A.y + A.height * 0.5f);
	Point2f CB(B.x + B.width * 0.5f, B.y + B.height * 0.5f);

	return static_cast<float>(norm(CA - CB));
}

// ---------- Rect Centre ----------
Point2d ClassicalVideoDetector ::centerOf(const Rect &Box) const
{
	return Point2d(Box.x + Box.width * 0.5, Box.y + Box.height * 0.5);
}

// ---------- Check Stationary Track ----------
bool ClassicalVideoDetector ::isStationaryTrack(const vector<Rect> &History) const
{
	if (History.size() < static_cast<size_t>(StationaryStableFrames))
	{
		return false;
	}

	double MinCx = 1e30;
	double MaxCx = -1e30;
	double MinCy = 1e30;
	double MaxCy = -1e30;
	Int32_t MinW = 1000000000;
	Int32_t MaxW = 0;
	Int32_t MinH = 1000000000;
	Int32_t MaxH = 0;

	for (const Rect &Box : History)
	{
		const Point2d Centre = centerOf(Box);
		MinCx = min(MinCx, Centre.x);
		MaxCx = max(MaxCx, Centre.x);
		MinCy = min(MinCy, Centre.y);
		MaxCy = max(MaxCy, Centre.y);
		MinW = min(MinW, Box.width);
		MaxW = max(MaxW, Box.width);
		MinH = min(MinH, Box.height);
		MaxH = max(MaxH, Box.height);
	}

	const Point2d FirstCentre = centerOf(History.front());
	const Point2d LastCentre = centerOf(History.back());
	const double FirstToLast = hypot(LastCentre.x - FirstCentre.x, LastCentre.y - FirstCentre.y);

	const bool PositionStable =
		FirstToLast <= StationaryPositionTolerance &&
		(MaxCx - MinCx) <= StationaryPositionTolerance * 2.0 &&
		(MaxCy - MinCy) <= StationaryPositionTolerance * 2.0;

	const bool SizeStable =
		(MaxW - MinW) <= StationarySizeTolerance * 2 &&
		(MaxH - MinH) <= StationarySizeTolerance * 2;

	return PositionStable && SizeStable;
}

// ---------- Apply NMS ----------
vector<struct _AIData_> ClassicalVideoDetector ::applyNMS(vector<struct _AIData_> &Detections, float IOUThreshold) const
{
	if (Detections.empty())
	{
		return {};
	}

	sort(Detections.begin(), Detections.end(), [](const struct _AIData_ &A, const struct _AIData_ &B)
		 { return A.Confidance > B.Confidance; });

	vector<struct _AIData_> Result;
	vector<bool> Suppressed(Detections.size(), false);

	for (size_t i = 0; i < Detections.size(); i++)
	{
		if (Suppressed[i])
		{
			continue;
		}

		Result.push_back(Detections[i]);
		for (size_t j = i + 1; j < Detections.size(); j++)
		{
			if (Suppressed[j])
			{
				continue;
			}

			if (rectIOU(Detections[i].BoundingBox, Detections[j].BoundingBox) > IOUThreshold)
			{
				Suppressed[j] = true;
			}
		}
	}

	return Result;
}

// ---------- Hungarian Solve ----------
void ClassicalVideoDetector ::hungarianSolve(const vector<vector<float>> &Cost, vector<Int32_t> &Assignment) const
{
	const float INF = 1e9f;
	Int32_t Rows = static_cast<Int32_t>(Cost.size());
	if (Rows == 0)
	{
		Assignment.clear();
		return;
	}

	Int32_t Cols = static_cast<Int32_t>(Cost[0].size());
	Int32_t N = max(Rows, Cols);
	vector<vector<float>> A(N, vector<float>(N, INF));

	for (Int32_t i = 0; i < Rows; i++)
	{
		for (Int32_t j = 0; j < Cols; j++)
		{
			A[i][j] = Cost[i][j];
		}
	}

	vector<float> U(N + 1, 0), V(N + 1, 0), MinV;
	vector<Int32_t> P(N + 1, 0), Way(N + 1, 0);

	for (Int32_t i = 1; i <= N; i++)
	{
		P[0] = i;
		Int32_t J0 = 0;
		MinV.assign(N + 1, INF);
		vector<Int8_t> Used(N + 1, false);

		do
		{
			Used[J0] = true;
			Int32_t I0 = P[J0];
			Int32_t J1 = 0;
			float Delta = INF;

			for (Int32_t j = 1; j <= N; j++)
			{
				if (Used[j])
				{
					continue;
				}

				float Cur = A[I0 - 1][j - 1] - U[I0] - V[j];
				if (Cur < MinV[j])
				{
					MinV[j] = Cur;
					Way[j] = J0;
				}
				if (MinV[j] < Delta)
				{
					Delta = MinV[j];
					J1 = j;
				}
			}

			for (Int32_t j = 0; j <= N; j++)
			{
				if (Used[j])
				{
					U[P[j]] += Delta;
					V[j] -= Delta;
				}
				else
				{
					MinV[j] -= Delta;
				}
			}
			J0 = J1;
		} while (P[J0] != 0);

		do
		{
			Int32_t J1 = Way[J0];
			P[J0] = P[J1];
			J0 = J1;
		} while (J0);
	}

	vector<Int32_t> Ans(N + 1, 0);
	for (Int32_t j = 1; j <= N; j++)
	{
		Ans[P[j]] = j;
	}

	Assignment.assign(Rows, -1);
	for (Int32_t i = 1; i <= Rows; i++)
	{
		if (Ans[i] >= 1 && Ans[i] <= Cols)
		{
			Assignment[i - 1] = Ans[i] - 1;
		}
	}
}

// ---------- Extract Template Crop ----------
Mat ClassicalVideoDetector ::extractTemplate(const Mat &GrayFrame, const Rect &Box) const
{
	Rect SafeBox = Box & Rect(0, 0, GrayFrame.cols, GrayFrame.rows);
	if (SafeBox.width < 6 || SafeBox.height < 6)
	{
		return Mat();
	}

	Mat TemplateImage = GrayFrame(SafeBox).clone();
	equalizeHist(TemplateImage, TemplateImage);
	return TemplateImage;
}

// ---------- Update Track Position With Template Matching ----------
bool ClassicalVideoDetector ::updateTrackByTemplate(struct _ClassicalTrack_ &Track, const Mat &GrayFrame)
{
	Track.TemplateMatched = false;
	Track.TemplateScore = 0.0f;

	if (Track.TemplateImage.empty() || GrayFrame.empty())
	{
		return false;
	}

	Rect SearchBox = Track.BoundingBox;
	const Int32_t Pad = max(30, static_cast<Int32_t>(max(SearchBox.width, SearchBox.height) * 1.5f));
	SearchBox.x -= Pad;
	SearchBox.y -= Pad;
	SearchBox.width += Pad * 2;
	SearchBox.height += Pad * 2;
	SearchBox &= Rect(0, 0, GrayFrame.cols, GrayFrame.rows);

	if (SearchBox.width < Track.TemplateImage.cols || SearchBox.height < Track.TemplateImage.rows)
	{
		return false;
	}

	Mat SearchGray = GrayFrame(SearchBox).clone();
	equalizeHist(SearchGray, SearchGray);

	Mat MatchResult;
	matchTemplate(SearchGray, Track.TemplateImage, MatchResult, TM_CCOEFF_NORMED);

	double MinVal = 0.0, MaxVal = 0.0;
	Point MinLoc, MaxLoc;
	minMaxLoc(MatchResult, &MinVal, &MaxVal, &MinLoc, &MaxLoc);

	Track.TemplateScore = static_cast<float>(MaxVal);
	if (Track.TemplateScore < TemplateMatchThreshold)
	{
		return false;
	}

	Track.BoundingBox.x = SearchBox.x + MaxLoc.x;
	Track.BoundingBox.y = SearchBox.y + MaxLoc.y;
	Track.BoundingBox.width = Track.TemplateImage.cols;
	Track.BoundingBox.height = Track.TemplateImage.rows;
	Track.BoundingBox &= Rect(0, 0, GrayFrame.cols, GrayFrame.rows);
	Track.Center = Point2f(Track.BoundingBox.x + Track.BoundingBox.width * 0.5f, Track.BoundingBox.y + Track.BoundingBox.height * 0.5f);
	Track.TemplateMatched = true;

	return true;
}

// ---------- Template Based Tracking ----------
void ClassicalVideoDetector ::templateTrack(Mat &VideoFrame)
{
	Mat GrayFrame;
	if (VideoFrame.channels() == 3)
	{
		cvtColor(VideoFrame, GrayFrame, COLOR_BGR2GRAY);
	}
	else
	{
		GrayFrame = VideoFrame.clone();
	}

	for (auto &Track : TrackArr)
	{
		updateTrackByTemplate(Track, GrayFrame);
	}

	const Int32_t TrackCnt = static_cast<Int32_t>(TrackArr.size());
	const Int32_t DetCnt = static_cast<Int32_t>(TargetDataArr.size());
	vector<vector<float>> Cost(TrackCnt, vector<float>(DetCnt, 1e3f));

	for (Int32_t t = 0; t < TrackCnt; t++)
	{
		for (Int32_t d = 0; d < DetCnt; d++)
		{
			const float Dist = centerDistance(TrackArr[t].BoundingBox, TargetDataArr[d].BoundingBox);
			if (Dist > MaxAssocDist)
			{
				continue;
			}

			const float IOUScore = rectIOU(TrackArr[t].BoundingBox, TargetDataArr[d].BoundingBox);
			Cost[t][d] = (Dist / MaxAssocDist) + (1.0f - IOUScore) * 0.50f;
		}
	}

	vector<Int32_t> Assignment;
	if (TrackCnt > 0 && DetCnt > 0)
	{
		hungarianSolve(Cost, Assignment);
	}

	vector<Int8_t> DetAssigned(DetCnt, false);
	for (Int32_t t = 0; t < TrackCnt; t++)
	{
		Int32_t d = -1;
		if (t < static_cast<Int32_t>(Assignment.size()))
		{
			d = Assignment[t];
		}

		if (d >= 0 && d < DetCnt && Cost[t][d] < 1.0f)
		{
			TrackArr[t].BoundingBox = TargetDataArr[d].BoundingBox;
			TrackArr[t].Center = Point2f(TargetDataArr[d].CenterPoint.x, TargetDataArr[d].CenterPoint.y);
			TrackArr[t].ClassID = TargetDataArr[d].ClassID;
			TrackArr[t].Missed = 0;
			TrackArr[t].Hits += 1;
			TrackArr[t].TemplateImage = extractTemplate(GrayFrame, TargetDataArr[d].BoundingBox);
			TargetDataArr[d].TrackID = TrackArr[t].TrackID;
			DetAssigned[d] = true;
		}
		else if (TrackArr[t].TemplateMatched)
		{
			struct _AIData_ TrackOnlyData;
			TrackOnlyData.Type = 1;
			TrackOnlyData.ClassID = TrackArr[t].ClassID;
			TrackOnlyData.TrackID = TrackArr[t].TrackID;
			TrackOnlyData.Confidance = std::clamp(TrackArr[t].TemplateScore, 0.0f, 0.99f);
			TrackOnlyData.BoundingBox = TrackArr[t].BoundingBox;
			TrackOnlyData.CenterPoint = Point(TrackArr[t].Center.x, TrackArr[t].Center.y);
			TargetDataArr.push_back(TrackOnlyData);
			TrackArr[t].Missed = 0;
		}
		else
		{
			TrackArr[t].Missed++;
		}
	}

	for (Int32_t d = 0; d < DetCnt; d++)
	{
		if (DetAssigned[d])
		{
			continue;
		}

		struct _ClassicalTrack_ NewTrack;
		NewTrack.TrackID = NextTrackID++;
		NewTrack.ClassID = TargetDataArr[d].ClassID;
		NewTrack.BoundingBox = TargetDataArr[d].BoundingBox;
		NewTrack.Center = Point2f(TargetDataArr[d].CenterPoint.x, TargetDataArr[d].CenterPoint.y);
		NewTrack.Missed = 0;
		NewTrack.Hits = 1;
		NewTrack.TemplateImage = extractTemplate(GrayFrame, TargetDataArr[d].BoundingBox);
		TrackArr.push_back(NewTrack);
		TargetDataArr[d].TrackID = NewTrack.TrackID;
	}

	TrackArr.erase(remove_if(TrackArr.begin(), TrackArr.end(), [this](const struct _ClassicalTrack_ &Track)
							 { return Track.Missed > MaxMissedFrames; }),
				   TrackArr.end());
}

// ---------- Filter Stationary Targets ----------
vector<struct _AIData_> ClassicalVideoDetector ::filterStationaryTargets(const vector<struct _AIData_> &Detections)
{
	vector<struct _AIData_> MovingDetections;
	MovingDetections.reserve(Detections.size());

	vector<bool> TrackUsed(StationaryTrackArr.size(), false);

	for (const auto &Detection : Detections)
	{
		const Rect CurrentBox = Detection.BoundingBox;
		Int32_t BestTrack = -1;
		double BestDistance = 1e30;

		for (size_t t = 0; t < StationaryTrackArr.size(); t++)
		{
			if (TrackUsed[t])
			{
				continue;
			}

			const Rect &PreviousBox = StationaryTrackArr[t].LastBox;
			const double Distance = centerDistance(PreviousBox, CurrentBox);
			const double DynamicMatchDistance = max(StationaryMatchDistance, 0.35 * static_cast<double>(max(PreviousBox.width, PreviousBox.height)));
			const Int32_t MaxSizeChange = max(10, static_cast<Int32_t>(0.50 * max(PreviousBox.width, PreviousBox.height)));

			const bool SizeReasonable =
				abs(CurrentBox.width - PreviousBox.width) <= MaxSizeChange &&
				abs(CurrentBox.height - PreviousBox.height) <= MaxSizeChange;

			if (SizeReasonable && Distance <= DynamicMatchDistance && Distance < BestDistance)
			{
				BestDistance = Distance;
				BestTrack = static_cast<Int32_t>(t);
			}
		}

		bool Stationary = false;
		if (BestTrack >= 0)
		{
			struct _StationaryTrack_ &Track = StationaryTrackArr[BestTrack];
			TrackUsed[BestTrack] = true;
			Track.MissedFrames = 0;
			Track.LastBox = CurrentBox;
			Track.History.push_back(CurrentBox);

			if (Track.History.size() > static_cast<size_t>(StationaryStableFrames))
			{
				Track.History.erase(Track.History.begin());
			}

			Stationary = isStationaryTrack(Track.History);
			if (Stationary == true && Track.Stationary == false)
			{
				cout << "[STATIC] Suppressing stationary target X=" << Detection.CenterPoint.x
					 << " Y=" << Detection.CenterPoint.y << endl;
			}
			Track.Stationary = Stationary;
		}
		else
		{
			struct _StationaryTrack_ NewTrack;
			NewTrack.LastBox = CurrentBox;
			NewTrack.History.push_back(CurrentBox);
			StationaryTrackArr.push_back(NewTrack);
			TrackUsed.push_back(true);
		}

		if (Stationary == false)
		{
			MovingDetections.push_back(Detection);
		}
	}

	for (size_t t = 0; t < StationaryTrackArr.size(); t++)
	{
		if (TrackUsed[t] == false)
		{
			StationaryTrackArr[t].MissedFrames++;
		}
	}

	for (size_t t = StationaryTrackArr.size(); t-- > 0;)
	{
		if (StationaryTrackArr[t].MissedFrames > StationaryMaxMissedFrames)
		{
			StationaryTrackArr.erase(StationaryTrackArr.begin() + static_cast<long>(t));
		}
	}

	return MovingDetections;
}

// ---------- Filter Exact Repeated Coordinates ----------
vector<struct _AIData_> ClassicalVideoDetector ::filterRepeatedCoordinates(const vector<struct _AIData_> &Detections)
{
	RepeatedFrameNumber++;
	for (auto &Track : RepeatedCoordinateTrackArr)
	{
		Track.SeenThisFrame = false;
	}

	vector<struct _AIData_> KeptDetections;
	KeptDetections.reserve(Detections.size());

	for (const auto &Detection : Detections)
	{
		const Int32_t X = Detection.CenterPoint.x;
		const Int32_t Y = Detection.CenterPoint.y;
		Int32_t MatchedTrack = -1;

		for (size_t t = 0; t < RepeatedCoordinateTrackArr.size(); t++)
		{
			if (RepeatedCoordinateTrackArr[t].SeenThisFrame == false &&
				RepeatedCoordinateTrackArr[t].X == X &&
				RepeatedCoordinateTrackArr[t].Y == Y)
			{
				MatchedTrack = static_cast<Int32_t>(t);
				break;
			}
		}

		Int32_t Consecutive = 1;
		if (MatchedTrack >= 0)
		{
			struct _RepeatedCoordinateTrack_ &Track = RepeatedCoordinateTrackArr[MatchedTrack];
			if (Track.LastSeenFrame == RepeatedFrameNumber - 1)
			{
				Track.ConsecutiveFrames++;
			}
			else
			{
				Track.ConsecutiveFrames = 1;
			}

			Track.LastSeenFrame = RepeatedFrameNumber;
			Track.SeenThisFrame = true;
			Consecutive = Track.ConsecutiveFrames;
		}
		else
		{
			struct _RepeatedCoordinateTrack_ NewTrack;
			NewTrack.X = X;
			NewTrack.Y = Y;
			NewTrack.ConsecutiveFrames = 1;
			NewTrack.LastSeenFrame = RepeatedFrameNumber;
			NewTrack.SeenThisFrame = true;
			RepeatedCoordinateTrackArr.push_back(NewTrack);
		}

		if (Consecutive < StaticCoordFrames)
		{
			KeptDetections.push_back(Detection);
		}
		else if (Consecutive == StaticCoordFrames)
		{
			cout << "[STATIC-COORD] Suppressing repeated target X=" << X
				 << " Y=" << Y << " after " << Consecutive
				 << " consecutive identical frames." << endl;
		}
	}

	for (size_t t = RepeatedCoordinateTrackArr.size(); t-- > 0;)
	{
		if (RepeatedCoordinateTrackArr[t].SeenThisFrame == false)
		{
			RepeatedCoordinateTrackArr.erase(RepeatedCoordinateTrackArr.begin() + static_cast<long>(t));
		}
	}

	return KeptDetections;
}

// ---------- Select N Targets Nearest To Frame Centre ----------
void ClassicalVideoDetector ::selectNearestCentreTargets(Size FrameSize)
{
	if (TargetDataArr.empty())
	{
		return;
	}

	const Int32_t KeepCount = min(max(1, CentreTargetCount), static_cast<Int32_t>(TargetDataArr.size()));
	const Point2d FrameCentre(FrameSize.width * 0.5, FrameSize.height * 0.5);

	struct _RankedTarget_
	{
		double Distance;
		size_t Index;
	};

	vector<struct _RankedTarget_> RankedTargets;
	RankedTargets.reserve(TargetDataArr.size());

	for (size_t i = 0; i < TargetDataArr.size(); i++)
	{
		const double DX = static_cast<double>(TargetDataArr[i].CenterPoint.x) - FrameCentre.x;
		const double DY = static_cast<double>(TargetDataArr[i].CenterPoint.y) - FrameCentre.y;
		RankedTargets.push_back({hypot(DX, DY), i});
	}

	sort(RankedTargets.begin(), RankedTargets.end(), [](const struct _RankedTarget_ &A, const struct _RankedTarget_ &B)
		 {
			 if (A.Distance != B.Distance)
			 {
				 return A.Distance < B.Distance;
			 }
			 return A.Index < B.Index;
		 });

	vector<struct _AIData_> SelectedTargets;
	SelectedTargets.reserve(KeepCount);
	for (Int32_t i = 0; i < KeepCount; i++)
	{
		SelectedTargets.push_back(TargetDataArr[RankedTargets[i].Index]);
	}

	TargetDataArr = SelectedTargets;
	LastCentreTargetArr = SelectedTargets;
	CentreMissedFrames = 0;
}

// ---------- Hold Previous Centre Targets For Short Detector Misses ----------
bool ClassicalVideoDetector ::appendCentreHoldTargets(Size FrameSize)
{
	(void)FrameSize;

	if (LastCentreTargetArr.empty() || CentreMissedFrames >= CentreHoldMaxFrames)
	{
		if (!LastCentreTargetArr.empty())
		{
			CentreMissedFrames++;
		}
		return false;
	}

	CentreMissedFrames++;
	TargetDataArr.insert(TargetDataArr.end(), LastCentreTargetArr.begin(), LastCentreTargetArr.end());
	return !TargetDataArr.empty();
}

// ---------- Draw Corner Style Bounding Box ----------
void ClassicalVideoDetector ::drawCornerBox(Mat &VideoFrame, const Rect &Box, const Scalar &Color, Int32_t Thickness, Int32_t CornerLength) const
{
	if (VideoFrame.empty() || Box.width <= 0 || Box.height <= 0)
	{
		return;
	}

	const Int32_t X1 = Box.x;
	const Int32_t Y1 = Box.y;
	const Int32_t X2 = Box.x + Box.width - 1;
	const Int32_t Y2 = Box.y + Box.height - 1;
	const Int32_t LenX = max(1, min(CornerLength, Box.width / 3));
	const Int32_t LenY = max(1, min(CornerLength, Box.height / 3));

	line(VideoFrame, Point(X1, Y1), Point(X1 + LenX, Y1), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y1), Point(X1, Y1 + LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y1), Point(X2 - LenX, Y1), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y1), Point(X2, Y1 + LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y2), Point(X1 + LenX, Y2), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X1, Y2), Point(X1, Y2 - LenY), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y2), Point(X2 - LenX, Y2), Color, Thickness, LINE_AA);
	line(VideoFrame, Point(X2, Y2), Point(X2, Y2 - LenY), Color, Thickness, LINE_AA);
}

// ---------- Draw Boxes And Fill Target Data ----------
void ClassicalVideoDetector ::drawBoxes(Mat &VideoFrame)
{
	UInt16_t TgtCnt = 0;
	double Dist;

	if (VideoFrame.empty())
	{
		TgtData.TgtDataStruct.Header[0] = AI_ID;
		TgtData.TgtDataStruct.Header[1] = C4I_ID;
		TgtData.TgtDataStruct.Header[2] = TgtDataCmd;
		TgtData.TgtDataStruct.VideoType = AI_Type;
		TgtData.TgtDataStruct.CheckSum = 0x00;
		TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
		TgtData.TgtDataStruct.TgtDataType = CentreTarget;
		TgtData.TgtDataStruct.TargetCnt = 0;
		TgtData.TgtDataStruct.DataLen = 0x05;
		TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;
		return;
	}

	Point FrameCentre(VideoFrame.cols / 2, VideoFrame.rows / 2);

	for (auto &Target : TargetDataArr)
	{
		Rect SafeBox = Target.BoundingBox & Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
		if (SafeBox.width <= 0 || SafeBox.height <= 0)
		{
			continue;
		}

		Target.BoundingBox = SafeBox;
		Target.CenterPoint = Point(SafeBox.x + SafeBox.width / 2, SafeBox.y + SafeBox.height / 2);

		drawCornerBox(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 1, 25);

		Dist = norm(Target.CenterPoint - FrameCentre);
		string Label;
		if (CentreTarget == true)
		{
			Label = "CENTER-PROTECTED Target " + to_string(TgtCnt + 1) + " D:" + to_string(static_cast<Int32_t>(Dist)) + "px (X:" + to_string(Target.CenterPoint.x) + " Y:" + to_string(Target.CenterPoint.y) + ")";
		}
		else
		{
			Label = TargetName + " " + to_string((UInt32_t)(Target.Confidance * 100)) + "% (" + to_string(Target.CenterPoint.x - VideoFrame.cols / 2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows / 2) + ")";
		}
		Int32_t Baseline = 0;
		Size TextSize = getTextSize(Label, FONT_HERSHEY_SIMPLEX, LabelScale, 1, &Baseline);
		Int32_t LabelX = std::clamp(Target.BoundingBox.x, 0, max(0, VideoFrame.cols - TextSize.width - 2));
		Int32_t LabelY = (Target.BoundingBox.y - 5 > TextSize.height) ? Target.BoundingBox.y - 5 : min(VideoFrame.rows - 2, Target.BoundingBox.y + Target.BoundingBox.height + TextSize.height + 4);
		putText(VideoFrame, Label, Point(LabelX, LabelY), FONT_HERSHEY_SIMPLEX, LabelScale, Scalar(255, 255, 255), 1);

		cout << VideoLabel << " Classical DoG : " << TargetName << " ID:" << (UInt32_t)Target.ClassID << (Target.TrackID != 0 ? " TID:" + to_string(Target.TrackID) : "") << " Conf:" << (UInt32_t)(Target.Confidance * 100) << "% Ny:" << (Target.CenterPoint.x - VideoFrame.cols / 2) << " Nz:" << (Target.CenterPoint.y - VideoFrame.rows / 2) << " W:" << Target.BoundingBox.width << " H:" << Target.BoundingBox.height << endl
			 << flush;

		line(VideoFrame, FrameCentre, Target.CenterPoint, Scalar(255, 255, 255), 1, LINE_AA);

		TargetData.ClassID = Target.ClassID;
		TargetData.TrackID = Target.TrackID;
		TargetData.Ny = Target.CenterPoint.x - VideoFrame.cols / 2;
		TargetData.Nz = Target.CenterPoint.y - VideoFrame.rows / 2;
		TargetData.Width = Target.BoundingBox.width;
		TargetData.Height = Target.BoundingBox.height;
		TargetData.Confidance = Target.Confidance * 100;

			if (TgtCnt < 5000)
			{
				TgtData.TgtDataStruct.TgtData[TgtCnt] = TargetData;
				TgtCnt++;
			}
		}

	TgtData.TgtDataStruct.Header[0] = AI_ID;
	TgtData.TgtDataStruct.Header[1] = C4I_ID;
	TgtData.TgtDataStruct.Header[2] = TgtDataCmd;
	TgtData.TgtDataStruct.VideoType = AI_Type;
	TgtData.TgtDataStruct.CheckSum = 0x00;
	TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
	TgtData.TgtDataStruct.TgtDataType = CentreTarget;
	TgtData.TgtDataStruct.TargetCnt = TgtCnt;
	TgtData.TgtDataStruct.DataLen = 0x05 + (TgtCnt * sizeof(struct _TargetData_));
	TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;
}

// ---------- Constructor ----------
ClassicalVideoDetector ::ClassicalVideoDetector(const string &Label, const string &Name, UInt8_t ClassID, Int32_t Thickness, double Scale)
{
	NextTrackID = 1;
	MaxMissedFrames = 15;
	StationaryStableFrames = 6;
	StationarySizeTolerance = 4;
	StationaryMaxMissedFrames = 3;
	CentreHoldMaxFrames = 3;
	CentreMissedFrames = 0;
	RepeatedFrameNumber = 0;
	MaxAssocDist = 120.0f;
	TemplateMatchThreshold = 0.55f;
	StationaryPositionTolerance = 3.0;
	StationaryMatchDistance = 12.0;
	VideoLabel = Label;
	TargetName = Name;
	OutputClassID = ClassID;
	BoxThickness = Thickness;
	LabelScale = Scale;
}

// ---------- Destructor ----------
ClassicalVideoDetector ::~ClassicalVideoDetector(void)
{
	TargetDataArr.clear();
	TrackArr.clear();
}

// ---------- Detect Object Function ----------
void ClassicalVideoDetector ::Run(Mat &VideoFrame)
{
	TargetDataArr.clear();

	if (VideoFrame.empty())
	{
		drawBoxes(VideoFrame);
		return;
	}

	Mat GrayFrame;
	if (VideoFrame.channels() == 3)
	{
		cvtColor(VideoFrame, GrayFrame, COLOR_BGR2GRAY);
	}
	else
	{
		GrayFrame = VideoFrame.clone();
	}

	Mat G1A, G2A, DogA;
	GaussianBlur(GrayFrame, G1A, Size(3, 3), 0.8);
	GaussianBlur(GrayFrame, G2A, Size(7, 7), 2.0);
	subtract(G1A, G2A, DogA, noArray(), CV_16S);

	Mat G1B, G2B, DogB;
	GaussianBlur(GrayFrame, G1B, Size(5, 5), 1.5);
	GaussianBlur(GrayFrame, G2B, Size(11, 11), 3.5);
	subtract(G1B, G2B, DogB, noArray(), CV_16S);

	Mat DogA32, DogB32;
	DogA.convertTo(DogA32, CV_32F);
	DogB.convertTo(DogB32, CV_32F);

	Mat AbsA, AbsB, DogConf;
	absdiff(DogA32, Scalar(0), AbsA);
	absdiff(DogB32, Scalar(0), AbsB);
	max(AbsA, AbsB, DogConf);

	const float DogThreshold = adaptiveResponseThreshold(DogConf);
	Mat MaskA = blobMask(DogA32, DogThreshold);
	Mat MaskB = blobMask(DogB32, DogThreshold);
	Mat CombinedMask;
	bitwise_or(MaskA, MaskB, CombinedMask);
	cleanupMask(CombinedMask);

	vector<vector<Point>> Contours;
	findContours(CombinedMask, Contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

	const double FrameArea = max(1.0, static_cast<double>(GrayFrame.cols) * GrayFrame.rows);
	const double MinArea = max(static_cast<double>(Config.MIN_CONTOUR_AREA), FrameArea * Config.MIN_AREA_FRAC);
	const double MaxAreaPercent = Config.MAX_AREA_FRAC * 100.0;
	vector<struct _AIData_> Candidates;

	for (auto &Contour : Contours)
	{
		const double Area = contourArea(Contour);
		if (Area <= MinArea)
		{
			continue;
		}

		Rect Box = boundingRect(Contour);
		if (Box.width <= 0 || Box.height <= 0)
		{
			continue;
		}
		if (Box.x < 0 || Box.y < 0 || Box.x + Box.width > GrayFrame.cols || Box.y + Box.height > GrayFrame.rows)
		{
			continue;
		}
		if (Box.y > GrayFrame.rows * Config.MAX_VERTICAL_POSITION)
		{
			continue;
		}

		const double Aspect = static_cast<double>(Box.width) / Box.height;
		const double Extent = Area / (Box.width * Box.height);
		const double RelativeArea = (Area / FrameArea) * 100.0;

		if (!(Config.MIN_ASPECT < Aspect && Aspect < Config.MAX_ASPECT && Extent > Config.MIN_EXTENT && RelativeArea < MaxAreaPercent))
		{
			continue;
		}

		const double DogMean = mean(DogConf(Box))[0];
		const double DogNorm = min(DogMean / 50.0, 1.0);
		const double Score = DogNorm * priorWeight(Box, GrayFrame.size());

		struct _AIData_ DetectData;
		DetectData.Type = 0;
		DetectData.ClassID = OutputClassID;
		DetectData.TrackID = 0;
		DetectData.Confidance = static_cast<float>(std::clamp(0.40 + (Score * 0.55), 0.0, 0.99));
		DetectData.BoundingBox = Box;
		DetectData.CenterPoint = Point(Box.x + Box.width / 2, Box.y + Box.height / 2);
		Candidates.push_back(DetectData);
	}

	TargetDataArr = applyNMS(Candidates, 0.18f);
	const bool DetectorReturnedAny = !TargetDataArr.empty();

	if (TrackingFlag == true)
	{
		templateTrack(VideoFrame);
	}

	if (CentreTarget == true)
	{
		TargetDataArr = filterRepeatedCoordinates(TargetDataArr);

		if (!TargetDataArr.empty())
		{
			selectNearestCentreTargets(VideoFrame.size());
		}
		else if (DetectorReturnedAny == false)
		{
			appendCentreHoldTargets(VideoFrame.size());
		}
		else
		{
			LastCentreTargetArr.clear();
			CentreMissedFrames = 0;
		}
	}
	else
	{
		TargetDataArr = filterStationaryTargets(TargetDataArr);
	}

	drawBoxes(VideoFrame);
}
