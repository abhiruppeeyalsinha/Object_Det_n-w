//============================================================================
// Name        : EotsAI-V1.1.3.cpp
// Author      : Solar Industries
// Version     : V1.1.3
// Released On : 11 Nov 2025
//============================================================================


// ---------- Header Inclusion ----------
#include "Struct.h"
#include "Includes.h"
#include "SysConfig.h"

#include "Seeker.h"
#include "IRVideoAI.h"
#include "EOVideoAI.h"
#include "Classical_Det_IRVideo.h"
#include "Classical_Det_EOVideo.h"
#include "C4IInterface.h"


// ---------- Other Flag Variables ----------
bool SaveVideo = false;
bool SingleVideo = false;
bool DisplayFrame = false;
bool AutoSaveVideo = false;
bool ClassicalDetectionFlag = false;

// ---------- AI Flag Variables ----------
bool CentreTarget = true;
bool TrackingFlag = false;
bool BirdPlaneDataFlag = false;
Int32_t CentreTargetCount = 1;
Int32_t StaticCoordFrames = 10;

// ---------- Thread Flag Variables ----------
bool C4ICmdRecvFlag = true;
bool C4IDataSendFlag = true;
bool IRVideoReadFlag = true;
bool EOVideoReadFlag = true;
bool ProcessVideoFlag = true;


// ---------- Software Details ----------
UInt16_t SW_CheckSum = 0U;
string SW_Health = "11/11/25 V01.01.03";	// DD/MM/YY V01.00.00

// ---------- Config Parameters ----------
UInt8_t AI_Type = 0;

string C4I_IPAddr = "0.0.0.0";
Int32_t C4I_Port;
Int32_t AI_Port;

// ---------- Camera Variables ----------
Size IR_Size(640, 512);
Size EO_Size(1920, 1080);

UInt16_t VideoFPS = 25;
UInt16_t FrameDelay = 1000/VideoFPS;

string IR_VideoSrc;
string EO_VideoSrc;

// ---------- AI Parameters ----------
string IR_Track_Model;
string EO_Track_Model;
string IR_Detect_Model;
string EO_Detect_Model;

string EO_ClassName[3] = {"Bird", "Drone" ,"Plane"};
string IR_ClassName[4] = {"Bird", "Fixed", "Hexa", "Plane"};

// ---------- Data Path ----------
string InpPath = "";
string LoadPath = "";
string SavePath = "";
string ParentPath = "";

// ---------- Data Structures & Buffers ----------
union _AICmd_ AICmd;
union _AIResp_ AIResp;
union _TgtData_ TgtData;
struct _TargetData_ TargetData;
struct _VideoData_ C4IVideoData, CameraData;

// ---------- Class Objects ----------
Seeker *SeekerObj;
IRVideoAI *IRVideoAIObj;
EOVideoAI *EOVideoAIObj;
Classical_Det_IRVideo *ClassicalDetIRVideoObj;
Classical_Det_EOVideo *ClassicalDetEOVideoObj;
C4IInterface *C4IInterfaceObj;



// ---------- Main Function ----------
int main(Int32_t argc, Int8_t *argv[])
{
	pthread_t RecvC4ICmdThread;
	pthread_t SendC4IDataThread;
	pthread_t IRVideoReadThread;
	pthread_t EOVideoReadThread;

	struct timespec ts;
	struct _VideoData_ VideoData;

	high_resolution_clock::time_point timCntStart, timCntEnd;
	duration<double, milli> timDuration;


	ts.tv_sec = 0;				// seconds
	ts.tv_nsec = 1000 * 10;		// 10 microseconds

	// Register force stop for CNTL+C
	signal(SIGINT, (void(*)(Int32_t))forceStop);

	SW_CheckSum = getSwCheckSum(getPath(0));

	cout << "Software Details  : " << SW_Health << endl;
	cout << "Software Checksum : 0x" << hex << uppercase << SW_CheckSum << dec << endl;

	// Set load path for the files
	LoadPath = getPath(1);

	// Load Config file
	loadConfigData();

	// Check user flags
	checkFlags(argc, argv);

	// Set Saving path for results
	SavePath = getPath(2);

	if(SingleVideo == true && AI_Type != 1 && AI_Type != 2)
	{
		cout << "Error : Must Select AI Type...." << endl;
		return 0;
	}

	// Create Class Objects
	SeekerObj = new Seeker();
	if(ClassicalDetectionFlag == true)
	{
		IRVideoAIObj = nullptr;
		EOVideoAIObj = nullptr;
		ClassicalDetIRVideoObj = new Classical_Det_IRVideo();
		ClassicalDetEOVideoObj = new Classical_Det_EOVideo();
		cout << "Detection Mode     : Classical DoG" << endl;
	}
	else
	{
		IRVideoAIObj = new IRVideoAI();
		EOVideoAIObj = new EOVideoAI();
		ClassicalDetIRVideoObj = nullptr;
		ClassicalDetEOVideoObj = nullptr;
		cout << "Detection Mode     : AI" << endl;
	}
	C4IInterfaceObj = new C4IInterface();

	if(SingleVideo == false || AI_Type == 1)
	{
		// Create & Start IR Video Reading thread
		if(pthread_create(&IRVideoReadThread, NULL, SeekerObj->readIRFramesThread, SeekerObj))
		{
			perror("IRVideoReadThread");
			delete SeekerObj;
			delete IRVideoAIObj;
			delete EOVideoAIObj;
			delete ClassicalDetIRVideoObj;
			delete ClassicalDetEOVideoObj;
			delete C4IInterfaceObj;
			raise(SIGINT);
		}
	}

	if(SingleVideo == false || AI_Type == 2)
	{
		// Create & Start EO Video Reading thread
		if(pthread_create(&EOVideoReadThread, NULL, SeekerObj->readEOFramesThread, SeekerObj))
		{
			perror("EOVideoReadThread");
			delete SeekerObj;
			delete IRVideoAIObj;
			delete EOVideoAIObj;
			delete ClassicalDetIRVideoObj;
			delete ClassicalDetEOVideoObj;
			delete C4IInterfaceObj;
			raise(SIGINT);
		}
	}

	if(SingleVideo == false)
	{
		// Create & Start C4I Command Receive thread
		if(pthread_create(&RecvC4ICmdThread, NULL, C4IInterfaceObj->recvCmdC4IThread, C4IInterfaceObj))
		{
			perror("RecvC4ICmdThread");
			delete SeekerObj;
			delete IRVideoAIObj;
			delete EOVideoAIObj;
			delete ClassicalDetIRVideoObj;
			delete ClassicalDetEOVideoObj;
			delete C4IInterfaceObj;
			raise(SIGINT);
		}
	}

	// Create & Start C4I Data Send thread
	if(pthread_create(&SendC4IDataThread, NULL, C4IInterfaceObj->sendDataC4IThread, C4IInterfaceObj))
	{
		perror("SendC4IDataThread");
		delete SeekerObj;
		delete IRVideoAIObj;
		delete EOVideoAIObj;
		delete ClassicalDetIRVideoObj;
		delete ClassicalDetEOVideoObj;
		delete C4IInterfaceObj;
		raise(SIGINT);
	}

	cout << "Video Processing Started..." << endl << endl;


	while(ProcessVideoFlag == true)
	{
		if(CameraData.FrameFlag == false)
		{
			clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, nullptr);
			continue;
		}

		VideoData.VideoFrame.release();
		VideoData = CameraData;
		CameraData.FrameFlag = false;

		// Start Measuring Execution Time
		timCntStart = high_resolution_clock::now();

		// Perform Object Detection
		if(VideoData.VideoType == 1)
		{
			if(ClassicalDetectionFlag == true)
			{
				ClassicalDetIRVideoObj->Run(VideoData.VideoFrame);
			}
			else
			{
				IRVideoAIObj->Run_enqueueV2(VideoData.VideoFrame);
			}
		}
		else if(VideoData.VideoType == 2)
		{
			if(ClassicalDetectionFlag == true)
			{
				ClassicalDetEOVideoObj->Run(VideoData.VideoFrame);
			}
			else
			{
				EOVideoAIObj->Run_enqueueV2(VideoData.VideoFrame);
			}
		}
		else
		{
			continue;
		}

		C4IVideoData.VideoFrame.release();
		C4IVideoData = VideoData;
		C4IVideoData.VideoFrame = VideoData.VideoFrame.clone();
		C4IVideoData.FrameFlag = true;

		// Calculate Total Processing Time
		timCntEnd = high_resolution_clock::now();
		timDuration = timCntEnd - timCntStart;
		cout << "Total Process Time - " << timDuration.count() << " ms" << endl << flush;

	}

	// Clear all flags
	SaveVideo = false;
	DisplayFrame = false;
	AutoSaveVideo = false;

	C4ICmdRecvFlag = false;
	C4IDataSendFlag = false;
	IRVideoReadFlag = false;
	EOVideoReadFlag = false;
	ProcessVideoFlag = false;

	destroyAllWindows();
	sleep(1);

	// Close All Threads
	try
	{
		pthread_cancel(RecvC4ICmdThread);
		pthread_cancel(SendC4IDataThread);
		pthread_cancel(IRVideoReadThread);
		pthread_cancel(EOVideoReadThread);
	}
	catch(Exception &e)
	{

	}

	// Delete All Objects
	try
	{
		delete SeekerObj;
		delete IRVideoAIObj;
		delete EOVideoAIObj;
		delete ClassicalDetIRVideoObj;
		delete ClassicalDetEOVideoObj;
		delete C4IInterfaceObj;
	}
	catch(Exception &e)
	{

	}

	cout << "Terminated Successfully..." << endl << flush;
	return 0;
}
