// ============================================================================
// Name        : IRVideoAI.cpp
// Created On  : 11 Nov 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "IRVideoAI.h"

// Logger for TensorRT messages
class Logger : public ILogger
{
	void log(Severity severity, const char *msg) noexcept override
	{
		if (severity <= Severity::kWARNING)
		{
			cout << "[TensorRT] " << msg << endl;
		}
	}
};

static Logger logger;

// ---------- Get Memory Size ----------
size_t IRVideoAI ::getMemorySize(Dims dims, size_t ElementSize)
{
	size_t size = ElementSize;

	for (Int32_t i = 0; i < dims.nbDims; i++)
	{
		size *= dims.d[i];
	}

	return size;
}

// ---------- Hungarian Solve ----------
void IRVideoAI ::HungarianSolve(const vector<vector<float>> &cost, vector<int> &assignment)
{
	const float INF = 1e9f;
	float delta, cur;
	Int32_t n_rows, n_cols, n;
	Int32_t i, j;

	Int32_t j0, i0, j1;

	n_rows = (Int32_t)cost.size();
	if (n_rows == 0)
	{
		assignment.clear();
		return;
	}

	n_cols = (Int32_t)cost[0].size();
	n = max(n_rows, n_cols);

	vector<vector<float>> a(n, vector<float>(n, INF));
	for (i = 0; i < n_rows; i++)
	{
		for (j = 0; j < n_cols; j++)
		{
			a[i][j] = cost[i][j];
		}
	}

	vector<float> u(n + 1, 0), v(n + 1, 0);
	vector<Int32_t> p(n + 1, 0), way(n + 1, 0);
	for (i = 1; i <= n; i++)
	{
		p[0] = i;
		j0 = 0;
		vector<float> minv(n + 1, INF);
		vector<Int8_t> used(n + 1, false);
		do
		{
			used[j0] = true;
			i0 = p[j0];
			j1 = 0;
			delta = INF;
			for (j = 1; j <= n; j++)
			{
				if (used[j])
				{
					continue;
				}

				cur = a[i0 - 1][j - 1] - u[i0] - v[j];
				if (cur < minv[j])
				{
					minv[j] = cur;
					way[j] = j0;
				}
				if (minv[j] < delta)
				{
					delta = minv[j];
					j1 = j;
				}
			}
			for (j = 0; j <= n; j++)
			{
				if (used[j])
				{
					u[p[j]] += delta;
					v[j] -= delta;
				}
				else
				{
					minv[j] -= delta;
				}
			}
			j0 = j1;
		} while (p[j0] != 0);

		do
		{
			j1 = way[j0];
			p[j0] = p[j1];
			j0 = j1;
		} while (j0);
	}

	vector<Int32_t> ans(n + 1, 0);
	for (j = 1; j <= n; j++)
	{
		ans[p[j]] = j;
	}

	assignment.assign(n_rows, -1);
	for (i = 1; i <= n_rows; i++)
	{
		if (ans[i] >= 1 && ans[i] <= n_cols)
		{
			assignment[i - 1] = ans[i] - 1;
		}
		else
		{
			assignment[i - 1] = -1;
		}
	}

	return;
}

// ---------- L2 Normalize ----------
void IRVideoAI ::l2Normalize(vector<float> &v)
{
	double Sum = 0.0, Denom = 0.0;
	for (float x : v)
	{
		Sum += (double)x * (double)x;
	}

	Denom = sqrt(Sum) + 1e-12;
	for (float &x : v)
	{
		x = (float)(x / Denom);
	}

	return;
}

// ---------- Rect IOU ----------
float IRVideoAI ::RectIOU(const Rect &a, const Rect &b)
{
	Int32_t X1, Y1, X2, Y2, W, H;
	float Inter, AreaA, AreaB, Uni;

	X1 = max(a.x, b.x);
	Y1 = max(a.y, b.y);
	X2 = min(a.x + a.width, b.x + b.width);
	Y2 = min(a.y + a.height, b.y + b.height);
	W = max(0, X2 - X1);
	H = max(0, Y2 - Y1);
	Inter = (float)(W * H);
	AreaA = (float)(a.width * a.height);
	AreaB = (float)(b.width * b.height);
	Uni = AreaA + AreaB - Inter + 1e-6f;

	return (Inter / Uni);
}

// ---------- Load Detection Engine File ----------
bool IRVideoAI ::LoadDetectModel(void)
{
	try
	{
		ifstream EngineFile(IR_Detect_Model, ios::binary);
		if (!EngineFile)
		{
			cerr << "Failed to read engine file." << endl;
			return false;
		}

		EngineFile.seekg(0, ios::end);

		auto fsize = EngineFile.tellg();
		EngineFile.seekg(0, ios::beg);

		vector<char> engine_data(fsize);
		EngineFile.read(engine_data.data(), fsize);
		EngineFile.close();

		runtime.reset(createInferRuntime(logger));
		engine.reset(runtime->deserializeCudaEngine(engine_data.data(), fsize));
		context.reset(engine->createExecutionContext());

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

		Int32_t nbBindings = engine->getNbIOTensors();
		Bindings.resize(nbBindings, nullptr);
		BindingSizes.resize(nbBindings, 0);

		for (Int32_t i = 0; i < nbBindings; i++)
		{
			const char *TensorName = engine->getIOTensorName(i);
			Dims dims = engine->getTensorShape(TensorName);
			BindingSizes[i] = getMemorySize(dims, sizeof(__half));
			cudaMalloc(&Bindings[i], BindingSizes[i]);
			context->setTensorAddress(TensorName, Bindings[i]);
		}

#pragma GCC diagnostic pop

		cudaStreamCreate(&Stream);

		InpBuff.resize(BindingSizes[0] / sizeof(__half));
		OutBuff.resize(BindingSizes[1] / sizeof(__half));

		return true;
	}
	catch (Exception &e)
	{
		return false;
	}

	return false;
}

// ---------- Load Tracking Engine File ----------
bool IRVideoAI ::LoadTrackModel(void)
{
	try
	{
		ifstream EngineFile(IR_Track_Model, ios::binary);
		if (!EngineFile)
		{
			cerr << "Failed to read ReIDengine file." << endl;
			return false;
		}

		EngineFile.seekg(0, ios::end);

		auto fsize = EngineFile.tellg();
		EngineFile.seekg(0, ios::beg);

		vector<char> engine_data(fsize);
		EngineFile.read(engine_data.data(), fsize);
		EngineFile.close();

		ReIDruntime.reset(createInferRuntime(logger));
		ReIDengine.reset(ReIDruntime->deserializeCudaEngine(engine_data.data(), fsize));
		ReIDcontext.reset(ReIDengine->createExecutionContext());

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

		Int32_t nbBindings = ReIDengine->getNbIOTensors();
		ReIDBindings.resize(nbBindings, nullptr);
		ReIDBindingSizes.resize(nbBindings, 0);

		for (Int32_t i = 0; i < nbBindings; i++)
		{
			const char *TensorName = ReIDengine->getIOTensorName(i);
			Dims dims = ReIDengine->getTensorShape(TensorName);
			ReIDBindingSizes[i] = getMemorySize(dims, sizeof(float));
			cudaMalloc(&ReIDBindings[i], ReIDBindingSizes[i]);
			ReIDcontext->setTensorAddress(TensorName, ReIDBindings[i]);

			if (i == 0)
			{
				ReIDInputDims = dims;
			}

			if (i == 1)
			{
				size_t n = 1;
				for (int d = 0; d < dims.nbDims; d++)
				{
					n *= dims.d[d];
				}

				ReIDOutputSize = n;
			}
		}

#pragma GCC diagnostic pop

		cudaStreamCreate(&ReIDStream);

		if (ReIDBindingSizes.size() < 2)
		{
			return false;
		}

		ReIDInpBuff.resize(ReIDBindingSizes[0] / sizeof(float));
		ReIDOutBuff.resize(ReIDBindingSizes[1] / sizeof(float));

		if (ReIDOutputSize == 0)
		{
			ReIDOutputSize = 512;
		}

		return true;
	}
	catch (Exception &e)
	{
		return false;
	}

	return false;
}

// ---------- PreProcess ----------
void IRVideoAI ::preProcess(Mat VideoFrame, __half *InputBuff)
{
	vector<Mat> FrameChannels(3);
	float *ChannelData;
	UInt32_t Channels;

	// Calculate Padding
	PadX = (Yolov5_DIM.width - VideoFrame.cols) / 2;
	PadY = (Yolov5_DIM.height - VideoFrame.rows) / 2;

	// Resize VideoFrame to Yolov5 required size using padding
	copyMakeBorder(VideoFrame, VideoFrame, PadY, PadY, PadX, PadX, BORDER_CONSTANT, Scalar(0, 0, 0));

	VideoFrame.convertTo(VideoFrame, CV_32F, 1.0 / 255);
	split(VideoFrame, FrameChannels);

	for (Channels = 0; Channels < 3; Channels++)
	{
		ChannelData = reinterpret_cast<float *>(FrameChannels[Channels].data);
		for (Int32_t i = 0; i < Yolov5_DIM.width * Yolov5_DIM.height; i++)
		{
			InpBuff[Channels * Yolov5_DIM.width * Yolov5_DIM.height + i] = __float2half(ChannelData[i]);
		}
	}

	return;
}

// ---------- PostProcess ----------
void IRVideoAI ::postProcess(vector<__half> &Output, UInt16_t VideoWidth, UInt16_t VideoHeight)
{
	vector<Rect> Boxes;
	vector<Int32_t> Indices;
	vector<UInt8_t> ClassIds;
	vector<float> Confidances;
	const UInt32_t Detections = 25200;

	float Confidence;
	float ClassScore[4];
	float ObjConf, ClassConf;
	UInt8_t ClassID = 0;

	Int16_t CentreX, CentreY, Width, Height;
	Int16_t X1, Y1, X2, Y2;

	struct _AIData_ DetectData;

	Boxes.clear();
	Indices.clear();
	ClassIds.clear();
	TargetDataArr.clear();
	Confidances.clear();

	for (UInt32_t i = 0; i < Detections; i++)
	{
		ObjConf = __half2float(Output[(i * 9) + 4]);

		// Skip if Object Confidence is less than Threshold
		if (ObjConf < ConfThreshold)
		{
			continue;
		}

		for (UInt32_t j = 0; j < 4; j++)
		{
			ClassScore[j] = __half2float(Output[(i * 9) + 5 + j]);
		}

		ClassID = max_element(ClassScore, ClassScore + 4) - ClassScore;
		ClassConf = ClassScore[ClassID];
		Confidence = ObjConf * ClassConf;

		// Skip if Confidence is less than Threshold
		if (Confidence <= ConfThreshold)
		{
			continue;
		}

		// Calculate Bounding Box Co-Ordinate & Size
		CentreX = __half2float(Output[i * 9 + 0]) - PadX;
		CentreY = __half2float(Output[i * 9 + 1]) - PadY;
		Width = Output[i * 9 + 2];
		Height = Output[i * 9 + 3];

		X1 = max(0, (CentreX - (Width / 2)));
		Y1 = max(0, (CentreY - (Height / 2)));

		X2 = min(VideoWidth - 1, (CentreX + (Width / 2)));
		Y2 = min(VideoHeight - 1, (CentreY + (Height / 2)));

		if (X2 >= X1 && Y2 >= Y1)
		{
			Boxes.emplace_back(Rect(X1, Y1, X2 - X1, Y2 - Y1));
			Confidances.emplace_back(Confidence);
			ClassIds.emplace_back(ClassID);
		}
	}

	dnn::NMSBoxes(Boxes, Confidances, ConfThreshold, IOUThreshold, Indices);

	for (UInt32_t idx : Indices)
	{
		DetectData.ClassID = ClassIds[idx];
		DetectData.TrackID = 0;
		DetectData.Confidance = Confidances[idx];
		DetectData.BoundingBox = Boxes[idx];
		DetectData.CenterPoint = Point(Boxes[idx].x + Boxes[idx].width / 2, Boxes[idx].y + Boxes[idx].height / 2);

		TargetDataArr.push_back(DetectData);
	}

	return;
}

// ---------- Tracking Inference ----------
void IRVideoAI ::ReIDInferance(Mat VideoFrame, vector<vector<float>> &OutFeatures)
{
	Rect bb;
	Mat crop, resized;
	vector<Mat> chs(3);

	vector<float> feat;
	size_t interleavedBytes;

	float v;
	float *ptr, *rowptr;
	int c = 0, r = 0, cc = 0, idx = 0;

	UInt32_t TargetCnt = 0;
	Int32_t inC = 3, inH = 128, inW = 256;

	// Host normalization arrays
	const float mean[3] = {0.485f, 0.456f, 0.406f};
	const float stdv[3] = {0.229f, 0.224f, 0.225f};

	// If No Detection
	if (TargetDataArr.empty())
	{
		OutFeatures.clear();
		return;
	}

	TargetCnt = TargetDataArr.size();

	// Determine input dims
	if (ReIDInputDims.nbDims == 4)
	{
		inC = ReIDInputDims.d[1];
		inH = ReIDInputDims.d[2];
		inW = ReIDInputDims.d[3];
	}
	else if (ReIDInputDims.nbDims == 3)
	{
		inC = ReIDInputDims.d[0];
		inH = ReIDInputDims.d[1];
		inW = ReIDInputDims.d[2];
	}
	else
	{
	}

	for (UInt32_t i = 0; i < TargetCnt; i++)
	{
		bb = TargetDataArr[i].BoundingBox & Rect(0, 0, VideoFrame.cols, VideoFrame.rows);
		if (bb.width <= 0 || bb.height <= 0)
		{
			OutFeatures[i].clear();
			continue;
		}

		crop = VideoFrame(bb).clone();
		if (crop.channels() == 3)
		{
			cvtColor(crop, crop, COLOR_BGR2RGB);
		}
		else
		{
			cvtColor(crop, crop, COLOR_GRAY2RGB);
		}

		resize(crop, resized, Size(inW, inH), 0, 0, INTER_LINEAR);
		resized.convertTo(resized, CV_32F, 1.0 / 255.0);

		interleavedBytes = (size_t)inH * (size_t)inW;
		if (ReIDInpBuff.size() < interleavedBytes * inC)
		{
			cerr << "IR ReID host input size mismatch" << endl;
			break;
		}

		split(resized, chs);
		for (c = 0; c < inC; c++)
		{
			ptr = ReIDInpBuff.data() + (c * interleavedBytes);
			idx = 0;
			for (r = 0; r < inH; r++)
			{
				rowptr = chs[c].ptr<float>(r);
				for (cc = 0; cc < inW; cc++)
				{
					v = rowptr[cc];
					v = (v - mean[c]) / stdv[c];
					ptr[idx++] = v;
				}
			}
		}

		cudaMemcpyAsync(ReIDBindings[0], ReIDInpBuff.data(), ReIDBindingSizes[0], cudaMemcpyHostToDevice, ReIDStream);

// enqueue inference
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

		if (ReIDcontext->enqueueV3(ReIDStream) == false)
		{
			cout << "ReID Inference failed..." << endl;
			continue;
		}

		cudaMemcpyAsync(ReIDOutBuff.data(), ReIDBindings[1], ReIDBindingSizes[1], cudaMemcpyDeviceToHost, ReIDStream);
		cudaStreamSynchronize(ReIDStream);
#pragma GCC diagnostic pop

		// build feature
		feat.resize(ReIDOutputSize);
		for (size_t k = 0; k < ReIDOutputSize && k < ReIDOutBuff.size(); ++k)
		{
			feat[k] = ReIDOutBuff[k];
		}
		l2Normalize(feat);
		OutFeatures[i] = move(feat);
	}

	return;
}

// ---------- Tracking PostProcess ----------
void IRVideoAI ::ReIDpostProcess(vector<vector<float>> &ReIDFeatures, vector<struct _AIData_> &TargetDataArr)
{
	size_t k;
	Int32_t T, D, t, d;

	Point2f p_ReID, p_target;

	float DistReID = 1.0f;
	float IOUScore, c, CenterDist;

	double Denom, CosSim;
	double dot = 0, na = 0, nb = 0;

	vector<Int32_t> assignment;

	T = (Int32_t)DSTrackArr.size();
	D = (Int32_t)TargetDataArr.size();
	vector<vector<float>> cost(T, vector<float>(D, 1e3f));

	for (t = 0; t < T; ++t)
	{
		for (d = 0; d < D; ++d)
		{
			DistReID = 1.0f;
			if (!DSTrackArr[t].Feature.empty() && d < (Int32_t)ReIDFeatures.size() && !ReIDFeatures[d].empty())
			{
				dot = 0;
				na = 0;
				nb = 0;

				for (k = 0; k < DSTrackArr[t].Feature.size() && k < ReIDFeatures[d].size(); ++k)
				{
					dot += (double)DSTrackArr[t].Feature[k] * (double)ReIDFeatures[d][k];
					na += (double)DSTrackArr[t].Feature[k] * DSTrackArr[t].Feature[k];
					nb += (double)ReIDFeatures[d][k] * ReIDFeatures[d][k];
				}
				Denom = sqrt(na) * sqrt(nb) + 1e-6;
				CosSim = dot / Denom;
				DistReID = (float)(1.0 - CosSim);
			}
			IOUScore = RectIOU(DSTrackArr[t].BBox, TargetDataArr[d].BoundingBox);
			c = ReID_DistWeight * DistReID + ReID_IoUWeight * (1.0f - IOUScore);

			p_ReID = DSTrackArr[t].Center;
			p_target.x = TargetDataArr[d].CenterPoint.x;
			p_target.y = TargetDataArr[d].CenterPoint.y;

			CenterDist = static_cast<float>(norm(p_ReID - p_target));
			if (CenterDist > MaxAssocDist)
			{
				c = 1e3f;
			}
			cost[t][d] = c;
		}
	}

	assignment.clear();
	if (T > 0 && D > 0)
	{
		HungarianSolve(cost, assignment);
	}
	else
	{
		assignment.clear();
	}

	vector<char> detAssigned(D, false);
	for (t = 0; t < T; t++)
	{
		d = -1;
		if (t < (Int32_t)assignment.size())
		{
			d = assignment[t];
		}
		if (d >= 0 && d < D && cost[t][d] < 1e2f)
		{
			DSTrackArr[t].BBox = TargetDataArr[d].BoundingBox;
			DSTrackArr[t].Center = Point2f((float)TargetDataArr[d].CenterPoint.x, (float)TargetDataArr[d].CenterPoint.y);
			DSTrackArr[t].Missed = 0;
			DSTrackArr[t].Hits += 1;
			Mat meas = (Mat_<float>(2, 1) << DSTrackArr[t].Center.x, DSTrackArr[t].Center.y);
			DSTrackArr[t].kf.correct(meas);
			if (d < (Int32_t)ReIDFeatures.size() && !ReIDFeatures[d].empty())
			{
				DSTrackArr[t].Feature = ReIDFeatures[d];
			}
			TargetDataArr[d].TrackID = DSTrackArr[t].TrackID;
			detAssigned[d] = true;
		}
		else
		{
			DSTrackArr[t].Missed++;
			Mat pred = DSTrackArr[t].kf.predict();
			DSTrackArr[t].Center = Point2f(pred.at<float>(0), pred.at<float>(1));
		}
	}

	// create new ReIDs for unmatched detections
	for (d = 0; d < D; ++d)
	{
		if (detAssigned[d])
		{
			continue;
		}

		struct _DSTrack_ nt;

		nt.TrackID = DS_NextTrackID++;
		nt.BBox = TargetDataArr[d].BoundingBox;
		nt.Center = Point2f((float)TargetDataArr[d].CenterPoint.x, (float)TargetDataArr[d].CenterPoint.y);
		nt.Missed = 0;
		nt.Hits = 1;
		nt.kf = cv::KalmanFilter(4, 2);
		nt.kf.transitionMatrix = (Mat_<float>(4, 4) << 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1);
		nt.kf.measurementMatrix = (Mat_<float>(2, 4) << 1, 0, 0, 0, 0, 1, 0, 0);
		nt.kf.processNoiseCov = Mat::eye(4, 4, CV_32F) * 1e-2f;
		nt.kf.measurementNoiseCov = Mat::eye(2, 2, CV_32F) * 1e-1f;
		nt.kf.errorCovPost = Mat::eye(4, 4, CV_32F);
		nt.kf.statePost = (Mat_<float>(4, 1) << nt.Center.x, nt.Center.y, 0, 0);
		if (d < (Int32_t)ReIDFeatures.size() && !ReIDFeatures[d].empty())
		{
			nt.Feature = ReIDFeatures[d];
		}
		DSTrackArr.push_back(std::move(nt));
		TargetDataArr[d].TrackID = DSTrackArr.back().TrackID;
	}

	// drop stale ReIDs
	DSTrackArr.erase(remove_if(DSTrackArr.begin(), DSTrackArr.end(), [this](const struct _DSTrack_ &t)
							   { return t.Missed > MaxMissedFrames; }),
					 DSTrackArr.end());

	return;
}

// ---------- Get CoOrdinates ----------
void IRVideoAI ::drawBoxes(Mat &VideoFrame)
{
	UInt16_t TgtCnt = 0;
	string Label = "";
	double Dist, MinDist = numeric_limits<double>::max();
	Point FrameCentre(VideoFrame.cols / 2, VideoFrame.rows / 2);

	// Draw quadrants
	line(VideoFrame, Point(FrameCentre.x, 0), Point(FrameCentre.x, VideoFrame.rows), Scalar(255, 255, 255), 1);
	line(VideoFrame, Point(0, FrameCentre.y), Point(VideoFrame.cols, FrameCentre.y), Scalar(255, 255, 255), 1);

	for (auto &Target : TargetDataArr)
	{
		if (4 < Target.ClassID)
		{
			continue;
		}

		rectangle(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 1);

		Label = IR_ClassName[Target.ClassID] + (Target.TrackID != 0 ? " (" + to_string(Target.TrackID) + ")" : "") + " " + to_string((UInt32_t)(Target.Confidance * 100)) + "% (" + to_string(Target.CenterPoint.x - VideoFrame.cols / 2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows / 2) + ")";

		putText(VideoFrame, Label, Target.BoundingBox.tl(), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(255, 255, 255), 1);

		cout << "IR Video AI : " << IR_ClassName[Target.ClassID] << " ID:" << (UInt32_t)Target.ClassID << (Target.TrackID != 0 ? " TID:" + to_string(Target.TrackID) : "") << " Conf:" << (UInt32_t)(Target.Confidance * 100) << "% Ny:" << (Target.CenterPoint.x - VideoFrame.cols / 2) << " Nz:" << (Target.CenterPoint.y - VideoFrame.rows / 2) << " W:" << Target.BoundingBox.width << " H:" << Target.BoundingBox.height << endl
			 << flush;

		if (Target.ClassID == 1 || Target.ClassID == 2)
		{
			line(VideoFrame, FrameCentre, Target.CenterPoint, Scalar(255, 255, 255), 1);
		}
		else
		{
			if (BirdPlaneDataFlag == false)
			{
				continue;
			}
		}

		TargetData.ClassID = Target.ClassID;
		TargetData.TrackID = Target.TrackID;
		TargetData.Ny = Target.CenterPoint.x - VideoFrame.cols / 2;
		TargetData.Nz = Target.CenterPoint.y - VideoFrame.rows / 2;
		TargetData.Width = Target.BoundingBox.width;
		TargetData.Height = Target.BoundingBox.height;
		TargetData.Confidance = Target.Confidance * 100;

		if (CentreTarget == true)
		{
			Dist = norm(Target.CenterPoint - FrameCentre);
			if (Dist < MinDist)
			{
				MinDist = Dist;

				TgtData.TgtDataStruct.TgtData[0] = TargetData;
				TgtCnt = 1;
			}
		}
		else
		{
			if (TgtCnt < 5000)
			{
				TgtData.TgtDataStruct.TgtData[TgtCnt] = TargetData;
				TgtCnt++;
			}
		}
	}

	// Set Header
	TgtData.TgtDataStruct.Header[0] = AI_ID;
	TgtData.TgtDataStruct.Header[1] = C4I_ID;
	TgtData.TgtDataStruct.Header[2] = TgtDataCmd;

	TgtData.TgtDataStruct.VideoType = AI_Type;
	TgtData.TgtDataStruct.CheckSum = 0x00;
	TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
	TgtData.TgtDataStruct.TgtDataType = CentreTarget;

	TgtData.TgtDataStruct.TargetCnt = TgtCnt;
	TgtData.TgtDataStruct.DataLen = 0x05 + (TgtCnt * sizeof(struct _TargetData_));
	TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;

	return;
}

// ---------- Constructor ----------
IRVideoAI ::IRVideoAI(void)
{
	Yolov5_DIM.height = 640;
	Yolov5_DIM.width = 640;

	PadY = 0;
	PadX = 0;

	ConfThreshold = 0.6;
	IOUThreshold = 0.6;

	DS_NextTrackID = 1;
	MaxMissedFrames = 25; // 1 Sec
	MaxAssocDist = 500;	  // px
	ReID_IoUWeight = 0.75f;
	ReID_DistWeight = 0.5f;

	if (LoadDetectModel() == true && LoadTrackModel() == true)
	{
		cout << "IR Engine Loaded Successfully" << endl
			 << endl;
	}
	else
	{
	}

	return;
}

// ---------- Destructor ----------
IRVideoAI ::~IRVideoAI(void)
{
	try
	{
		for (void *ptr : Bindings)
		{
			if (ptr)
			{
				cudaFree(ptr);
			}
		}

		cudaStreamDestroy(Stream);
	}
	catch (Exception &e)
	{
	}

	return;
}

// ---------- Detect Object Function ----------
void IRVideoAI ::Run_enqueueV2(Mat &VideoFrame)
{
	vector<vector<float>> ReIDFeatures;
	ReIDFeatures.clear();

	// PreProcess
	preProcess(VideoFrame, InpBuff.data());

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

	// Inference
	context->setTensorAddress(engine->getIOTensorName(0), Bindings[0]);
	context->setTensorAddress(engine->getIOTensorName(1), Bindings[1]);
	cudaMemcpyAsync(Bindings[0], InpBuff.data(), BindingSizes[0], cudaMemcpyHostToDevice, Stream);
	cerr << "start inference!!" << endl;
	bool ok = context->enqueueV3(Stream);
	if (!ok)
	{
		cerr << "inference enqueueV3 Fail!!" << endl;
	}
	else
	{
		cerr << "IR~Inference Working" << endl;
	}
	context->enqueueV3(Stream);
	cudaMemcpyAsync(OutBuff.data(), Bindings[1], BindingSizes[1], cudaMemcpyDeviceToHost, Stream);
	cudaStreamSynchronize(Stream);

#pragma GCC diagnostic pop

	// PostProcess
	postProcess(OutBuff, VideoFrame.cols, VideoFrame.rows);

	// Tracking
	if (TrackingFlag == true)
	{
		ReIDFeatures.resize(TargetDataArr.size());

		if (!TargetDataArr.empty())
		{
			ReIDInferance(VideoFrame, ReIDFeatures);
		}

		ReIDpostProcess(ReIDFeatures, TargetDataArr);
	}

	drawBoxes(VideoFrame);

	return;
}
