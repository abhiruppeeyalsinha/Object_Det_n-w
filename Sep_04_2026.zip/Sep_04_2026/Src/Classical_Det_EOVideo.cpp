// ============================================================================
// Name        : Classical_Det_EOVideo.cpp
// Created On  : 04 Sep 2026
// ============================================================================

// ---------- Header Inclusion ----------
#include "Classical_Det_EOVideo.h"

// ---------- Constructor ----------
Classical_Det_EOVideo ::Classical_Det_EOVideo(void)
	: Detector("EO Video", "Classical", 1, 1, 0.45)
{
	cout << "EO Classical DoG Detector Loaded Successfully" << endl
		 << endl;
}

// ---------- Destructor ----------
Classical_Det_EOVideo ::~Classical_Det_EOVideo(void)
{
}

// ---------- Detect Object Function ----------
void Classical_Det_EOVideo ::Run(Mat &VideoFrame)
{
	Detector.Run(VideoFrame);
}
