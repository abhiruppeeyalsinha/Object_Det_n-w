// ============================================================================
// Name        : Classical_Det_IRVideo.cpp
// Created On  : 04 Sep 2026
// ============================================================================

// ---------- Header Inclusion ----------
#include "Classical_Det_IRVideo.h"

// ---------- Constructor ----------
Classical_Det_IRVideo ::Classical_Det_IRVideo(void)
	: Detector("IR Video", "Classical", 1, 1, 0.45)
{
	cout << "IR Classical DoG Detector Loaded Successfully" << endl
		 << endl;
}

// ---------- Destructor ----------
Classical_Det_IRVideo ::~Classical_Det_IRVideo(void)
{
}

// ---------- Detect Object Function ----------
void Classical_Det_IRVideo ::Run(Mat &VideoFrame)
{
	Detector.Run(VideoFrame);
}
