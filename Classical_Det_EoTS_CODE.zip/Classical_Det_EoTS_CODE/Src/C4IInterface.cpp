// ============================================================================
// Name        : C4IInterface.cpp
// Created On  : 11 Nov 2025
// ============================================================================


// ---------- Header Inclusion ----------
#include "C4IInterface.h"


// Constructor
C4IInterface :: C4IInterface(void)
{
	Len = sizeof(CAddr);

	timeout.tv_sec = 1;
	timeout.tv_usec = 0;

	RecvSock = socket(AF_INET, SOCK_DGRAM, 0);
	SendSock = socket(AF_INET, SOCK_DGRAM, 0);

	memset(&SAddr, 0, sizeof(SAddr));
	memset(&CAddr, 0, sizeof(CAddr));
	memset(&RAddr, 0, sizeof(RAddr));

	SAddr.sin_family = AF_INET;
	SAddr.sin_addr.s_addr = INADDR_ANY;
	SAddr.sin_port = htons(AI_Port);

	CAddr.sin_family = AF_INET;
	CAddr.sin_addr.s_addr = inet_addr(C4I_IPAddr.c_str());
	CAddr.sin_port = htons(C4I_Port);

	// Release UDP Port if already bound
	releaseUDPPort(AI_Port);

	if(bind(RecvSock, (struct sockaddr *)&SAddr, sizeof(SAddr)) < 0)
	{
		perror((string("Bind : ") + to_string(AI_Port) + string(" : ")).c_str());
		raise(SIGINT);
	}

	if(setsockopt(RecvSock, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(struct timeval)) == -1)
	{
		cerr << "Error setting receive timeout." << endl;
		raise(SIGINT);
	}

	Flags = fcntl(SendSock, F_GETFL, 0);
	fcntl(SendSock, F_SETFL, Flags | O_NONBLOCK);

	return;
}


// Destructor
C4IInterface :: ~C4IInterface(void)
{
	close(SendSock);
	close(RecvSock);

	return;
}


// Receive Cmd Function
void C4IInterface :: recvCmdC4I(void)
{
	Int32_t RetVal = 0, ByteCnt = 0;

	while(C4ICmdRecvFlag == true)
	{
		memset(AICmd.Buffer, 0, sizeof(AICmd.Buffer));

		try
		{
			RetVal = recvfrom(RecvSock, AICmd.Buffer, sizeof(AICmd.AICmdStruct), 0, (struct sockaddr *)&RAddr, &Len);
			if(RetVal <= 0)
			{
				if(errno == EWOULDBLOCK || errno == EAGAIN)
				{
					// cout << "UDP Receive Timeout" << endl << flush;
				}
				else
				{
					cout << "Error in receiving C4I command..." << endl << flush;
				}

				continue;
			}
		}
		catch(exception &e)
		{
			cerr << "Error : Receive failed C4I command : " << e.what() << endl;
			continue;
		}


		AIResp.AIRespStruct.Header[0] = AI_ID;
		AIResp.AIRespStruct.Header[1] = C4I_ID;
		AIResp.AIRespStruct.Header[2] = AICmd.Buffer[2];
		AIResp.AIRespStruct.DataLen = 0x01;
		AIResp.AIRespStruct.CheckSum = 0x00;


		// Check Headers
		if(AICmd.Buffer[0] != C4I_ID || AICmd.Buffer[1] != AI_ID)
		{
			AIResp.AIRespStruct.AckByte = 0xB2;
			goto SEND;
		}

		// Check CheckSum


		cout << "Recv Data from C4I : L - " << RetVal << " : ";
		for(ByteCnt = 0; ByteCnt < RetVal; ByteCnt++)
		{
			printf("%02X ", TgtData.Buffer[ByteCnt]);
		}
		cout << endl;


		// Change AI Type According C4I
		if(AICmd.Buffer[2] == AISwitchCmd)
		{
			if(AICmd.AICmdStruct.AIType == 1)
			{
				AI_Type = 1;
				cout << "IR AI cmd recv from C4I..." << endl;
			}
			else if(AICmd.AICmdStruct.AIType == 2)
			{
				AI_Type = 2;
				cout << "IR AI cmd recv from C4I..." << endl;
			}
			else
			{
				AI_Type = 0;
				cout << "AI off cmd recv from C4I..." << endl;
			}

			CentreTarget = AICmd.AICmdStruct.TgtDataType;
			AIResp.AIRespStruct.AckByte = 0xE5;
		}

		else if(AICmd.Buffer[2] == SaveVideoCmd)
		{
			SaveVideo = !!AICmd.SaveCmdStruct.Stat;
			AIResp.AIRespStruct.AckByte = 0xE5;
		}

		else
		{
			AIResp.AIRespStruct.AckByte = 0xB2;
		}

	SEND:
		try
		{
			RetVal = AIResp.AIRespStruct.DataLen + 0x05;
			RetVal = sendto(RecvSock, AIResp.Buffer, RetVal, 0, (struct sockaddr *)&CAddr, sizeof(CAddr));
			cout << "Sent Response to C4I : L:" << RetVal << " : ";
			for(ByteCnt = 0; ByteCnt < RetVal; ByteCnt++)
			{
				printf("%02X ", AIResp.Buffer[ByteCnt]);
			}
			cout << endl;
		}
		catch(exception &e)
		{
			cerr << "Error : " << e.what() << endl;
		}
	}

	return;
}


// Send Data Function
void C4IInterface :: sendDataC4I(void)
{
	UInt32_t FrameLength;
	UInt8_t Packet[64*1024];
	vector<UInt8_t> FrameBuff;

	Int32_t RetVal = 0;
	UInt64_t FrameCnt = 0;
	UInt8_t PacketCnt = 0, PacketNo = 0;
	UInt16_t BuffSize = 63*1024, PacketSize = 0;


	string Time;
	Size VideoDim;
	stringstream ss;
	UInt16_t SaveFrameCnt = 0;
	VideoWriter IR_OutVid, EO_OutVid;

	steady_clock :: time_point SaveTime;
	auto now = system_clock::now();
	auto in_time_t = system_clock::to_time_t(now);


	while(C4IDataSendFlag == true)
	{
		if(C4IVideoData.FrameFlag == false)
		{
			if(duration_cast<seconds>(steady_clock::now() - SaveTime).count() > 5*60)
			{
				if(IR_OutVid.isOpened())
				{
					IR_OutVid.release();
				}

				if(EO_OutVid.isOpened())
				{
					EO_OutVid.release();
				}

				SaveTime = steady_clock::now();
			}

			usleep(2000);
			continue;
		}

		C4IVideoData.FrameFlag = false;

		// Send Target Data to C4I
		try
		{
			RetVal = TgtData.TgtDataStruct.DataLen + 0x06;
			RetVal = sendto(SendSock, TgtData.Buffer, RetVal, 0, (struct sockaddr *)&CAddr, Len);
			// cout << "Sent Target Data to C4I : L:" << RetVal << endl;
		}
		catch(exception &e)
		{
			cerr << "Error : " << e.what() << endl;
		}

		// Save Video
		if(SaveVideo == true || AutoSaveVideo == true)
		{
			SaveTime = steady_clock::now();

			if(C4IVideoData.VideoType == 1)
			{
				if(SaveFrameCnt >= 7500 && IR_OutVid.isOpened())
				{
					IR_OutVid.release();
					SaveFrameCnt = 0;
				}

				if(!IR_OutVid.isOpened())
				{
					VideoDim.width = C4IVideoData.VideoFrame.cols;
					VideoDim.height = C4IVideoData.VideoFrame.rows;

					now = system_clock::now();
					in_time_t = system_clock::to_time_t(now);

					ss.str("");
					ss.clear();
					ss << put_time(localtime(&in_time_t), "%d-%m-%y_%H:%M:%S");
					Time = ss.str();

					IR_OutVid.open(SavePath + "IR_" + Time + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, true);

					if(EO_OutVid.isOpened())
					{
						EO_OutVid.release();
						SaveFrameCnt = 0;
					}
				}

				IR_OutVid.write(C4IVideoData.VideoFrame);
				SaveFrameCnt++;
			}
			else if(C4IVideoData.VideoType == 2)
			{
				if(SaveFrameCnt >= 7500 && EO_OutVid.isOpened())
				{
					EO_OutVid.release();
					SaveFrameCnt = 0;
				}

				if(!EO_OutVid.isOpened())
				{
					VideoDim.width = C4IVideoData.VideoFrame.cols;
					VideoDim.height = C4IVideoData.VideoFrame.rows;

					now = system_clock::now();
					in_time_t = system_clock::to_time_t(now);

					ss.str("");
					ss.clear();
					ss << put_time(localtime(&in_time_t), "%d-%m-%y_%H:%M:%S");
					Time = ss.str();

					EO_OutVid.open(SavePath + "EO_" + Time + ".avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), VideoFPS, VideoDim, true);

					if(IR_OutVid.isOpened())
					{
						IR_OutVid.release();
						SaveFrameCnt = 0;
					}
				}

				EO_OutVid.write(C4IVideoData.VideoFrame);
				SaveFrameCnt++;
			}
			else
			{

			}
		}

		// Display & Video Stream Configuration
		resize(C4IVideoData.VideoFrame, C4IVideoData.VideoFrame, Size(640, 512));
		if(C4IVideoData.VideoType == 1)
		{
			cvtColor(C4IVideoData.VideoFrame, C4IVideoData.VideoFrame, COLOR_BGR2GRAY);
		}

		// Display Video Frames
		if(DisplayFrame == true)
		{
			imshow("EOTS AI Video", C4IVideoData.VideoFrame);

			if(waitKey(1) == 'q')
			{
				// Clear all flags
				SaveVideo = false;
				DisplayFrame = false;
				AutoSaveVideo = false;

				C4ICmdRecvFlag = false;
				C4IDataSendFlag = false;
				IRVideoReadFlag = false;
				EOVideoReadFlag = false;
				ProcessVideoFlag = false;
				break;
			}
		}

		// Video Stream
		FrameBuff.clear();
		imencode(".jpeg", C4IVideoData.VideoFrame, FrameBuff, {IMWRITE_JPEG_QUALITY, 60});
		FrameLength = FrameBuff.size();

		PacketCnt = 1 + (UInt8_t)(BuffSize < FrameLength);
		if(FrameLength > (UInt32_t)(BuffSize * 2))
		{
			cout << "Video Packet Size is to big..." << endl;
			continue;
		}

		for(PacketNo = 0; PacketNo < PacketCnt; PacketNo++)
		{
			PacketSize = FindMin(BuffSize, (FrameLength - (PacketNo * BuffSize))) + 7;

			Packet[0] = (UInt8_t)AI_ID;
			Packet[1] = (UInt8_t)C4I_ID;
			Packet[2] = (UInt8_t)VideoDataCmd;

			Packet[3] = (UInt8_t)((PacketSize >> 0)&0xFF);
			Packet[4] = (UInt8_t)((PacketSize >> 8)&0xFF);

			Packet[5] = (UInt8_t)C4IVideoData.VideoType;
			memcpy((void *)(Packet+6), (void *)&FrameCnt, 4);
			Packet[10] = (UInt8_t)PacketCnt;
			Packet[11] = (UInt8_t)PacketNo;

			memcpy(Packet+12, FrameBuff.data()+(PacketNo * BuffSize), PacketSize-7);
			Packet[PacketSize+5] = (UInt8_t)0x00;

			try
			{
				usleep(1000*5);
				RetVal = sendto(SendSock, Packet, PacketSize+13, 0, (struct sockaddr *)&CAddr, Len);
				// cout << "Sent Video Data to C4I : L:" << RetVal << " F:" << FrameCnt << " PC:" << (UInt32_t)PacketCnt << " PN:" << (UInt32_t)(PacketNo+1) << endl;
			}
			catch(exception &e)
			{
				cerr << "Error : " << e.what() << endl;
				continue;
			}
		}

		cout << endl;
		FrameCnt++;
	}


	if(IR_OutVid.isOpened())
	{
		IR_OutVid.release();
	}

	if(EO_OutVid.isOpened())
	{
		EO_OutVid.release();
	}

	return;
}


// Receive Cmd Function
void * C4IInterface :: recvCmdC4IThread(void *args)
{
	C4IInterface *Instance = static_cast<C4IInterface *>(args);
	Instance->recvCmdC4I();
	pthread_exit(NULL);
}


// Send Data Function
void * C4IInterface :: sendDataC4IThread(void *args)
{
	C4IInterface *Instance = static_cast<C4IInterface *>(args);
	Instance->sendDataC4I();
	pthread_exit(NULL);
}




