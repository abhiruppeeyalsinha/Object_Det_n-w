// ============================================================================
// Name        : EOVideoAI.cpp
// Created On  : 11 Nov 2025
// ============================================================================

// ---------- Header Inclusion ----------
#include "EOVideoAI.h"
#include "Classical_Det_EOVideo.h"

// Logger for TensorRT messages
class Logger : public ILogger
{
	void log(Severity severity, const char *msg) noexcept override
	{
		if (severity <= Severity::kWARNING)
		{
			cout << "[TensorRT] " << msg << endl;
		}
	}
};

static Logger logger;

// ---------- Get Memory Size ----------
size_t EOVideoAI ::getMemorySize(Dims dims, size_t ElementSize)
{
	size_t size = ElementSize;

	for (Int32_t i = 0; i < dims.nbDims; i++)
	{
		size *= dims.d[i];
	}

	return size;
}

// ---------- Load Detection Engine File ----------
bool EOVideoAI ::LoadDetectModel(void)
{
	try
	{
		ifstream EngineFile(EO_Detect_Model, ios::binary);
		if (!EngineFile)
		{
			cerr << "Failed to read engine file." << endl;
			return false;
		}

		EngineFile.seekg(0, ios::end);

		auto fsize = EngineFile.tellg();
		EngineFile.seekg(0, ios::beg);

		vector<char> engine_data(fsize);
		EngineFile.read(engine_data.data(), fsize);
		EngineFile.close();

		runtime.reset(createInferRuntime(logger));
		engine.reset(runtime->deserializeCudaEngine(engine_data.data(), fsize));
		context.reset(engine->createExecutionContext());

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

		Int32_t nbBindings = engine->getNbIOTensors();
		Bindings.resize(nbBindings, nullptr);
		BindingSizes.resize(nbBindings, 0);

		for (Int32_t i = 0; i < nbBindings; i++)
		{
			const char *TensorName = engine->getIOTensorName(i);
			Dims dims = engine->getTensorShape(TensorName);
			BindingSizes[i] = getMemorySize(dims, sizeof(__half));
			cudaMalloc(&Bindings[i], BindingSizes[i]);
			context->setTensorAddress(TensorName, Bindings[i]);
		}

#pragma GCC diagnostic pop

		cudaStreamCreate(&Stream);

		InpBuff.resize(BindingSizes[0] / sizeof(__half));
		OutBuff.resize(BindingSizes[1] / sizeof(__half));

		return true;
	}
	catch (Exception &e)
	{
		return false;
	}

	return false;
}

// ---------- PreProcess ----------
void EOVideoAI ::preProcess(Mat VideoFrame, __half *)
{
	vector<Mat> FrameChannels(3);
	float *ChannelData;
	UInt32_t Channels;

	float Scale = 0;
	UInt16_t NewWidth, NewHeight;

	Scale = (float)min(((float)Yolov5_DIM.width / (float)VideoFrame.cols), ((float)Yolov5_DIM.height / (float)VideoFrame.rows));

	NewWidth = round(VideoFrame.cols * Scale);
	NewHeight = round(VideoFrame.rows * Scale);
	resize(VideoFrame, VideoFrame, Size(NewWidth, NewHeight));

	// Calculate Padding
	PadX = (Yolov5_DIM.width - NewWidth) / 2;
	PadY = (Yolov5_DIM.height - NewHeight) / 2;

	// Resize VideoFrame to Yolov5 required size using padding
	copyMakeBorder(VideoFrame, VideoFrame, PadY, (Yolov5_DIM.height - NewHeight - PadY), PadX, (Yolov5_DIM.width - NewWidth - PadX), BORDER_CONSTANT, Scalar(0, 0, 0));

	VideoFrame.convertTo(VideoFrame, CV_32F, 1.0 / 255);
	split(VideoFrame, FrameChannels);

	for (Channels = 0; Channels < 3; Channels++)
	{
		ChannelData = reinterpret_cast<float *>(FrameChannels[Channels].data);
		for (Int32_t i = 0; i < Yolov5_DIM.width * Yolov5_DIM.height; i++)
		{
			InpBuff[Channels * Yolov5_DIM.width * Yolov5_DIM.height + i] = __float2half(ChannelData[i]);
		}
	}

	return;
}

// ---------- PostProcess ----------
void EOVideoAI ::postProcess(vector<__half> &Output, UInt16_t VideoWidth, UInt16_t VideoHeight)
{
	vector<Rect> Boxes;
	vector<Int32_t> Indices;
	vector<UInt8_t> ClassIds;
	vector<float> Confidances;
	const UInt32_t Detections = 25200;

	float Confidence;
	float ClassScore[4];
	float ObjConf, ClassConf;
	UInt8_t ClassID = 0;

	float Scale;
	float InvScale;

	Int16_t CentreX, CentreY, Width, Height;
	Int16_t X1, Y1, X2, Y2;

	struct _AIData_ DetectData;

	Boxes.clear();
	Indices.clear();
	ClassIds.clear();
	TargetDataArr.clear();
	Confidances.clear();

	Scale = (float)min((float)Yolov5_DIM.width / (float)VideoWidth, (float)Yolov5_DIM.height / (float)VideoHeight);
	InvScale = 1.0f / Scale; // resize factor

	for (UInt32_t i = 0; i < Detections; i++)
	{
		ObjConf = __half2float(Output[(i * 8) + 4]);

		// Skip if Object Confidence is less than Threshold
		if (ObjConf < ConfThreshold)
		{
			continue;
		}

		for (UInt32_t j = 0; j < 3; j++)
		{
			ClassScore[j] = __half2float(Output[(i * 8) + 5 + j]);
		}

		ClassID = max_element(ClassScore, ClassScore + 3) - ClassScore;
		ClassConf = ClassScore[ClassID];
		Confidence = ObjConf * ClassConf;

		// Skip if Confidence is less than Threshold
		if (Confidence <= ConfThreshold)
		{
			continue;
		}

		// Calculate Bounding Box Co-Ordinate & Size
		CentreX = __half2float(Output[i * 8 + 0]) - PadX;
		CentreY = __half2float(Output[i * 8 + 1]) - PadY;
		Width = __half2float(Output[i * 8 + 2]);
		Height = __half2float(Output[i * 8 + 3]);

		CentreX *= InvScale;
		CentreY *= InvScale;
		Width *= InvScale;
		Height *= InvScale;

		X1 = max(0, (CentreX - (Width / 2)));
		Y1 = max(0, (CentreY - (Height / 2)));

		X2 = min(VideoWidth - 1, (CentreX + (Width / 2)));
		Y2 = min(VideoHeight - 1, (CentreY + (Height / 2)));

		if (X2 >= X1 && Y2 >= Y1)
		{
			Boxes.emplace_back(Rect(X1, Y1, X2 - X1, Y2 - Y1));
			Confidances.emplace_back(Confidence);
			ClassIds.emplace_back(ClassID);
		}
	}

	dnn::NMSBoxes(Boxes, Confidances, ConfThreshold, IOUThreshold, Indices);

	for (UInt32_t idx : Indices)
	{
		DetectData.ClassID = ClassIds[idx];
		DetectData.Type = 0;
		DetectData.TrackID = 0;
		DetectData.Confidance = Confidances[idx];
		DetectData.BoundingBox = Boxes[idx];
		DetectData.CenterPoint = Point(Boxes[idx].x + Boxes[idx].width / 2, Boxes[idx].y + Boxes[idx].height / 2);

		TargetDataArr.push_back(DetectData);
	}

	return;
}

// ---------- Template Matching ----------
void EOVideoAI ::templateMatch(Mat &VideoFrame)
{
	Rect FrameRect(0, 0, VideoFrame.cols, VideoFrame.rows);

	if (!TargetDataArr.empty())
	{
		vector<char> TemplateUsed(TemplateArr.size(), false);

		for (auto &Target : TargetDataArr)
		{
			Rect BBox = Target.BoundingBox & FrameRect;
			if (BBox.width <= 2 || BBox.height <= 2)
			{
				continue;
			}

			Int32_t BestIdx = -1;
			double BestDist = numeric_limits<double>::max();
			for (UInt32_t i = 0; i < TemplateArr.size(); i++)
			{
				if (TemplateUsed[i] || TemplateArr[i].ClassID != Target.ClassID)
				{
					continue;
				}

				double Dist = norm(Target.CenterPoint - TemplateArr[i].CenterPoint);
				double Gate = (double)max(max(BBox.width, BBox.height),
										  max(TemplateArr[i].BoundingBox.width, TemplateArr[i].BoundingBox.height)) *
								  4.0 +
							  40.0;
				if (Dist < Gate && Dist < BestDist)
				{
					BestDist = Dist;
					BestIdx = i;
				}
			}

			if (BestIdx >= 0)
			{
				Target.TrackID = TemplateArr[BestIdx].TrackID;
				TemplateUsed[BestIdx] = true;
			}
			else
			{
				Target.TrackID = TM_NextTrackID++;
			}

			Target.Type = 0;

			struct _Template_ Tmplt;
			Tmplt.ClassID = Target.ClassID;
			Tmplt.TrackID = Target.TrackID;
			Tmplt.FrameCnt = 0;
			Tmplt.CenterPoint = Target.CenterPoint;
			Tmplt.BoundingBox = BBox;
			Tmplt.ROIBox = BBox;
			Tmplt.OverLapBox = BBox;
			Tmplt.Template = VideoFrame(BBox).clone();

			if (!Tmplt.Template.empty())
			{
				TemplateArr.push_back(Tmplt);
			}
		}

		if (TemplateArr.size() > TargetDataArr.size())
		{
			TemplateArr.erase(TemplateArr.begin(), TemplateArr.end() - TargetDataArr.size());
		}
		return;
	}

	vector<struct _Template_> UpdatedTemplates;
	vector<struct _AIData_> MatchedTargets;

	for (auto Tmplt : TemplateArr)
	{
		if (Tmplt.Template.empty() || Tmplt.FrameCnt > MaxTemplateMissedFrames)
		{
			continue;
		}

		Int32_t SearchW = max((Int32_t)(Tmplt.BoundingBox.width * TemplateSearchScale), Tmplt.BoundingBox.width + 40);
		Int32_t SearchH = max((Int32_t)(Tmplt.BoundingBox.height * TemplateSearchScale), Tmplt.BoundingBox.height + 40);
		Rect SearchBox(Tmplt.CenterPoint.x - SearchW / 2, Tmplt.CenterPoint.y - SearchH / 2, SearchW, SearchH);
		SearchBox &= FrameRect;

		if (SearchBox.width < Tmplt.Template.cols || SearchBox.height < Tmplt.Template.rows)
		{
			Tmplt.FrameCnt++;
			UpdatedTemplates.push_back(Tmplt);
			continue;
		}

		Mat Result;
		matchTemplate(VideoFrame(SearchBox), Tmplt.Template, Result, TM_CCOEFF_NORMED);

		double MinVal, MaxVal;
		Point MinLoc, MaxLoc;
		minMaxLoc(Result, &MinVal, &MaxVal, &MinLoc, &MaxLoc);

		if (MaxVal >= TempConfThreshold)
		{
			Rect BBox(SearchBox.x + MaxLoc.x, SearchBox.y + MaxLoc.y, Tmplt.Template.cols, Tmplt.Template.rows);
			BBox &= FrameRect;
			if (BBox.width <= 2 || BBox.height <= 2)
			{
				continue;
			}

			struct _AIData_ Target;
			Target.Type = 1;
			Target.ClassID = Tmplt.ClassID;
			Target.TrackID = Tmplt.TrackID;
			Target.Confidance = (float)MaxVal;
			Target.BoundingBox = BBox;
			Target.CenterPoint = Point(BBox.x + BBox.width / 2, BBox.y + BBox.height / 2);
			MatchedTargets.push_back(Target);

			Tmplt.FrameCnt = 0;
			Tmplt.CenterPoint = Target.CenterPoint;
			Tmplt.BoundingBox = BBox;
			Tmplt.ROIBox = SearchBox;
			Tmplt.OverLapBox = BBox;
			Tmplt.Template = VideoFrame(BBox).clone();
			UpdatedTemplates.push_back(Tmplt);
		}
		else
		{
			Tmplt.FrameCnt++;
			if (Tmplt.FrameCnt <= MaxTemplateMissedFrames)
			{
				UpdatedTemplates.push_back(Tmplt);
			}
		}
	}

	TemplateArr = UpdatedTemplates;
	TargetDataArr = MatchedTargets;

	return;
}

// ---------- Get CoOrdinates ----------
void EOVideoAI ::drawBoxes(Mat &VideoFrame)
{
	UInt16_t TgtCnt = 0;
	string Label = "";
	double Dist, MinDist = numeric_limits<double>::max();
	Point FrameCentre(VideoFrame.cols / 2, VideoFrame.rows / 2);

	// Draw quadrants
	// line(VideoFrame, Point(FrameCentre.x, 0), Point(FrameCentre.x, VideoFrame.rows), Scalar(255, 255, 255), 2);
	// line(VideoFrame, Point(0, FrameCentre.y), Point(VideoFrame.cols, FrameCentre.y), Scalar(255, 255, 255), 2);

	for (auto &Target : TargetDataArr)
	{
		if (3 < Target.ClassID)
		{
			continue;
		}

		rectangle(VideoFrame, Target.BoundingBox, Scalar(255, 255, 255), 2);

		Label = string(Target.Type == 1 ? "TM " : "") + EO_ClassName[Target.ClassID] + (Target.TrackID != 0 ? " (" + to_string(Target.TrackID) + ")" : "") + " " + to_string((UInt32_t)(Target.Confidance * 100)) + "% (" + to_string(Target.CenterPoint.x - VideoFrame.cols / 2) + ", " + to_string(Target.CenterPoint.y - VideoFrame.rows / 2) + ")";

		putText(VideoFrame, Label, Target.BoundingBox.tl(), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 255, 255), 2);

		cout << "EO Video " << (Target.Type == 1 ? "TM" : (ClassicalDetectionFlag ? "Classical" : "AI")) << " : " << EO_ClassName[Target.ClassID] << " ID:" << (UInt32_t)Target.ClassID << (Target.TrackID != 0 ? " TID:" + to_string(Target.TrackID) : "") << " Conf:" << (UInt32_t)(Target.Confidance * 100) << "% Ny:" << (Target.CenterPoint.x - VideoFrame.cols / 2) << " Nz:" << (Target.CenterPoint.y - VideoFrame.rows / 2) << " W:" << Target.BoundingBox.width << " H:" << Target.BoundingBox.height << endl
			 << flush;

		if (Target.ClassID == 1)
		{
			line(VideoFrame, FrameCentre, Target.CenterPoint, Scalar(255, 255, 255), 2);
		}
		else
		{
			if (BirdPlaneDataFlag == false)
			{
				continue;
			}
		}

		TargetData.ClassID = Target.ClassID;
		TargetData.TrackID = Target.TrackID;
		TargetData.Ny = Target.CenterPoint.x - VideoFrame.cols / 2;
		TargetData.Nz = Target.CenterPoint.y - VideoFrame.rows / 2;
		TargetData.Width = Target.BoundingBox.width;
		TargetData.Height = Target.BoundingBox.height;
		TargetData.Confidance = Target.Confidance * 100;

		if (CentreTarget == true)
		{
			Dist = norm(Target.CenterPoint - FrameCentre);
			if (Dist < MinDist)
			{
				MinDist = Dist;

				TgtData.TgtDataStruct.TgtData[0] = TargetData;
				TgtCnt = 1;
			}
		}
		else
		{
			if (TgtCnt < 5000)
			{
				TgtData.TgtDataStruct.TgtData[TgtCnt] = TargetData;
				TgtCnt++;
			}
		}
	}

	// Set Header
	TgtData.TgtDataStruct.Header[0] = AI_ID;
	TgtData.TgtDataStruct.Header[1] = C4I_ID;
	TgtData.TgtDataStruct.Header[2] = TgtDataCmd;

	TgtData.TgtDataStruct.VideoType = AI_Type;
	TgtData.TgtDataStruct.CheckSum = 0x00;
	TgtData.TgtDataStruct.SaveStatus = SaveVideo | AutoSaveVideo;
	TgtData.TgtDataStruct.TgtDataType = CentreTarget;

	TgtData.TgtDataStruct.TargetCnt = TgtCnt;
	TgtData.TgtDataStruct.DataLen = 0x05 + (TgtCnt * sizeof(struct _TargetData_));
	TgtData.Buffer[TgtData.TgtDataStruct.DataLen + 0x05] = 0x00;

	return;
}

// ---------- Constructor ----------
EOVideoAI ::EOVideoAI(void)
{
	Yolov5_DIM.height = 640;
	Yolov5_DIM.width = 640;

	PadY = 0;
	PadX = 0;
	Stream = nullptr;

	ConfThreshold = 0.6;
	IOUThreshold = 0.6;

	TM_NextTrackID = 1;
	MaxTemplateMissedFrames = 25;
	TempConfThreshold = 0.50f;
	TemplateSearchScale = 3.0f;

	if (ClassicalDetectionFlag == true)
	{
		cout << "EO Classical Detector Selected: " << (UInt32_t)ClassicalDetectorType << endl
			 << endl;
	}
	else if (LoadDetectModel() == true)
	{
		cout << "EO Engine Loaded Successfully" << endl
			 << endl;
	}
	else
	{
	}

	return;
}

// ---------- Destructor ----------
EOVideoAI ::~EOVideoAI(void)
{
	try
	{
		for (void *ptr : Bindings)
		{
			if (ptr)
			{
				cudaFree(ptr);
			}
		}

		if (Stream)
		{
			cudaStreamDestroy(Stream);
		}
	}
	catch (Exception &e)
	{
	}

	return;
}

// ---------- Detect Object Function ----------
void EOVideoAI ::Run_enqueueV2(Mat &VideoFrame)
{
	if (ClassicalDetectionFlag == true)
	{
		runClassicalEODetection(VideoFrame, ClassicalDetectorType, TargetDataArr);
	}
	else
	{
		// PreProcess
		preProcess(VideoFrame, InpBuff.data());

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

		// Inference
		context->setTensorAddress(engine->getIOTensorName(0), Bindings[0]);
		context->setTensorAddress(engine->getIOTensorName(1), Bindings[1]);
		cudaMemcpyAsync(Bindings[0], InpBuff.data(), BindingSizes[0], cudaMemcpyHostToDevice, Stream);
		cerr << "start inference!!" << endl;
		bool ok = context->enqueueV3(Stream);
		if (!ok)
		{
			cerr << "inference enqueueV3 Fail!!" << endl;
		}
		else
		{
			cerr << "EO Inference Working" << endl;
		}
		cudaMemcpyAsync(OutBuff.data(), Bindings[1], BindingSizes[1], cudaMemcpyDeviceToHost, Stream);
		cudaStreamSynchronize(Stream);
#pragma GCC diagnostic pop

		// PostProcess
		postProcess(OutBuff, VideoFrame.cols, VideoFrame.rows);
	}

	// Tracking
	if (TrackingFlag == true)
	{
		templateMatch(VideoFrame);
	}

	drawBoxes(VideoFrame);

	return;
}

// =================== xxxx ======================================
